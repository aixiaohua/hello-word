/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c) 2005-2050  SourcePhotonics Corporation  All rights reserved
 *
 *   This is unpublished proprietary source code of SourcePhotonics Corporation.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   typedef.h
 * DESCRIPTION:
 *   Base type definition.
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 ******************************************************************************/

#ifndef __TYPEDEF_H__
#define __TYPEDEF_H__

#include "def_compiler.h"

/* these parameters are defined only for easy code reading */
#define IN                          /* nothing */
#define OUT                         /* nothing */

typedef uint8_t         BOOL;       /* Boolean: TRUE/FALSE */
typedef uint8_t         UINT8;      /* 8-bit */
typedef int8_t          SINT8;
typedef uint16_t        UINT16;     /* 16-bit */
typedef int16_t         SINT16;
typedef unsigned int    UINT32;     /* 32-bit */
typedef signed   int    SINT32;
typedef uint64_t        UINT64;     /* 64-bit */
typedef int64_t         SINT64;

#define TRUE            (BOOL)1
#define FALSE           (BOOL)0

#define HIGH            1
#define LOW             0

#define ENABLE          1
#define DISABLE         0

/* NULL pointer */
#define NULL            ((void *)0)


#include "base_macro.h"


#endif

