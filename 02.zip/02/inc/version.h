/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   version.h
 * DESCRIPTION:
 *   Product firmware version definition.
 * HISTORY:
 *   2013.11.27        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __VERSION_H
#define __VERSION_H


/******************************************************************************
 * signature related definition
 *****************************************************************************/
/* image signature related */
typedef struct
{
	UINT32	vFileClass; 		/* file class		 */
	UINT32	vFileSubclass;		/* file sub-class	 */
	UINT32	vFileAlignedSize;	/* file aligned size */
	UINT32	vFileChecksum;		/* file checksum	 */
	UINT8	aFileRev[8];		/* file revision	 */
	UINT32	vFileContentSize;	/* file content size */
	UINT32	vFileCookie;		/* file cookie		 */
} FILE_SIG_T;

/* file(firmware) signature definition, don't try to remove it !!! */
extern __signature __code FILE_SIG_T   vSigFileFW;

#define FW_VERSION_TABLE_ADDR_BASE  (IMAGE_BASE+FILE0_SIG_OFFSET+offsetof(SIGNATURE_T,file_version))
#define GET_FW_ID(_v)               DRV_Flash_Read(FW_VERSION_TABLE_ADDR_BASE+0, sizeof(_v), (_v))
#define GET_FW_VERSION(_v)          DRV_Flash_Read(FW_VERSION_TABLE_ADDR_BASE+4, sizeof(_v), (_v))


#endif /* __VERSION_H */

