/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   base_macro.h
 * DESCRIPTION:
 *   N/A
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#ifndef __BASE_MACRO_H__
#define __BASE_MACRO_H__

#include "def_system.h"
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>
#include <malloc.h>
#include <errno.h>
#include "_stdlib.h"
#include "_stdio.h"
#include "_string.h"


/* volatile/none-volatile address access */
#define VP64                *(volatile UINT64 *)(UINT32)
#define VP32                *(volatile UINT32 *)(UINT32)
#define VP16                *(volatile UINT16 *)(UINT32)
#define VP8                 *(volatile UINT8  *)(UINT32)
#define P64                 *(UINT64 *)(UINT32)
#define P32                 *(UINT32 *)(UINT32)
#define P16                 *(UINT16 *)(UINT32)
#define P8                  *(UINT8  *)(UINT32)


/* combined macro generation, maximum 3 level delay expanding */
#define _COMBINE2_DELAY0(a,b)           a##b
#define _COMBINE3_DELAY0(a,b,c)         a##b##c
#define _COMBINE4_DELAY0(a,b,c,d)       a##b##c##d
#define _COMBINE5_DELAY0(a,b,c,d,e)     a##b##c##d##e
#define _COMBINE2_DELAY1(a,b)           _COMBINE2_DELAY0(a,b)
#define _COMBINE2_DELAY2(a,b)           _COMBINE2_DELAY1(a,b)
#define _COMBINE2_DELAY3(a,b)           _COMBINE2_DELAY2(a,b)
#define _COMBINE3_DELAY1(a,b,c)         _COMBINE3_DELAY0(a,b,c)
#define _COMBINE3_DELAY2(a,b,c)         _COMBINE3_DELAY1(a,b,c)
#define _COMBINE3_DELAY3(a,b,c)         _COMBINE3_DELAY2(a,b,c)
#define _COMBINE4_DELAY1(a,b,c,d)       _COMBINE4_DELAY0(a,b,c,d)
#define _COMBINE4_DELAY2(a,b,c,d)       _COMBINE4_DELAY1(a,b,c,d)
#define _COMBINE4_DELAY3(a,b,c,d)       _COMBINE4_DELAY2(a,b,c,d)
#define _COMBINE5_DELAY1(a,b,c,d,e)     _COMBINE5_DELAY0(a,b,c,d,e)
#define _COMBINE5_DELAY2(a,b,c,d,e)     _COMBINE5_DELAY1(a,b,c,d,e)
#define _COMBINE5_DELAY3(a,b,c,d,e)     _COMBINE5_DELAY2(a,b,c,d,e)
#define COMBINE(a,b)                    _COMBINE2_DELAY3(a,b)
#define COMBINE2(a,b)                   _COMBINE2_DELAY3(a,b)
#define COMBINE3(a,b,c)                 _COMBINE3_DELAY3(a,b,c)
#define COMBINE4(a,b,c,d)               _COMBINE4_DELAY3(a,b,c,d)
#define COMBINE5(a,b,c,d,e)             _COMBINE5_DELAY3(a,b,c,d,e)

#define _TOSTR_DELAY0(v)                # v
#define _TOSTR_DELAY1(v)                _TOSTR_DELAY0(v)
#define _TOSTR_DELAY2(v)                _TOSTR_DELAY1(v)
#define _TOSTR_DELAY3(v)                _TOSTR_DELAY2(v)
#define TOSTR(v)                        _TOSTR_DELAY3(v)


/* remove warning */
#define NO_WARNING(x)       do { if (x) {} } while (0)

/* calculate the total element of an array */
#define COUNT_OF(n)         (SINT32)(sizeof(n) / sizeof((n)[0]))

/* calculate the Byte Offset of member in struct.
 *
 * e.g:
 *  typedef struct
 *  {
 *      int  a;
 *      int  b;
 *      char c;
 *  } TYPE_S;
 *
 * To get the Byte Offset of (c) in TYPE_S, just use offsetof(TYPE_S, c).
 *  acturally, the offset in this sample is 8.
 */
#undef offsetof
#ifdef __compiler_offsetof
 #define offsetof(TYPE, MEMBER)  __compiler_offsetof(TYPE, MEMBER)
#else
 #define offsetof(TYPE, MEMBER)  ((size_t) &((TYPE *)0)->MEMBER)
#endif

/* bit operation */
#define SET_BIT(n, b)       do { (n) |= (1UL << (UINT8)(b));  } while (0)
#define CLR_BIT(n, b)       do { (n) &= ~(1UL << (UINT8)(b)); } while (0)
#define READ_BIT(n, b)      ((BOOL)(((n) >> (UINT8)(b)) & 1UL))
#define REVERSE_BIT(n, b)   do { (n) ^= (1UL << (UINT8)(b)); } while (0)
#define WRITE_BIT(n, b, v)  do { (n) = ((n) & ~(1UL << (UINT8)(b))) | ((UINT32)(v) << (UINT8)(b)); } while (0)


/* Get mask.
 *
 * e.g:
 *   if get 10-bit mask started from bit0, it will return 0x3FF.
 *   if get 10-bit mask started from bit5, it will return 0x7FE0.
 *
 * Note:
 *   1. the range of (start) : 0 <= start <= 31
 *      the range of (n)     : 0 <= n <= 31
 *   2. by default, this will return 32-bit mask, if only need 8-bit or 16-bit mask,
 *      you should limit the result like this:
 *         8-bit :  (UINT8)(GET_MASK(0, 5))  --- Start from bit0, occupy 5 bits;
 *        16-bit : (UINT16)(GET_MASK(3, 7))  --- Start from bit3, occupy 7 bits;
 */
#define GET_MASK(start, n)  (((0x1UL << (UINT8)(n)) - 1) << (UINT8)(start))


/* get the absolute value */
#define ABS_8(x)    (((SINT8) (x) >= 0) ? (UINT8) (x) : (((SINT8) (x) == (SINT8) 0x80)       ? 0x7FU        : (UINT8) (0-(SINT8) (x))))
#define ABS_16(x)   (((SINT16)(x) >= 0) ? (UINT16)(x) : (((SINT16)(x) == (SINT16)0x8000)     ? 0x7FFFU      : (UINT16)(0-(SINT16)(x))))
#define ABS_32(x)   (((SINT32)(x) >= 0) ? (UINT32)(x) : (((SINT32)(x) == (SINT32)0x80000000L)? 0x7FFFFFFFUL : (UINT32)(0-(SINT32)(x))))


/* operate memory as big-endian */
#define SET_BE_16(_buf, _v)                                                 \
    do {                                                                    \
        ((UINT8 *)(_buf))[0] = (UINT8)(((UINT16)(_v) >> 8) & 0xFFUL);       \
        ((UINT8 *)(_buf))[1] = (UINT8)(((UINT16)(_v) >> 0) & 0xFFUL);       \
    } while (0)
#define GET_BE_16(_buf)     (UINT16)                                        \
                            ( ((UINT16)(((const UINT8 *)(_buf))[0]) << 8)   \
                            | ((UINT16)(((const UINT8 *)(_buf))[1]) << 0) )
#define SET_BE_32(_buf, _v)                                                 \
    do {                                                                    \
        ((UINT8 *)(_buf))[0] = (UINT8)(((UINT32)(_v) >> 24) & 0xFFUL);      \
        ((UINT8 *)(_buf))[1] = (UINT8)(((UINT32)(_v) >> 16) & 0xFFUL);      \
        ((UINT8 *)(_buf))[2] = (UINT8)(((UINT32)(_v) >>  8) & 0xFFUL);      \
        ((UINT8 *)(_buf))[3] = (UINT8)(((UINT32)(_v) >>  0) & 0xFFUL);      \
    } while (0)
#define GET_BE_32(_buf)     ( ((UINT32)(((const UINT8 *)(_buf))[0]) << 24)  \
                            | ((UINT32)(((const UINT8 *)(_buf))[1]) << 16)  \
                            | ((UINT32)(((const UINT8 *)(_buf))[2]) <<  8)  \
                            | ((UINT32)(((const UINT8 *)(_buf))[3]) <<  0) )
#define SET_BE_64(_buf, _v)                                                 \
    do {                                                                    \
        ((UINT8 *)(_buf))[0] = (UINT8)(((UINT64)(_v) >> 56) & 0xFFULL);     \
        ((UINT8 *)(_buf))[1] = (UINT8)(((UINT64)(_v) >> 48) & 0xFFULL);     \
        ((UINT8 *)(_buf))[2] = (UINT8)(((UINT64)(_v) >> 40) & 0xFFULL);     \
        ((UINT8 *)(_buf))[3] = (UINT8)(((UINT64)(_v) >> 32) & 0xFFULL);     \
        ((UINT8 *)(_buf))[4] = (UINT8)(((UINT64)(_v) >> 24) & 0xFFULL);     \
        ((UINT8 *)(_buf))[5] = (UINT8)(((UINT64)(_v) >> 16) & 0xFFULL);     \
        ((UINT8 *)(_buf))[6] = (UINT8)(((UINT64)(_v) >>  8) & 0xFFULL);     \
        ((UINT8 *)(_buf))[7] = (UINT8)(((UINT64)(_v) >>  0) & 0xFFULL);     \
    } while (0)
#define GET_BE_64(_buf)     ( ((UINT64)(((const UINT8 *)(_buf))[0]) << 56)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[1]) << 48)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[2]) << 40)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[3]) << 32)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[4]) << 24)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[5]) << 16)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[6]) <<  8)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[7]) <<  0) )



/* operate memory as little-endian */
#define SET_LE_16(_buf, _v)                                                 \
    do {                                                                    \
        ((UINT8 *)(_buf))[1] = (UINT8)(((UINT16)(_v) >> 8) & 0xFFUL);       \
        ((UINT8 *)(_buf))[0] = (UINT8)(((UINT16)(_v) >> 0) & 0xFFUL);       \
    } while (0)
#define GET_LE_16(_buf)     (UINT16)                                        \
                            ( ((UINT16)(((const UINT8 *)(_buf))[1]) << 8)   \
                            | ((UINT16)(((const UINT8 *)(_buf))[0]) << 0) )
#define SET_LE_32(_buf, _v)                                                 \
    do {                                                                    \
        ((UINT8 *)(_buf))[3] = (UINT8)(((UINT32)(_v) >> 24) & 0xFFUL);      \
        ((UINT8 *)(_buf))[2] = (UINT8)(((UINT32)(_v) >> 16) & 0xFFUL);      \
        ((UINT8 *)(_buf))[1] = (UINT8)(((UINT32)(_v) >>  8) & 0xFFUL);      \
        ((UINT8 *)(_buf))[0] = (UINT8)(((UINT32)(_v) >>  0) & 0xFFUL);      \
    } while (0)
#define GET_LE_32(_buf)     ( ((UINT32)(((const UINT8 *)(_buf))[3]) << 24)  \
                            | ((UINT32)(((const UINT8 *)(_buf))[2]) << 16)  \
                            | ((UINT32)(((const UINT8 *)(_buf))[1]) <<  8)  \
                            | ((UINT32)(((const UINT8 *)(_buf))[0]) <<  0) )
#define SET_LE_64(_buf, _v)                                                 \
    do {                                                                    \
        ((UINT8 *)(_buf))[7] = (UINT8)(((UINT64)(_v) >> 56) & 0xFFULL);     \
        ((UINT8 *)(_buf))[6] = (UINT8)(((UINT64)(_v) >> 48) & 0xFFULL);     \
        ((UINT8 *)(_buf))[5] = (UINT8)(((UINT64)(_v) >> 40) & 0xFFULL);     \
        ((UINT8 *)(_buf))[4] = (UINT8)(((UINT64)(_v) >> 32) & 0xFFULL);     \
        ((UINT8 *)(_buf))[3] = (UINT8)(((UINT64)(_v) >> 24) & 0xFFULL);     \
        ((UINT8 *)(_buf))[2] = (UINT8)(((UINT64)(_v) >> 16) & 0xFFULL);     \
        ((UINT8 *)(_buf))[1] = (UINT8)(((UINT64)(_v) >>  8) & 0xFFULL);     \
        ((UINT8 *)(_buf))[0] = (UINT8)(((UINT64)(_v) >>  0) & 0xFFULL);     \
    } while (0)
#define GET_LE_64(_buf)     ( ((UINT64)(((const UINT8 *)(_buf))[7]) << 56)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[6]) << 48)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[5]) << 40)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[4]) << 32)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[3]) << 24)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[2]) << 16)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[1]) <<  8)  \
                            | ((UINT64)(((const UINT8 *)(_buf))[0]) <<  0) )


/* Limit value API */
#define LIMIT_U16(x)    (((x) >=  65535L)? (UINT16)(0xFFFF) :               \
                         ((x) <=       0)? (UINT16)(0x0000) :               \
                                           (UINT16)(x))
#define LIMIT_S16(x)    (((x) >=  32767L)? (SINT16)(0x7FFF) :               \
                         ((x) <= -32768L)? (SINT16)(0x8000) :               \
                                           (SINT16)(x))
#define LIMIT_AddS16(_sum, _v1, _v2)                                        \
    do {                                                                    \
        SINT16  _tmpSum = (_v1) + (_v2);                                    \
                                                                            \
        /* check overflow/underflow:                                        \
         *  *) All the overflow result is lower than any operate value;     \
         *  *) All the underflow result is greater than any operate value;  \
         */                                                                 \
        if (((_v1) >= 0) && (_tmpSum < (_v2)))                              \
        {                                                                   \
            /* overflow */                                                  \
            _tmpSum = 0x7FFF;                                               \
        }                                                                   \
        else if (((_v1) < 0) && (_tmpSum >= (_v2)))                         \
        {                                                                   \
            /* underflow */                                                 \
            _tmpSum = 0x8000;                                               \
        }                                                                   \
        else                                                                \
        {                                                                   \
            /* no overflow/underflow, do nothing */                         \
        }                                                                   \
                                                                            \
        (_sum) = _tmpSum;                                                   \
    } while (0)
#define LIMIT_AddS32(_sum, _v1, _v2)                                        \
    do {                                                                    \
        SINT32  _tmpSum = (_v1) + (_v2);                                    \
                                                                            \
        /* check overflow/underflow:                                        \
         *  *) All the overflow result is lower than any operate value;     \
         *  *) All the underflow result is greater than any operate value;  \
         */                                                                 \
        if (((_v1) >= 0) && (_tmpSum < (_v2)))                              \
        {                                                                   \
            /* overflow */                                                  \
            _tmpSum = 0x7FFFFFFFL;                                          \
        }                                                                   \
        else if (((_v1) < 0) && (_tmpSum >= (_v2)))                         \
        {                                                                   \
            /* underflow */                                                 \
            _tmpSum = 0x80000000L;                                          \
        }                                                                   \
        else                                                                \
        {                                                                   \
            /* no overflow/underflow, do nothing */                         \
        }                                                                   \
                                                                            \
        (_sum) = _tmpSum;                                                   \
    } while (0)


/* get positive/negative toggle bitmap */
#define BITMAP_POS_TOGGLE(_old, _new)   (((_old) ^ (_new)) & (_new))
#define BITMAP_NEG_TOGGLE(_old, _new)   (((_old) ^ (_new)) & ~(_new))

#endif

