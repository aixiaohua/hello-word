/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 dbg_io.c
 *
 * DESCRIPTION:
 *	 dbg IO function
 *
 * HISTORY:
 *	 2018.7.20		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "dbg.h"

/******************************************************************************
 * FUNCTION NAME:
 *		dbg_io_UpdateStatus
 *
 * DESCRIPTION:
 *		IO status update
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
static void dbg_io_UpdateStatus(void)
{
	/* For manufacturing usage */
	if (!CFG_GET_BIT(Debug_RT_IO_Mode))
	{
		/* Status-mode */
		CFG_SET_BIT(Debug_RT_IO_POWEREN_OUT,	DRV_IO_Read(IO(IO_PowerEN_OUT)));
		CFG_SET_BIT(Debug_RT_IO_TXPWREN_OUT,	DRV_IO_Read(IO(IO_TXPWREN_OUT)));
		CFG_SET_BIT(Debug_RT_IO_RXPWREN_OUT,	DRV_IO_Read(IO(IO_RXPWREN_OUT)));
		CFG_SET_BIT(Debug_RT_IO_TECEN_OUT,		DRV_IO_Read(IO(IO_TECEN_OUT)));
		CFG_SET_BIT(Debug_RT_IO_TECSW1_OUT,		DRV_IO_Read(IO(IO_TECSW1_OUT)));
		CFG_SET_BIT(Debug_RT_IO_TECSW2_OUT,		DRV_IO_Read(IO(IO_TECSW2_OUT)));
		CFG_SET_BIT(Debug_RT_IO_TXDIS_OUT,		DRV_IO_Read(IO(IO_TXDIS_OUT)));
		CFG_SET_BIT(Debug_RT_IO_LPowerEN_OUT, 	DRV_IO_Read(IO(IO_LPowerEN_OUT)));
		CFG_SET_BIT(Debug_RT_IO_APDEN_OUT,		DRV_IO_Read(IO(IO_APDEN_OUT)));
	}
	else
	{
		/* Debug-mode */
		DRV_IO_Write(IO(IO_PowerEN_OUT),	CFG_GET_BIT(Debug_RT_IO_POWEREN_OUT));
		DRV_IO_Write(IO(IO_TXPWREN_OUT),	CFG_GET_BIT(Debug_RT_IO_TXPWREN_OUT));
		DRV_IO_Write(IO(IO_RXPWREN_OUT),	CFG_GET_BIT(Debug_RT_IO_RXPWREN_OUT));
		DRV_IO_Write(IO(IO_TECEN_OUT),		CFG_GET_BIT(Debug_RT_IO_TECEN_OUT));
		DRV_IO_Write(IO(IO_TXDIS_OUT),		CFG_GET_BIT(Debug_RT_IO_TXDIS_OUT));
		DRV_IO_Write(IO(IO_LPowerEN_OUT), 	CFG_GET_BIT(Debug_RT_IO_LPowerEN_OUT));
		DRV_IO_Write(IO(IO_APDEN_OUT),		CFG_GET_BIT(Debug_RT_IO_APDEN_OUT));
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_IO_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for IO DBG
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_IO_ReadyState(void)
{
	dbg_io_UpdateStatus();
}

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_IO_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for IO DBG
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_IO_LowPwrState(void)
{
	dbg_io_UpdateStatus();
}

