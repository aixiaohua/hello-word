/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 dbg.c
 *
 * DESCRIPTION:
 *	 dbg function
 *
 * HISTORY:
 *	 2018.7.20		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "dbg.h"

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for DBG
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_ReadyState(void)
{
#if STACK_CHECK_SUPPORT
	DBG_Stack_Entry();
#endif

	DBG_CMD_Entry();

	DBG_IO_ReadyState();
}

/******************************************************************************
 * FUNCTION NAME:
 *		DBG_LowPwrState
 *
 * DESCRIPTION:
 *		Low power state handler for DBG
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_LowPwrState(void)
{
#if STACK_CHECK_SUPPORT
	DBG_Stack_Entry();
#endif

	DBG_CMD_Entry();

	DBG_IO_LowPwrState();
}

