/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   dbg_cmd.h
 *
 * DESCRIPTION:
 *   Command interface.
 *
 * HISTORY:
 *   2018.6.27        Harry.Huang        Create/Update
 *
 *****************************************************************************/

#ifndef __DBG_CMD_H__
#define __DBG_CMD_H__

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_CMD_Entry
 *
 * DESCRIPTION:
 *      Run-time command application entry.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      TRUE/FALSE
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.6.27        Harry.Huang         Create/Update
 *****************************************************************************/
void DBG_CMD_Entry(void);

#endif

