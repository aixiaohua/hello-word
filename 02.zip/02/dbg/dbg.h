/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 dbg.h
 *
 * DESCRIPTION:
 *	 dbg function header.
 *
 * HISTORY:
 *	 2018.7.20		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#ifndef __DBG_H__
#define __DBG_H__

#include "dbg_cmd.h"
#include "dbg_log.h"
#include "dbg_stack.h"
#include "dbg_io.h"

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for DBG
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *		DBG_LowPwrState
 *
 * DESCRIPTION:
 *		Low power state handler for DBG
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_LowPwrState(void);

#endif


