/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   dbg_log.h
 *
 * DESCRIPTION:
 *   Debug supporting.
 *
 * HISTORY:
 *   2013.12.30        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DBG_LOG_H__
#define __DBG_LOG_H__


/* For releasing mode, NO warning/error logs will be print out */
#if RELEASE_MODE
	#undef DEBUG_LOG_LEVEL
	#define DEBUG_LOG_LEVEL		5
#endif

/* Debug log level 0 */
#if (DEBUG_LOG_LEVEL <= 0)
	#define DBG_LOG_DEBUG(...)		do {                                        \
	                                    printf("\n\rdebug|%s:%d| ",             \
	                                           __func__, __LINE__);             \
	                                    printf(__VA_ARGS__);                    \
	                                } while (0)
#else
	#define DBG_LOG_DEBUG(...)		/* do nothing */
#endif

/* Debug log level 1 */
#if (DEBUG_LOG_LEVEL <= 1)
	#define DBG_LOG_ASSERT(expr)	do {                                        \
	                                    if (!expr)                              \
	                                    {                                       \
	                                        printf("\n\rassert|%s:%d| ",        \
	                                               __func__, __LINE__);         \
	                                        printf(TOSTR(expr));                \
	                                    }                                       \
                                	} while (0)
#else
	#define DBG_LOG_ASSERT(expr)	/* do nothing */
#endif

/* Debug log level 2 */
#if (DEBUG_LOG_LEVEL <= 2)
	#define DBG_LOG_INFO(...)		do {                                        \
		                                printf("\n\rinfo|%s:%d| ",              \
		                                       __func__, __LINE__);             \
		                                printf(__VA_ARGS__);                    \
		                            } while (0)
#else
	#define DBG_LOG_INFO(...)		/* do nothing */
#endif

/* Debug log level 3 */
#if (DEBUG_LOG_LEVEL <= 3)
	#define DBG_LOG_WARN(...)		do {                                        \
		                                printf("\n\rwarning|%s:%d| ",           \
		                                       __func__, __LINE__);             \
		                                printf(__VA_ARGS__);                    \
		                            } while (0)
#else
	#define DBG_LOG_WARN(...)		/* do nothing */
#endif

/* Debug log level 4 */
#if (DEBUG_LOG_LEVEL <= 4)
	#define DBG_LOG_ERROR(...)		do {                                        \
									    printf("\n\rerror|%s:%d| ",             \
									           __func__, __LINE__);             \
									    printf(__VA_ARGS__);                    \
									} while (0)
#else
	#define DBG_LOG_ERROR(...)		/* do nothing */
#endif

/* Debug log level 5 */
#if (DEBUG_LOG_LEVEL <= 5)
	#define DBG_LOG_FATAL(...)		do {                                        \
		                                printf("\n\rfatal|%s:%d| ",             \
		                                       __func__, __LINE__);             \
		                                printf(__VA_ARGS__);                    \
		                                printf("\n\r --- System Halt! ---");    \
		                                printf("\n\r");                         \
		                                while (1)                               \
		                                {}                                      \
		                            } while (0)
#else
	#define DBG_LOG_FATAL(...)		/* do nothing */
#endif

#endif

