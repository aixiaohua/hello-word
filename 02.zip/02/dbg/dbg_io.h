/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 dbg_io.h
 *
 * DESCRIPTION:
 *	 dbg IO function
 *
 * HISTORY:
 *	 2018.7.20		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#ifndef __DBG_IO_H__
#define __DBG_IO_H__

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_IO_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for IO DBG
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_IO_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_IO_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for IO DBG
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void DBG_IO_LowPwrState(void);

#endif

