/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   dbg_cmd.c
 *
 * DESCRIPTION:
 *   Command interface.
 *
 * HISTORY:
 *   2018.6.27        Harry.Huang        Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "dbg.h"

#if 1
/*
 * Debug_Cmd_And_Result register is 16-bit unsigned:
 * 0x0000 - 0x7FFF means commands:
 * 0x0000 is invalid command
 * 0x0001-0x7FFF is used for commands, so it supports up to 32766 commands
 *
 * 0x8000 - 0x82FF means command results:
 * The MSB means results:
 * 0x80 is BUSY. The command is still executing
 * 0x81 is SUCCESS. The command finished successfully
 * 0x82 is FAIL. The command failed.
 * 0x83 - 0xFF is reserved for future use
 * The LSB means error code:
 * 0x00 means error code is not specified.
 * 0x01 - 0xFF means error code, and it suppports up to 255 error codes.
 */
typedef enum
{
	CMD_ID_INVALID				= 0x0000,

	CMD_ID_SOFT_REBOOT			= 0x0001,	/* Force software Reboot */

	CMD_ID_READ_GN2104S			= 0x0011,	/* Read GN2104S register */
	CMD_ID_WRITE_GN2104S		= 0x0012,	/* Write GN2104S register */
	CMD_ID_EXEC_MICRO_CMD		= 0x0013,	/* Execute micro command */

	/* More CMD_ID can be added here */

	CMD_ID_MAX					= 0x7FFF,	/* The command should not over than this */
} CMD_ID_T;

typedef enum
{
	CMD_RESULT_BUSY				= 0x80,
	CMD_RESULT_SUCCESS			= 0x81,
	CMD_RESULT_FAIL				= 0x82,
} CMD_RESULT_T;

typedef enum
{
	CMD_ERRCODE_NA				= 0x00,
	CDM_ERRCODE_I2C_FAIL		= 0x01,

	/* More ERRCODE can be added here */
} CMD_ERRCODE_T;

/* CMD_ENTRY_T, there is a command function for each command ID */
typedef struct
{
	CMD_ID_T	vCmd;
	BOOL		(*pCmdExecFunc)(void);
} CMD_ENTRY_T;
#endif

#if 1
#define GET_CMD()               	CFG_GET16(Debug_Cmd_And_Result)
#define SET_CMD_RESULT(vResult)  	CFG_SET8(Debug_Cmd_And_Result, (vResult))
#define SET_CMD_ERRCODE(vCode)		CFG_SETO8(Debug_Cmd_And_Result, 1, (vCode))
#endif

#if 1
static BOOL dbg_cmd_Reboot(void);
static BOOL dbg_cmd_ReadGN2104S(void);
static BOOL dbg_cmd_WriteGN2104S(void);
static BOOL dbg_cmd_ExecMicroCmd(void);
#endif

/* Define command list */
static __code CMD_ENTRY_T aCmdList[] =
{
	{CMD_ID_SOFT_REBOOT,		dbg_cmd_Reboot},
	{CMD_ID_READ_GN2104S,		dbg_cmd_ReadGN2104S},
	{CMD_ID_WRITE_GN2104S,		dbg_cmd_WriteGN2104S},
	{CMD_ID_EXEC_MICRO_CMD,		dbg_cmd_ExecMicroCmd},

	/* More CmdList can be added here */
};

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      dbg_cmd_Reboot
 *
 * DESCRIPTION:
 *      Run-time command application.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      TRUE/FALSE
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.4.21        Luke.Yu         Create/Update
 *****************************************************************************/
static BOOL dbg_cmd_Reboot(void)
{
	UINT8 vRebootType;

	vRebootType = CFG_GET8(Debug_Cmd_Param);
	if (vRebootType == 0x5A)
	{
		/* reboot through watchdog,
		 * we just do nothing, but waiting for watchdog timeout.
		 */
		for (;;)
		{
			/* do nothing */
		}
	}
	else
	{
		/* default, using Default reboot mode */
		DRV_CPU_Reset();
	}

	/* never reach here;
	 * if reach here, assume an error occur.
	 */

	return FALSE;
}

/******************************************************************************
 * FUNCTION NAME:
 *      dbg_cmd_ReadGN2104S
 *
 * DESCRIPTION:
 *      Read GN2104S register
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      TRUE/FALSE
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.6.27        Harry.Huang         Create/Update
 *****************************************************************************/
static BOOL dbg_cmd_ReadGN2104S(void)
{
	UINT8	vData;
	UINT16	vRegOffset;

	/* Get command parameters */
	vRegOffset = CFG_GET16(Debug_Cmd_Param);

	/* Clear command parameter & data */
	CFG_MEMSET(Debug_Cmd_Param, 0x00, I2C_LEN(Debug_Cmd_Param));
	CFG_MEMSET(Debug_Cmd_Data, 0x00, I2C_LEN(Debug_Cmd_Data));

	if (DRV_CDR_GN2104S_ReadRegister(vRegOffset, &vData) == TRUE)
	{
		CFG_SET8(Debug_Cmd_Data, vData);

		return TRUE;
	}
	else
	{
		SET_CMD_ERRCODE(CDM_ERRCODE_I2C_FAIL);

		return FALSE;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      dbg_cmd_WriteGN2104S
 *
 * DESCRIPTION:
 *      Write GN2104S register
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      TRUE/FALSE
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.6.27        Harry.Huang         Create/Update
 *****************************************************************************/
static BOOL dbg_cmd_WriteGN2104S(void)
{
	UINT8	vData;
	UINT16	vRegOffset;

	/* Get command parameters */
	vRegOffset = CFG_GET16(Debug_Cmd_Param);
	vData = CFG_GETO8(Debug_Cmd_Param, 2);

	/* Clear command parameter & data */
	CFG_MEMSET(Debug_Cmd_Param, 0x00, I2C_LEN(Debug_Cmd_Param));
	CFG_MEMSET(Debug_Cmd_Data, 0x00, I2C_LEN(Debug_Cmd_Data));

	if (DRV_CDR_GN2104S_WriteRegister(vRegOffset, vData) == TRUE)
	{
		return TRUE;
	}
	else
	{
		SET_CMD_ERRCODE(CDM_ERRCODE_I2C_FAIL);

		return FALSE;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      dbg_cmd_ExecMicroCmd
 *
 * DESCRIPTION:
 *      Excc GN2104S micro command
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      TRUE/FALSE
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.6.27        Harry.Huang         Create/Update
 *****************************************************************************/
static BOOL dbg_cmd_ExecMicroCmd(void)
{
	BOOL			bResult;
	UINT8			vLoop;
	GN2104_MACRO_T	vMacro;

	memset(&vMacro, 0x00, sizeof(vMacro));

	/* Get macro command parameters */
	vMacro.vCmd = CFG_GET8(Debug_Cmd_Param);
	for (vLoop=0; vLoop<sizeof(vMacro.aInBuf); vLoop++)
	{
		vMacro.aInBuf[vLoop] = CFG_GETO8(Debug_Cmd_Param, 1 + vLoop);
	}

	/* Clear command parameter & data */
	CFG_MEMSET(Debug_Cmd_Param, 0x00, I2C_LEN(Debug_Cmd_Param));
	CFG_MEMSET(Debug_Cmd_Data, 0x00, I2C_LEN(Debug_Cmd_Data));

	/* Execut macro */
	bResult = DRV_CDR_GN2104_ExecMacro(DRV_CDR_GN2104S_I2C_ADDR, &vMacro);

	/* Update macro output buffer */
	for (vLoop=0; vLoop<sizeof(vMacro.aOutBuf); vLoop++)
	{
		CFG_SETO8(Debug_Cmd_Data, vLoop, vMacro.aOutBuf[vLoop]);
	}

	return bResult;
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      DBG_CMD_Entry
 *
 * DESCRIPTION:
 *      Run-time command application entry.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      TRUE/FALSE
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.6.27        Harry.Huang         Create/Update
 *****************************************************************************/
void DBG_CMD_Entry(void)
{
	BOOL		bResult;
	CMD_ID_T	vCmd;
	UINT16		vLoop;

	/* Get command and check its validity */
	vCmd = GET_CMD();
	if ((vCmd > CMD_ID_INVALID) && (vCmd < CMD_ID_MAX))
	{
		/* Set command to BUSY, and clear failure code */
		SET_CMD_RESULT(CMD_RESULT_BUSY);
		SET_CMD_ERRCODE(CMD_ERRCODE_NA);

		/* Excute command */
		bResult = FALSE;
		for (vLoop = 0; vLoop < COUNT_OF(aCmdList); vLoop++)
		{
			if (aCmdList[vLoop].vCmd == vCmd)
			{
				bResult = aCmdList[vLoop].pCmdExecFunc();
				break;
			}
		}

		/*
		 * Set command result
		 * Note: Error code should be set in the command function
		 */
		SET_CMD_RESULT(bResult ? CMD_RESULT_SUCCESS : CMD_RESULT_FAIL);
	}
}
#endif

