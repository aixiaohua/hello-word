/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   dbg_stack.c
 *
 * DESCRIPTION:
 *   Stack related.
 *
 * HISTORY:
 *   2015.3.18        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "dbg.h"

#if STACK_CHECK_SUPPORT

/* Stack size check:
 *  we must make sure the stack is aligned to 8byte,
 *  to follow the APCS(ARM Procedure Call Standard).
 */
#if (((MSP_STACK_SIZE%8) != 0) || ((PSP_STACK_SIZE%8) != 0))
	#error "Stack size must be aligned to 8 bytes!"
#endif

/* Stack allocation:
 *
 *	  top						  bottom
 *		----------------------------
 *	   |	 PSP	  | 	MSP 	|
 *	   +----------------------------
 */
#define PSP_STACK_OFFSET			(0)
#define MSP_STACK_OFFSET			(PSP_STACK_OFFSET + PSP_STACK_SIZE)
#define GET_STACK_TOP(name)			((UINT32)STACK_TOP + name##_STACK_OFFSET)
#define GET_STACK_BOTTOM(name)		(GET_STACK_TOP(name) + name##_STACK_SIZE)

UINT8 aStackBuf[STACK_SIZE] __aligned(8);

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_Stack_GetStackInfo
 *
 * DESCRIPTION:
 *      Get Stack Information.
 *
 * PARAMETERS:
 *      vStackType : Stack type.
 *      pStackInfo : Output stack information.
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2015.3.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DBG_Stack_GetStackInfo
(
    IN  STACK_TYPE_T    vStackType,
    OUT STACK_INFO_T   *pStackInfo
)
{
    static struct
    {
        UINT32  vBottom;
        UINT32  vTop;
    } __code aStackInfoTable[] =
    {
        { GET_STACK_BOTTOM(PSP), GET_STACK_TOP(PSP), },     /* PSP */
        { GET_STACK_BOTTOM(MSP), GET_STACK_TOP(MSP), },     /* MSP */
    };

    UINT32  vStackCurrent;

    /* Get the bottom & top address of selected stack type */
    pStackInfo->vBottom = aStackInfoTable[vStackType].vBottom;
    pStackInfo->vTop    = aStackInfoTable[vStackType].vTop;

    /* Find the stack current address */
    vStackCurrent = pStackInfo->vTop;
    while ((vStackCurrent < pStackInfo->vBottom)
            && ((P32(vStackCurrent)) == STACK_INIT_VALUE))
    {
        vStackCurrent += sizeof(vStackCurrent);
    }
    pStackInfo->vCurrent = vStackCurrent;

    /* Calculate the stack current usage percent */
    pStackInfo->vUsagePercent = (UINT8)
                                 ((pStackInfo->vBottom - pStackInfo->vCurrent)
                                 *100 /(pStackInfo->vBottom - pStackInfo->vTop));
}


/******************************************************************************
 * FUNCTION NAME:
 *      DBG_Stack_Entry
 *
 * DESCRIPTION:
 *      Stack entry.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2015.3.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DBG_Stack_Entry(void)
{
	STACK_INFO_T    vStackInfo;

	DBG_Stack_GetStackInfo(STACK_TYPE_PSP, &vStackInfo);
	if (vStackInfo.vUsagePercent >= STACK_FATAL_PERCENT)
	{
		DBG_LOG_FATAL("PSP Stack Overflow! usage=%d%%",
				vStackInfo.vUsagePercent);
	}

	DBG_Stack_GetStackInfo(STACK_TYPE_MSP, &vStackInfo);
	if (vStackInfo.vUsagePercent >= STACK_FATAL_PERCENT)
	{
		DBG_LOG_FATAL("MSP Stack Overflow! usage=%d%%",
				vStackInfo.vUsagePercent);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_Stack_Init
 *
 * DESCRIPTION:
 *      Stack Initialize.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      Init all stack memory to fixed value, for checking usage.
 *
 * HISTORY:
 *      2015.03.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DBG_Stack_Init(void)
{
	UINT32  vOffset;

	for (vOffset = STACK_TOP; vOffset < STACK_BOTTOM; vOffset += sizeof(vOffset))
	{
		P32(vOffset) = STACK_INIT_VALUE;
	}
}

#endif

