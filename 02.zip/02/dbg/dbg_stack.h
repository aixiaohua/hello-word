/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   dbg_stack.h
 *
 * DESCRIPTION:
 *   Stack related.
 *
 * HISTORY:
 *   2015.3.18        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DBG_STACK_H__
#define __DBG_STACK_H__

/* stack size definition (unit of byte) */
#define MSP_STACK_SIZE          (4096)  /* handler mode */
#define PSP_STACK_SIZE          (8)     /* thread mode, currently unused */

/* stack definition: started from the end of RAM */
#define STACK_SIZE              (MSP_STACK_SIZE + PSP_STACK_SIZE)
extern UINT8      				aStackBuf[STACK_SIZE] __aligned(8);
#define STACK_TOP               (UINT32)(&aStackBuf[0])
#define STACK_BOTTOM            (UINT32)(STACK_TOP + sizeof(aStackBuf))


#if STACK_CHECK_SUPPORT

#define STACK_FATAL_PERCENT (95)
#define STACK_INIT_VALUE        (0xEEEEEEEEUL)

typedef enum
{
    STACK_TYPE_PSP = 0,
    STACK_TYPE_MSP,
} STACK_TYPE_T;

typedef struct
{
    UINT32  vBottom;
    UINT32  vCurrent;
    UINT32  vTop;
    UINT8   vUsagePercent;
} STACK_INFO_T;

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_Stack_GetStackInfo
 * DESCRIPTION:
 *      Get Stack Information.
 * PARAMETERS:
 *      vStackType : Stack type.
 *      pStackInfo : Output stack information.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2015.3.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DBG_Stack_GetStackInfo
(
    IN  STACK_TYPE_T    vStackType,
    OUT STACK_INFO_T   *pStackInfo
);

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_Stack_Entry
 * DESCRIPTION:
 *      Stack entry.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      If one stack is overflow, halt CPU.
 * HISTORY:
 *      2015.03.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DBG_Stack_Entry(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DBG_Stack_Init
 *
 * DESCRIPTION:
 *      Stack Initialize.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      Init all stack memory to fixed value, for checking usage.
 *
 * HISTORY:
 *      2015.03.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DBG_Stack_Init(void);

#endif
#endif

