/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   def_vector.h
 *
 * DESCRIPTION:
 *   Vector definition related.
 *
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/


/* Vector Root Entry Definition:
 *
 * Note:
 *   1) ISR will be serviced as ascending priority id sequence;
 *      i.e. 0 is always the highest priority id.
 *   2) For ADuCM320, the lowest priority id is 7.
 */
#ifdef DECLARE_VECTOR

#if DRV_I2CS_SUPPORT
DECLARE_VECTOR(Vector_I2CS,
               I2C0S_IRQn,
               MSA_I2C_ISR,
               0,
               NO_COOKIE,
               "I2C Slave Interrupt")

#endif

DECLARE_VECTOR(Vector_LPMode,
               EINT4_IRQn,
               MSA_ISR_LPModeISR,
               1,
               IRQ_MODE_BOTH_EDGE,
               "LPMode&TXDIS Interrupt")

DECLARE_VECTOR(Vector_ResetL,
               EINT7_IRQn,
               MSA_ISR_ResetLISR,
               2,
               IRQ_MODE_NEG_EDGE,
               "ResetL Interrupt")


#if DRV_SWI_SUPPORT
/* for ADuCM320, we use watchdog timer vector to expand the SWI interrupt,
 *  to support as much as possible SWI interrupts.
 */
DECLARE_VECTOR(Vector_SWI,
               WDT_IRQn,
               DRV_SWI_ISR,
               3,
               NO_COOKIE,
               "Simulated Software Interrupt (SWI) Dispatcher Interrupt")
#endif

#if DRV_TIMER_SUPPORT
DECLARE_VECTOR(Vector_TIMER,
               SysTick_IRQn,
               DRV_Timer_ISR,
               5,
               NO_COOKIE,
               "Simulated Timer Dispatcher Interrupt")
#endif

#if DRV_ADC_SUPPORT
DECLARE_VECTOR(Vector_ADC,
               LVD0_IRQn,
               DRV_ADC_ISR,
               7,
               NO_COOKIE,
               "ADC Sample Interrupt")
#endif

#if DRV_UART_SUPPORT
DECLARE_VECTOR(Vector_UART,
               UART_IRQn,
               DRV_UART_ISR,
               7,
               NO_COOKIE,
               "UART TX/RX Interrupt")
#endif

#endif


/* Simulated Timer Entry Definition */
#ifdef DECLARE_VECTOR_TIMER

/* Note:
 *  1. All timer interval values should not below "DRV_Timer_SysTickInterval";
 *     else, it will be auto limited to "DRV_Timer_SysTickInterval".
 *  2. Default, all timers are disabled;
 *     use DRV_Timer_SetState() to enable it.
 */

#if SYSTEM_TICK_SUPPORT
DECLARE_VECTOR_TIMER(Timer_SystemTick,
                     TIMER_MS(DRV_Timer_SystemTickValue),
                     DRV_Timer_SystemTick_Timer,
                     "System Tick Timer")
#endif

#if APP_TEC_SUPPORT
DECLARE_VECTOR_TIMER(Timer_TEC,
                     TIMER_MS(APL_TEC_TIMER_INTERVAL),
                     APP_TEC_Timer,
                     "TEC Timer")
#endif

DECLARE_VECTOR_TIMER(Timer_ModSelL,
                     TIMER_MS(MSA_ISR_MODSELL_TIMER_INTERVAL),
                     MSA_ISR_ModSelLISR,
                     "ModSelL Timer")

#endif


/* Simulated Software Interrupt (SWI) Entry Definition */
#ifdef DECLARE_VECTOR_SWI

/* Note:
 *  1. Default, all software interrupt are disabled;
 *      use DRV_SWI_SetState() to enable it.
 *  2. Use DRV_SWI_SetInterrupt() to trigger the software interrupt.
 *  3. Maximum 65536 software interrupts are supported.
 */
DECLARE_VECTOR_SWI(SWI_IntL,
				   MSA_ISR_IntLISR,
				   SWI_TYPE_FAST,
				   "IntL update SWI")

#endif

