/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   def_boot.h
 *
 * DESCRIPTION:
 *   N/A
 *
 * HISTORY:
 *   2009.4.13        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#ifndef __DEF_BOOT_H__
#define __DEF_BOOT_H__


#include "ADuCM320i.h"

/* project related parameters, which are defined in "project_cfg.bat" */
#define RAM_BASE            __RAM_BASE__
#define RAM_SIZE            __RAM_SIZE__
#define FLASH_BASE          __FLASH_BASE__
#define FLASH_SIZE          __FLASH_SIZE__
#define FLASH_BLOCK_SIZE    __FLASH_BLOCK_SIZE__
#define FLASH_PAGE_SIZE     __FLASH_PAGE_SIZE__

/* project memory layout related parameters, which are defined in "project_cfg.bat" */
#define NVM_COUNT           __NVM_COUNT__
#define NVM0_BASE           __NVM0_BASE__
#define NVM0_SIZE           __NVM0_SIZE__
#define NVM1_BASE           __NVM1_BASE__
#define NVM1_SIZE           __NVM1_SIZE__
#define IMAGE_BASE          __IMAGE_BASE__
#define IMAGE_SIZE          __IMAGE_SIZE__
#define CONFIG_BASE         __CONFIG_BASE__
#define CONFIG_SIZE         __CONFIG_SIZE__

/* project image related parameters, which are defined in "project_cfg.bat" */
#define FILE_COUNT          __FILE_COUNT__
#define FILE0_SIG_OFFSET    __FILE0_SIG_OFFSET__
#define FILE0_CLASS         __FILE0_CLASS__
#define FILE0_SUBCLASS      __FILE0_SUBCLASS__
#define FILE1_SIG_OFFSET    __FILE1_SIG_OFFSET__
#define FILE1_CLASS         __FILE1_CLASS__
#define FILE1_SUBCLASS      __FILE1_SUBCLASS__


/* release mode definition */
#ifdef _RELEASE_
 #define RELEASE_MODE       1
#else
 #define RELEASE_MODE       0
#endif


/* vector total count */
#define CM3_VECTOR_COUNT    (16)
#define CPU_VECTOR_COUNT    (55)    /* ADuCM320 supported vector counter */


#endif

