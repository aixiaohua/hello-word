/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   def_system.h
 *
 * DESCRIPTION:
 *   Product system definition configuration:
 *    -> Set to 1, enable  this driver/function;
 *    -> Set to 0, disable this driver/function;
 *
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#ifndef __DEF_SYSTEM_H__
#define __DEF_SYSTEM_H__


#define NA                          0
#define NO_COOKIE                   0

typedef enum
{
	CHANNEL_0 = 0x0,
	CHANNEL_1,
	CHANNEL_2,
	CHANNEL_3,
	SYSTEM_CHANNEL_NUM
}CHANNEL_INDEX_T;

/* Application supporting */
#define APP_SUPPORT                 1   /* Globally enable/disable Application  */
#define APP_TEC_SUPPORT             (1 && APP_SUPPORT)
#define APP_ADJ_SUPPORT             (1 && APP_SUPPORT)
#define APP_APDPROTECTED_SUPPORT    (1 && APP_ADJ_SUPPORT)

/* Supported Peripherals */
#define DRV_VECTOR_SUPPORT          1   /* Vector                       */
#define DRV_EXCEPTION_SUPPORT       0   /* Exception                    */
#define DRV_PSM_SUPPORT             0   /* Power Supply Monitor         */
#define DRV_PMU_SUPPORT             0   /* Power Management Unit        */
#define DRV_UART_SUPPORT            1   /* UART                         */
 #define DRV_UART_BAUDRATE          115200UL    /* bps */
#define DRV_WATCHDOG_SUPPORT        1   /* Watchdog                     */
#define DRV_RESET_SUPPORT           1   /* Reset                        */
#define DRV_DMA_SUPPORT             0   /* Direct Memory Access         */
#define DRV_IO_SUPPORT              1   /* GPIO                         */
#define DRV_FLASH_SUPPORT           1   /* Flash                        */
#define DRV_TIMER_SUPPORT           1   /* Timer                        */
#define DRV_SWI_SUPPORT             1   /* Enhanced Software Interrupt  */
#define DRV_I2CM_SUPPORT            1   /* Inter IC Bus (I2C Master)    */
 #define DRV_I2CM_RATE              400 /* I2C Master Rate:  80/100/150/200/300/400KHz */
#define DRV_I2CS_SUPPORT            1   /* Inter IC Bus (I2C Slave)     */
#define DRV_MDIOS_SUPPORT           0   /* MDIO Slave                   */
#define DRV_MDIOM_SUPPORT           0   /* MDIO Master                  */
#define DRV_SPI_SUPPORT             0   /* Serial Peripheral Interface  */
#define DRV_PWM_SUPPORT             0   /* Pulse Width Modulation       */
#define DRV_PLA_SUPPORT             1   /* Programmable Logic Array     */
#define DRV_VREF_SUPPORT            1   /* Voltage Reference            */
#define DRV_ADC_SUPPORT             (1 && DRV_VREF_SUPPORT)
 #define DRV_ADC_SwFilter_SUPPORT   (1 && DRV_ADC_SUPPORT)
#define DRV_DAC_SUPPORT             (1 && DRV_VREF_SUPPORT)
 #define DRV_DAC_MCU_SUPPORT		 (1 && DRV_DAC_SUPPORT)
  #define DRV_VDAC_SUPPORT		      (1 && DRV_DAC_MCU_SUPPORT)
  #define DRV_IDAC_SUPPORT		      (1 && DRV_DAC_MCU_SUPPORT)
 #define DRV_DAC_EXT_SUPPORT 	     (1 && DRV_DAC_SUPPORT)
  #define DRV_DAC_LD_SUPPORT		  (1 && DRV_DAC_EXT_SUPPORT && DRV_I2CM_SUPPORT && DRV_LD_SUPPORT)
  #define DRV_DAC_AD5629R_SUPPORT     (1 && DRV_DAC_EXT_SUPPORT && DRV_I2CM_SUPPORT)
  #define DRV_DAC_AD5691R_SUPPORT     (1 && DRV_DAC_EXT_SUPPORT && DRV_I2CM_SUPPORT)
#define DRV_EEPROM_SUPPORT			(0)	/* external EEPROM */

/* Miscellaneous Function supporting */
#define SYSTEM_TICK_SUPPORT         1   /* System Tick Timer                */
#define TIME_MEASURE_SUPPORT        0   /* Code Execute Time Measuring      */
#define SECURE_MODE_SUPPORT         1   /* Secure Mode                      */
#define STDIO_SUPPORT               1   /* Standard Input/Output Interface  */
#define STDIO_FLOAT_SUPPORT         (0 && STDIO_SUPPORT)        /* stdio float-point supporting */
#define STACK_CHECK_SUPPORT         1   /* Stack Check                      */
#define IMAGE_SUPPORT               1   /* Image Related                    */
#define HOT_RESET_SUPPORT           (0 && DRV_RESET_SUPPORT)    /* Hot Reset Related            */
 #define HOT_RESET_NSA_SUPPORT      (0 && HOT_RESET_SUPPORT)    /* Hot Reset: No-Service-Affect */

/* LD Chip supporting */
#define DRV_LD_SUPPORT              1   /* Globally enable/disable CDR */
 #define DRV_CDR_GN2104_SUPPORT		(1 && DRV_LD_SUPPORT && DRV_I2CM_SUPPORT)
  #define DRV_CDR_GN2104S_SUPPORT   (1 && DRV_CDR_GN2104_SUPPORT && DRV_I2CM_SUPPORT)
  #define DRV_CDR_GN2104TX_SUPPORT   (0 && DRV_CDR_GN2104_SUPPORT && DRV_I2CM_SUPPORT)
 #define DRV_CDR_MAOM037057_SUPPORT	(1 && DRV_LD_SUPPORT && DRV_I2CM_SUPPORT)

/* timing definition */
#define CHIP_RETRY_MAX_TIME         (1000UL)    /* ms */
#define CHIP_RETRY_INTERVAL         (10)        /* ms */
#define TEC_LOCK_MAX_TIME           (90000UL)   /* ms */

/* debug log level definition:
 *  =0 - These debug logs will be print out: debug/assert/info/warning/error/fatal;
 *  =1 - These debug logs will be print out: assert/info/warning/error/fatal;
 *  =2 - These debug logs will be print out: info/warning/error/fatal;
 *  =3 - These debug logs will be print out: warning/error/fatal;
 *  =4 - These debug logs will be print out: error/fatal;
 *  =5 - These debug logs will be print out: fatal;
 *  >5 - No    debug logs will be print out;
 */
#define DEBUG_LOG_LEVEL             1

typedef enum
{
	/* invalid ADC type */
	DAC_TYPE_INVALID = 0x00,

	DAC_TYPE_LOSTHRESSET_CH0,
	DAC_TYPE_LOSTHRESSET_CH1,
	DAC_TYPE_LOSTHRESSET_CH2,
	DAC_TYPE_LOSTHRESSET_CH3,

	DAC_TYPE_LOSHYSTSET_CH0,
	DAC_TYPE_LOSHYSTSET_CH1,
	DAC_TYPE_LOSHYSTSET_CH2,
	DAC_TYPE_LOSHYSTSET_CH3,

	DAC_TYPE_RXEQSET_CH0,
	DAC_TYPE_RXEQSET_CH1,
	DAC_TYPE_RXEQSET_CH2,
	DAC_TYPE_RXEQSET_CH3,

	DAC_TYPE_MODSET,
	DAC_TYPE_APCSET,
	DAC_TYPE_BIASSET,
	DAC_TYPE_CPSET,
	DAC_TYPE_LOSSET,
	DAC_TYPE_OMALOSSET,
	DAC_TYPE_RSSILOSSET,
	DAC_TYPE_TXHFDESET,
	DAC_TYPE_TXLFDESET,
	DAC_TYPE_TXEQSET,
	DAC_TYPE_RXEMSET,
	DAC_TYPE_LOSTHRESSET,
	DAC_TYPE_LOSHYSTSET,
	DAC_TYPE_RXEQSET,
	DAC_TYPE_TXEMPHSET,
	DAC_TYPE_END
} DAC_TYPE_T;

typedef enum
{
	CHIP_ID_MCU			= 0x00,
	CHIP_ID_MCU_VDAC	= 0xFF,
	CHIP_ID_MCU_IDAC	= 0xFE,

	CHIP_ID_GN1155		= 0x01,
	CHIP_ID_VSC7967		= 0x02,
	CHIP_ID_ONET8501V	= 0x03,
	CHIP_ID_ONET8501PB	= 0x04,
	CHIP_ID_VSC7966		= 0x05,
	CHIP_ID_ONET1101L	= 0x06,
	CHIP_ID_M02098		= 0x07,
	CHIP_ID_TN7350		= 0x08,
	CHIP_ID_NT25L90		= 0x09,
	CHIP_ID_GN7355		= 0x0A,
	CHIP_ID_GN2010D		= 0x0B,
	CHIP_ID_GN2010E		= 0x0C,
	CHIP_ID_MAX3799		= 0x0D,
	CHIP_ID_AEL2003		= 0x0E,
	CHIP_ID_GN1411A		= 0x0F,
	CHIP_ID_GN7354		= 0x10,
	CHIP_ID_MAX3710		= 0x11,
	CHIP_ID_MAX3945		= 0x12,
	CHIP_ID_GN2012		= 0x13,
	CHIP_ID_MAX3948		= 0x14,
	CHIP_ID_GN1157		= 0x15,
	CHIP_ID_ONET1141L	= 0x16,
	CHIP_ID_MAX3949		= 0x17,
	CHIP_ID_SI5040		= 0x18,
	CHIP_ID_M02077		= 0x19,
	CHIP_ID_M37040		= 0x1A,
	CHIP_ID_M37041		= 0x1B,
	CHIP_ID_GN2044		= 0x1C,
	CHIP_ID_MX3956		= 0x1D,
	CHIP_ID_GN2104_RX	= 0x1E,
	CHIP_ID_GN2104_TX	= 0x1F,
	CHIP_ID_GN2042		= 0x20,
	CHIP_ID_ONET4291PA	= 0x21,
	CHIP_ID_ONET1151	= 0x22,
	CHIP_ID_NT28L90		= 0x23,
	CHIP_ID_MAX24016    = 0x29,
	CHIP_ID_MAX24033    = 0x2C,
    CHIP_ID_GN2104S     = 0x30,
	CHIP_ID_AD5691R     = 0x31,
	CHIP_ID_AD5629R     = 0x32,
	CHIP_ID_MAOM037057  = 0x33,
	CHIP_ID_END
} CHIP_ID_T;

#endif

