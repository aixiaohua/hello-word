/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 def_compiler.h
 *
 * DESCRIPTION:
 *	 N/A
 *
 * HISTORY:
 *	 2013.5.27		  Panda.Xiong		 Create/Update
 *
*****************************************************************************/

#ifndef __DEF_COMPILER_H__
#define __DEF_COMPILER_H__


#include <stdint.h>
#include <sys/types.h>
#include "arm.h"


#define NOP()		__NOP()

/* Converts a bit number into a byte value */
#define _BV(b)		(1UL << (b))

/* ROL: Left Roll-Shift for data;
 * ROR: Right Roll-Shift for data;
 */
#define ROL(v, n)	do { (v) = (((v) << (n)) | ((v) >> (8*sizeof(v)-(n)))); } while (0)
#define ROR(v, n)	do { (v) = (((v) >> (n)) | ((v) << (8*sizeof(v)-(n)))); } while (0)

/* Swap data:  Big-Endian  <-->  Little-Endian */
#define SWAP_16(x)	(UINT16)(__REV16((UINT16)(x)))
#define SWAP_32(x)	(UINT32)(__REV((UINT32)(x)))
#define SWAP_64(x)	(UINT64)(SWAP_32((UINT64)(x)>>32) | SWAP_32((UINT64)(x)<<32))


#endif

