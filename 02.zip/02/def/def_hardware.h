/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   def_hardware.h
 *
 * DESCRIPTION:
 *   Hardware definition, including IO, ADC, DAC, etc.
 *
 * HISTORY:
 *   2018.8.20        Harry.Huang        Create/Update
*****************************************************************************/


#ifdef DECLARE_IO

/*             Name             PORT         BIT         Mode          Direction              Init    Description */

/* PORT 0 */
DECLARE_IO(IO_RXPWREN_OUT,      IO_PORT(0),  IO_BIT(0),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,    "")
DECLARE_IO(IO_P0_1,             IO_PORT(0),  IO_BIT(1),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  HIGH,    "")
DECLARE_IO(IO_ModSelL_IN,       IO_PORT(0),  IO_BIT(2),  MODE_IRQ,     IO_INPUT_PULLUP_ENABLE,  HIGH,    "")
DECLARE_IO(IO_PowerEN_OUT,      IO_PORT(0),  IO_BIT(3),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,     "")
DECLARE_IO(I2CS_SCL,            IO_PORT(0),  IO_BIT(4),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,    "")
DECLARE_IO(I2CS_SDA,            IO_PORT(0),  IO_BIT(5),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,    "")
DECLARE_IO(I2CM_SCL,            IO_PORT(0),  IO_BIT(6),  MODE_IO,      IO_OUTPUT_OPENDRAIN,     HIGH,    "")
DECLARE_IO(I2CM_SDA,            IO_PORT(0),  IO_BIT(7),  MODE_IO,      IO_OUTPUT_OPENDRAIN,     HIGH,    "")

/* PORT 1 */
DECLARE_IO(UART_RXD,            IO_PORT(1),  IO_BIT(0),  MODE_AUX1,    IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(UART_TXD,            IO_PORT(1),  IO_BIT(1),  MODE_AUX1,    IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_TXLOS_IN,         IO_PORT(1),  IO_BIT(2),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  LOW,    "")
DECLARE_IO(IO_RESET_RXCDR,      IO_PORT(1),  IO_BIT(3),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,    "")
DECLARE_IO(IO_TXDIS_OUT,        IO_PORT(1),  IO_BIT(4),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,    "")
DECLARE_IO(IO_P1_5,             IO_PORT(1),  IO_BIT(5),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_IntL_OUT,  		IO_PORT(1),  IO_BIT(6),  MODE_IO,      IO_OUTPUT_OPENDRAIN,     HIGH,   "")
DECLARE_IO(IO_P1_7,             IO_PORT(1),  IO_BIT(7),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  LOW,    "")

/* PORT 2 */
DECLARE_IO(IO_RXLOS_IN,         IO_PORT(2),  IO_BIT(0),  MODE_PLA,     IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_P2_1,             IO_PORT(2),  IO_BIT(1),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_LPMode_IN, 		IO_PORT(2),  IO_BIT(2),  MODE_IRQ,     IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_P2_3,             IO_PORT(2),  IO_BIT(3),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_TXPWREN_OUT,      IO_PORT(2),  IO_BIT(4),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,    "")
DECLARE_IO(IO_P2_5,             IO_PORT(2),  IO_BIT(5),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_ResetL_IN,        IO_PORT(2),  IO_BIT(6),  MODE_IRQ,     IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_TECSW2_OUT,       IO_PORT(2),  IO_BIT(7),  MODE_IO,      IO_OUTPUT_PUSHPULL,      HIGH,   "")

/* PORT 3 */
DECLARE_IO(IO_APDEN_OUT,        IO_PORT(3),  IO_BIT(0),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,    "")
DECLARE_IO(IO_P3_1,             IO_PORT(3),  IO_BIT(1),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_TECEN_OUT,        IO_PORT(3),  IO_BIT(2),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,    "")
DECLARE_IO(IO_LPowerEN_OUT,     IO_PORT(3),  IO_BIT(3),  MODE_IO,      IO_OUTPUT_PUSHPULL,      LOW,    "")
DECLARE_IO(IO_TXLOL_IN,         IO_PORT(3),  IO_BIT(4),  MODE_IO,      IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(IO_TECSW1_OUT,       IO_PORT(3),  IO_BIT(5),  MODE_IO,      IO_OUTPUT_PUSHPULL,      HIGH,   "")
DECLARE_IO(IO_P3_6,             IO_PORT(3),  IO_BIT(6),  MODE_AUX1,    IO_INPUT_PULLUP_ENABLE,  HIGH,   "")
DECLARE_IO(DAC_VG0Set,          IO_PORT(3),  IO_BIT(7),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")

/* PORT 4 */
DECLARE_IO(ADC_RX_VPD2,         IO_PORT(4),  IO_BIT(2),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(IO_P4_3,             IO_PORT(4),  IO_BIT(3),  MODE_IO,      IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(ADC_TXPWR_CH3,       IO_PORT(4),  IO_BIT(4),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(ADC_TXPWR_CH2,       IO_PORT(4),  IO_BIT(5),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(ADC_TXPWR_CH1,       IO_PORT(4),  IO_BIT(6),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(ADC_TXPWR_CH0,       IO_PORT(4),  IO_BIT(7),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")

/* PORT 5 */
DECLARE_IO(DAC_VC2Set,          IO_PORT(5),  IO_BIT(0),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(DAC_VC0Set,          IO_PORT(5),  IO_BIT(1),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(DAC_VG2Set,          IO_PORT(5),  IO_BIT(2),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")
DECLARE_IO(DAC_TECSet,          IO_PORT(5),  IO_BIT(3),  MODE_AUX1,    IO_INPUT_PULLUP_DISABLE, HIGH,   "")

#endif


#ifdef DECLARE_ADC

/* Note:
 *  *) All ADC channel must be defined as Channel ID ascending mode.
 *  *) For differential ADC channel,
 *      both positive/negative channel need to be defined.
 *  *) If one ADC is unused, just config it as ADC_DISABLE.
 */

/*            Name              Pos Channel         Neg Channel      Mode              Average        Description */
DECLARE_ADC(ADC_RXPWR_CH0,      ADC_CHP_AIN0,      ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_RXPWR_CH1,      ADC_CHP_AIN1,      ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_TEC_N,          ADC_CHP_AIN2,      ADC_CHN_VREFN, ADC_MODE_DIFF,    ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_TEC_P,          ADC_CHP_AIN3,      ADC_CHP_AIN2,  ADC_MODE_DIFF,    ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_RXPWR_CH2,      ADC_CHP_AIN4,      ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_RXPWR_CH3,      ADC_CHP_AIN5,	   ADC_CHN_VREFN, ADC_MODE_SINGLE,	ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_LDTEMP_Coarse,  ADC_CHP_AIN6,      ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_Reserved_7,     ADC_CHP_AIN7,      ADC_CHN_VREFN, ADC_MODE_DISABLE, ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_ChipTEMP,       ADC_CHP_AIN8,      ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_Reserved_9,     ADC_CHP_AIN9,      ADC_CHN_VREFN, ADC_MODE_DISABLE, ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_Reserved_10,    ADC_CHP_AIN10,     ADC_CHN_VREFN, ADC_MODE_DISABLE, ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_Buf_Vref2V5,    ADC_CHP_AIN11,     ADC_CHN_VREFN, ADC_MODE_DISABLE, ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_TXPWR_CH3,      ADC_CHP_AIN12,     ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_TXPWR_CH2,      ADC_CHP_AIN13,     ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_TXPWR_CH1,      ADC_CHP_AIN14,     ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")
DECLARE_ADC(ADC_TXPWR_CH0,      ADC_CHP_AIN15,     ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_64, "ADC Channel")

DECLARE_ADC(ADC_MCUTEMP,        ADC_CHP_TEMP,      ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_IOVDD,          ADC_CHP_IOVDD_HALF,ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_8,  "ADC Channel")
DECLARE_ADC(ADC_AVDD,           ADC_CHP_AVDD_HALF, ADC_CHN_VREFN, ADC_MODE_SINGLE,  ADC_AVG_TIME_8,  "ADC Channel")

#endif


#ifdef DECLARE_VDAC

/* Note: Init value of VGSet and VCSet must be 0x0000 in this project
 * to guarantee VGSet and VCSet are output behind EASet and BIASSet.
 */

/*            Name           source            Channel    Configuration          Init                             Description */
DECLARE_VDAC(TECSet,    CHIP_ID_MCU_VDAC, _VDAC(0),  VDAC_ENABLE_REF_2V5,   0x0000,                              "VDAC Channel: Reserved")
DECLARE_VDAC(VGSet_CH1, CHIP_ID_MCU_VDAC, _VDAC(1),  VDAC_ENABLE_REF_2V5,   CFG_GET16(Init_VGSet_Value_CH2),     "VDAC Channel: Reserved")
DECLARE_VDAC(VGSet_CH0, CHIP_ID_MCU_VDAC, _VDAC(2),  VDAC_ENABLE_REF_2V5,   CFG_GET16(Init_VGSet_Value_CH1),     "VDAC Channel: Reserved")
DECLARE_VDAC(VCSet_CH2, CHIP_ID_MCU_VDAC, _VDAC(3),  VDAC_ENABLE_REF_2V5,   CFG_GET16(Init_VCSet_Value_CH3),     "VDAC Channel: Reserved")
DECLARE_VDAC(VCSet_CH3, CHIP_ID_MCU_VDAC, _VDAC(4),  VDAC_ENABLE_REF_2V5,   CFG_GET16(Init_VCSet_Value_CH4),     "VDAC Channel: Reserved")
DECLARE_VDAC(VCSet_CH1, CHIP_ID_MCU_VDAC, _VDAC(5),  VDAC_ENABLE_REF_2V5,   CFG_GET16(Init_VCSet_Value_CH2),     "VDAC Channel: Reserved")
DECLARE_VDAC(VCSet_CH0, CHIP_ID_MCU_VDAC, _VDAC(6),  VDAC_ENABLE_REF_2V5,   CFG_GET16(Init_VCSet_Value_CH1),     "VDAC Channel: Reserved")
DECLARE_VDAC(VGSet_CH2, CHIP_ID_MCU_VDAC, _VDAC(7),  VDAC_ENABLE_REF_2V5,   CFG_GET16(Init_VGSet_Value_CH3),     "VDAC Channel: Reserved")

#endif


#ifdef DECLARE_IDAC

/* Note: Init value of BIASSet must be 0x0000 in this project
 * to guarantee TX has no output during initialization.
 */

/*            Name             source            Channel    Configuration                        Init     Description */
DECLARE_IDAC(BIASSet_CH0, CHIP_ID_MCU_IDAC, _IDAC(0),  (IDAC_ENABLE|IDAC_BANDWIDTH_153HZ),    0x0000,  "IDAC Channel: Reserved")
DECLARE_IDAC(BIASSet_CH3, CHIP_ID_MCU_IDAC, _IDAC(1),  (IDAC_ENABLE|IDAC_BANDWIDTH_153HZ),    0x0000,  "IDAC Channel: Reserved")
DECLARE_IDAC(BIASSet_CH1, CHIP_ID_MCU_IDAC, _IDAC(2),  (IDAC_ENABLE|IDAC_BANDWIDTH_153HZ),    0x0000,  "IDAC Channel: Reserved")
DECLARE_IDAC(BIASSet_CH2, CHIP_ID_MCU_IDAC, _IDAC(3),  (IDAC_ENABLE|IDAC_BANDWIDTH_153HZ),    0x0000,  "IDAC Channel: Reserved")

#endif


#ifdef DECLARE_DAC_AD5629R

/* Channel is determined by A0 pin connection of DAC_AD5629R:
 * A0 pin connection is GND, Channel is from 0 to 7;
 * A0 pin connection is NC,  Channel is from 8 to 15;
 * A0 pin connection is VDD, Channel is from 16 to 23;
 *
 * Note: All of the 8 channels of the chip must be defined;
 */

/*					  Name			 Source 		   Channel		  Configuration 	   Init								Description */
DECLARE_DAC_AD5629R(EASet_CH3,   CHIP_ID_AD5629R,   _AD5629R(0),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_EASet_Value_CH1),   "DAC Channel Output")
DECLARE_DAC_AD5629R(APDSet_CH1,  CHIP_ID_AD5629R,   _AD5629R(1),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_APDSet_Value_CH4),  "DAC Channel Output")
DECLARE_DAC_AD5629R(EASet_CH1,   CHIP_ID_AD5629R,   _AD5629R(2),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_EASet_Value_CH2),   "DAC Channel Output")
DECLARE_DAC_AD5629R(APDSet_CH2,  CHIP_ID_AD5629R,   _AD5629R(3),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_APDSet_Value_CH3),  "DAC Channel Output")
DECLARE_DAC_AD5629R(EASet_CH2,   CHIP_ID_AD5629R,   _AD5629R(4),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_EASet_Value_CH3),   "DAC Channel Output")
DECLARE_DAC_AD5629R(APDSet_CH3,  CHIP_ID_AD5629R,   _AD5629R(5),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_APDSet_Value_CH2),  "DAC Channel Output")
DECLARE_DAC_AD5629R(EASet_CH0,   CHIP_ID_AD5629R,   _AD5629R(6),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_EASet_Value_CH4),   "DAC Channel Output")
DECLARE_DAC_AD5629R(APDSet_CH0,  CHIP_ID_AD5629R,   _AD5629R(7),  DAC_AD5629R_ENABLE,  CFG_GET16(Init_APDSet_Value_CH1),  "DAC Channel Output")

#endif

#ifdef DECLARE_DAC_AD5691R

/* Channel is determined by A0 pin connection of DAC_AD5691R:
 * A0 pin connection is GND, Channel is _AD5691R(0);
 * A0 pin connection is VDD, Channel is _AD5691R(1);
 */

/* Note: Init value of VGSet and VCSet must be 0x0000 in this project
 * to guarantee VGSet and VCSet are output behind EASet and BIASSet.
 */

/*                    Name      Source           Channel       Configuration           Init                           Description */
DECLARE_DAC_AD5691R(VGSet_CH3, CHIP_ID_AD5691R, _AD5691R(0), DAC_AD5691R_ENABLE,   CFG_GET16(Init_VGSet_Value_CH4),  "DAC Channel Output")
/*
DECLARE_DAC_AD5691R(DAC_AD5691R_Reserved_1, CHIP_ID_AD5691R, _AD5691R(1), DAC_AD5691R_ENABLE,   0x0000, "DAC Channel Output")
*/

#endif

#ifdef DECLARE_DAC_GN2104RX

/* DAC channel definition.
 *
 *   name         : DAC channel name;
 *   DST          : The destination of DAC;
 *   Type         : DAC type;
 *   unused       : N/A;
 *   pin_no       : DAC channel hardware pin number;
 *   desc         : DAC description;
 *
 *   Note         :
 *      N/A
 */

/*                   Name                   Source             Channel                   Configuration  Init       Description */
DECLARE_DAC_GN2104RX(RXLOSThresSet_CH0, CHIP_ID_GN2104S, DAC_TYPE_LOSTHRESSET_CH0, NO_COOKIE,     NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXLOSThresSet_CH1, CHIP_ID_GN2104S, DAC_TYPE_LOSTHRESSET_CH1, NO_COOKIE,	    NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXLOSThresSet_CH2, CHIP_ID_GN2104S, DAC_TYPE_LOSTHRESSET_CH2, NO_COOKIE,     NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXLOSThresSet_CH3, CHIP_ID_GN2104S, DAC_TYPE_LOSTHRESSET_CH3, NO_COOKIE,     NO_COOKIE, "")

DECLARE_DAC_GN2104RX(RXLOSHystSet_CH0,  CHIP_ID_GN2104S, DAC_TYPE_LOSHYSTSET_CH0,  NO_COOKIE,     NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXLOSHystSet_CH1,  CHIP_ID_GN2104S, DAC_TYPE_LOSHYSTSET_CH1,  NO_COOKIE,	    NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXLOSHystSet_CH2,  CHIP_ID_GN2104S, DAC_TYPE_LOSHYSTSET_CH2,  NO_COOKIE,	    NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXLOSHystSet_CH3,  CHIP_ID_GN2104S, DAC_TYPE_LOSHYSTSET_CH3,  NO_COOKIE,	    NO_COOKIE, "")

DECLARE_DAC_GN2104RX(RXEQSet_CH0,       CHIP_ID_GN2104S, DAC_TYPE_RXEQSET_CH0,     NO_COOKIE,     NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXEQSet_CH1,       CHIP_ID_GN2104S, DAC_TYPE_RXEQSET_CH1,     NO_COOKIE,	    NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXEQSet_CH2,       CHIP_ID_GN2104S, DAC_TYPE_RXEQSET_CH2,     NO_COOKIE,	    NO_COOKIE, "")
DECLARE_DAC_GN2104RX(RXEQSet_CH3,       CHIP_ID_GN2104S, DAC_TYPE_RXEQSET_CH3,     NO_COOKIE,	    NO_COOKIE, "")

#endif


#ifdef DECLARE_PLA_ELEMENT

/*                     Block           Element         Input           Output           Init  Description  */
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(0),  PLAIN_B0E0,     PLAOUT_B0E00,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(1),  PLAIN_B0E1,     PLAOUT_B0E01,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(2),  PLAIN_B0E2,     PLAOUT_B0E02,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(3),  PLAIN_B0E3,     PLAOUT_B0E03,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(4),  PLAIN_B0E4,     PLAOUT_B0E04,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(5),  PLAIN_B0E5,     PLAOUT_B0E05,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(6),  PLAIN_B0E6,     PLAOUT_B0E06,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(0), _PLA_ELEMENT(7),  PLAIN_B0E7,     PLAOUT_B0E07,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(0),  PLAIN_B1E0,     PLAOUT_B1E00,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(1),  PLAIN_B1E1,     PLAOUT_B1E01,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(2),  PLAIN_B1E2,     PLAOUT_B1E02,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(3),  PLAIN_B1E3,     PLAOUT_B1E03,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(4),  PLAIN_B1E4,     PLAOUT_B1E04,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(5),  PLAIN_B1E5,     PLAOUT_B1E05,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(6),  PLAIN_B1E6,     PLAOUT_B1E06,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(1), _PLA_ELEMENT(7),  PLAIN_B1E7,     PLAOUT_B1E07,       LOW,    "")

DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(0),  PLAIN_B2E0,     PLAOUT_B2E00,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(1),  PLAIN_B2E1,     PLAOUT_B2E01,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(2),  PLAIN_B2E2,     PLAOUT_B2E02,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(3),  PLAIN_B2E3,     PLAOUT_B2E03,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(4),  PLAIN_B2E4,     PLAOUT_B2E04,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(5),  PLAIN_B2E5,     PLAOUT_B2E05,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(6),  PLAIN_B2E6,     PLAOUT_B2E06,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(2), _PLA_ELEMENT(7),  PLAIN_B2E7,     PLAOUT_B2E07,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(0),  PLAIN_B3E0,     PLAOUT_B3E00,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(1),  PLAIN_B3E1,     PLAOUT_B3E01,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(2),  PLAIN_B3E2,     PLAOUT_B3E02,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(3),  PLAIN_B3E3,     PLAOUT_B3E03,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(4),  PLAIN_B3E4,     PLAOUT_B3E04,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(5),  PLAIN_B3E5,     PLAOUT_B3E05,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(6),  PLAIN_B3E6,     PLAOUT_B3E06,       LOW,    "")
DECLARE_PLA_ELEMENT(_PLA_BLOCK(3), _PLA_ELEMENT(7),  PLAIN_B3E7,     PLAOUT_B3E07,       LOW,    "")

#endif

