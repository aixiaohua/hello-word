/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2010   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   msa_i2c.c
 *
 * NODULE NAME:
 *   N/A
 *
 * DESCRIPTION:
 *   I2C Interrupt handler
 *
 * HISTORY:
 *   2009.4.17        Luke.Yu         Create/Update
 *
*****************************************************************************/
#include "cfg.h"
#include "msa.h"
#include "apt_msa_i2c.h"

#if DRV_I2CS_SUPPORT

#define I2C_SLAVE_INDEX1					0x0
#define I2C_SLAVE_ID1							0xA0

typedef enum
{
    I2C_STATE_INIT = 0,     /* initial state         */
    I2C_STATE_ADDR_R,       /* receive Addr+Read     */
    I2C_STATE_ADDR_W,       /* receive Addr+Write    */
    I2C_STATE_W_OFFSET,     /* receive Write Offset  */
    I2C_STATE_W_DATA,       /* receive Write Data    */
    I2C_STATE_R_DATA        /* send Read Data        */
} I2C_STATE_T;


static volatile I2C_STATE_T  vI2cState;

/* always record current State Machine state of I2C Slave */
static UINT8 vI2cAddrId = 0;
static UINT8 aI2cRead[I2C_TOTAL_ADDRESS];
static UINT8 aI2cReadNext[I2C_TOTAL_ADDRESS];
static UINT8 vI2cWriteLen;
static UINT8 vI2cStartOffset;	                    /* start offset */
static UINT8 aI2cRTOffset[I2C_TOTAL_ADDRESS];		/* real-time offset */
static UINT8 aI2cWriteBuffer[MSA_PAGE_SIZE];



/******************************************************************************
 * FUNCTION NAME:
 *      msa_i2c_OffsetInc
 *
 * DESCRIPTION:
 *      Increase I2C offset.
 *
 * PARAMETERS:
 *      vOffset   : Current offset.
 *
 * RETURN:
 *      Offset increment.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.3.10        Melinda.Lu         Create/Update
 *****************************************************************************/
static UINT8 msa_i2c_OffsetInc(UINT8 vOffset)
{
	UINT8 vOffsetInc;

	if (MSA_PAGE_OFFSET(vOffset) == MSA_PAGE_OFFSET_MSK)
	{
		/* has reached to the end of DIRECT_LOW or High Page,
		 *  force the LSB 7-bits to 0, but keep the highest bit,
		 *  to indicate the DIRECT_LOW or High Page.
		 */
		vOffsetInc = vOffset & MSA_PAGE_SIZE;
	}
	else
	{
		/* increase offset of this addressed I2C Address */
		vOffsetInc = vOffset+1;
	}

	return vOffsetInc;
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_i2c_ReadByte
 *
 * DESCRIPTION:
 *      Read one IIC byte data.
 *
 * PARAMETERS:
 *      vSelAddr  : Selected IIC address.
 *      vOffset   : Slected Offset of the Slected IIC Page.
 *
 * RETURN:
 *      Getted data of this IIC offset.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.4.20        Luke.Yu         Create/Update
 *****************************************************************************/
static UINT8 msa_i2c_ReadByte(UINT8 vOffset)
{
	return APT_MSA_I2C_ReadByte(vOffset);
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_i2c_ReadPrefetch
 *
 * DESCRIPTION:
 *      Fetch next byte data.
 *
 * PARAMETERS:
 *      vIsAddr : =1, called when received Addr+W & Offset;
 *              =0, other cases.
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2012.08.17        Melinda.Lu        Update
 *****************************************************************************/
static void msa_i2c_ReadPrefetch(void)
{
	UINT8 vOffset, vOffsetNext;

	vOffset = aI2cRTOffset[vI2cAddrId];
	vOffsetNext = msa_i2c_OffsetInc(aI2cRTOffset[vI2cAddrId]);

	switch (vI2cState)
	{
		case I2C_STATE_W_OFFSET:
			/* after receiving offset,
			 * the prefetched buffer need to be refreshed with the new data.
			 */
			aI2cRead[vI2cAddrId] = msa_i2c_ReadByte(vOffset);
			aI2cReadNext[vI2cAddrId] = msa_i2c_ReadByte(vOffsetNext);
			break;

		case I2C_STATE_W_DATA:
			/* when offset is changed after I2C writing,
			 * the prefetching buffer need to be refreshed with the new data.
			 */
			aI2cRead[vI2cAddrId] = msa_i2c_ReadByte(vOffset);
			aI2cReadNext[vI2cAddrId] = msa_i2c_ReadByte(vOffsetNext);
			break;

		case I2C_STATE_R_DATA:
			/* after transmiting each data,
			 *
			 */

	    	/* Check the data sent out is interrupt flag or not,
	    	 * if it is, clear it firstly.
	    	 */
    	APT_MSA_I2C_ClearIntFlag(vOffset);

			vOffset = msa_i2c_OffsetInc(vOffset);
			vOffsetNext = msa_i2c_OffsetInc(vOffsetNext);

			if(vOffset & 0x01)
			{
				aI2cRead[vI2cAddrId] = aI2cReadNext[vI2cAddrId];
			}
			else
			{
				aI2cRead[vI2cAddrId] = msa_i2c_ReadByte(vOffset);
			}

			aI2cReadNext[vI2cAddrId] = msa_i2c_ReadByte(vOffsetNext);
			aI2cRTOffset[vI2cAddrId] = vOffset;
			break;

		default:
			break;
	}

	/* refresh Tx FIFO */
	APT_MSA_I2C_TxFIFORefresh(aI2cRead[vI2cAddrId], aI2cReadNext[vI2cAddrId]);
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_i2c_ReadStopHandler
 *
 * DESCRIPTION:
 *      I2C Master Read Stop Handler.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
static void msa_i2c_ReadStopHandler(void)
{
	/* Fush I2C Master read data */
	APT_MSA_I2C_ReadFlush();
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_i2c_WriteStopHandler
 *
 * DESCRIPTION:
 *		I2C Master Write Stop Handler.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2016.3.21		 Melinda.Lu 	   Create/Update
 *****************************************************************************/
static void msa_i2c_WriteStopHandler(void)
{
	if (vI2cWriteLen)
	{
		/* Fix bug:
		 *  while saving configuration to flash,
		 *  the SCL line is always been stretched to LOW.
		 */
		APT_MSA_I2C_SetAck(DISABLE);

		APT_MSA_I2C_WriteFlush(vI2cStartOffset, vI2cWriteLen, aI2cWriteBuffer);

		/* enable ACK */
		APT_MSA_I2C_SetAck(ENABLE);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_MgmtInit
 *
 * DESCRIPTION:
 *      Set I2C speciality of MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.11.14        Hayden.Ai         Create/Update
 *****************************************************************************/
void MSA_I2C_MgmtInit(void)
{
	APT_MSA_I2C_SetSlaveAddr(I2C_SLAVE_INDEX1, I2C_SLAVE_ID1);
	/* rate etc... */
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_Enable
 *
 * DESCRIPTION:
 *      Enable I2C function of MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.7.23        Harry.Huang         Create/Update
 *****************************************************************************/
void MSA_I2C_Enable(void)
{
	/* Reset I2C Slave Interface */
	APT_MSA_I2C_SetEn(DISABLE); 	  /* first, disable I2C Slave  */
	APT_MSA_I2C_Init(); 		  /* reset I2C State Machine   */
	
	/* prefetch I2C data */
	aI2cRead[0]	= CFG_Memget8(CFG_PAGE_0xA0_DIRECT, 0);
	aI2cReadNext[0] = CFG_Memget8(CFG_PAGE_0xA0_DIRECT, 1);
	aI2cRTOffset[0] = 0;

	/* reset I2C State Machine */
	vI2cState = I2C_STATE_INIT;
	vI2cAddrId	=	0;
	
	APT_MSA_I2C_SetEn(ENABLE);		  /* enable I2C Slave */
	APT_MSA_I2C_TxFIFORefresh(aI2cRead[vI2cAddrId], aI2cReadNext[vI2cAddrId]); /* at last, refresh TX FIFO */
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_Disable
 *
 * DESCRIPTION:
 *      Disable I2C function of MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.7.23        Harry.Huang         Create/Update
 *****************************************************************************/
void MSA_I2C_Disable(void)
{
	APT_MSA_I2C_SetEn(DISABLE);
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_ISR
 *
 * DESCRIPTION:
 *      I2C Slave Interrupt Service Routine.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.4.10        Luke.Yu         Create/Update
 *****************************************************************************/
void MSA_I2C_ISR(void)
{
	UINT16 vState;
	UINT8 vReceiveData;

	APT_MSA_I2C_GetDrvStatus(&vState);

	/* Repeat-Start */
	if (vState & APT_I2C_STATE_RESTART)
	{
		vI2cState = I2C_STATE_INIT;
	}

	if (vI2cState == I2C_STATE_INIT)
	{
		/* get the selected I2C Information */
		APT_MSA_I2C_GetDrvAddr(&vI2cAddrId);
	}

	/* I2C Master Read */
	if (vState & APT_I2C_STATE_MREAD)
	{
		switch (vI2cState)
		{
			case I2C_STATE_INIT:
				vI2cState = I2C_STATE_R_DATA;
				break;

			case I2C_STATE_R_DATA:
			default:
				/* do nothing */
				break;
		}

		/* prefetch I2C Read data */
		msa_i2c_ReadPrefetch();
	}

	/* I2C Master Write */
	else if (vState & APT_I2C_STATE_MWRITE)
	{
		vReceiveData = APT_MSA_I2C_RxByte();

		switch (vI2cState)
		{
			case I2C_STATE_INIT:
				/* reset Written Buffer Counter,
				 *  to make sure all previous incorrect written data are dropped.
				 * this is used to improve the I2C State Machine stability.
				 */
				vI2cStartOffset = 0;
				vI2cWriteLen = 0;
				vI2cState = I2C_STATE_W_OFFSET;
				/* no break here */

			case I2C_STATE_W_OFFSET:
				/* this Byte data is offset */
				aI2cRTOffset[vI2cAddrId] = vReceiveData;
				vI2cStartOffset = vReceiveData;
				msa_i2c_ReadPrefetch();
				vI2cState = I2C_STATE_W_DATA;
				break;

			case I2C_STATE_W_DATA:
				/* only support 128-byte sequential write */
				if (vI2cWriteLen < sizeof(aI2cWriteBuffer))
				{
					aI2cWriteBuffer[vI2cWriteLen] = vReceiveData;
					vI2cWriteLen++;
					aI2cRTOffset[vI2cAddrId] = msa_i2c_OffsetInc(aI2cRTOffset[vI2cAddrId]);
				}
				break;

			default:
				break;
		}
	}

	/* I2C Stop */
	else if (vState & APT_I2C_STATE_STOP)
	{
		switch (vI2cState)
		{
			case I2C_STATE_R_DATA:
				msa_i2c_ReadStopHandler();
				/* no break here */

			case I2C_STATE_INIT:
				break;

			case I2C_STATE_W_DATA:
				/* I2C Master Write Stop Handler */
				msa_i2c_WriteStopHandler();
				msa_i2c_ReadPrefetch();
				break;

			default:
				/* do nothing */
				break;
		}

		/* reset I2C State Machine */
		vI2cState = I2C_STATE_INIT;
	}
}
#endif

