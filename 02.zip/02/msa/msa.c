/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa.c
 *
 * DESCRIPTION:
 *	 MSA related function
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "dbg.h"
#include "msa.h"


/******************************************************************************
 * FUNCTION NAME:
 *      MSA_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_PwrDnState(void)
{
	MSA_ISR_PwrDnState();
	MSA_DDM_PwrDnState();
	MSA_FLAG_PwrDnState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ReadyState(void)
{
	MSA_ISR_ReadyState();

	/* Update ready state DDM (Dynamic Diagnostic Monitoring) value */
	MSA_DDM_ReadyState();

	/* update high-power interrupt & Alarm/Warning flags */
	MSA_FLAG_ReadyState();

	/* update Real-Time control */
	MSA_CTRL_ReadyState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_PwrUpState
 *
 * DESCRIPTION:
 *      Pwrup state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_PwrUpState(void)
{
	MSA_ISR_PwrUpState();
	MSA_CTRL_PwrUpState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_LowPwrState(void)
{
	MSA_ISR_LowPwrState();

	/* update low-power DDM (Dynamic Diagnostic Monitoring) value */
	MSA_DDM_LowPwrState();

	/* update low-power Alarm & Warning flag */
	MSA_FLAG_LowPwrState();

	/* update IntL output */
	MSA_ISR_UpdateIntL();
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_MgmtInit
 *
 * DESCRIPTION:
 *      MgmtInit state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_MgmtInit(void)
{
	MSA_I2C_MgmtInit();

	MSA_ISR_MgmtInit();

	MSA_FLAG_MgmtInit();
}

