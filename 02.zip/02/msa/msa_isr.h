/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_isr.h
 *
 * DESCRIPTION:
 *	 MSA ISR related function
 *
 * HISTORY:
 *	 2018.7.26		 Harry.Huang		 Create/Update
*****************************************************************************/

#ifndef __MSA_ISR_H__
#define __MSA_ISR_H__

#define MSA_ISR_MODSELL_TIMER_INTERVAL			1 /* 1ms */

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_IsResetLAsserted
 *
 * DESCRIPTION:
 *		Get ResetL asserted state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		TRUE: ResetL asserted
 *		FALSE: ResetL deasserted
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL MSA_ISR_IsResetLAsserted(void);


/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_IsLPModeAsserted
 *
 * DESCRIPTION:
 *		Get LPMode asserted state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		TRUE: LPMode asserted
 *		FALSE: LPMode deasserted
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL MSA_ISR_IsLPModeAsserted(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_DeassertLPMode
 *
 * DESCRIPTION:
 *		Deassert LPMode
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_DeassertLPMode(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_SetDataReady
 *
 * DESCRIPTION:
 *		When DataNotReady changed from High to Low, MSA_FLAG should notify MSA_ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_SetDataReady(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_UpdateIntL
 *
 * DESCRIPTION:
 *		Trigger IntL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_UpdateIntL(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_IntLISR
 *
 * DESCRIPTION:
 *		IntL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_IntLISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_ModSelLISR
 *
 * DESCRIPTION:
 *		ModSelL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_ModSelLISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_ResetLISR
 *
 * DESCRIPTION:
 *		ResetL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.31		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_ResetLISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_LPModeISR
 *
 * DESCRIPTION:
 *		LPMode ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_LPModeISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA ISR
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_PwrDnState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA ISR function
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_PwrUpState
 *
 * DESCRIPTION:
 *      Power up state for MSA ISR
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_PwrUpState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for MSA ISR function
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_LowPwrState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_MgmtInit
 *
 * DESCRIPTION:
 *      Management init state for MSA ISR
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_MgmtInit(void);

#endif

