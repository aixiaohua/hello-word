/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_stm.c
 *
 * DESCRIPTION:
 *	 MSA state machine function
 *
 * HISTORY:
 *	 2018.7.20		 Harry.Huang		 Create/Update
*****************************************************************************/

#ifndef __MSA_STM_H__
#define __MSA_STM_H__

typedef enum
{
    MODULE_STATE_Reset = 0x0,
    MODULE_STATE_MgmtInit,
    MODULE_STATE_LowPwr,
    MODULE_STATE_PwrUp,
    MODULE_STATE_Ready,
    MODULE_STATE_PwrDn,
} MODULE_STATE_T;

typedef MODULE_STATE_T (*MODULE_STATE_FUNC)(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_STM_GetPrevState
 *
 * DESCRIPTION:
 *		Get previous module state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.20		Harry.Huang 		Create/Update
 *****************************************************************************/
MODULE_STATE_T MSA_STM_GetPrevState(void);

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_STM_GetCurrentState
 *
 * DESCRIPTION:
 *		Get current module state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.20		Harry.Huang 		Create/Update
 *****************************************************************************/
MODULE_STATE_T MSA_STM_GetCurrentState(void);

#endif

