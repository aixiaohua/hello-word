/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_flag.c
 *
 * DESCRIPTION:
 *	 MSA flag related function
 *
 * HISTORY:
 *	 2018.7.10		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "msa_isr.h"
#include "apt_msa_flag.h"

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateTEMP
 *
 * DESCRIPTION:
 *		Update alarm & warning flags for temperature
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateTEMP(void)
{
	SINT16 vData = (SINT16)CFG_GET16(RT_TEMP);

	if (vData > (SINT16)CFG_GET16(Threshold_TEMP_Alarm_High))
	{
		CFG_SET_BIT(Alarm_TEMP_High, TRUE);
	}

	if (vData > (SINT16)CFG_GET16(Threshold_TEMP_Warning_High))
	{
		CFG_SET_BIT(Warning_TEMP_High, TRUE);
	}

	if (vData < (SINT16)CFG_GET16(Threshold_TEMP_Warning_Low))
	{
		CFG_SET_BIT(Warning_TEMP_Low, TRUE);
	}

	if (vData < (SINT16)CFG_GET16(Threshold_TEMP_Alarm_Low))
	{
		CFG_SET_BIT(Alarm_TEMP_Low, TRUE);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateVCC
 *
 * DESCRIPTION:
 *		Update alarm & warning flags for VCC
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateVCC(void)
{
	UINT16 vData = CFG_GET16(RT_VCC);

	if (vData > CFG_GET16(Threshold_VCC_Alarm_High))
	{
		CFG_SET_BIT(Alarm_VCC_High, TRUE);
	}

	if (vData > CFG_GET16(Threshold_VCC_Warning_High))
	{
		CFG_SET_BIT(Warning_VCC_High, TRUE);
	}

	if (vData < CFG_GET16(Threshold_VCC_Warning_Low))
	{
		CFG_SET_BIT(Warning_VCC_Low, TRUE);
	}

	if (vData < CFG_GET16(Threshold_VCC_Alarm_Low))
	{
		CFG_SET_BIT(Alarm_VCC_Low, TRUE);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateTXBias
 *
 * DESCRIPTION:
 *		Update alarm & warning flags for Tx Bias
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateTXBias(void)
{
	UINT16	vData, vAlarmHi, vAlarmLo, vWarningHi, vWarningLo;

	vAlarmHi = CFG_GET16(Threshold_TXBIAS_Alarm_High);
	vAlarmLo = CFG_GET16(Threshold_TXBIAS_Alarm_Low);
	vWarningHi = CFG_GET16(Threshold_TXBIAS_Warning_High);
	vWarningLo = CFG_GET16(Threshold_TXBIAS_Warning_Low);

	/* channel 1 */
	vData = CFG_GET16(RT_TXBIAS_CH1);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXBIAS_High_CH1, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXBIAS_High_CH1, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXBIAS_Low_CH1, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXBIAS_Low_CH1, 1);
	}

	/* channel 2 */
	vData = CFG_GET16(RT_TXBIAS_CH2);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXBIAS_High_CH2, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXBIAS_High_CH2, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXBIAS_Low_CH2, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXBIAS_Low_CH2, 1);
	}

	/* channel 3 */
	vData = CFG_GET16(RT_TXBIAS_CH3);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXBIAS_High_CH3, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXBIAS_High_CH3, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXBIAS_Low_CH3, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXBIAS_Low_CH3, 1);
	}

	/* channel 4 */
	vData = CFG_GET16(RT_TXBIAS_CH4);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXBIAS_High_CH4, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXBIAS_High_CH4, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXBIAS_Low_CH4, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXBIAS_Low_CH4, 1);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateTXPower
 *
 * DESCRIPTION:
 *		Update alarm & warning flags for Tx Power
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateTXPower(void)
{
	UINT16	vData;
	UINT16	vAlarmHi, vAlarmLo, vWarningHi, vWarningLo;

	vAlarmHi = CFG_GET16(Threshold_TXPWR_Alarm_High);
	vAlarmLo = CFG_GET16(Threshold_TXPWR_Alarm_Low);
	vWarningHi = CFG_GET16(Threshold_TXPWR_Warning_High);
	vWarningLo = CFG_GET16(Threshold_TXPWR_Warning_Low);

	/* channel 1 */
	vData = CFG_GET16(RT_TXPWR_CH1);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXPWR_High_CH1, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXPWR_High_CH1, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXPWR_Low_CH1, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXPWR_Low_CH1, 1);
	}

	/* channel 2 */
	vData = CFG_GET16(RT_TXPWR_CH2);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXPWR_High_CH2, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXPWR_High_CH2, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXPWR_Low_CH2, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXPWR_Low_CH2, 1);
	}

	/* channel 3 */
	vData = CFG_GET16(RT_TXPWR_CH3);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXPWR_High_CH3, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXPWR_High_CH3, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXPWR_Low_CH3, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXPWR_Low_CH3, 1);
	}

	/* channel 4 */
	vData = CFG_GET16(RT_TXPWR_CH4);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_TXPWR_High_CH4, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_TXPWR_High_CH4, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_TXPWR_Low_CH4, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_TXPWR_Low_CH4, 1);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateRXPower
 *
 * DESCRIPTION:
 *		Update alarm & warning flags for Rx Power
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateRXPower(void)
{
	UINT16	vData, vAlarmHi, vAlarmLo, vWarningHi, vWarningLo;

	vAlarmHi = CFG_GET16(Threshold_RXPWR_Alarm_High);
	vAlarmLo = CFG_GET16(Threshold_RXPWR_Alarm_Low);
	vWarningHi = CFG_GET16(Threshold_RXPWR_Warning_High);
	vWarningLo = CFG_GET16(Threshold_RXPWR_Warning_Low);

	/* channel 1 */
	vData = CFG_GET16(RT_RXPWR_CH1);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_RXPWR_High_CH1, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_RXPWR_High_CH1, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_RXPWR_Low_CH1, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_RXPWR_Low_CH1, 1);
	}

	/* channel 2 */
	vData = CFG_GET16(RT_RXPWR_CH2);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_RXPWR_High_CH2, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_RXPWR_High_CH2, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_RXPWR_Low_CH2, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_RXPWR_Low_CH2, 1);
	}

	/* channel 3 */
	vData = CFG_GET16(RT_RXPWR_CH3);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_RXPWR_High_CH3, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_RXPWR_High_CH3, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_RXPWR_Low_CH3, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_RXPWR_Low_CH3, 1);
	}

	/* channel 4 */
	vData = CFG_GET16(RT_RXPWR_CH4);
	if (vData > vAlarmHi)
	{
		CFG_SET_BIT(Alarm_RXPWR_High_CH4, 1);
	}
	if (vData > vWarningHi)
	{
		CFG_SET_BIT(Warning_RXPWR_High_CH4, 1);
	}
	if (vData < vWarningLo)
	{
		CFG_SET_BIT(Warning_RXPWR_Low_CH4, 1);
	}
	if (vData < vAlarmLo)
	{
		CFG_SET_BIT(Alarm_RXPWR_Low_CH4, 1);
	}
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateTXLOL
 *
 * DESCRIPTION:
 *		Update Tx LOL flag
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateTXLOL(void)
{
	UINT8 vChannel;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		if (APT_MSA_FLAG_GetTXLOL(vChannel))
		{
			CFG_SET_BITO(Interrupt_TXLOL_CH1, vChannel, 1);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateRXLOL
 *
 * DESCRIPTION:
 *		Update Rx LOL flag
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateRXLOL(void)
{
	UINT8 vChannel;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		if (APT_MSA_FLAG_GetRXLOL(vChannel))
		{
			CFG_SET_BITO(Interrupt_RXLOL_CH1, vChannel, 1);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateTXLOS
 *
 * DESCRIPTION:
 *		Update Tx LOS flag
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateTXLOS(void)
{
	UINT8 vChannel;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		if (APT_MSA_FLAG_GetTXLOS(vChannel))
		{
			CFG_SET_BITO(Interrupt_TXLOS_CH1, vChannel, 1);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateRXLOS
 *
 * DESCRIPTION:
 *		Update Rx LOS flag
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateRXLOS(void)
{
	UINT8 vChannel;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		if (APT_MSA_FLAG_GetRXLOS(vChannel))
		{
			CFG_SET_BITO(Interrupt_RXLOS_CH1, vChannel, 1);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateTXFault
 *
 * DESCRIPTION:
 *		Update Tx fault flag
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateTXFault(void)
{
	UINT8 vChannel;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		if (APT_MSA_FLAG_GetTXFault(vChannel))
		{
			CFG_SET_BITO(Interrupt_TXFAULT_CH1, vChannel, 1);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateTXEQFault
 *
 * DESCRIPTION:
 *		Update Tx EQ fault flag
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateTXEQFault(void)
{
	UINT8 vChannel;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		if (APT_MSA_FLAG_GetTXEQFault(vChannel))
		{
			CFG_SET_BITO(Interrupt_TXEQFault_CH1, vChannel, 1);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateInitComplete
 *
 * DESCRIPTION:
 *		Update init complete flag
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateInitComplete(void)
{
	/* Init_Complete_Flag is latched, and be cleared after read */
	if (APT_MSA_FLAG_GetInitComplete())
	{
		CFG_SET_BIT(Initialization_Complete_Flag, TRUE);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_flag_UpdateDataNotReady
 *
 * DESCRIPTION:
 *		Update data not ready state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_flag_UpdateDataNotReady(void)
{
	/* Set data ready */
	if (CFG_GET_BIT(RT_Data_Ready_State))
	{
		MSA_ISR_SetDataReady();

    	CFG_SET_BIT(RT_Data_Ready_State, LOW);
	}

}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      MSA_FLAG_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA flag
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_FLAG_PwrDnState(void)
{
	/* Clear TX/RX LOS/LOL, TX FAULT & TX EQ FAULT */
	CFG_SET8(Interrupt_Flag_1, 0x00);
	CFG_SET8(Interrupt_Flag_2, 0x00);
	CFG_SET8(Interrupt_Flag_3, 0x00);

	/* Clear Alarm & Warning of TX BIAS, TX Power, RX Power */
	CFG_SET8(Alarm_Warning_Flag_4, 0x00);
	CFG_SET8(Alarm_Warning_Flag_5, 0x00);
	CFG_SET8(Alarm_Warning_Flag_6, 0x00);
	CFG_SET8(Alarm_Warning_Flag_7, 0x00);
	CFG_SET8(Alarm_Warning_Flag_8, 0x00);
	CFG_SET8(Alarm_Warning_Flag_9, 0x00);
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_FLAG_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA flag function
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_FLAG_ReadyState(void)
{
	msa_flag_UpdateTEMP();
	msa_flag_UpdateVCC();
	msa_flag_UpdateTXBias();
	msa_flag_UpdateTXPower();
	msa_flag_UpdateRXPower();

	msa_flag_UpdateTXLOL();
	msa_flag_UpdateRXLOL();
	msa_flag_UpdateTXLOS();
	msa_flag_UpdateRXLOS();
	msa_flag_UpdateTXFault();
	msa_flag_UpdateTXEQFault();
	msa_flag_UpdateInitComplete();
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_FLAG_LowPwrState
 *
 * DESCRIPTION:
 *		Low Power state for MSA flags function.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_FLAG_LowPwrState(void)
{
	msa_flag_UpdateTEMP();
	msa_flag_UpdateVCC();

	msa_flag_UpdateDataNotReady();
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_FLAG_MgmtInit
 *
 * DESCRIPTION:
 *      Management init state for MSA FLAG
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_FLAG_MgmtInit(void)
{
	/* Set Data_not_Ready flag */
	CFG_SET_BIT(RT_Data_Ready_State, TRUE);
}

#endif

