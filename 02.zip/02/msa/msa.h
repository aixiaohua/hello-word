/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa.h
 *
 * DESCRIPTION:
 *	 MSA related.
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#ifndef __MSA_H__
#define __MSA_H__

#include "msa_ddm.h"
#include "msa_flag.h"
#include "msa_ctrl.h"
#include "msa_stm.h"
#include "msa_i2c.h"
#include "msa_isr.h"

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_PwrDnState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_PwrUpState
 *
 * DESCRIPTION:
 *      Pwrup state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_PwrUpState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_LowPwrState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_MgmtInit
 *
 * DESCRIPTION:
 *      MgmtInit state for MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_MgmtInit(void);

#endif

