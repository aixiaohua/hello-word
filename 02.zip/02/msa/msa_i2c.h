/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2010   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   msa_i2c.h
 *
 * NODULE NAME:
 *   N/A
 *
 * DESCRIPTION:
 *   N/A
 *
 * HISTORY:
 *   2009.4.10        Luke.Yu         Create/Update
*****************************************************************************/

#ifndef __MSA_I2C_H__
#define __MSA_I2C_H__

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_MgmtInit
 *
 * DESCRIPTION:
 *      Set I2C speciality of MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.11.14        Hayden.Ai         Create/Update
 *****************************************************************************/
void MSA_I2C_MgmtInit(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_Enable
 *
 * DESCRIPTION:
 *      Enable I2C function of MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.7.23        Harry.Huang         Create/Update
 *****************************************************************************/
void MSA_I2C_Enable(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_Disable
 *
 * DESCRIPTION:
 *      Disable I2C function of MSA
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.7.23        Harry.Huang         Create/Update
 *****************************************************************************/
void MSA_I2C_Disable(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_I2C_ISR
 *
 * DESCRIPTION:
 *      I2C Slave Interrupt Service Routine.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.4.10        Luke.Yu         Create/Update
 *****************************************************************************/
void MSA_I2C_ISR(void);

#endif

