/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_isr.c
 *
 * DESCRIPTION:
 *	 MSA ISR related function
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "msa.h"
#include "apt_msa_isr.h"

static volatile BOOL	bResetL = HIGH;
static volatile BOOL	bDataNotReadyFallEdge = FALSE;
static volatile BOOL 	bLPMode;
extern BOOL 			bDataReadyIsRead;

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		msa_isr_UpdateLPMode
 *
 * DESCRIPTION:
 *		Update LPMode state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
static void msa_isr_UpdateLPMode(void)
{
	if (!CFG_GET_BIT(RT_HighPowerClass_En) || (CFG_GET_BIT(RT_PowerOverride) && CFG_GET_BIT(RT_PowerSet)))
	{
		bLPMode = TRUE;
	}
}

#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_IsResetLAsserted
 *
 * DESCRIPTION:
 *		Get ResetL asserted state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		TRUE: ResetL asserted
 *		FALSE: ResetL deasserted
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL MSA_ISR_IsResetLAsserted(void)
{
	return ((!bResetL) | (APT_MSA_ISR_GetIOData(APT_DRV_RESETL) == LOW));
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_IsLPModeAsserted
 *
 * DESCRIPTION:
 *		Get LPMode asserted state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		TRUE: LPMode asserted
 *		FALSE: LPMode deasserted
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL MSA_ISR_IsLPModeAsserted(void)
{
	return bLPMode;
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_DeassertLPMode
 *
 * DESCRIPTION:
 *		Deassert LPMode
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_DeassertLPMode(void)
{
	bLPMode = FALSE;;
}


/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_SetDataReady
 *
 * DESCRIPTION:
 *		When DataNotReady changed from High to Low, MSA_FLAG should notify MSA_ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_SetDataReady(void)
{
	bDataNotReadyFallEdge = TRUE;
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_UpdateIntL
 *
 * DESCRIPTION:
 *		Trigger IntL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_UpdateIntL(void)
{
	/* trigger interrupt to update IntL output */
	APT_MSA_ISR_SetSWIInterrupt();
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_IntLISR
 *
 * DESCRIPTION:
 *		IntL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_IntLISR(void)
{
	BOOL	bHasInterrupt;
	UINT8	vLoop;

	bHasInterrupt = FALSE;

	// TODO: check these two flags later
	/* Will not set interrupt flag, if bDataReadyIsRead & bDataNotReadyFallEdge are both true */
	if (bDataReadyIsRead && bDataNotReadyFallEdge)
	{
		bDataNotReadyFallEdge = FALSE;
	}

	/* Set interrupt flag, if DataNotReady changed from true to false */
	if (bDataNotReadyFallEdge)
	{
		bHasInterrupt = TRUE;
	}

	/* Interrupt alarm/warning flag part1 */
	if (!bHasInterrupt)
	{
		for (vLoop	= 0;
			 vLoop <= CFG_OFFSET(Alarm_Warning_Flag_2) - CFG_OFFSET(Interrupt_Flag_1);
			 vLoop++)
		{
			if (0x00 != (CFG_GETO8(Interrupt_Flag_1, vLoop)
						 & (~ CFG_GETO8(Mask_Interrupt_Flag_1, vLoop))))
			{
				bHasInterrupt = TRUE;

				/* The IntL status is asserted, no need to check other flags */
				break;
			}
		}
	}

	/* Interrupt alarm/warning flag part2 */
	if (!bHasInterrupt)
	{
		for (vLoop	= 0;
			 vLoop <= CFG_OFFSET_END(Alarm_Warning_Reserved) - CFG_OFFSET(Alarm_Warning_Flag_4);
			 vLoop++)
		{
			if (0x00 != (CFG_GETO8(Alarm_Warning_Flag_4, vLoop)
						 & (~ CFG_GETO8(Mask_Alarm_Warning_Flag_4, vLoop))))
			{
				bHasInterrupt = TRUE;

				/* The IntL status is asserted, no need to check other flags */
				break;
			}
		}
	}

	/* Output IntL signal */
	// TODO: Move to adaption layer
	APT_MSA_ISR_SetDrvIntL(bHasInterrupt);

	/* Update real-time status of IntL */
	CFG_SET_BIT(RT_IntL_State, !bHasInterrupt);
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_ModSelLISR
 *
 * DESCRIPTION:
 *		ModSelL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.26		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_ModSelLISR(void)
{
	static BOOL	bPreModSelL = TRUE;

	/* ModSelL asserted */
	if (bPreModSelL && (!APT_MSA_ISR_GetIOData(APT_DRV_MODSEL)))
	{
		/* Host_select_hold: 10us */
		usleep(10);

		/* Check ModSelL signal again, to make sure it's not a fake signal */
		if (!APT_MSA_ISR_GetIOData(APT_DRV_MODSEL))
		{
			/* ModSelL asserted, enable I2C Slave commulication */
			MSA_I2C_Enable();

			/* switch to positive edge triggering mode */
			bPreModSelL = FALSE;
		}
	}

	/* ModSelL de-asserted */
	else if (!bPreModSelL && APT_MSA_ISR_GetIOData(APT_DRV_MODSEL))
	{
		/* Host_select_hold: 10us */
		usleep(10);

		/* Check ModSelL signal again, to make sure it's not a fake signal */
		if (APT_MSA_ISR_GetIOData(APT_DRV_MODSEL))
		{
			/* ModSelL de-asserted, disable I2C Slave commulication */
			MSA_I2C_Disable();

			/* Switch to negative edge triggering mode */
			bPreModSelL = TRUE;
		}
	}
	else
	{
		/* do nothing */
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_ResetLISR
 *
 * DESCRIPTION:
 *		ResetL ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.31		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_ResetLISR(void)
{
	#if DRV_VECTOR_SUPPORT
	/* enable this interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_EN, APT_DRV_RESETL);
	#endif

	/* t_reset_init: 2us */
	/* DRV_CPU_DelayUs(2); */

	/* check ResetL signal again, to make sure it's not a fake signal */
	if (APT_MSA_ISR_GetIOData(APT_DRV_RESETL) == LOW)
	{
		/* set ResetL asserted flag */
		bResetL = LOW;

		/* disable this interrupt, because after the reset signal detected,
		 * the entire module will be reset;
		 * after reset, this interrrupt will be enabled again;
		 * hence, there is no need to enable this interrupt.
		 */
		#if DRV_VECTOR_SUPPORT
		/* disable this interrupt */
		APT_MSA_ISR_SetInterrupt(APT_INT_DIS, APT_DRV_RESETL);
		#endif
	}

	#if DRV_VECTOR_SUPPORT
	/* clear this interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_CLR, APT_DRV_RESETL);
	#endif
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_LPModeISR
 *
 * DESCRIPTION:
 *		LPMode ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_LPModeISR(void)
{
#if DRV_VECTOR_SUPPORT
    /* enable this interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_EN, APT_DRV_LPMODE);
#endif
	
	if (APT_MSA_ISR_GetIOData(APT_DRV_LPMODE)
		&& !CFG_GET_BIT(RT_PowerOverride))
	{
		/* LPMode pin is high and power override is unselected, enter low power mode */
			APT_MSA_ISR_SetLPMode();

		#if DRV_VECTOR_SUPPORT
	    /* disable this interrupt */
		APT_MSA_ISR_SetInterrupt(APT_INT_DIS, APT_DRV_LPMODE);
		#endif
	}
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA ISR
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_PwrDnState(void)
{
#if DRV_VECTOR_SUPPORT
	/* disable LPMode interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_DIS, APT_DRV_LPMODE);
#endif
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA ISR function
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_ReadyState(void)
{
	msa_isr_UpdateLPMode();
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_PwrUpState
 *
 * DESCRIPTION:
 *      Power up state for MSA ISR
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_PwrUpState(void)
{
#if DRV_VECTOR_SUPPORT
	/* enable LPMode interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_EN, APT_DRV_LPMODE);

	/* clear this interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_CLR, APT_DRV_LPMODE);
#endif
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ISR_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for MSA ISR function
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_LowPwrState(void)
{
	msa_isr_UpdateLPMode();
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_ISR_MgmtInit
 *
 * DESCRIPTION:
 *		Management init state for MSA ISR
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_ISR_MgmtInit(void)
{
	/* Deassert ResetL*/
	bResetL = HIGH;
	bLPMode = FALSE;

	/* Enable IntL refresh interrupt */
#if DRV_VECTOR_SUPPORT && DRV_SWI_SUPPORT
	APT_MSA_ISR_SetState(ENABLE, APT_DRV_SWI);
#endif

	/* Enable ModSelL Refresh Timer */
#if DRV_TIMER_SUPPORT
	APT_MSA_ISR_SetTimer(ENABLE, APT_DRV_MODSEL);
#endif

#if DRV_VECTOR_SUPPORT
	/* clear this interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_CLR, APT_DRV_RESETL);

	/* enable this interrupt */
	APT_MSA_ISR_SetInterrupt(APT_INT_EN, APT_DRV_RESETL);
#endif

}

#endif

