/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_ctrl.h
 *
 * DESCRIPTION:
 *	 MSA ctrl related function
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/

#ifndef __MSA_CTRL_H__
#define __MSA_CTRL_H__

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_CTRL_ReadyState
 *
 * DESCRIPTION:
 *      Update Real-Time Control
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.7.25        Harry.Huang         Create/Update
 *****************************************************************************/
void MSA_CTRL_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_CTRL_PwrUpState
 *
 * DESCRIPTION:
 *      Power up state for MSA CTRL
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_CTRL_PwrUpState(void);

#endif

