/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_ctrl.c
 *
 * DESCRIPTION:
 *	 MSA ctrl related function
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "apt_msa_ctrl.h"

static BOOL	bPowerUpFlag = TRUE;

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateRXOutput
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Output.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateRXOutput(void)
{
	UINT8		vChannel;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		APT_MSA_CTRL_UpdateRXOutput(vChannel,
			CFG_GET_BITO(RX_Output_Disable_CH1, vChannel*I2C_LEN(RX_Output_Disable_CH1)));
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateTXOutput
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Output.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateTXOutput(void)
{
	// TODO: Check it later
	APT_MSA_CTRL_UpdateTXOutput();
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateRXSquelch
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Squelch.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateRXSquelch(UINT8 vChannel)
{
	APT_MSA_CTRL_UpdateRXSquelch(vChannel,
		CFG_GET_BITO(RX_SQ_Disable_CH1, vChannel*I2C_LEN(RX_SQ_Disable_CH1)));
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateTXSquelch
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Squelch.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateTXSquelch(UINT8 vChannel)
{
	APT_MSA_CTRL_UpdateTXSquelch(vChannel,
		CFG_GET_BITO(TX_SQ_Disable_CH1, vChannel*I2C_LEN(TX_SQ_Disable_CH1)));
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateRXCDRBypass
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX CDR Bypass.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateRXCDRBypass(UINT8 vChannel)
{
	APT_MSA_CTRL_UpdateRXCDRBypass(vChannel,
		CFG_GET_BITO(RT_RxCDRBypass_CH1, vChannel*I2C_LEN(RT_RxCDRBypass_CH1)));
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateTXCDRBypass
 *
 * DESCRIPTION:
 *      Update Real-Time Control of Tx CDR Bypass.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateTXCDRBypass(UINT8 vChannel)
{
	APT_MSA_CTRL_UpdateTXCDRBypass(vChannel,
		CFG_GET_BITO(RT_TxCDRBypass_CH1, vChannel*I2C_LEN(RT_TxCDRBypass_CH1)));
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateRXRate
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Rate.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateRXRate(UINT8 vChannel)
{
	APT_MSA_CTRL_UpdateRXRate(vChannel,
		(UINT8)CFG_GET_BITO(RT_RxRateSelect_CH1, vChannel*I2C_LEN(RT_RxRateSelect_CH1)));
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateTXRate
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Rate.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateTXRate(UINT8 vChannel)
{
	APT_MSA_CTRL_UpdateTXRate(vChannel,
		(UINT8)CFG_GET_BITO(RT_TxRateSelect_CH1, vChannel*I2C_LEN(RT_TxRateSelect_CH1)));
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateRXEmphasis
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Emphasis
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateRXEmphasis(UINT8 vChannel)
{
	UINT8 aCode[SYSTEM_CHANNEL_NUM];

	aCode[0] = CFG_GET_BIT(RX_Output_DeEmphasis_CH1);
	aCode[1] = CFG_GET_BIT(RX_Output_DeEmphasis_CH2);
	aCode[2] = CFG_GET_BIT(RX_Output_DeEmphasis_CH3);
	aCode[3] = CFG_GET_BIT(RX_Output_DeEmphasis_CH4);

	APT_MSA_CTRL_UpdateRXEmphasis(vChannel, aCode[vChannel]);
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateRXAmplitude
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Amplitude
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateRXAmplitude(UINT8 vChannel)
{
	UINT8 aCode[SYSTEM_CHANNEL_NUM];

	aCode[0] = CFG_GET_BIT(RX_Output_Amplitude_CH1);
	aCode[1] = CFG_GET_BIT(RX_Output_Amplitude_CH2);
	aCode[2] = CFG_GET_BIT(RX_Output_Amplitude_CH3);
	aCode[3] = CFG_GET_BIT(RX_Output_Amplitude_CH4);

	APT_MSA_CTRL_UpdateRXAmplitude(vChannel, aCode[vChannel]);
}

/******************************************************************************
 * FUNCTION NAME:
 *      msa_ctrl_UpdateTXEQ
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX EQ
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
static void msa_ctrl_UpdateTXEQ(UINT8 vChannel)
{
	UINT8 aCode[SYSTEM_CHANNEL_NUM];

	aCode[0] = CFG_GET_BIT(TX_Input_Equalization_CH1);
	aCode[1] = CFG_GET_BIT(TX_Input_Equalization_CH2);
	aCode[2] = CFG_GET_BIT(TX_Input_Equalization_CH3);
	aCode[3] = CFG_GET_BIT(TX_Input_Equalization_CH4);

	APT_MSA_CTRL_UpdateTXEQ(vChannel, aCode[vChannel]);
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      MSA_CTRL_ReadyState
 *
 * DESCRIPTION:
 *      Update Real-Time Control
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.7.25        Harry.Huang         Create/Update
 *****************************************************************************/
void MSA_CTRL_ReadyState(void)
{
	static UINT8	vChannel = 0;

	/* Update all channel, when transit from Low Power to Ready */
	if (bPowerUpFlag)
	{
		for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
		{
			msa_ctrl_UpdateRXSquelch(vChannel);
			msa_ctrl_UpdateTXSquelch(vChannel);
			msa_ctrl_UpdateRXCDRBypass(vChannel);
			msa_ctrl_UpdateTXCDRBypass(vChannel);
			msa_ctrl_UpdateRXRate(vChannel);
			msa_ctrl_UpdateTXRate(vChannel);
			msa_ctrl_UpdateRXEmphasis(vChannel);
			msa_ctrl_UpdateRXAmplitude(vChannel);
			msa_ctrl_UpdateTXEQ(vChannel);
		}

		vChannel = 0;

		bPowerUpFlag = FALSE;
	}
	else
	{
		msa_ctrl_UpdateRXSquelch(vChannel);
		msa_ctrl_UpdateTXSquelch(vChannel);
		msa_ctrl_UpdateRXCDRBypass(vChannel);
		msa_ctrl_UpdateTXCDRBypass(vChannel);
		msa_ctrl_UpdateRXRate(vChannel);
		msa_ctrl_UpdateTXRate(vChannel);
		msa_ctrl_UpdateRXEmphasis(vChannel);
		msa_ctrl_UpdateRXAmplitude(vChannel);
		msa_ctrl_UpdateTXEQ(vChannel);

		vChannel++;
		if (vChannel >= SYSTEM_CHANNEL_NUM)
		{
			vChannel = 0;
		}
	}

	msa_ctrl_UpdateRXOutput();
	msa_ctrl_UpdateTXOutput();
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_CTRL_PwrUpState
 *
 * DESCRIPTION:
 *      Power up state for MSA CTRL
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_CTRL_PwrUpState(void)
{
	bPowerUpFlag = TRUE;
}
#endif

