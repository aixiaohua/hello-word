/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_stm.c
 *
 * DESCRIPTION:
 *	 MSA state machine function
 *
 * HISTORY:
 *	 2018.7.20		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "msa.h"
#include "apt.h"
#include "app.h"

static MODULE_STATE_T msa_stm_State_Reset(void);
static MODULE_STATE_T msa_stm_State_MgmtInit(void);
static MODULE_STATE_T msa_stm_State_LowPwr(void);
static MODULE_STATE_T msa_stm_State_PwrUp(void);
static MODULE_STATE_T msa_stm_State_Ready(void);
static MODULE_STATE_T msa_stm_State_PwrDn(void);

static MODULE_STATE_T	vModuleStateCurrent;
static MODULE_STATE_T	vModuleStatePrev;

static __code MODULE_STATE_FUNC  aModuleStateTable[] =
{
	/* Note: The sequence should strictly the same with MODULE_STATE_T */
	msa_stm_State_Reset,
	msa_stm_State_MgmtInit,
	msa_stm_State_LowPwr,
	msa_stm_State_PwrUp,
	msa_stm_State_Ready,
	msa_stm_State_PwrDn,
};

/* state machine part API */
#if 1

/******************************************************************************
 * FUNCTION NAME:
 *		State_Reset_Handler
 * DESCRIPTION:
 *		Reset State Handler.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
#define State_Reset_Handler()		do {							\
										DRV_ResetState();			\
										CFG_ResetState();			\
									} while (0)

/******************************************************************************
 * FUNCTION NAME:
 *		State_MgmtInit_Handler
 * DESCRIPTION:
 *		Initialize State Handler.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
#define State_MgmtInit_Handler()	do {							\
										CFG_InitializeState();		\
										DRV_InitializeState();		\
										APT_MgmtInit();				\
										MSA_MgmtInit();				\
									} while (0)

/******************************************************************************
 * FUNCTION NAME:
 *		State_LowPwr_Handler
 * DESCRIPTION:
 *		Low-Power State Handler.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
#define State_LowPwr_Handler()		do {							\
										DRV_LowPowerState();		\
										DBG_LowPwrState();			\
										APT_LowPwrState();			\
										MSA_LowPwrState();			\
									} while (0)

/******************************************************************************
 * FUNCTION NAME:
 *		State_PwrUp_Handler
 * DESCRIPTION:
 *		High-Power-Up State Handler.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
#define State_PwrUp_Handler()		do {							\
										DRV_HighPowerUpState(); 	\
										APT_PwrUpState();			\
										MSA_PwrUpState();			\
										APP_PwrUpState();			\
									} while (0)

/******************************************************************************
 * FUNCTION NAME:
 *		State_Ready_Handler
 * DESCRIPTION:
 *		High-Power State Handler.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
#define State_Ready_Handler()		do {							\
										DRV_HighPowerState();		\
										DBG_ReadyState();			\
										APT_ReadyState();			\
										MSA_ReadyState();			\
										APP_ReadyState();			\
									} while (0)

/******************************************************************************
 * FUNCTION NAME:
 *		State_PwrDn_Handler
 * DESCRIPTION:
 *		High-Power-Down State Handler.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Downdate
 *****************************************************************************/
#define State_PwrDn_Handler() do {									\
										APP_PwrDnState();			\
										APT_PwrDnState();			\
										MSA_PwrDnState();			\
										DRV_HighPowerDownState();	\
									} while (0)

#endif

#if 1

static MODULE_STATE_T msa_stm_State_Reset(void)
{
	if (MSA_STM_GetPrevState() != MODULE_STATE_Reset)
	{
		/* Reset CPU */
		DRV_CPU_Reset();

		/* never reach here */
	}

	/* State machine handler part */
	State_Reset_Handler();

	/* Switch state machine */
	if (MSA_ISR_IsResetLAsserted())
	{
		return MODULE_STATE_Reset;
	}
	else
	{
		return MODULE_STATE_MgmtInit;
	}
}

static MODULE_STATE_T msa_stm_State_MgmtInit(void)
{
	/* State machine handler part */
	State_MgmtInit_Handler();

	/* Switch state machine */
	if (MSA_ISR_IsResetLAsserted())
	{
		return MODULE_STATE_Reset;
	}
	else
	{
		/* Globally enable interrupt */
		DRV_INT_GlobalEnableInterrupt();

		/* Wait for system interrupts have been serviced correctly */
		DRV_CPU_DelayMs(50);

		return MODULE_STATE_LowPwr;
	}
}

static MODULE_STATE_T msa_stm_State_LowPwr(void)
{
	/* State machine handler part */
	State_LowPwr_Handler();

	/* Switch state machine */
	if (MSA_ISR_IsResetLAsserted())
	{
		return MODULE_STATE_Reset;
	}
	else if (MSA_ISR_IsLPModeAsserted())
	{
		/* clear LPMode flag */
		MSA_ISR_DeassertLPMode();

		return MODULE_STATE_LowPwr;
	}
	else
	{
		return MODULE_STATE_PwrUp;
	}
}

static MODULE_STATE_T msa_stm_State_PwrUp(void)
{
	/* State machine handler part */
	State_PwrUp_Handler();

	/* Switch state machine */
	if (MSA_ISR_IsResetLAsserted() || MSA_ISR_IsLPModeAsserted())
	{
		return MODULE_STATE_PwrDn;
	}
	else
	{
		return MODULE_STATE_Ready;
	}
}

static MODULE_STATE_T msa_stm_State_Ready(void)
{
	/* State machine handler part */
	State_LowPwr_Handler();
	State_Ready_Handler();

	/* switch state machine */
	if (MSA_ISR_IsResetLAsserted() || MSA_ISR_IsLPModeAsserted())
	{
		return MODULE_STATE_PwrDn;
	}
	else
	{
		return MODULE_STATE_Ready;
	}
}

static MODULE_STATE_T msa_stm_State_PwrDn(void)
{
	/* State machine handler part */
	State_PwrDn_Handler();

	/* Switch state machine */
	if (MSA_ISR_IsResetLAsserted())
	{
		return MODULE_STATE_Reset;
	}
	else
	{
		return MODULE_STATE_LowPwr;
	}
}


/******************************************************************************
 * FUNCTION NAME:
 *		MSA_STM_GetPrevState
 *
 * DESCRIPTION:
 *		Get previous module state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.20		Harry.Huang 		Create/Update
 *****************************************************************************/
MODULE_STATE_T MSA_STM_GetPrevState(void)
{
	return vModuleStatePrev;
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_STM_GetCurrentState
 *
 * DESCRIPTION:
 *		Get current module state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.20		Harry.Huang 		Create/Update
 *****************************************************************************/
MODULE_STATE_T MSA_STM_GetCurrentState(void)
{
	return vModuleStateCurrent;
}
#endif

/******************************************************************************
 * FUNCTION NAME:
 *		main
 *
 * DESCRIPTION:
 *		System entry of C file.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		0
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
int main(void)
{
	MODULE_STATE_T vModuleState;

	/* power-on is reset state */
	vModuleStateCurrent = MODULE_STATE_Reset;
	vModuleStatePrev	= MODULE_STATE_Reset;

	/* dead loop here, system state machine handling */
	for (;;)
	{
		/* run system state machine */
		vModuleState = aModuleStateTable[vModuleStateCurrent]();
		vModuleStatePrev = vModuleStateCurrent;
		vModuleStateCurrent = vModuleState;

		/* record current system state */
		CFG_SET8(Debug_RT_GlobalStatus_StateMachine, vModuleState);
	}
}

