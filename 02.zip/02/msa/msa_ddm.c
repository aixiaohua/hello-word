/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 msa_ddm.c
 *
 * DESCRIPTION:
 *	 MSA DDM related function
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "apt_msa_ddm.h"

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		msa_ddm_UpdateTemp
 *
 * DESCRIPTION:
 *		Update temperature DDM value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_ddm_UpdateTemp(void)
{
	UINT16	vADValue;

	/* Get current temperature value */
	vADValue = APT_MSA_DDM_GetTemp();

	/* Set to SFF-8636 Area */
	CFG_SET16(RT_TEMP, vADValue);
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_ddm_UpdateVCC
 *
 * DESCRIPTION:
 *		Update temperature DDM value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_ddm_UpdateVCC(void)
{
	UINT16	vADValue;

	/* Get current Vcc value */
	vADValue = APT_MSA_DDM_GetVCC();

	/* Set to SFF-8636 Area */
	CFG_SET16(RT_VCC, vADValue);
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_ddm_UpdateTXBias
 *
 * DESCRIPTION:
 *		Update Tx Bias DDM value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_ddm_UpdateTXBias(void)
{
	UINT8	vChannel;
	UINT16	vADValue;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		vADValue = APT_MSA_DDM_GetTXBias(vChannel);

		/* Set to SFF-8636 Area */
		CFG_SETO16(RT_TXBIAS_CH1, vChannel*I2C_LEN(RT_TXBIAS_CH1), vADValue);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_ddm_UpdateTXPower
 *
 * DESCRIPTION:
 *		Update Tx Power DDM value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_ddm_UpdateTXPower(void)
{
	UINT8	vChannel;
	UINT16	vTxPower;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		vTxPower = APT_MSA_DDM_GetTXPWR(vChannel);

		/* Set to SFF-8636 Area */
		CFG_SETO16(RT_TXPWR_CH1, vChannel*I2C_LEN(RT_TXPWR_CH1), vTxPower);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		msa_ddm_UpdateRXPower
 *
 * DESCRIPTION:
 *		Update Rx Power DDM value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
void msa_ddm_UpdateRXPower(void)
{
	UINT8  vChannel;
	UINT16 vRxPower;

	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		vRxPower = APT_MSA_DDM_GetRXPower(vChannel);

		/* Set to SFF-8636 Area */
		CFG_SETO16(RT_RXPWR_CH1, vChannel*I2C_LEN(RT_RXPWR_CH1), vRxPower);
	}
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      MSA_DDM_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA DDM
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_DDM_PwrDnState(void)
{
	UINT8  vChannel;

	/* Clear TX Bias, TX Power, RX Power DDMI values */
	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		CFG_SETO16(RT_TXBIAS_CH1, vChannel * I2C_LEN(RT_TXBIAS_CH1), 0x00);
		CFG_SETO16(RT_TXPWR_CH1, vChannel * I2C_LEN(RT_TXPWR_CH1), 0x00);
		CFG_SETO16(RT_RXPWR_CH1, vChannel * I2C_LEN(RT_RXPWR_CH1), 0x00);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_DDM_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA DDM function
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_DDM_ReadyState(void)
{
	msa_ddm_UpdateTemp();
	msa_ddm_UpdateVCC();
	msa_ddm_UpdateTXBias();
	msa_ddm_UpdateTXPower();
	msa_ddm_UpdateRXPower();
}

/******************************************************************************
 * FUNCTION NAME:
 *		MSA_DDM_LowPwrState
 *
 * DESCRIPTION:
 *		Low Power state for MSA DDM function.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void MSA_DDM_LowPwrState(void)
{
	msa_ddm_UpdateTemp();
	msa_ddm_UpdateVCC();
}
#endif

