/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 drv.c
 * DESCRIPTION:
 *	 Driver Entry.
 * HISTORY:
 *	 2014.3.17		  Panda.Xiong		 Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_Retrieve
 * DESCRIPTION:
 *		N/A
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void DRV_Retrieve(void)
{
#if DRV_CDR_GN2104S_SUPPORT
	DRV_CDR_GN2104S_Retrieve();
#endif

#if DRV_CDR_MAOM037057_SUPPORT
	DRV_CDR_MAOM037057_Retrieve();
#endif
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_HighPowerDownState
 * DESCRIPTION:
 *		N/A
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void DRV_HighPowerDownState(void)
{
	/* power-down RX circuit */
	DRV_IO_Write(IO(IO_RXPWREN_OUT), LOW);
	DRV_IO_Write(IO(IO_RESET_RXCDR), LOW);

	/* power-down TX circuit */
	DRV_IO_Write(IO(IO_TXPWREN_OUT), LOW);
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_HighPowerState
 * DESCRIPTION:
 *		N/A
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void DRV_HighPowerState(void)
{
#if DRV_CDR_GN2104S_SUPPORT
	DRV_CDR_GN2104S_Entry();
#endif

#if DRV_CDR_MAOM037057_SUPPORT
	DRV_CDR_MAOM037057_Entry();
#endif
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_HighPowerUpState
 * DESCRIPTION:
 *		N/A
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void DRV_HighPowerUpState(void)
{
	/* enable global power */
	DRV_IO_Write(IO(IO_PowerEN_OUT), HIGH);
	DRV_CPU_DelayMs(10);

#if DRV_DAC_SUPPORT
	DRV_DAC_Init();
#endif

	/* power-up RX circuit */
	DRV_IO_Write(IO(IO_RXPWREN_OUT), HIGH);
	DRV_CPU_DelayMs(10);

	/* power-up TX circuit */
	DRV_IO_Write(IO(IO_TXPWREN_OUT), HIGH);
	DRV_CPU_DelayMs(10);

#if DRV_CDR_GN2104S_SUPPORT
	DRV_CDR_GN2104S_Init();
#endif

#if DRV_CDR_MAOM037057_SUPPORT
	DRV_CDR_MAOM037057_Init();
#endif
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_LowPowerState
 * DESCRIPTION:
 *		N/A
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void DRV_LowPowerState(void)
{
#if DRV_SWI_SUPPORT
	DRV_SWI_Entry();
#endif

#if DRV_WATCHDOG_SUPPORT
	DRV_WATCHDOG_Kick();
#endif

#if SYSTEM_TICK_SUPPORT
	DRV_Timer_UpdatePollingTime();
#endif
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_InitializeState
 * DESCRIPTION:
 *		N/A
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void DRV_InitializeState(void)
{
#if DRV_RESET_SUPPORT
	DRV_Reset_Init();
#endif

#if DRV_VECTOR_SUPPORT
	DRV_VECTOR_Init();
#endif

#if DRV_PLA_SUPPORT
	DRV_PLA_Init();
#endif

#if DRV_I2CM_SUPPORT
	DRV_I2CM_Init();
#endif

#if DRV_SPI_SUPPORT
	DRV_SPI_Init();
#endif

#if DRV_TIMER_SUPPORT
	DRV_Timer_Init();
#endif

#if DRV_SWI_SUPPORT
	DRV_SWI_Init();
#endif

#if DRV_VREF_SUPPORT
	DRV_VREF_Init();
#endif

#if DRV_ADC_SUPPORT
	DRV_ADC_Init();
#endif
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_ResetState
 * DESCRIPTION:
 *		N/A
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void DRV_ResetState(void)
{
	DRV_CPU_Init();

#if DRV_I2CS_SUPPORT
	DRV_I2CS_Init();
#endif

#if DRV_UART_SUPPORT
	DRV_UART_Init();
#endif

#if DRV_FLASH_SUPPORT
	DRV_Flash_Init();
#endif

#if DRV_WATCHDOG_SUPPORT
	DRV_WATCHDOG_Enable();
#endif

#if DRV_IO_SUPPORT
	DRV_IO_Init();
#endif
}

