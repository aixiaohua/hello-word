/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2010   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_dac.c
 * DESCRIPTION:
 *   DAC Driver.
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"

#if DRV_DAC_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_Get
 * DESCRIPTION:
 *      Get realtime DAC Value.
 * PARAMETERS:
 *      vSrc      : Chip id;
 *      vChannel  : DAC channel;
 *      pDacData  : DAC value;
 * RETURN:
 *      TRUE    : Read DAC success.
 *      FALSE   : Read DAC fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.3.16        Luke.Yu         Update
 *****************************************************************************/
BOOL DRV_DAC_Get(UINT8 vSrc, UINT8 vChannel, UINT16 *pDacData)
{
	switch (vSrc)
	{
		#if DRV_VDAC_SUPPORT
		case CHIP_ID_MCU_VDAC:
			return DRV_VDAC_Get(vChannel, pDacData);
		#endif

		#if DRV_IDAC_SUPPORT
        case CHIP_ID_MCU_IDAC:
            return DRV_IDAC_Get(vChannel, pDacData);
		#endif

		#if DRV_CDR_GN2104S_SUPPORT
        case CHIP_ID_GN2104S:
            return DRV_CDR_GN2104S_DAC_Get((DAC_TYPE_T)vChannel, pDacData);
		#endif

		#if DRV_CDR_MAOM037057_SUPPORT
		case CHIP_ID_MAOM037057:
			return DRV_CDR_MAOM037057_DAC_Get((DAC_TYPE_T)vChannel, pDacData);
		#endif
		
		#if DRV_DAC_AD5629R_SUPPORT
		case CHIP_ID_AD5629R:
			*pDacData = DRV_DAC_AD5629R_Get(vChannel);
			return TRUE;
		#endif

		#if DRV_DAC_AD5691R_SUPPORT
		case CHIP_ID_AD5691R:
			*pDacData = DRV_DAC_AD5691R_Get(vChannel);
			return TRUE;
		#endif

		default:
			*pDacData = 0x00;
			return FALSE;
	}
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_Set
 * DESCRIPTION:
 *      Set realtime DAC Value.
 * PARAMETERS:
 *      vSrc      : Chip id;
 *      vChannel  : DAC channel;
 *      DacData   : DAC value;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.3.16        Luke.Yu         Update
 *****************************************************************************/
void DRV_DAC_Set(UINT8 vSrc, UINT8 vChannel, UINT16 vDacData)
{
	switch (vSrc)
	{
		#if DRV_VDAC_SUPPORT
		case CHIP_ID_MCU_VDAC:
			DRV_VDAC_Set(vChannel, vDacData);
			break;
		#endif

		#if DRV_IDAC_SUPPORT
		case CHIP_ID_MCU_IDAC:
			DRV_IDAC_Set(vChannel, vDacData);
			break;
		#endif

		#if DRV_CDR_GN2104S_SUPPORT
        case CHIP_ID_GN2104S:
            DRV_CDR_GN2104S_DAC_Set((DAC_TYPE_T)vChannel, vDacData);
			break;
		#endif

		#if DRV_CDR_MAOM037057_SUPPORT
		case CHIP_ID_MAOM037057:
			DRV_CDR_MAOM037057_DAC_Set((DAC_TYPE_T)vChannel, vDacData);
			break;
		#endif
		
		#if DRV_DAC_AD5629R_SUPPORT
		case CHIP_ID_AD5629R:
			DRV_DAC_AD5629R_Set(vChannel, vDacData);
			break;
		#endif

		#if DRV_DAC_AD5691R_SUPPORT
		case CHIP_ID_AD5691R:
			DRV_DAC_AD5691R_Set(vChannel, vDacData);
			break;
		#endif

		default:
			break;
	}
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_Init
 * DESCRIPTION:
 *      DAC driver init.
 * PARAMETERS:
 *      N/A;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_DAC_Init(void)
{	
  #if DRV_VDAC_SUPPORT
	DRV_VDAC_Init();
  #endif

  #if DRV_IDAC_SUPPORT
	DRV_IDAC_Init();
  #endif

  #if DRV_DAC_AD5629R_SUPPORT
	DRV_DAC_AD5629R_Init();
  #endif

  #if DRV_DAC_AD5691R_SUPPORT
	DRV_DAC_AD5691R_Init();
  #endif
}

#endif

