/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2010   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_dac.h
 * DESCRIPTION:
 *   DAC Driver.
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_DAC_H
#define __DRV_DAC_H


#if DRV_DAC_SUPPORT
 
#define DAC_CH_S(name)		COMBINE(DAC_CH_S_, name)
#define DAC_CH_N(name)		COMBINE(DAC_CH_N_, name)
#define DAC(name)			DAC_CH_S(name), DAC_CH_N(name) 

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_Get
 * DESCRIPTION:
 *      Get realtime DAC Value.
 * PARAMETERS:
 *      vSrc      : Chip id;
 *      vChannel  : DAC channel;
 *      pDacData  : DAC value;
 * RETURN:
 *      TRUE    : Read DAC success.
 *      FALSE   : Read DAC fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.3.16        Luke.Yu         Update
 *****************************************************************************/
BOOL DRV_DAC_Get(UINT8 vSrc, UINT8 vChannel, UINT16 *pDacData);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_Set
 * DESCRIPTION:
 *      Set realtime DAC Value.
 * PARAMETERS:
 *      vSrc      : Chip id;
 *      vChannel  : DAC channel;
 *      DacData   : DAC value;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.3.16        Luke.Yu         Update
 *****************************************************************************/
void DRV_DAC_Set(UINT8 vSrc, UINT8 vChannel, UINT16 vDacData);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_Init
 * DESCRIPTION:
 *      DAC driver init.
 * PARAMETERS:
 *      N/A;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_DAC_Init(void);

#endif


#endif /* __DRV_DAC_H */

