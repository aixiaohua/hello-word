/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_vref.c
 * DESCRIPTION:
 *   Voltage Reference driver.
 * HISTORY:
 *   2014.6.18        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_VREF_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VREF_Init
 * DESCRIPTION:
 *      Voltage Reference init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_VREF_Init(void)
{
    /* powe-up internal reference */
    ADCCON_REFB_PUP_BBA = 1;

    /* delay for reference power-up */
    DRV_CPU_DelayMs(DRV_VREF_PowerUpTime);

    /* select internal reference */
    AFEREFC_REF_BBA = 0;

    /* power-up 2.5V reference buffer */
    AFEREFC_B2V5R_PD_BBA = 0;

    /* power-up 2.5V reference output driving buffer B */
    AFEREFC_B2MA_PDB_BBA = 1;

    /* power-up 1.2V bandgap */
    AFEREFC_BG_PD_BBA = 0;
}

#endif

