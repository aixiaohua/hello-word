/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_flash.h
 * DESCRIPTION:
 *   Flash driver.
 * HISTORY:
 *   2014.6.23        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#ifndef __DRV_FLASH_H
#define __DRV_FLASH_H


#if DRV_FLASH_SUPPORT

/* flash key related,
 *  see "Table 303" of "ADuCM320_UG-498.pdf" for details.
 */
#define FLASH_IsSwapped()       (FEECON1_SWAP_BBA == 1)
#define FLASH_KEY1              (0x1DFE0)   /* KEY1  */
#define FLASH_KEY2              (0x1DFE8)   /* KEY2  */
#define FLASH_KEY1_             (0x3DFE0)   /* KEY1' */
#define FLASH_KEY2_             (0x3DFE8)   /* KEY2' */
#define FLASH_K1B0              (FLASH_IsSwapped()? FLASH_KEY1_ : FLASH_KEY1 )
#define FLASH_K2B0              (FLASH_IsSwapped()? FLASH_KEY2_ : FLASH_KEY2 )
#define FLASH_K1B1              (FLASH_IsSwapped()? FLASH_KEY1  : FLASH_KEY1_)
#define FLASH_K2B1              (FLASH_IsSwapped()? FLASH_KEY2  : FLASH_KEY2_)
#define FLASH_SET_KEY(_addr, _v)    do {                                    \
                                        UINT8   _buf[4];                    \
                                        SET_LE_32(_buf, (UINT32)(_v));      \
                                        FLASH_MEMCPY((_addr),               \
                                                     _buf,                  \
                                                     sizeof(_buf));         \
                                    } while (0)
#define FLASH_GET_KEY(_addr)        ((SINT32)(VP32(_addr)))


/* flash basic external API */
#define FLASH_MEMDMP(_dst, _src, _len)  memcpy((UINT8 *)(_dst),             \
                                               (const UINT8 *)(_src),       \
                                               (SINT32)(_len))
#define FLASH_MEMCPY(_dst, _src, _len)  DRV_Flash_Update(                   \
                                                    (UINT32)(_dst),         \
                                                    (UINT32)(_len),         \
                                                    FALSE,                  \
                                                    (const UINT8 *)(_src))
#define FLASH_MEMSET(_dst, _val, _len)  do {                                \
                                            UINT8   _v = (UINT8)(_val);     \
                                            DRV_Flash_Update(               \
                                                    (UINT32)(_dst),         \
                                                    (UINT32)(_len),         \
                                                    TRUE,                   \
                                                    &_v);                   \
                                        } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_Update
 * DESCRIPTION:
 *      Flash update driver.
 *      i.e., if the update area is not empty, will auto-erase it,
 *            then write the new data into it.
 * PARAMETERS:
 *      vAddr   : Flash Address.
 *      vLen    : Flash Update Data Length.
 *      bMemset : =TRUE, memset flash area, the memset data should be *pBuf.
 *      pBuf    : Flash Update Data Buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      Support update one or more flash pages.
 * HISTORY:
 *      2015.1.16        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Flash_Update
(
    IN       UINT32  vAddr,
    IN       UINT32  vLen,
    IN       BOOL    bMemset,
    IN const UINT8  *pBuf
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_Init
 * DESCRIPTION:
 *      Flash init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.2        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_Flash_Init(void);

#if SECURE_MODE_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_EnterDownloadMode
 * DESCRIPTION:
 *      Enter download mode.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.11.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_Flash_EnterDownloadMode(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_IsSecureMode
 * DESCRIPTION:
 *      Check whether flash is in Secure Mode.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      TRUE : Flash is in Secure Mode;
 *      FALSE: Flash is not in Secure Mode;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.11.7        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Flash_IsSecureMode()        (FALSE)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_EnterSecureMode
 * DESCRIPTION:
 *      Enter Secure Mode.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.11.7        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Flash_EnterSecureMode()     /* do nothing */

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_ExitSecureMode
 * DESCRIPTION:
 *      Exit Secure Mode.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.11.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_Flash_ExitSecureMode(void);

#endif

#endif


#endif /* __DRV_FLASH_H */

