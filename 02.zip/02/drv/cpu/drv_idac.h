/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_vdac.h
 * DESCRIPTION:
 *   VDAC Driver.
 * HISTORY:
 *   2017.4.26        Melinda.Lu           Create/Update
 *
*****************************************************************************/

#ifndef __DRV_IDAC_H__
#define __DRV_IDAC_H__


#if DRV_IDAC_SUPPORT

#define _IDAC(_ch) 					_ch

/* DAC channel definition */
#define DECLARE_IDAC(_name, _src, _ch, _cfg, _init, _desc)                 \
                                    DAC_CH_S(_name) = (_src),              \
                                    DAC_CH_N(_name) = (_ch),
typedef enum
{
    #include "def_hardware.h"
} DAC_IDAC_CH_T;
#undef DECLARE_IDAC


typedef enum
{
	IDAC_CH0 = 0,
	IDAC_CH1,
	IDAC_CH2,
	IDAC_CH3,
	IDAC_CH_MAX
} DRV_IDAC_CH_T;

#define DRV_IDAC_Resolution     	14
#define DRV_IDAC_MaxValue       	0x3FFF

/* IDAC voltage output settling timing */
#define DRV_IDAC_SettlingTime_1   	100      /* us, to 0.1% */
#define DRV_IDAC_SettlingTime_2   	50       /* us, to 1%   */
#define DRV_IDAC_SettlingTime_3   	25       /* us, Full Scale to 0mA */

/* IDACxCON register */
#define IDAC_PDOWN_BIT     			0       /* IDACx power-down bit */
 #define IDAC_POWER_DOWN			(1<<IDAC_PDOWN_BIT)
 #define IDAC_POWER_UP				(0<<IDAC_PDOWN_BIT)
#define IDAC_ENABLE_BIT				7		/* IDACx clear bit      */
 #define IDAC_ENABLE				(1<<IDAC_ENABLE_BIT)
 #define IDAC_DISABLE				(0<<IDAC_ENABLE_BIT)
#define IDAC_AUTOSHUTDOWN_BIT		6		/* IDACx automatic shut down in case of overtemperature bit */
 #define IDAC_AUTOSHUTDOWN_EN		(1<<IDAC_AUTOSHUTDOWN_BIT)
 #define IDAC_AUTOSHUTDOWN_DIS		(0<<IDAC_AUTOSHUTDOWN_BIT)
#define IDAC_PULLDOWN_BIT			1		/* IDACx pull-down current source bit */
 #define IDAC_PULLDOWN_EN			(1<<IDAC_PULLDOWN_BIT)
 #define IDAC_PULLDOWN_DIS			(0<<IDAC_PULLDOWN_BIT)
#define IDAC_BANDWIDTH_BIT			2		/* IDACx bandwidth setting bits */
 #define IDAC_BANDWIDTH_262KHZ		(0<<IDAC_BANDWIDTH_BIT)		/* R = 60,    Fc = 262kHz */
 #define IDAC_BANDWIDTH_2dot8KHZ  	(5<<IDAC_BANDWIDTH_BIT)	    /* R = 5.6k,  Fc = 2.8kHz */
 #define IDAC_BANDWIDTH_1dot4KHZ  	(6<<IDAC_BANDWIDTH_BIT)	    /* R = 11.2k, Fc = 1.4kHz */
 #define IDAC_BANDWIDTH_715HZ  		(7<<IDAC_BANDWIDTH_BIT)	    /* R = 22.2k, Fc = 715Hz  */
 #define IDAC_BANDWIDTH_357HZ  		(8<<IDAC_BANDWIDTH_BIT)	    /* R = 44.4k, Fc = 357Hz  */
 #define IDAC_BANDWIDTH_153HZ  		(9<<IDAC_BANDWIDTH_BIT)	    /* R = 104k,  Fc = 153Hz  */

/* 14-bit IDAC:
 * The IDAC output is controlled by an internal 11-bit and 5-bit DAC;
 * The 11-bit DAC(IDACxDAT[27:17]) controls the most significant bits.
 * The 5-bit DAC(IDACxDAT[16:12]) controls the LSBs;
 * The two MSBs of the 5-bit DAC(IDACxDAT[16:15]) overlap the two LSBs of the 11-bit DAC(IDACxDAT[18:17].
 * 14-BIT IDAC OUTPUT  13 12 11 10 9  8  7  6  5  4  3  2  1  0
 * 11-BIT DAC IDACxDAT 27 26 25 25 23 22 21 20 19 18 17
 * 5 -BIT DAC                                     16 15 14 13 12
 */
#define IDACDAT_DATH_START_BIT 		   	17
#define IDACDAT_DATL_START_BIT 		   	12
#define IDACDAT_DATHL_MASK_BIT			((UINT32)0xFFFF << IDACDAT_DATL_START_BIT)
#define IDACDAT_MASK_DATHL(_vData)		((UINT32)(_vData) & ~IDACDAT_DATHL_MASK_BIT)

#define GET_IDACDAT_DATH(_data)			(((_data) >> 3) & 0x7FF)
#define GET_IDACDAT_DATL(_data)			((_data) & 0x1F)

typedef struct
{
   UINT32    IDACDAT;     /* IDAC data register    */
   UINT8     IDACCON;     /* IDAC control register */
   UINT8     Reserved[3];
} DRV_IDAC_BANK_T;

typedef struct
{
   DRV_IDAC_BANK_T IDACxREG[IDAC_CH_MAX];
} DRV_IDAC_REG_T;

#define DRV_IDAC_REG_BASE_ADDR	(0x40086800UL)
#define IDAC_REG             	((volatile DRV_IDAC_REG_T *)(DRV_IDAC_REG_BASE_ADDR))
#define IDAC_CONTROL(_ch)  		(IDAC_REG->IDACxREG[(_ch)].IDACCON)
#define IDAC_DAT(_ch)      		(IDAC_REG->IDACxREG[(_ch)].IDACDAT)

/* convert IDAC output to the format of IDACxDAT */
#define GET_IDACDAT(_data)				(((UINT32)GET_IDACDAT_DATH(_data) << IDACDAT_DATH_START_BIT) \
                                         | ((UINT32)GET_IDACDAT_DATL(_data) << IDACDAT_DATL_START_BIT))

/* convert IDACxDAT to the format of IDAC output */
#define GET_IDACOUT(_data)				(((((_data) >> IDACDAT_DATH_START_BIT) & 0x7FF) << 3) \
	                                     | (((_data) >> IDACDAT_DATL_START_BIT) & 0x07 ))

/* internl IDAC API */
#define drv_idac_Get(_ch)				(GET_IDACOUT(IDAC_DAT(_ch)))
#define drv_idac_SetConfig(_ch, _data)	do { IDAC_CONTROL(_ch) = (UINT8)(_data); } while (0)
#define drv_idac_Set(_ch, _data)	    do { IDAC_DAT(_ch) = (UINT32)GET_IDACDAT(_data); } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *		DRV_IDAC_Get
 * DESCRIPTION:
 *		Get IDAC Data;
 * PARAMETERS:
 *		vChannel: channel
 *		vData	: data to be set;
 * RETURN:
 *		TRUE/FALSE
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.4.27		 Melinda.Lu 		Create/Update
 *****************************************************************************/
BOOL DRV_IDAC_Get
(
	IN UINT8  vChannel,
	IN UINT16 *pData
);

/******************************************************************************
 * FUNCTION NAME:
 *		DRV_IDAC_Set
 * DESCRIPTION:
 *		Set IDAC Data;
 * PARAMETERS:
 *		vData : data to be set;
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.4.27		 Melinda.Lu 		Create/Update
 *****************************************************************************/
void DRV_IDAC_Set
(
	IN UINT8  vChannel,
	IN UINT16 vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IDAC_Init
 * DESCRIPTION:
 *      IDAC driver init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.26        Melinda.Lu           Create/Update
 *****************************************************************************/
void DRV_IDAC_Init(void);

#endif
#endif

