/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_swi.h
 * DESCRIPTION:
 *   Enhanced Software Interrupt Handler.
 * HISTORY:
 *   2013.7.26        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#ifndef __DRV_SWI_H__
#define __DRV_SWI_H__


#if DRV_SWI_SUPPORT

/* SWI type definition */
typedef enum
{
    SWI_TYPE_FAST = 0,  /* fast responding SWI (in interrupt)   */
    SWI_TYPE_SLOW,      /* slow responding SWI (in back-ground) */
} SWI_TYPE_T;

/* SWI name definition */
#define SWI(n)        COMBINE(SWI_, n)
#define DECLARE_VECTOR_SWI(_name, _callback, _type, _desc)  SWI(_name),
typedef enum
{
    DRV_SWI_NAME_START = -1,
    #include "def_vector.h"
    DRV_SWI_NAME_END
} DRV_SWI_NAME_T;
#undef  DECLARE_VECTOR_SWI

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_SetInterrupt
 * DESCRIPTION:
 *      Set SWI Interrupt Flag.
 * PARAMETERS:
 *      vName  : SWI Name;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_SetInterrupt(IN DRV_SWI_NAME_T vName);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_SetState
 * DESCRIPTION:
 *      Set SWI State.
 * PARAMETERS:
 *      vName  : SWI Name;
 *      vState : ENABLE/DISABLE.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_SetState
(
    IN DRV_SWI_NAME_T   vName,
    IN BOOL             bState
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_ISR
 * DESCRIPTION:
 *      SWI ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_ISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_Entry
 * DESCRIPTION:
 *      SWI Entry.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.19        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_Entry(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_Init
 * DESCRIPTION:
 *      SWI Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_Init(void);

#endif
#endif

