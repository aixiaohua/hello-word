/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_swi.c
 * DESCRIPTION:
 *   Enhanced Software Interrupt Handler.
 * HISTORY:
 *   2013.7.26        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "msa.h"

#if DRV_SWI_SUPPORT

/* SWI configuration table */
#define DECLARE_VECTOR_SWI(_name, _callback, _type, _desc)  { (_callback), (_type), },
typedef void (*SWI_HANDLER_FUNC)(void);
static struct
{
    SWI_HANDLER_FUNC    pHandler;
    SWI_TYPE_T          vType;
} __code aSwiCfgTable[] =
{
    #include "def_vector.h"
};
#undef  DECLARE_VECTOR_SWI

/* SWI real-time table */
#define DECLARE_VECTOR_SWI(_name, _callback, _type, _desc)  { DISABLE, FALSE, },
static struct
{
    BOOL    bEnable  : 1;
    BOOL    bIntFlag : 1;
} aSwiRTTable[] =
{
    #include "def_vector.h"
};
#undef  DECLARE_VECTOR_SWI


/******************************************************************************
 * FUNCTION NAME:
 *      drv_swi_Dispatcher
 * DESCRIPTION:
 *      SWI Dispatcher.
 * PARAMETERS:
 *      vType : Only dispatch SWIs with this type.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.19        Panda.Xiong         Create/Update
 *****************************************************************************/
static void drv_swi_Dispatcher(IN SWI_TYPE_T vType)
{
    SINT32  vLoop;

    for (vLoop = 0; vLoop < COUNT_OF(aSwiRTTable); vLoop++)
    {
        if ((aSwiRTTable[vLoop].bEnable == ENABLE)
            && (aSwiCfgTable[vLoop].vType == vType))
        {
            if (aSwiRTTable[vLoop].bIntFlag)
            {
                /* handle this software interrupt */
                aSwiCfgTable[vLoop].pHandler();

                /* clear this software interrupt flag */
                aSwiRTTable[vLoop].bIntFlag = FALSE;
            }
        }
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_SetInterrupt
 * DESCRIPTION:
 *      Set SWI Interrupt Flag.
 * PARAMETERS:
 *      vName  : SWI Name;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_SetInterrupt(IN DRV_SWI_NAME_T vName)
{
    /* set SWI interrupt flag */
    aSwiRTTable[vName].bIntFlag = TRUE;

    /* only set SWI global interrupt,
     * while this SWI is enabled, and it needs fast reponding.
     */
    if ((aSwiRTTable[vName].bEnable == ENABLE)
        && (aSwiCfgTable[vName].vType == SWI_TYPE_FAST))
    {
      #if DRV_VECTOR_SUPPORT
        /* set SWI global interrupt */
        DRV_VECTOR_SetInterrupt(VECTOR(Vector_SWI));
      #endif
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_SetState
 * DESCRIPTION:
 *      Set SWI State.
 * PARAMETERS:
 *      vName  : SWI Name;
 *      vState : ENABLE/DISABLE.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_SetState
(
    IN DRV_SWI_NAME_T   vName,
    IN BOOL             bState
)
{
    /* clear SWI flag */
    aSwiRTTable[vName].bIntFlag = FALSE;

    /* set SWI state */
    aSwiRTTable[vName].bEnable  = bState;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_ISR
 * DESCRIPTION:
 *      SWI ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_ISR(void)
{
  #if DRV_VECTOR_SUPPORT
    /* clear SWI global interrupt flag */
    DRV_VECTOR_ClearInterrupt(VECTOR(Vector_SWI));
  #endif

    /* dispatch fast SWI */
    drv_swi_Dispatcher(SWI_TYPE_FAST);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_Entry
 * DESCRIPTION:
 *      SWI Entry.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.19        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_Entry(void)
{
    /* dispatch slow SWI */
    drv_swi_Dispatcher(SWI_TYPE_SLOW);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SWI_Init
 * DESCRIPTION:
 *      SWI Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2012.3.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SWI_Init(void)
{
  #if DRV_VECTOR_SUPPORT
    /* enable SWI global interrupt */
    DRV_VECTOR_EnableInterrupt(VECTOR(Vector_SWI));
  #endif
}

#endif

