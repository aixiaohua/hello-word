/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * MODULE NAME:
 *   drv_pla.h
 * DESCRIPTION:
 *   PLA(Programmable Logic Array) driver.
 * HISTORY:
 *   2014.08.26        Panda.Xiong         Create/Update
 *
******************************************************************************/

#ifndef __DRV_PLA_H__
#define __DRV_PLA_H__


#if DRV_PLA_SUPPORT

/* PLA block clock source */
#define PLA_CLK_BLOCK_P0_3          (0x0) /* GPIO clock on P0.3       */
#define PLA_CLK_BLOCK_P1_1          (0x1) /* GPIO clock on P1.1       */
#define PLA_CLK_BLOCK_P2_0          (0x2) /* GPIO clock on P2.0       */
#define PLA_CLK_BLOCK_HCLK          (0x3) /* HCLK                     */
#define PLA_CLK_BLOCK_MOSC          (0x4) /* MOSC (16 MHz)            */
#define PLA_CLK_BLOCK_T0            (0x5) /* Timer 0                  */
#define PLA_CLK_BLOCK_T2            (0x6) /* Timer 2                  */
#define PLA_CLK_BLOCK_KOSC          (0x7) /* KOSC (32 kHz)            */

#define _PLA_BLOCK(n)               n
#define _PLA_ELEMENT(n)             n
#define _PLA_ELEMENT_ID(b, n)       ((b)*8 + (n))
#define __PLA_REG_ADDR(reg, n)      ((UINT32)&(pADI_PLA->reg) + (((n)<<1)&0x4))
#define __PLA_BLOCK(name)           COMBINE(PLA_BLOCK_,   name)
#define __PLA_ELEMENT(name)         COMBINE(PLA_ELEMENT_, name)
#define __PLA_ELEMENT_ID(name)      _PLA_ELEMENT_ID(__PLA_BLOCK(name), __PLA_ELEMENT(name))
#define PLA(name)                   name

/* PLA element definition */
#define DECLARE_PLA_ELEMENT(block, element, in, out, init, desc)            \
                                           __PLA_BLOCK(in)    = (block),    \
                                           __PLA_ELEMENT(in)  = (element),  \
                                           __PLA_BLOCK(out)   = (block),    \
                                           __PLA_ELEMENT(out) = (element),
typedef enum
{
    #include "def_hardware.h"
} PLA_ELEMENT_T;
#undef DECLARE_PLA_ELEMENT


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_PLA_SetDIN
 * DESCRIPTION:
 *      Set PLADIN value.
 * PARAMETERS:
 *      _name : PLADIN name;
 *      _data : PLADIN value to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.08.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_PLA_SetDIN(_name, _data)    BITBAND_WRITE_BIT(__PLA_REG_ADDR(PLA_DIN0, __PLA_BLOCK(_name)),     \
                                                          __PLA_ELEMENT_ID(_name) & 0xFFFF,                 \
                                                          (_data))

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_PLA_GetDIN
 * DESCRIPTION:
 *      Get PLADIN value.
 * PARAMETERS:
 *      _name : PLADIN name;
 * RETURN:
 *      PLADIN value.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.08.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_PLA_GetDIN(_name)           BITBAND_READ_BIT(__PLA_REG_ADDR(PLA_DIN0, __PLA_BLOCK(_name)),      \
                                                         __PLA_ELEMENT_ID(_name) & 0xFFFF)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_PLA_GetDOUT
 * DESCRIPTION:
 *      Get PLADOUT value.
 * PARAMETERS:
 *      _name : PLADOUT name;
 * RETURN:
 *      PLADOUT value.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.08.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_PLA_GetDOUT(_name)           BITBAND_READ_BIT(__PLA_REG_ADDR(PLA_DOUT0, __PLA_BLOCK(_name)),    \
                                                          __PLA_ELEMENT_ID(_name) & 0xFFFF)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_PLA_Init
 * DESCRIPTION:
 *      PLA Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.08.26        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_PLA_Init(void);

#endif


#endif  /* __DRV_PLA_H */

