/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_i2cm.h
 * DESCRIPTION:
 *   I2C Master Driver.
 * HISTORY:
 *   2013.6.7        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#ifndef __DRV_I2CM_H
#define __DRV_I2CM_H


#if DRV_I2CM_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_Read
 * DESCRIPTION:
 *      Read one or more bytes, with/without offset.
 * PARAMETERS:
 *      vI2cAddr   : I2C slave chip address.
 *      vOffsetLen : offset buffer length to be send.
 *      aOffsetBuf : offset buffer.
 *      vDataLen   : data length to be read.
 *      aDataBuf   : data buffer.
 * RETURN:
 *      TRUE   : read success.
 *      FALSE  : read fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_Read
(
    IN       UINT8      vI2cAddr,
    IN       UINT8      vOffsetLen,
    IN const UINT8     *aOffsetBuf,
    IN       UINT16     vDataLen,
    OUT      UINT8     *aDataBuf
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_WriteBytes
 * DESCRIPTION:
 *      Write one or more bytes, with/without offset.
 * PARAMETERS:
 *      vI2cAddr    : I2C slave chip address.
 *      vOffsetLen  : offset buffer length to be send.
 *      aOffsetBuf  : offset buffer.
 *      aDataBuf    : data length to be write.
 *      data_buf    : data buffer.
 * RETURN:
 *      TRUE   : write success.
 *      FALSE  : write fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_Write
(
    IN       UINT8      vI2cAddr,
    IN       UINT8      vOffsetLen,
    IN const UINT8     *aOffsetBuf,
    IN       UINT16     vDataLen,
    IN const UINT8     *aDataBuf
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_ReadBytes
 * DESCRIPTION:
 *      Random read one or more bytes.
 * PARAMETERS:
 *      vI2cAddr   : I2C slave chip address.
 *      vOffset    : Read start offset.
 *      vDataLen   : data length to be read.
 *      aDataBuf   : data buffer.
 * RETURN:
 *      TRUE   : read success.
 *      FALSE  : read fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_ReadBytes
(
    IN  UINT8   vI2cAddr,
    IN  UINT8   vOffset,
    IN  UINT16  vDataLen,
    OUT UINT8  *aDataBuf
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_WriteBytes
 * DESCRIPTION:
 *      Random write one or more bytes.
 * PARAMETERS:
 *      vI2cAddr : I2C slave chip address.
 *      vOffset  : I2C offset.
 *      vDataLen : I2C data length.
 *      aDataBuf : I2C data buffer.
 * RETURN:
 *      TRUE   : write success.
 *      FALSE  : write fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_WriteBytes
(
    IN       UINT8      vI2cAddr,
    IN       UINT8      vOffset,
    IN       UINT16     vDataLen,
    IN const UINT8     *aDataBuf
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_WriteByte
 * DESCRIPTION:
 *      Random write one or more bytes.
 * PARAMETERS:
 *      vI2cAddr : I2C slave chip address.
 *      vOffset  : offset buffer length to be send.
 *      vData    : data buffer.
 * RETURN:
 *      TRUE   : write success.
 *      FALSE  : write fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_WriteByte
(
    IN       UINT8       vI2cAddr,
    IN       UINT8       vOffset,
    IN       UINT8       vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_ReadByte
 * DESCRIPTION:
 *      Random read byte.
 * PARAMETERS:
 *      vI2cAddr : I2C slave chip address.
 *      vOffset  : Read start offset.
 *      pData    : data buffer.
 * RETURN:
 *      TRUE   : read success.
 *      FALSE  : read fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
#define DRV_I2CM_ReadByte(_vI2cAddr, _vOffset, _pData)                     \
    DRV_I2CM_ReadBytes((_vI2cAddr), (_vOffset), 1, (_pData))

/*******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_Detect
 * DESCRIPTION:
 *      I2C detect chip.
 * PARAMETERS:
 *      vI2cAddr : I2C chip address.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_Detect(IN UINT8 vI2cAddr);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_Init
 * DESCRIPTION:
 *      I2C init driver.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
void DRV_I2CM_Init(void);

#endif


#endif /* __DRV_I2CM_H */

