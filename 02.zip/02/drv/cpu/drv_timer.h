/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_timer.h
 * DESCRIPTION:
 *   N/A
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_TIMER_H__
#define __DRV_TIMER_H__


#if DRV_TIMER_SUPPORT

/* timer counter format definition,
 * if want to support longer timer, change this type definition.
 */
typedef UINT32  DRV_TIMER_COUNTER_T;

#define DRV_Timer_SystemTickValue       1       /* ms */
#define DRV_Timer_SysTickInterval       1       /* ms */

#define DRV_Timer_IsTimeout()           READ_BIT(SysTick->CTRL, 16)
#define DRV_Timer_ClearTimeoutFlag()    CLR_BIT(SCB->ICSR, 25)
#define DRV_Timer_Enable()              do { SysTick->VAL  = 0x0000; SysTick->CTRL = 0x0007; } while (0)
#define DRV_Timer_Disable()             do { SysTick->CTRL = 0x0000; SysTick->VAL  = 0x0000; } while (0)

#define TIMER_US(x)     (DRV_TIMER_COUNTER_T)(((x)/1000+DRV_Timer_SysTickInterval-1)/DRV_Timer_SysTickInterval)
#define TIMER_MS(x)     (DRV_TIMER_COUNTER_T)(((x)+DRV_Timer_SysTickInterval-1)/DRV_Timer_SysTickInterval)

/* timer name definition */
#define TIMER(n)        COMBINE(TIMER_, n)
#define DECLARE_VECTOR_TIMER(_name, _tick, _callback, _desc)    TIMER(_name),
typedef enum
{
    DRV_TIMER_NAME_START = -1,
    #include "def_vector.h"
    DRV_TIMER_NAME_END
} DRV_TIMER_NAME_T;
#undef  DECLARE_VECTOR_TIMER


#if SYSTEM_TICK_SUPPORT

/* Real-Time System Tick Counter */
typedef UINT32  SYSTICK_T;
extern volatile SYSTICK_T   vSystemTickCount;
extern volatile SINT16      vDelayTickCount;

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_GetSystemTick
 * DESCRIPTION:
 *      Get current System Tick.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      Current System Tick value.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_Timer_GetSystemTick()       (vSystemTickCount)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_UpdateSystemTick
 * DESCRIPTION:
 *      Update System Tick, every time update 1 tick.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_Timer_UpdateSystemTick()                                        \
    do {                                                                    \
        DRV_Timer_GetSystemTick()++;                                        \
        CFG_SET32(System_RT_Tick_Count, DRV_Timer_GetSystemTick());         \
        vDelayTickCount--;                                                  \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_UpdatePollingTime
 * DESCRIPTION:
 *      Update Polling Time.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_Timer_UpdatePollingTime()                                       \
    do {                                                                    \
        static SYSTICK_T    _prev_tick = 0;                                 \
        SYSTICK_T           _curr_tick = DRV_Timer_GetSystemTick();         \
                                                                            \
	    CFG_SET8(System_RT_Polling_Time, (_curr_tick - _prev_tick));		\
        _prev_tick = _curr_tick;                                            \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_SystemTick_Timer
 * DESCRIPTION:
 *      System Tick Timer ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_SystemTick_Timer(void);

#endif

/* Time-Measure Usage:
 *
 *  For short time measuring:
 *   add below line at the test start point:
 *      DRV_Timer_ShortTimeMeasure_Start();
 *   and, during testing, you can get the currently elapsed time:
 *      elapsed_time = DRV_Timer_ShortTimeMeasure_Elasped();
 *   and, at the test end point, you can get the total elapsed time
 *    as following: (unit of 1us)
 *      elapsed_time = DRV_Timer_ShortTimeMeasure_Stop();
 *
 *  For long time measuring:
 *   add below line at the test start point:
 *      DRV_Timer_LongTimeMeasure_Start();
 *   and, during testing, you can get the currently elapsed time:
 *      elapsed_time = DRV_Timer_ShortTimeMeasure_Elasped();
 *   and, at the test end point, you can get the total elapsed time
 *    as following: (unit of 1ms)
 *      elapsed_time = DRV_Timer_LongTimeMeasure_Stop();
 *
 * Note:
 *  The Time-Measure uses the Timer 1 as short time measuring.
 */
#if TIME_MEASURE_SUPPORT

/* for timer measure internal usage only */
_DRV_TIMER_EXTERN_          UINT32      vShortTimeMeasureStop;
_DRV_TIMER_EXTERN_ volatile SYSTICK_T   vLongTimeMeasureStart;

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_ShortTimeMeasure_Start
 * DESCRIPTION:
 *      Short Time-Measure Start.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      Used to record the start of Time-Measure.
 *      This is only used for short time measuring,
 *       maximum timing: ~(2^32-1)us.
 *      But, you must make sure API DRV_Timer_ShortTimeMeasure_Elasped()
 *       be called within every ~65.535ms,
 *       else, the elasped time will be inaccurate.
 * HISTORY:
 *      2014.12.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Timer_ShortTimeMeasure_Start()                                  \
    do {                                                                    \
        T1CON_ENABLE_BBA      = 1;      /* Enable Timer 1 */                \
        vShortTimeMeasureStop = 0;      /* Internal Reset */                \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_ShortTimeMeasure_Elasped()
 * DESCRIPTION:
 *      Short Time-Measure Get Currently Elasped Time.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      The currently elapsed time since Short Time-Measure Start,
 *       unit of microsecond(us).
 * NOTES:
 *      N/A
 * HISTORY:
 *      2015.05.06        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Timer_ShortTimeMeasure_Elasped()                                \
    (vShortTimeMeasureStop += pADI_TMR1->TVAL,                              \
     T1CON_ENABLE_BBA = 0,              /* Disable Timer 1   */             \
     NOP(),                             /* For Timer Stopped */             \
     T1CON_ENABLE_BBA = 1,              /* Enable  Timer 1   */             \
     vShortTimeMeasureStop)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_ShortTimeMeasure_Stop
 * DESCRIPTION:
 *      Short Time-Measure Stop.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      The total elapsed time since Short Time-Measure Start,
 *       unit of microsecond(us).
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Timer_ShortTimeMeasure_Stop()                                   \
    (vShortTimeMeasureStop += pADI_TMR1->TVAL,                              \
     T1CON_ENABLE_BBA = 0,              /* Disable Timer 1 */               \
     vShortTimeMeasureStop)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_LongTimeMeasure_Start
 * DESCRIPTION:
 *      Long Time-Measure Start.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      Used to record the start of Time-Measure.
 *      This is only used for long time measuring,
 *       maximum timing: Infinity.
 * HISTORY:
 *      2014.12.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Timer_LongTimeMeasure_Start()                                   \
    do {                                                                    \
        vLongTimeMeasureStart = DRV_Timer_GetSystemTick();                  \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_LongTimeMeasure_Elasped
 * DESCRIPTION:
 *      Long Time-Measure Get Currently Elasped Time.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      The currently elapsed time since Long Time-Measure Start,
 *       unit of millisecond(ms).
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Timer_LongTimeMeasure_Elasped()                                 \
    (DRV_Timer_GetSystemTick() - vLongTimeMeasureStart)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_LongTimeMeasure_Stop
 * DESCRIPTION:
 *      Long Time-Measure Stop.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      The total elapsed time since Long Time-Measure Start,
 *       unit of millisecond(ms).
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Timer_LongTimeMeasure_Stop()                                    \
    DRV_Timer_LongTimeMeasure_Elasped()

#endif

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_SetState
 * DESCRIPTION:
 *      Set Simulated Timer State.
 * PARAMETERS:
 *      vName  : Timer Name;
 *      bState : ENABLE/DISABLE.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_SetState
(
    IN DRV_TIMER_NAME_T vName,
    IN BOOL             bState
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_GetState
 * DESCRIPTION:
 *      Get Simulated Timer State.
 * PARAMETERS:
 *      vName  : Timer Name;
 * RETURN:
 *      TRUE : ENABLED;
 *      FALSE: DISABLE;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
BOOL DRV_Timer_GetState(IN DRV_TIMER_NAME_T vName);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_ISR
 * DESCRIPTION:
 *      Simulated Timer Dispatcher ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_ISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_Init
 * DESCRIPTION:
 *      Timer Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_Init(void);

#endif


#endif /* __DRV_TIMER_H */

