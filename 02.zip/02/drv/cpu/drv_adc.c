/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_adc.c
 * DESCRIPTION:
 *   ADC Driver.
 * HISTORY:
 *   2013.5.27        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"

#if DRV_ADC_SUPPORT

/* ADC power-up time */
#define DRV_ADC_PowerUpTime         5   /* us */

#define DRV_ADC_StartConversion()   do { pADI_ADC->ADCCON = (pADI_ADC->ADCCON & ~ADCCON_C_TYPE_MSK) | ADCCON_C_TYPE_CONT; } while (0)
#define DRV_ADC_StopConversion()    do { pADI_ADC->ADCCON = (pADI_ADC->ADCCON & ~ADCCON_C_TYPE_MSK) | ADCCON_C_TYPE_NO;   } while (0)

#define DRV_ADC_Reset()             do {                                        \
                                        /* power-down ADC */                    \
                                        ADCCON_PUP_BBA = 0;                     \
                                                                                \
                                        /* disable ADC sequencer */             \
                                        pADI_ADC->ADCSEQ  = 0x00000000UL;       \
                                        pADI_ADC->ADCSEQC = 0x0008C631UL;       \
                                                                                \
                                        /* power-up ADC & reference buffer */   \
                                        ADCCON_PUP_BBA = 1;                     \
                                                                                \
                                        /* wait for ADC power-up */             \
                                        DRV_CPU_DelayUs(DRV_ADC_PowerUpTime);   \
                                    } while (0)
#define DRV_ADC_ClearInterrupt()    do { INTCLR_CLR_ADC_SEQ_BBA = 1; } while (0)


/* ADC configuration */
static struct
{
    UINT8   vMode;  /* ADC mode         */
    UINT8   vCHP;   /* positive channel */
    UINT8   vCHN;   /* negative channel */
    UINT8   vAvgNo; /* average number   */
} __code aADCConfig[ADC_CH_MAX] =
{
#define DECLARE_ADC(_name, _chp, _chn, _mode, _avg, _desc)                  \
                                    { (_mode), (_chp), (_chn), (_avg), },
#include "def_hardware.h"
#undef DECLARE_ADC
};

#if DRV_ADC_SwFilter_SUPPORT
static struct
{
    SINT32  vSumVal;    /* ADC sum value   */
    UINT16  vSumCount;  /* ADC sum counter */
} aADCSumBuf[ADC_CH_MAX];
#endif

SINT16   aADCBuf[ADC_CH_MAX];

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_ADC_ISR
 * DESCRIPTION:
 *      ADC ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.29        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_ADC_ISR(void)
{
    UINT16  vChannel;

  #if DRV_ADC_SwFilter_SUPPORT

    for (vChannel = 0; vChannel < COUNT_OF(aADCBuf); vChannel++)
    {
        UINT8   vAvgNo = aADCConfig[vChannel].vAvgNo;

        /* sum ADC real-time value for each channel */
        aADCSumBuf[vChannel].vSumVal += ((SINT32)(pADI_ADC->ADCDAT[vChannel]) >> 13);

        /* average ADC data */
        if (++aADCSumBuf[vChannel].vSumCount == (1U<<vAvgNo))
        {
            aADCBuf[vChannel] = (aADCSumBuf[vChannel].vSumVal >> vAvgNo);

            /* reset */
            aADCSumBuf[vChannel].vSumVal   = 0;
            aADCSumBuf[vChannel].vSumCount = 0;
        }
    }

  #else

    /* get ADC real-time value for each channel */
    for (vChannel = 0; vChannel < COUNT_OF(aADCBuf); vChannel++)
    {
        aADCBuf[vChannel] = ((SINT32)(pADI_ADC->ADCDAT[vChannel]) >> 13);
    }

  #endif

    /* clear interrupt flag */
    DRV_ADC_ClearInterrupt();
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_ADC_Init
 * DESCRIPTION:
 *      Init ADC.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_ADC_Init(void)
{
    UINT16  vChannel;

/* ADC basic initializion */
#if 1
    /* reset ADC to known status */
    DRV_ADC_Reset();

    /* disable both P/N buffer on all channel */
    pADI_InBuf->IBUFCON = 0x0F;

    /* Sample Rate     = 80Ksps
     * Conversion Time = 1/SampleRate
     *                 = 12.5us   per ADC Conversion
     */
    pADI_ADC->ADCCNVC = 0x007D00FAUL;

    /* power-up temperature sensor, and disable chopping mode for it */
    AFETEMPC_PD_BBA   = 0;
    AFETEMPC_CHOP_BBA = 0;
#endif

/* ADC sequencer initializion */
#if 1
    /* default, disable ADC sequencer for all channel */
    pADI_ADC->ADCSEQ = 0x0000;

    for (vChannel = 0; vChannel < COUNT_OF(aADCConfig); vChannel++)
    {
        UINT8   vMode;
        UINT8   vCHP;
        UINT8   vCHN;

		vMode = aADCConfig[vChannel].vMode;
        vCHP  = aADCConfig[vChannel].vCHP;
        vCHN  = aADCConfig[vChannel].vCHN;

		#if DRV_ADC_SwFilter_SUPPORT
		/* init ADC sum buffer */
		aADCSumBuf[vChannel].vSumVal = 0;
		aADCSumBuf[vChannel].vSumCount = 0;
		#endif

        switch (vMode)
        {
            case ADC_MODE_DIFF:
                if (READ_BIT(vCHP, 0) == 1)
                {
                    /* differential negative channel, do nothing */
                    break;
                }
                else
                {
                    /* positive channel */
                }
                /* no break here */

            case ADC_MODE_SINGLE:
                switch (vCHP)
                {
                    case ADC_CHP_AIN0:
                    case ADC_CHP_AIN2:
                    case ADC_CHP_AIN4:
                    case ADC_CHP_AIN6:
                        /* config the P/N channel of AIN0/2/4/6 */
                        pADI_ADC->ADCSEQC =
                          ( (pADI_ADC->ADCSEQC
                                & ~(0x1FUL << (((vCHP/2)*5)&0x1F)))
                          | ((UINT32)vCHN << (((vCHP/2)*5)&0x1F)) );
                        break;

                    default:
                        /* do nothing */
                        break;
                }

                /* enable this channel for sequencer */
                SET_BIT(pADI_ADC->ADCSEQ, vCHP);
                break;

            case ADC_MODE_DISABLE:
            default:
                /* do nothing */
                break;
        }
    }

    /* enable ADC sequencer */
    ADCSEQ_EN_BBA = 1;
#endif

/* ADC others initialization */
#if 1
    /* clear interrupt flag */
    DRV_ADC_ClearInterrupt();

    /* start ADC conversion */
    DRV_ADC_StartConversion();

    /* active ADC sequencer interrupt as LV-Die 0 source */
    INTSEL_SEL_ADC_SEQ_0_BBA = 1;

  #if DRV_VECTOR_SUPPORT
    /* enable ADC interrupt */
    DRV_VECTOR_EnableInterrupt(VECTOR(Vector_ADC));
  #endif
#endif
}

#endif

