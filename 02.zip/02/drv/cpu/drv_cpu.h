/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2010   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cpu.h
 * DESCRIPTION:
 *   CPU Part driver.
 * HISTORY:
 *   2014.12.26        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#ifndef __DRV_CPU_H
#define __DRV_CPU_H


/* Core Clock */
#define CORE_CLOCK              80000000UL  /* Hz */

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_SetRetain
 * DESCRIPTION:
 *      Set retain MCU output status during reset.
 * PARAMETERS:
 *      _v: =TRUE,  retain;
 *          =FALSE, no retain;
 * RETURN:
 *      N/A
 * NOTES:
 *     N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_CPU_SetRetain(_v)   do {                                        \
                                    BOOL bLock;                             \
                                                                            \
                                    /* force retain/no-retain GPIO/PLA/LVDie\
                                     * status during reset.                 \
                                     */                                     \
                                    bLock = DRV_INT_LockGlobalInterrupt();  \
                                    pADI_RESET->RSTKEY         = 0x2009;    \
                                    pADI_RESET->RSTKEY         = 0x0426;    \
                                    RSTCFG_GPIO_PLA_RETAIN_BBA = !(_v);     \
                                    LVRST_RETAIN_BBA           = !(_v);     \
                                    DRV_INT_UnlockGlobalInterrupt(bLock);   \
                                } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_SetJTAG
 * DESCRIPTION:
 *      Enable/Disable JTAG Interface.
 * PARAMETERS:
 *      _v: =ENABLE,  Enable JTAG Interface;
 *          =DISABLE, Disable JTAG Interface;
 * RETURN:
 *      N/A
 * NOTES:
 *     N/A
 * HISTORY:
 *      2015.10.20        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_CPU_SetJTAG(_v)     do {                                        \
                                    BOOL bLock;                             \
                                                                            \
                                    bLock = DRV_INT_LockGlobalInterrupt();  \
                                    pADI_FEE->FEEKEY = FLASH_KEY_ENABLE;    \
                                    FEECON1_DBG_BBA = (_v);                 \
                                    pADI_FEE->FEEKEY = FLASH_KEY_DISABLE;   \
                                    DRV_INT_UnlockGlobalInterrupt(bLock);   \
                                } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_Delay100ns
 * DESCRIPTION:
 *      Delay 100 Nanoseconds.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *     N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_CPU_Delay100ns()    do {                                        \
                                    /* 80MHz Core Clock:                    \
                                     *       T = 0.0125us                   \
                                     *  ==>  100ns = 8T                     \
                                     */                                     \
                                    NOP(); NOP(); NOP(); NOP();             \
                                    NOP(); NOP(); NOP(); NOP();             \
                                } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_DelayUs
 * DESCRIPTION:
 *      Delay Microseconds.
 * PARAMETERS:
 *      vUsec : Microseconds to be delayed.
 * RETURN:
 *      N/A
 * NOTES:
 *     Note: Do not use it for long time delay (over 1000us).
 *           If delay over 1000us, please use DRV_CPU_DelayMs().
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
__noinline void DRV_CPU_DelayUs(IN SINT16 vUsec);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_DelayMs
 * DESCRIPTION:
 *      Delay Millisecond.
 * PARAMETERS:
 *      vMsec : Millisecond to be delayed.
 * RETURN:
 *      N/A
 * NOTES:
 *      Don't use it in ISR.
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_CPU_DelayMs(IN UINT16 vMsec);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_Reset
 * DESCRIPTION:
 *      Reset CPU.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_CPU_Reset(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_Init
 * DESCRIPTION:
 *      Init CPU.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_CPU_Init(void);


#endif /* __DRV_CPU_H */

