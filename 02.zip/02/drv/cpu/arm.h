/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   arm.h
 * DESCRIPTION:
 *   N/A
 * HISTORY:
 *   2013.12.16         Panda.Xiong          Create/Update
 *
*****************************************************************************/

#ifndef __ARM_H
#define __ARM_H


#ifndef __cortex_m3__
 #error "Only support Cortex-M3 yet!"
#endif


#if defined(__GNUC__)
 /* note: these macros may be pre-defined by gcc */
 #ifndef __dead2
  #define __dead2           __attribute__((__noreturn__))
 #endif
 #ifndef __pure2
  #define __pure2           __attribute__((__const__))
 #endif
 #ifndef __unused
  #define __unused          __attribute__((__unused__))
 #endif
 #ifndef __used
  #define __used            __attribute__((__used__))
 #endif
 #ifndef __packed
  #define __packed          __attribute__((__packed__))
 #endif
 #ifndef __aligned
  #define __aligned(x)      __attribute__((__aligned__(x)))
 #endif
 #ifndef __section
  #define __section(x)      __attribute__((__section__(x)))
 #endif
 #ifndef __noinline
  #define __noinline        __attribute__ (( noinline ))
 #endif
 #ifndef __naked
  #define __naked           __attribute__ (( naked ))
 #endif
 #ifndef __weak
  #define __weak            __attribute__ (( weak ))
 #endif
 #ifndef __alias
  #define __alias(s)        __attribute__ (( alias(s) ))
 #endif
 #ifndef __asm
  #define __asm(args...)    __asm__ __volatile__ (args)
 #endif
#elif defined(lint)
 #define __dead2            /* empty */
 #define __pure2            /* empty */
 #define __unused           /* empty */
 #define __used             /* empty */
 #define __packed           /* empty */
 #define __aligned(x)       /* empty */
 #define __section(x)       /* empty */
 #define __noinline         /* empty */
 #define __naked            /* empty */
 #define __weak             /* empty */
 #define __alias(s)         /* empty */
 #define __asm(args...)     /* empty */
#else
 #error "Only support GCC compiler yet!"
#endif


/* these are defined in linker script file (*.ld) */
extern unsigned int         __text_start[];
extern unsigned int         __text_end[];
extern unsigned int         __data_start[];
extern unsigned int         __data_end[];
extern unsigned int         __bss_start[];
extern unsigned int         __bss_end[];
extern unsigned int         __reset_start[];
extern unsigned int         __reset_end[];
extern unsigned int         __heap_start[];
extern unsigned int         __heap_end[];


#define __rom_vector        __section(".rom_vector") __used
#define __signature         __section(".signature")  __used
#define __const_text        __section(".const_text") __used
#define __ram_vector        __section(".ram_vector") __used
#define __reset             __section(".reset")      __used
#define __ram               __section(".ram")
#define __code              const
#define __no_init           /* non-initialized section, do nothing here */


/* setup vector handler */
#define ARM_SETUP_HANDLER(_id, _isr)                                        \
    do {                                                                    \
        __data_start[(_id)-(Reset_IRQn-1)] = (unsigned int)(_isr);          \
    } while (0)


/* bit-band alias address operation */
#define _BITBAND_ADDR(_addr, _bit)          (((UINT32)(_addr) & 0xF0000000)         \
                                             + 0x2000000                            \
                                             + (((UINT32)(_addr) & 0xFFFFF) << 5)   \
                                             + ((UINT8)(_bit) << 2))
#define BITBAND_WRITE_BIT(_addr, _bit, _v)  do { (VP32(_BITBAND_ADDR((_addr), (_bit)))) = ((UINT8)(_v) & 0x1); } while (0)
#define BITBAND_READ_BIT(_addr, _bit)       (UINT8)((VP32(_BITBAND_ADDR((_addr), (_bit)))) & 0x1)


#endif /* __ARM_H */

