/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_io.c
 * DESCRIPTION:
 *   GPIO driver.
 * HISTORY:
 *   2013.12.30        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_IO_SUPPORT
/******************************************************************************
 * FUNCTION NAME:
 *		drv_io_SetDirection
 * DESCRIPTION:
 *		Set IO pin direction.
 * PARAMETERS:
 *		vPort : port
 *		vBit  : bit
 *      vDir :  direction
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.6.1		Melinda.Lu 		Create/Update
 *****************************************************************************/
static void drv_io_SetDirection
(
    IN UINT8    vPort,
    IN UINT8    vBit,
    IN UINT8    vDirection
)
{
	switch (vDirection)
	{
		case IO_INPUT_PULLUP_DISABLE:
			drv_io_DisableOutput(vPort, vBit);
			drv_io_DisableOpenDrain(vPort, vBit);
			drv_io_DisablePull(vPort, vBit);
			drv_io_EnableInput(vPort, vBit);
			break;

		case IO_INPUT_PULLUP_ENABLE:
			drv_io_DisableOutput(vPort, vBit);
			drv_io_DisableOpenDrain(vPort, vBit);
			drv_io_EnablePull(vPort, vBit);
			drv_io_EnableInput(vPort, vBit);
			break;

		case IO_OUTPUT_PUSHPULL:
			drv_io_DisableInput(vPort, vBit);
			drv_io_DisableOpenDrain(vPort, vBit);
			drv_io_EnablePull(vPort, vBit);
			drv_io_EnableOutput(vPort, vBit);
			drv_io_EnableInput(vPort, vBit);
			break;

		case IO_OUTPUT_OPENDRAIN:
			drv_io_DisableInput(vPort, vBit);
			drv_io_DisablePull(vPort, vBit);
			drv_io_EnableOpenDrain(vPort, vBit);
			drv_io_EnableOutput(vPort, vBit);
			drv_io_EnableInput(vPort, vBit);
			break;

		case IO_TRI_STATE:
		default:
			drv_io_DisableInput(vPort, vBit);
			drv_io_DisableOutput(vPort, vBit);
			drv_io_DisablePull(vPort, vBit);
			drv_io_DisableOpenDrain(vPort, vBit);
			break;
	}
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_IO_SetMode
 * DESCRIPTION:
 *		Set IO pin modes.
 * PARAMETERS:
 *		vPort : port
 *		vBit  : bit
 *      vMode : mode
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.6.1		Melinda.Lu 		Create/Update
 *****************************************************************************/
void DRV_IO_SetMode
(
    IN UINT8    vPort,
    IN UINT8    vBit,
    IN UINT8    vMode
)
{
	UINT16  vConfig;

	vConfig = GPIO_CONFIG(vPort);
	vConfig &= ~(GPIO_MODE_MASK<<((vBit)*2));
	vConfig |= ((UINT16)(vMode)<<((vBit)*2));

	GPIO_CONFIG(vPort) = vConfig;
}


/******************************************************************************
 * FUNCTION NAME:
 *		DRV_IO_Read
 * DESCRIPTION:
 *		Read IO pin state.
 * PARAMETERS:
 *		vPort : port
 *		vBit  : bit
 * RETURN:
 *		IO data
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.6.1		Melinda.Lu 		Create/Update
 *****************************************************************************/
BOOL DRV_IO_Read
(
    IN UINT8    vPort,
    IN UINT8    vBit
)
{
    return READ_BIT(GPIO_INPUT(vPort), (vBit));
}

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IO_Write
 * DESCRIPTION:
 *      Write IO pin output data.
 * PARAMETERS:
 *      vPort : port
 *      vBit  : bit
 *      vData : =1, output high;
 *              =0, output low.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.6.1        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_IO_Write
(
    IN UINT8    vPort,
    IN UINT8    vBit,
    IN BOOL     bData
)
{
	if (bData)
	{
		drv_io_Set(vPort, vBit);
	}
	else
	{
		drv_io_Clear(vPort, vBit);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IO_Init
 * DESCRIPTION:
 *      IO Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_IO_Init(void)
{
  #if HOT_RESET_NSA_SUPPORT
    if (PLF_RESET_IsPrevHotResetNSA())
    {
        DBG_LOG_INFO("IO init skipped!");
        return;
    }
  #endif

#define DECLARE_IO(_name, _port, _bit, _mode, _dir, _init, _desc)           \
    do                                                                      \
    {                                                                       \
        DRV_IO_SetMode((_port), (_bit), (_mode));                           \
        DRV_IO_Write((_port), (_bit), (_init));                             \
        drv_io_SetDirection((_port), (_bit), (_dir));                       \
    } while (0);

#include "def_hardware.h"

#undef DECLARE_IO
}

#endif

