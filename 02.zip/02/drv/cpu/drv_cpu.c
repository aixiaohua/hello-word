/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2010   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cpu.c
 * DESCRIPTION:
 *   CPU Part driver.
 * HISTORY:
 *   2014.12.26        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_DelayUs
 * DESCRIPTION:
 *      Delay Microseconds.
 * PARAMETERS:
 *      vUsec : Microseconds to be delayed.
 * RETURN:
 *      N/A
 * NOTES:
 *     Note: Do not use it for long time delay (over 1000us).
 *           If delay over 1000us, please use DRV_CPU_DelayMs().
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
__noinline void DRV_CPU_DelayUs(IN SINT16 vUsec)
{
    /* 80MHz Core Clock:
     *    T  = 0.0125us    ==>    1us = 80T
     *
     * after compiled this function(DRV_CPU_DelayUs),
     * we can found the while() loop will be compiled to 4 instruction,
     *  i.e. one loop takes 4T,
     * so we add additional 76T in one loop, to delay 1us.
     */

    do
    {
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP(); NOP(); NOP(); NOP(); NOP();
        NOP();
    } while (--vUsec > 0);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_DelayMs
 * DESCRIPTION:
 *      Delay Millisecond.
 * PARAMETERS:
 *      vMsec : Millisecond to be delayed.
 * RETURN:
 *      N/A
 * NOTES:
 *      Don't use it in ISR.
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_CPU_DelayMs(IN UINT16 vMsec)
{
    /* here, we assume timer is always running,
     * else, the MCU may dead loop here!!!
     */
  #if SYSTEM_TICK_SUPPORT
    /* if interrupt is not locked/disabled, use interrupt mode to delay;
     * else, use polling mode to delay.
     */
    if (!DRV_INT_IsGlobalInterruptLocked())
    {
        /* interrupt mode */

        vDelayTickCount = vMsec/DRV_Timer_SystemTickValue;
        while (vDelayTickCount > 0)
        {
          #if DRV_WATCHDOG_SUPPORT
            /* kick watchdog, to prevent watchdog timeout */
            DRV_WATCHDOG_Kick();
          #endif

            /* TODO: idle MCU */
        }
    }
    else
  #endif
    {
        /* polling mode */

      #if DRV_TIMER_SUPPORT
        /* convert to timer tick counts */
        vMsec = TIMER_MS(vMsec);

        while (vMsec-- > 0)
        {
            while (!DRV_Timer_IsTimeout())
            {}

            /* clear Timeout Flag */
            DRV_Timer_ClearTimeoutFlag();

          #if SYSTEM_TICK_SUPPORT
            /* update System Tick */
            DRV_Timer_UpdateSystemTick();
          #endif

          #if DRV_WATCHDOG_SUPPORT
            /* kick watchdog, to prevent Watchdog Timeout */
            DRV_WATCHDOG_Kick();
          #endif
        }
      #endif
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_Reset
 * DESCRIPTION:
 *      Reset CPU.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
__ram void DRV_CPU_Reset(void)
{
    /* disable all interrupts */
    DRV_INT_GlobalDisableInterrupt();

  #if DRV_WATCHDOG_SUPPORT
    /* disable Watchdog Timer */
    DRV_WATCHDOG_Disable();
  #endif

    /* dead loop here, to wait for CPU reboot */
    for (;;)
    {
      #if DRV_RESET_SUPPORT
        /* force software reset CPU */
        DRV_Reset_SoftwareReset();
      #endif
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CPU_Init
 * DESCRIPTION:
 *      Init CPU.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.26        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_CPU_Init(void)
{
    /* globally disable all interrupt */
    DRV_INT_GlobalDisableInterrupt();

  #if (CORE_CLOCK == 80000000UL)
    /* set UCLK=80MHz, PCLK=20MHz, HCLK(core_clock)=80MHz */
    pADI_CLKCTL->CLKCON0 = (pADI_CLKCTL->CLKCON0 & ~CLKCON0_CLKMUX_MSK)
                            | (CLKCON0_CLKMUX_SPLL);
    pADI_CLKCTL->CLKCON1 = (pADI_CLKCTL->CLKCON1 & ~(CLKCON1_CDPCLK_MSK | CLKCON1_CDHCLK_MSK))
                            | (CLKCON1_CDPCLK_DIV4 | CLKCON1_CDHCLK_DIV1);
  #else
    #error "Unsupported Core Clock yet!"
  #endif

    /* disable/enable clock of the peripherals */
  	#if 0
	CLKCON5_D2DCLKOFF_BBA   = 1;
	CLKCON5_UCLKUARTOFF_BBA = 0;
	CLKCON5_UCLKI2C0OFF_BBA = 0;
	CLKCON5_UCLKI2C1OFF_BBA = 1;
	CLKCON5_UCLKSPI1OFF_BBA = 1;
	CLKCON5_UCLKSPI0OFF_BBA = 1;
	#else
	pADI_CLKCTL->CLKCON5 = (CLKCON5_D2DCLKOFF_OFF   |
	                       CLKCON5_UCLKUARTOFF_ON  |
	                       CLKCON5_UCLKI2C1OFF_OFF |
	                       CLKCON5_UCLKI2C0OFF_ON  |
	                       CLKCON5_UCLKSPI1OFF_OFF |
	                       CLKCON5_UCLKSPI0OFF_OFF);
	#endif

    /* disable & clear all interrupt of Low-Voltage-Die */
    pADI_LV_INT->INTSEL = 0x0000;
    pADI_LV_INT->INTCLR = 0xFF;

    /* force don't retain MCU output status during reset */
    DRV_CPU_SetRetain(FALSE);
}

