/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_vector.c
 * DESCRIPTION:
 *   Vector related.
 * HISTORY:
 *   2014.10.22        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "msa.h"

#if DRV_VECTOR_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_Init
 * DESCRIPTION:
 *      Vector Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_VECTOR_Init(void)
{
#define DECLARE_VECTOR(_name, _id, _handler, _priority, _cookie, _desc)     \
    do {                                                                    \
        /* setup vector handler */                                          \
        ARM_SETUP_HANDLER((_id), (_handler));                               \
                                                                            \
        switch (_id)                                                        \
        {                                                                   \
            case Reset_IRQn:                                                \
            case NonMaskableInt_IRQn:                                       \
            case HardFault_IRQn:                                            \
                /* fixed priority, do nothing */                            \
                break;                                                      \
                                                                            \
            case EINT0_IRQn:                                                \
            case EINT1_IRQn:                                                \
            case EINT2_IRQn:                                                \
            case EINT3_IRQn:                                                \
            case EINT4_IRQn:                                                \
            case EINT5_IRQn:                                                \
            case EINT6_IRQn:                                                \
            case EINT7_IRQn:                                                \
            case EINT8_IRQn:                                                \
                /* config external interrupt, disabled by default */        \
                EXTERNAL_INT_SET_STATE((_id), DISABLE);                     \
                EXTERNAL_INT_SET_MODE((_id), (_cookie));                    \
                EXTERNAL_INT_CLR_FLAG(_id);                                 \
                /* no break here */                                         \
                                                                            \
            default:                                                        \
                /* set vector priority in NVIC */                           \
                NVIC_SetPriority((_id), (_priority));                       \
                break;                                                      \
        }                                                                   \
    } while (0);

#include "def_vector.h"

#undef  DECLARE_VECTOR
}

#endif

