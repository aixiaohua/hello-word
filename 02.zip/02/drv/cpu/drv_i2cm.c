/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_i2cm.c
 * DESCRIPTION:
 *   I2C Master Driver.
 * HISTORY:
 *   2013.6.7        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_I2CM_SUPPORT

/* =1, send I2C Stop at I2C Master Bus initializing;
 * =0, do not send I2C Stop. (default)
 */
#define DRV_I2CM_INIT_STOP_SUPPORT          (0)

/* I2C Driver Porting part */
#if 1

#if   (DRV_I2CM_RATE == 80)
 #define DRV_I2CM_FixRate()         DRV_CPU_DelayUs(4)
#elif (DRV_I2CM_RATE == 100)
 #define DRV_I2CM_FixRate()         DRV_CPU_DelayUs(3)
#elif (DRV_I2CM_RATE == 150)
 #define DRV_I2CM_FixRate()         DRV_CPU_DelayUs(2)
#elif (DRV_I2CM_RATE == 200)
 #define DRV_I2CM_FixRate()         do {                                    \
                                        /* delay 1.5us */                   \
                                        DRV_CPU_DelayUs(1);                 \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                    } while (0)
#elif (DRV_I2CM_RATE == 300)
 #define DRV_I2CM_FixRate()         DRV_CPU_DelayUs(1)
#elif (DRV_I2CM_RATE == 400)
 #define DRV_I2CM_FixRate()         do {                                    \
                                        /* delay 0.8us */                   \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                        DRV_CPU_Delay100ns();               \
                                    } while (0)
#else
 #error "Unsupported I2C Master Rate!"
#endif

#define DRV_I2CM_SET_SCL(_data)     do {                                        \
                                        DRV_IO_Write(IO(I2CM_SCL), (_data));    \
                                                                                \
                                        /* clock-stretch */                     \
                                        if ((_data) == HIGH)                    \
                                        {                                       \
                                            /* maximum clock-stretch 500us */   \
                                            UINT16  vTimeoutCount = 5000;       \
                                                                                \
                                            while ((DRV_I2CM_GET_SCL() == LOW)  \
                                                    && vTimeoutCount--)         \
                                            {                                   \
                                                DRV_CPU_Delay100ns();           \
                                            }                                   \
                                        }                                       \
                                                                                \
                                        DRV_I2CM_FixRate();                     \
                                    } while (0)
#define DRV_I2CM_SET_SDA(_data)     do {                                        \
                                        DRV_IO_Write(IO(I2CM_SDA), (_data));    \
                                        DRV_I2CM_FixRate();                     \
                                    } while (0)
#define DRV_I2CM_GET_SCL()          DRV_IO_Read(IO(I2CM_SCL))
#define DRV_I2CM_GET_SDA()          DRV_IO_Read(IO(I2CM_SDA))

#endif


/* low-level I2C driver */
#if 1

/* return : TRUE,  an ACK received;
 *          FALSE, no ACK received.
 */
static BOOL _drv_i2cm_SendByte(UINT8 vData)
{
    UINT8   vLoop;
    BOOL    vAck;

    for (vLoop = 8; vLoop != 0; vLoop--)
    {
        /* Transmitting data, MSB first, LSB last */
        ROL(vData, 1);
        DRV_I2CM_SET_SDA(vData & 0x1);

        DRV_I2CM_SET_SCL(1);
        DRV_I2CM_SET_SCL(0);
    }

    /* release SDA */
    DRV_I2CM_SET_SDA(1);

    /* check ACK */
    DRV_I2CM_SET_SCL(1);
    vAck = DRV_I2CM_GET_SDA();
    DRV_I2CM_SET_SCL(0);

    return !vAck;
}

static UINT8 _drv_i2cm_ReceiveByte(void)
{
    UINT8   vLoop;
    UINT8   vData = 0;

    for (vLoop = 8; vLoop != 0; vLoop--)
    {
        DRV_I2CM_SET_SCL(1);
        vData <<= 1;
        vData |= DRV_I2CM_GET_SDA();
        DRV_I2CM_SET_SCL(0);
    }

    return vData;
}

#define _drv_i2cm_SendAck(_ack)                                             \
    do {                                                                    \
        /* send ACK */                                                      \
        DRV_I2CM_SET_SDA(_ack);                                             \
                                                                            \
        /* generate one clock */                                            \
        DRV_I2CM_SET_SCL(1);                                                \
        DRV_I2CM_SET_SCL(0);                                                \
                                                                            \
        /* release SDA */                                                   \
        DRV_I2CM_SET_SDA(1);                                                \
    } while (0)

#define _drv_i2cm_Start()                                                   \
    do {                                                                    \
        /* I2C Start/ReStart:                                               \
         *   SDA changed from HIGH(1) to LOW(0), while SCL is HIGH(1).      \
         */                                                                 \
        DRV_I2CM_SET_SDA(1);                                                \
        DRV_I2CM_SET_SCL(1);                                                \
        DRV_I2CM_SET_SDA(0);                                                \
        DRV_I2CM_SET_SCL(0);                                                \
    } while (0)

#define _drv_i2cm_ReStart()     _drv_i2cm_Start()

#define _drv_i2cm_Stop()                                                    \
    do {                                                                    \
        /* Note: this is a I2C Start, if current SCL/SDA is HIGH;           \
         *       this will only happen while initializing I2C Master Bus.   \
         */                                                                 \
        DRV_I2CM_SET_SDA(0);                                                \
        DRV_I2CM_SET_SCL(0);                                                \
                                                                            \
        /* I2C Stop:                                                        \
         *   SDA changed from LOW(0) to HIGH(1), while SCL is HIGH(1).      \
         */                                                                 \
        DRV_I2CM_SET_SCL(1);                                                \
        DRV_I2CM_SET_SDA(1);                                                \
    } while (0)

#define _drv_i2cm_Init()                                                    \
    do {                                                                    \
        /* force stop all operations on I2C bus */                          \
        _drv_i2cm_Stop();                                                   \
    } while (0)

/* check I2C hardware is ready to operate or not */
static BOOL _drv_i2cm_CheckReady(void)
{
    BOOL    bResult = FALSE;

    if ((DRV_I2CM_GET_SCL() == 1)
        && (DRV_I2CM_GET_SDA() == 1))
    {
        /* The I2C only can be started, while SCL/SDA is at high level */
        bResult = TRUE;
    }
    else if ((DRV_I2CM_GET_SCL() == 1)
            && (DRV_I2CM_GET_SDA() == 0))
    {
        /* SCL line is OK, but SDA line has been stretched by I2C Slave,
         *  we should attempt to reset the I2C Bus,
         *  to recover the SDA to idle state.
         *
         * According to SFF-8431 & INF-8077 Spec,
         *  we can follow below steps to recover SDA line:
         *
         *   Memory (Management Interface) Reset:
         *    1) Clock up to 9 cycles.
         *    2) Look for SDA high in each cycle while SCL is high.
         *    3) Create a START condition as SDA is high.
         */

        UINT8   vLoop;

        for (vLoop = 9; vLoop > 0; vLoop--)
        {
            DRV_I2CM_SET_SCL(0);
            DRV_I2CM_SET_SCL(1);

            if (DRV_I2CM_GET_SDA() == 1)
            {
                /* we have successfully recover the SDA line to idle state */
                bResult = TRUE;
                break;
            }
        }
    }
    else
    {
        /* Unsupported stretching on SCL/SDA line, operation fail */
    }

    return bResult;
}

#endif


#if 1

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_Read
 * DESCRIPTION:
 *      Read one or more bytes, with/without offset.
 * PARAMETERS:
 *      vI2cAddr   : I2C slave chip address.
 *      vOffsetLen : offset buffer length to be send.
 *      aOffsetBuf : offset buffer.
 *      vDataLen   : data length to be read.
 *      aDataBuf   : data buffer.
 * RETURN:
 *      TRUE   : read success.
 *      FALSE  : read fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_Read
(
    IN       UINT8      vI2cAddr,
    IN       UINT8      vOffsetLen,
    IN const UINT8     *aOffsetBuf,
    IN       UINT16     vDataLen,
    OUT      UINT8     *aDataBuf
)
{
    UINT16  vLoop;

  #if DRV_WATCHDOG_SUPPORT
    DRV_WATCHDOG_Kick();
  #endif

    /* make sure the I2C is ready */
    if (!_drv_i2cm_CheckReady())
    {
        goto _error_exit;
    }

    /* send I2C start */
    _drv_i2cm_Start();

    if (vOffsetLen > 0)
    {
        /* send I2C slave address + Write */
        if (!_drv_i2cm_SendByte(vI2cAddr&0xFE))
        {
            goto _error_exit;
        }

        /* send offset */
        for (vLoop = 0; vLoop < vOffsetLen; vLoop++)
        {
            /* send offset */
            if (!_drv_i2cm_SendByte(aOffsetBuf[vLoop]))
            {
                goto _error_exit;
            }
        }

        /* send I2C repeat start */
        _drv_i2cm_ReStart();
    }

    /* send I2C slave address + Read */
    if (!_drv_i2cm_SendByte(vI2cAddr|0x01))
    {
        goto _error_exit;
    }

    /* read data */
    for (vLoop = 0; vLoop < vDataLen; vLoop++)
    {
        /* read data */
        aDataBuf[vLoop] = _drv_i2cm_ReceiveByte();

        /* if it's the last byte data, don't send ACK */
        if (vLoop == (vDataLen - 1))
        {
            _drv_i2cm_SendAck(1);       /* send NACK */
        }
        else
        {
            _drv_i2cm_SendAck(0);       /* send ACK  */
        }
    }

/* success exit */
    /* send I2C stop */
    _drv_i2cm_Stop();
    return TRUE;

_error_exit:
    /* we should reset the I2C, or the I2C bus will keep on fail */
    _drv_i2cm_Init();
    return FALSE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_WriteBytes
 * DESCRIPTION:
 *      Write one or more bytes, with/without offset.
 * PARAMETERS:
 *      vI2cAddr    : I2C slave chip address.
 *      vOffsetLen  : offset buffer length to be send.
 *      aOffsetBuf  : offset buffer.
 *      aDataBuf    : data length to be write.
 *      data_buf    : data buffer.
 * RETURN:
 *      TRUE   : write success.
 *      FALSE  : write fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_Write
(
    IN       UINT8      vI2cAddr,
    IN       UINT8      vOffsetLen,
    IN const UINT8     *aOffsetBuf,
    IN       UINT16     vDataLen,
    IN const UINT8     *aDataBuf
)
{
    UINT16  vLoop;

  #if DRV_WATCHDOG_SUPPORT
    DRV_WATCHDOG_Kick();
  #endif

    /* make sure the I2C is ready */
    if (!_drv_i2cm_CheckReady())
    {
        goto _error_exit;
    }

    /* send I2C start */
    _drv_i2cm_Start();

    /* send I2C slave address + Write */
    if (!_drv_i2cm_SendByte(vI2cAddr&0xFE))
    {
        goto _error_exit;
    }

    /* send offset */
    for (vLoop = 0; vLoop < vOffsetLen; vLoop++)
    {
        if (!_drv_i2cm_SendByte(aOffsetBuf[vLoop]))
        {
            goto _error_exit;
        }
    }

    /* send data */
    for (vLoop = 0; vLoop < vDataLen; vLoop++)
    {
        if (!_drv_i2cm_SendByte(aDataBuf[vLoop]))
        {
            goto _error_exit;
        }
    }

/* success exit */
    /* send I2C stop */
    _drv_i2cm_Stop();
    return TRUE;

_error_exit:
    /* we should reset the I2C, or the I2C bus will keep on fail */
    _drv_i2cm_Init();
    return FALSE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_ReadBytes
 * DESCRIPTION:
 *      Random read one or more bytes.
 * PARAMETERS:
 *      vI2cAddr   : I2C slave chip address.
 *      vOffset    : Read start offset.
 *      vDataLen   : data length to be read.
 *      aDataBuf   : data buffer.
 * RETURN:
 *      TRUE   : read success.
 *      FALSE  : read fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_ReadBytes
(
    IN  UINT8   vI2cAddr,
    IN  UINT8   vOffset,
    IN  UINT16  vDataLen,
    OUT UINT8  *aDataBuf
)
{
    return DRV_I2CM_Read(vI2cAddr, 1, &vOffset, vDataLen, aDataBuf);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_WriteBytes
 * DESCRIPTION:
 *      Random write one or more bytes.
 * PARAMETERS:
 *      vI2cAddr : I2C slave chip address.
 *      vOffset  : I2C offset.
 *      vDataLen : I2C data length.
 *      aDataBuf : I2C data buffer.
 * RETURN:
 *      TRUE   : write success.
 *      FALSE  : write fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_WriteBytes
(
    IN       UINT8      vI2cAddr,
    IN       UINT8      vOffset,
    IN       UINT16     vDataLen,
    IN const UINT8     *aDataBuf
)
{
    return DRV_I2CM_Write(vI2cAddr, 1, &vOffset, vDataLen, aDataBuf);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_WriteByte
 * DESCRIPTION:
 *      Random write one or more bytes.
 * PARAMETERS:
 *      vI2cAddr : I2C slave chip address.
 *      vOffset  : offset buffer length to be send.
 *      vData    : data buffer.
 * RETURN:
 *      TRUE   : write success.
 *      FALSE  : write fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_WriteByte
(
    IN       UINT8       vI2cAddr,
    IN       UINT8       vOffset,
    IN       UINT8       vData
)
{
    return DRV_I2CM_WriteBytes(vI2cAddr, vOffset, 1, &vData);
}


/*******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_Detect
 * DESCRIPTION:
 *      I2C detect chip.
 * PARAMETERS:
 *      vI2cAddr : I2C chip address.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
BOOL DRV_I2CM_Detect(IN UINT8 vI2cAddr)
{
    return DRV_I2CM_Write(vI2cAddr, 0, NULL, 0, NULL);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_I2CM_Init
 * DESCRIPTION:
 *      I2C init driver.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 ******************************************************************************/
void DRV_I2CM_Init(void)
{
#if DRV_I2CM_INIT_STOP_SUPPORT
    _drv_i2cm_Init();
#endif
}

#endif

#endif

