/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_i2cs.C
 * DESCRIPTION:
 *   I2C slave driver.
 * HISTORY:
 *   2017.3.7        Melinda.Lu         Create/Update
 *
 *****************************************************************************/
#include "cfg.h"
#include "drv.h"


#if DRV_I2CS_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 * 	 DRV_I2CS_Init
 * DESCRIPTION:
 * 	 I2C slave init.
 * PARAMETERS:
 * 	 N/A
 * RETURN:
 * 	 N/A
 * NOTES:
 * 	 N/A
 * HISTORY:
 * 	 2017.3.10 	   Melinda.Lu		   Create/Update
 *****************************************************************************/
void DRV_I2CS_Init(void)
{
	/* default, disable I2C */
	DRV_I2CS_Disable();
}

#endif

