/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   startup.c
 * DESCRIPTION:
 *   Cortex-M3 start-up file.
 *
 *   ### WARNING ###
 *    DO NOT TRY TO MODIFY THE "romVectorTable" and "Reset_Handler",
 *     AS WELL AS THEIR LOCATION IN ROM,
 *    ELSE, THE SYSTEM MAY BE RUNNING ABNORMALLY !!!
 *
 * HISTORY:
 *   2013.11.27        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"


        void Fault_Handler(void);
        void CM3_Handler(void);
        void IRQ_Handler(void);
__naked void Reset_Handler(void);
__naked void __main(void);


/* rom vector table */
__rom_vector void (*romVectorTable[CM3_VECTOR_COUNT])(void) =
{
    /* cortex-m3 standard system exception */
    (void *)STACK_BOTTOM,   /* stack bottom                         */
    Reset_Handler,          /* reset                                */
    CM3_Handler,            /* NMI                                  */
    Fault_Handler,          /* hard fault                           */
    CM3_Handler,            /* memory management fault              */
    CM3_Handler,            /* bus fault                            */
    CM3_Handler,            /* usage fault                          */
    CM3_Handler,            /* reserved                             */
    CM3_Handler,            /* reserved                             */
    CM3_Handler,            /* reserved                             */
    CM3_Handler,            /* reserved                             */
    CM3_Handler,            /* SVC                                  */
    CM3_Handler,            /* debug monitor                        */
    CM3_Handler,            /* reserved                             */
    CM3_Handler,            /* PendSV                               */
    CM3_Handler,            /* SysTick                              */
};

/* ram vector table */
__ram_vector void (*ramVectorTable[CM3_VECTOR_COUNT+CPU_VECTOR_COUNT])(void);

void Fault_Handler(void)
{
    UINT32  vLoop;

    printf("\n\r ---- Error: System Fault Detected! ---- \n\r");
    printf("\n\r FAULT Information:");
    printf("\n\r  HFSR      : %.8X", (UINT32)SCB->HFSR);
    printf("\n\r  CFSR      : %.8X", (UINT32)SCB->CFSR);
    printf("\n\r  MMFAR     : %.8X", (UINT32)SCB->MMFAR);
    printf("\n\r  BFAR      : %.8X", (UINT32)SCB->BFAR);
    printf("\n\r CPU Information:");
    printf("\n\r  xPSR      : %.8X", (UINT32)__get_xPSR());
    printf("\n\r  PRIMASK   : %.8X", (UINT32)__get_PRIMASK());
    printf("\n\r  FAULTMASK : %.8X", (UINT32)__get_FAULTMASK());
    printf("\n\r  BASEPRI   : %.8X", (UINT32)__get_BASEPRI());
    printf("\n\r  CONTROL   : %.8X", (UINT32)__get_CONTROL());
    printf("\n\r Stack Information:");
    printf("\n\r  MSP       : %.8X", (UINT32)__get_MSP());
    printf("\n\r  PSP       : %.8X", (UINT32)__get_PSP());
    printf("\n\r  TOP       : %.8X", STACK_TOP);
    printf("\n\r  BOTTOM    : %.8X", STACK_BOTTOM);
    printf("\n\r Stack Contents:");
    for (vLoop  = (UINT32)__get_MSP();
         vLoop <= STACK_BOTTOM;
         vLoop += sizeof(UINT32)*4)
    {
        printf("\n\r  %.8X: %.8X %.8X - %.8X %.8X",
               vLoop,
               VP32(vLoop+0x0), VP32(vLoop+0x4),
               VP32(vLoop+0x8), VP32(vLoop+0xC));
    }

    /* dead loop here */
    for (;;)
    {}
}

void CM3_Handler(void)
{
    printf("\n\r ---- Error: Unsupported CM3 Handler Detected! ---- \n\r");

    /* dead loop here */
    for (;;)
    {}
}

void IRQ_Handler(void)
{
    printf("\n\r ---- Error: Unsupported IRQ #%d Detected! ---- \n\r",
           (UINT8)__get_IPSR());

    /* dead loop here */
    for (;;)
    {}
}

/* system boot-up from here */
__const_text __naked void Reset_Handler(void)
{
    extern void main(void);
    unsigned int   *dst, *src;

    /* force re-init MSP vlaue again,
     * due to the stack pointer may be incorrect after flash swapped.
     */
    __set_MSP((unsigned int)(romVectorTable[0]));

    /* copy .data from rom to ram */
    src = __text_end;
    dst = __data_start;
    while (dst < __data_end)
    {
        *dst++ = *src++;
    }

    /* initialize ram vector table */
    src = (unsigned int *)romVectorTable;
    dst = (unsigned int *)ramVectorTable;
    while (dst < (unsigned int *)ramVectorTable+CM3_VECTOR_COUNT)
    {
        *dst++ = *src++;
    }
    while (dst < (unsigned int *)ramVectorTable+CM3_VECTOR_COUNT+CPU_VECTOR_COUNT)
    {
        *dst++ = (unsigned int)IRQ_Handler;
    }

    /* relocate to ram vector table */
    SCB->VTOR = (unsigned int)ramVectorTable;

    /* clear .bss */
    dst = __bss_start;
    while (dst < __bss_end)
    {
        *dst++ = 0;
    }

    /* stack init */
  #if STACK_CHECK_SUPPORT
    DBG_Stack_Init();
  #endif

    /* enter C main */
    main();

    /* never reach here */
    for (;;)
    {}
}

