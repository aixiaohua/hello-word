/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_vref.h
 * DESCRIPTION:
 *   Voltage Reference driver.
 * HISTORY:
 *   2014.6.18        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_VREF_H
#define __DRV_VREF_H


#if DRV_VREF_SUPPORT

/* voltage reference value */
#define DRV_VREF_RefVoltage_ADC     2.510   /* voltage */
#define DRV_VREF_RefVoltage_VDAC    2.500   /* voltage */

/* voltage reference power-up time */
#define DRV_VREF_PowerUpTime        50      /* ms */

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VREF_Init
 * DESCRIPTION:
 *      Voltage Reference init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_VREF_Init(void);

#endif


#endif /* __DRV_VREF_H */

