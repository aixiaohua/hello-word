/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_mdios.h
 * DESCRIPTION:
 *   MDIO slave driver.
 * HISTORY:
 *   2014.7.8        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_MDIOS_H
#define __DRV_MDIOS_H


#if DRV_MDIOS_SUPPORT

#define DRV_MDIOS_ReadPortAddrPin() ((pADI_MDIO->MDPIN & MDPIN_MD_PIN_MSK) >> 0)
#define DRV_MDIOS_RxDev()           ((pADI_MDIO->MDFRM & MDFRM_MD_DEV_MSK) >> 7)
#define DRV_MDIOS_RxPort()          ((pADI_MDIO->MDFRM & MDFRM_MD_PHY_MSK) >> 2)
#define DRV_MDIOS_RxOpCode()        ((pADI_MDIO->MDFRM & MDFRM_MD_OP_MSK)  >> 0)
#define DRV_MDIOS_RxOffset()        ((UINT16)(pADI_MDIO->MDADR))
#define DRV_MDIOS_RxData()          ((UINT16)(pADI_MDIO->MDRXD))
#define DRV_MDIOS_TxData(_v)        do { pADI_MDIO->MDTXD = (UINT16)(_v); } while (0)
#define DRV_MDIOS_GetTxData()       (pADI_MDIO->MDTXD)

#define DRV_MDIOS_ReadStatus()      ((UINT8)(pADI_MDIO->MDSTA))
#define DRV_MDIOS_Status_FrameAddr  0x52    /* MDIO frame: Address               */
#define DRV_MDIOS_Status_FrameWrite 0x51    /* MDIO frame: Write                 */
#define DRV_MDIOS_Status_FramePRIA  0x54    /* MDIO frame: Post-Read-Inc-Address */
#define DRV_MDIOS_Status_FrameRead  0x58    /* MDIO frame: Read                  */

#define DRV_MDIOS_Reset()           do {                                                        \
                                        /* reset MDIO block */                                  \
                                        MDCON_MD_RST_BBA = 1;                                   \
                                                                                                \
                                        /* wait for MDIO ready again */                         \
                                        DRV_CPU_DelayUs(10); /* 10us, TBD */                    \
                                    } while (0)
#define DRV_MDIOS_5PortAddr()       do { MDCON_MD_PHM_BBA = 0; } while (0)
#define DRV_MDIOS_3PortAddr()       do { MDCON_MD_PHM_BBA = 1; } while (0)
#define DRV_MDIOS_OpenDrain()       do { MDCON_MD_DRV_BBA = 0; } while (0)
#define DRV_MDIOS_PushPull()        do { MDCON_MD_DRV_BBA = 1; } while (0)
#define DRV_MDIOS_SetDeviceAddr(_v) do { pADI_MDIO->MDPHY =                                     \
                                            (pADI_MDIO->MDPHY & ~MDPHY_MD_DEVADD_MSK)           \
                                            | (((_v) << 10) & MDPHY_MD_DEVADD_MSK);             \
                                    } while (0)
#define DRV_MDIOS_SelectPortAddr(_v) do { pADI_MDIO->MDPHY =                                    \
                                            (pADI_MDIO->MDPHY & ~MDPHY_MD_PHYSEL_MSK)           \
                                            | (((_v) << 5) & MDPHY_MD_PHYSEL_MSK);              \
                                    } while (0)
#define DRV_MDIOS_SetSwPortAddr(_v) do { pADI_MDIO->MDPHY =                                     \
                                            (pADI_MDIO->MDPHY & ~MDPHY_MD_PHYSW_MSK)            \
                                            | (((_v) << 0) & MDPHY_MD_PHYSW_MSK);               \
                                    } while (0)
#define DRV_MDIOS_Enable()          do {                                                        \
                                        /* enable MDIO interrupt:                               \
                                         *  ADRF : end of Address frame;                        \
                                         *  WRF  : end of Write frame;                          \
                                         *  INCF : end of PosrReadIncAdd frame;                 \
                                         *  RDF  : end of Read frame;                           \
                                         */                                                     \
                                        pADI_MDIO->MDIEN = ( MDIEN_MD_ADRI                      \
                                                           | MDIEN_MD_WRFI                      \
                                                           | MDIEN_MD_INCFI                     \
                                                           | MDIEN_MD_RDFI );                   \
                                                                                                \
                                        /* enable MDIO slave interrupt */                       \
                                        DRV_VECTOR_EnableInterrupt(VECTOR(Vector_MDIOS));       \
                                    } while (0)
#define DRV_MDIOS_Disable()         do {                                                        \
                                        /* disable MDIO interface */                            \
                                        pADI_MDIO->MDIEN = 0x00;                                \
                                                                                                \
                                        /* disable MDIO interrupt */                            \
                                        DRV_VECTOR_DisableInterrupt(VECTOR(Vector_MDIOS));      \
                                    } while (0)

#endif


#endif /* __DRV_MDIOS_H */

