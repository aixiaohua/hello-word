/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_idac.c
 * DESCRIPTION:
 *   IDAC Driver.
 * HISTORY:
 *   2017.4.26        Melinda.Lu           Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"

#if DRV_IDAC_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IDAC_Get
 * DESCRIPTION:
 *      Get IDAC Data;
 * PARAMETERS:
 *      vChannel: channel
 *      vData   : data to be set;
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL DRV_IDAC_Get
(
	IN UINT8  vChannel,
    IN UINT16 *pData
)
{
	*pData = (UINT16)drv_idac_Get(vChannel);

	return TRUE;
}

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IDAC_Set
 * DESCRIPTION:
 *      Set IDAC Data;
 * PARAMETERS:
 *      vChannel: channel
 *      vData   : data to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_IDAC_Set
(
	IN UINT8  vChannel,
    IN UINT16 vData
)
{
	/* limit DAC range */
	if (vData > DRV_IDAC_MaxValue)
	{
		vData = DRV_IDAC_MaxValue;
	}

	drv_idac_Set(vChannel,vData);

	/* wait VDAC stable */
	DRV_CPU_DelayUs(DRV_IDAC_SettlingTime_2);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IDAC_Init
 * DESCRIPTION:
 *      IDAC driver init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.26        Melinda.Lu           Create/Update
 *****************************************************************************/
void DRV_IDAC_Init(void)
{
  #if HOT_RESET_NSA_SUPPORT
    if (PLF_RESET_IsPrevHotResetNSA())
    {
        DBG_LOG_INFO("IDAC init skipped!");
        return;
    }
  #endif

#define DECLARE_IDAC(_name, _src, _ch, _cfg, _init, _desc)                  \
    do                                                                      \
    {                                                                       \
        /* set IDAC in power-down mode,                                     \
         * to force output is floating.                                     \
         */                                                                 \
        drv_idac_SetConfig((_ch), IDAC_POWER_DOWN);                         \
                                                                            \
        /* set IDAC output init value */                                    \
        DRV_IDAC_Set((_ch), (_init));                                       \
                                                                            \
        /* set IDAC configuration value */                                  \
        drv_idac_SetConfig((_ch), (_cfg));                                  \
    } while (0);

#include "def_hardware.h"

#undef DECLARE_IDAC
}

#endif

