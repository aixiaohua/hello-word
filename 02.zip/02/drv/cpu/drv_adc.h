/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_adc.h
 * DESCRIPTION:
 *   ADC Driver.
 * HISTORY:
 *   2013.5.29        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#ifndef __DRV_ADC_H__
#define __DRV_ADC_H__


#if DRV_ADC_SUPPORT

/* no actural usage, just for Source Insight can recognize these macro */
#define DECLARE_ADC(...)    /* empty */
#undef DECLARE_ADC

#define ADC(_name)          COMBINE(ADC_, _name)

/* ADC mode */
#define ADC_MODE_DISABLE    0x00
#define ADC_MODE_SINGLE     0x01
#define ADC_MODE_DIFF       0x02

/* ADC average */
#define ADC_AVG_TIME_1      0x00
#define ADC_AVG_TIME_2      0x01
#define ADC_AVG_TIME_4      0x02
#define ADC_AVG_TIME_8      0x03
#define ADC_AVG_TIME_16     0x04
#define ADC_AVG_TIME_32     0x05
#define ADC_AVG_TIME_64     0x06
#define ADC_AVG_TIME_128    0x07
#define ADC_AVG_TIME_256    0x08

/* ADC positive channel */
#define ADC_CHP_AIN0        0x00
#define ADC_CHP_AIN1        0x01
#define ADC_CHP_AIN2        0x02
#define ADC_CHP_AIN3        0x03
#define ADC_CHP_AIN4        0x04
#define ADC_CHP_AIN5        0x05
#define ADC_CHP_AIN6        0x06
#define ADC_CHP_AIN7        0x07
#define ADC_CHP_AIN8        0x08
#define ADC_CHP_AIN9        0x09
#define ADC_CHP_AIN10       0x0A
#define ADC_CHP_AIN11       0x0B
#define ADC_CHP_AIN12       0x0C
#define ADC_CHP_AIN13       0x0D
#define ADC_CHP_AIN14       0x0E
#define ADC_CHP_AIN15       0x0F
#define ADC_CHP_IDAC3       0x12
#define ADC_CHP_IDAC1       0x13
#define ADC_CHP_IDAC0       0x14
#define ADC_CHP_IDAC2       0x15
#define ADC_CHP_TEMP        0x16
#define ADC_CHP_VREFP       0x17
#define ADC_CHP_PVDD        0x18
#define ADC_CHP_IOVDD_HALF  0x19
#define ADC_CHP_AVDD_HALF   0x1A
#define ADC_CHP_VREFN       0x1B

/* ADC negative channel */
#define ADC_CHN_AIN0        0x00
#define ADC_CHN_AIN1        0x01
#define ADC_CHN_AIN2        0x02
#define ADC_CHN_AIN3        0x03
#define ADC_CHN_AIN4        0x04
#define ADC_CHN_AIN5        0x05
#define ADC_CHN_AIN6        0x06
#define ADC_CHN_AIN7        0x07
#define ADC_CHN_AIN8        0x08
#define ADC_CHN_AIN9        0x09
#define ADC_CHN_AIN10       0x0A
#define ADC_CHN_AIN11       0x0B
#define ADC_CHN_AIN12       0x0C
#define ADC_CHN_AIN13       0x0D
#define ADC_CHN_AIN14       0x0E
#define ADC_CHN_AIN15       0x0F
#define ADC_CHN_VREFP       0x10
#define ADC_CHN_VREFN       0x11
#define ADC_CHN_AGND        0x12
#define ADC_CHN_PGND        0x13


/* ADC channel definition */
typedef enum
{
    ADC_CH_START = -1,

#define DECLARE_ADC(_name, _chp, _chn, _mode, _avg, _desc)  ADC(_name) = (_chp),
#include "def_hardware.h"
#undef DECLARE_ADC

    ADC_CH_END,

    ADC_CH_MAX = ADC_CH_END
} ADC_CH_T;


/* 16-bit ADC result: 1-bit sign + 15-bit data */
#define DRV_ADC_Resolution          15
#define DRV_ADC_MaxPositiveValue    (SINT16)((1UL<<DRV_ADC_Resolution) - 1)
#define DRV_ADC_MaxNegativeValue    (SINT16)((~0UL)<<DRV_ADC_Resolution)

/* ADC data buffer */
extern SINT16   aADCBuf[ADC_CH_MAX];

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_ADC_Get
 * DESCRIPTION:
 *      Get ADC sampled value.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      ADC sampled value.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.29        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_ADC_Get(_name)      aADCBuf[(_name)]

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_ADC_ISR
 * DESCRIPTION:
 *      ADC ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.29        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_ADC_ISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_ADC_Init
 * DESCRIPTION:
 *      Init ADC.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.29        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_ADC_Init(void);

#endif
#endif

