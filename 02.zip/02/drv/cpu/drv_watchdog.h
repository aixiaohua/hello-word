/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_watchdog.h
 * DESCRIPTION:
 *   N/A
 * HISTORY:
 *   2013.5.27        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#ifndef __DRV_WATCHDOG_H
#define __DRV_WATCHDOG_H


#if DRV_WATCHDOG_SUPPORT

#define DRV_WATCHDOG_TIMEOUT_VAL    3   /* second */

#define DRV_WATCHDOG_PRESCALE       256

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_WATCHDOG_Enable
 * DESCRIPTION:
 *      Enable Watchdog Timer.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      According to the ADuCM320 datasheet,
 *       the watchdog can only be disabled once,
 *       as a result, this API can only be called once.
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_WATCHDOG_Enable()                                               \
    do {                                                                    \
        /* the watchdog is default enabled,                                 \
         *  we need to disable it first,                                    \
         *  then config it to desired state.                                \
         */                                                                 \
        DRV_WATCHDOG_Disable();                                             \
                                                                            \
        /* re-config watchdog */                                            \
        pADI_WDT->T3LD  = ((32768UL * DRV_WATCHDOG_TIMEOUT_VAL)             \
                          / DRV_WATCHDOG_PRESCALE);                         \
        pADI_WDT->T3CON = (T3CON_MOD_PERIODIC                               \
                          | T3CON_ENABLE_EN                                 \
                          | T3CON_PRE_DIV256                                \
                          | T3CON_IRQ_DIS                                   \
                          | T3CON_PMD_EN);                                  \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_WATCHDOG_Disable
 * DESCRIPTION:
 *      Disable watchdog timer.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_WATCHDOG_Disable()                                              \
    do {                                                                    \
        T3CON_ENABLE_BBA = 0;                                               \
        DRV_WATCHDOG_Kick();                                                \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_WATCHDOG_Kick
 * DESCRIPTION:
 *      Kick watchdog timer, to prevent watchdog timeout.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
#define DRV_WATCHDOG_Kick()     do {                                        \
                                    if (T3STA_CLRI_BBA == 0)                \
                                    {                                       \
                                        pADI_WDT->T3CLRI = 0xCCCC;          \
                                    }                                       \
                                } while (0)

#endif


#endif /* __DRV_WATCHDOG_H */

