/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_spi.c
 * DESCRIPTION:
 *   Simulated SPI(Serial Peripheral Interface) Driver.
 * HISTORY:
 *   2013.6.25        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_SPI_SUPPORT

#define DRV_SPI_IO_Read(_io)    DRV_IO_Read(_io)

#define DRV_SPI_IO_Write(_io, _state)                                       \
    do {                                                                    \
        DRV_IO_Write((_io), (_state));                                      \
                                                                            \
        /* wait until the output IO state is stable */                      \
        while (DRV_SPI_IO_Read(_io) != (_state))                            \
        {}                                                                  \
    } while (0)


#define DRV_SPI_FixReadDutyCycle()                                          \
    do {                                                                    \
        /* do nothing */                                                    \
    } while (0)

#define DRV_SPI_FixWriteDutyCycle()                                         \
    do {                                                                    \
        /* do nothing */                                                    \
    } while (0)


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_ReadBytes
 * DESCRIPTION:
 *      Read n Bytes data, via SPI Bus.
 * PARAMETERS:
 *      vByteLen  : Read data byte length.
 *      pBuf      : Read data buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SPI_ReadBytes
(
    IN  UINT8   vByteLen,
    OUT UINT8  *pBuf
)
{
    while (vByteLen--)
    {
        *pBuf++ = DRV_SPI_ReadByte();
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_WriteBytes
 * DESCRIPTION:
 *      Write n Bytes data, via SPI Bus.
 * PARAMETERS:
 *      vByteLen  : Write data byte length.
 *      pBuf      : Write data buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SPI_WriteBytes
(
    IN       UINT8  vByteLen,
    IN const UINT8 *pBuf
)
{
    while (vByteLen--)
    {
        DRV_SPI_WriteByte(*pBuf++);
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_ReadByte
 * DESCRIPTION:
 *      Read 1 Bytes data, via SPI Bus.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      return the read data
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT8 DRV_SPI_ReadByte(void)
{
    UINT8   vData;
    UINT8   vBitIndex;

    vData = 0x00;
    for (vBitIndex = 8; vBitIndex != 0; vBitIndex--)
    {
        /* Generate one clock, to tell SPI Slave to send one bit data */
        DRV_SPI_IO_Write(IO(SPI_SCK), IO_SPI_SCK_ACTIVE);
        DRV_SPI_FixReadDutyCycle();
        DRV_SPI_IO_Write(IO(SPI_SCK), IO_SPI_SCK_INACTIVE);

        /* Sample data: MSB first, LSB last */
        vData <<= 1;
        vData |= DRV_SPI_IO_Read(IO(SPI_MISO));
    }

    return vData;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_WriteByte
 * DESCRIPTION:
 *      Write 1 Bytes data, via SPI Bus.
 * PARAMETERS:
 *      vData      : Write data buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SPI_WriteByte(IN UINT8 vData)
{
    UINT8   vBitIndex;

    for (vBitIndex = 8; vBitIndex != 0; vBitIndex--)
    {
        BOOL    bData = READ_BIT(vData, vBitIndex-1);

        /* Transmitting data, MSB first, LSB last */
        DRV_SPI_IO_Write(IO(SPI_MOSI), bData);

        /* Generate one clock, to tell SPI Slave one bit data is ready */
        DRV_SPI_IO_Write(IO(SPI_SCK), IO_SPI_SCK_ACTIVE);
        DRV_SPI_FixWriteDutyCycle();
        DRV_SPI_IO_Write(IO(SPI_SCK), IO_SPI_SCK_INACTIVE);
    }
}

#endif

