/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_reset.h
 * DESCRIPTION:
 *   Reset source driver.
 * HISTORY:
 *   2011.3.9        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#ifndef __DRV_RESET_H
#define __DRV_RESET_H


#if DRV_RESET_SUPPORT

#define DRV_Reset_IsSoftwareReset() (RSTSTA_SWRST_BBA  != 0)
#define DRV_Reset_IsWatchdogReset() (RSTSTA_WDRST_BBA  != 0)
#define DRV_Reset_IsExternalReset() (RSTSTA_EXTRST_BBA != 0)
#define DRV_Reset_IsPORReset()      (RSTSTA_POR_BBA    != 0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Reset_SoftwareReset
 * DESCRIPTION:
 *      Force Software Reset.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.5.21        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Reset_SoftwareReset()   do {                                        \
                                        /* perform core reset */                \
                                        NVIC_SystemReset();                     \
                                    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Reset_ClearFlag
 * DESCRIPTION:
 *      Clear Reset Flags.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.5.21        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Reset_ClearFlag()       do {                                        \
                                        RSTSTA_SWRST_BBA  = 1;                  \
                                        RSTSTA_WDRST_BBA  = 1;                  \
                                        RSTSTA_EXTRST_BBA = 1;                  \
                                        RSTSTA_POR_BBA    = 1;                  \
                                    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Reset_Init
 * DESCRIPTION:
 *      Init Reset Source.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.5.21        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_Reset_Init()        do {                                            \
                                    if (DRV_Reset_IsSoftwareReset())            \
                                    {                                           \
                                        DBG_LOG_INFO("Software Reset Detected!");     \
                                    }                                           \
                                    if (DRV_Reset_IsWatchdogReset())            \
                                    {                                           \
                                        DBG_LOG_WARN("Watchdog Reset Detected!");  \
                                    }                                           \
                                    if (DRV_Reset_IsExternalReset())            \
                                    {                                           \
                                        DBG_LOG_INFO("External Reset Detected!");     \
                                    }                                           \
                                    if (DRV_Reset_IsPORReset())                 \
                                    {                                           \
                                        DBG_LOG_INFO("Power-On-Reset Detected!");     \
                                    }                                           \
                                } while (0)

#endif


#endif /* __DRV_RESET_H */

