/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_uart.h
 * DESCRIPTION:
 *   UART Driver.
 * HISTORY:
 *   2013.12.21        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_UART_H
#define __DRV_UART_H


#if DRV_UART_SUPPORT

#define drv_uart_IsRxEmpty()        (COMLSR_DR_BBA == 0)
#define drv_uart_ReadByte()         ((UINT8)pADI_UART->COMRX)
#define DRV_UART_WriteByte(_vByte)  do { pADI_UART->COMTX = (UINT8)(_vByte); } while (0)
#define DRV_UART_IsTxEmpty()        (COMLSR_THRE_BBA)


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_IsRxEmpty
 * DESCRIPTION:
 *      Check UART RX is empty or not.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      =TRUE : UART RX is empty;
 *      =FALSE: UART RX is not empty;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.24        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_UART_IsRxEmpty(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_ReadByte
 * DESCRIPTION:
 *      Read Byte from UART RX FIFO.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      The read byte data.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.24        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT8 DRV_UART_ReadByte(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_ISR
 * DESCRIPTION:
 *      UART ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.3.24        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_UART_ISR(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_Init
 * DESCRIPTION:
 *      UART Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.24        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_UART_Init(void);

#endif


#endif /* __DRV_UART_H */

