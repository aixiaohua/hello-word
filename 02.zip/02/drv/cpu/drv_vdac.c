/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_vdac.c
 * DESCRIPTION:
 *   VDAC Driver.
 * HISTORY:
 *   2013.12.30        Panda.Xiong           Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"

#if DRV_VDAC_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VDAC_Get
 * DESCRIPTION:
 *      Get VDAC Data;
 * PARAMETERS:
 *      vChannel: channel
 *      vData   : data to be set;
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL DRV_VDAC_Get
(
	IN UINT8  vChannel,
    IN UINT16 *pData
)
{
	*pData = (UINT16)drv_vdac_Get(vChannel);

	return TRUE;
}

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VDAC_Set
 * DESCRIPTION:
 *      Set VDAC Data;
 * PARAMETERS:
 *      vChannel: channel
 *      vData   : data to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_VDAC_Set
(
	IN UINT8  vChannel,
    IN UINT16 vData
)
{
	/* limit DAC range */
	if (vData > DRV_VDAC_MaxValue)
	{
		vData = DRV_VDAC_MaxValue;
	}

	drv_vdac_Set(vChannel,vData);

	/* wait VDAC stable */
	DRV_CPU_DelayUs(DRV_VDAC_SettlingTime);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VDAC_Init
 * DESCRIPTION:
 *      VDAC driver init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.12.30        Panda.Xiong           Create/Update
 *****************************************************************************/
void DRV_VDAC_Init(void)
{
  #if HOT_RESET_NSA_SUPPORT
    if (PLF_RESET_IsPrevHotResetNSA())
    {
        DBG_LOG_INFO("VDAC init skipped!");
        return;
    }
  #endif

#define DECLARE_VDAC(_name, _src, _ch, _cfg, _init, _desc)                  \
    do                                                                      \
    {                                                                       \
        /* set VDAC configuration value,                                    \
         * but still in power-down mode,                                    \
         * to force output is floating.                                     \
         */                                                                 \
        drv_vdac_SetConfig((_ch), (1UL<<VDAC_POWER_DOWN_BIT));              \
                                                                            \
        /* set VDAC output init value */                                    \
        DRV_VDAC_Set((_ch), (_init));                                       \
                                                                            \
        /* set VDAC configuration value */                                  \
        drv_vdac_SetConfig((_ch), (_cfg));                                  \
    } while (0);

#include "def_hardware.h"

#undef DECLARE_VDAC
}

#endif

