/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_i2cs.h
 * DESCRIPTION:
 *   I2C slave driver.
 * HISTORY:
 *   2017.3.7        Melinda.Lu         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_I2CS_H
#define __DRV_I2CS_H


#if DRV_I2CS_SUPPORT

#define I2CS_AutoStretchSCL_Disable		(0x0)
#define I2CS_AutoStretchSCL_Indefinite	(0xF)

#define DRV_I2CS_IsReStart(_v)      	((_v) & I2CSSTA_REPSTART_MSK)
#define DRV_I2CS_IsMasterRead(_v)   	((_v) & I2CSSTA_STXREQ_MSK)
#define DRV_I2CS_IsMasterWrite(_v)  	((_v) & I2CSSTA_SRXREQ_MSK)
#define DRV_I2CS_IsI2cStop(_v)      	((_v) & I2CSSTA_STOP_MSK)

#define DRV_I2CS_ReadStatus()      		(pADI_I2C0->I2CSSTA)

#define DRV_I2CS_ReceiveByte()      	(UINT8)(pADI_I2C0->I2CSRX)
#define DRV_I2CS_SendByte(_v)        	do { pADI_I2C0->I2CSTX = (UINT8)(_v); } while (0)

#define DRV_I2CS_FillTxFIFO(_v)			DRV_I2CS_SendByte(_v)

/* Tx FIFO is two bytes deep */
#define DRV_I2CS_FillUpTxFIFO(_v1, _v2)	do { DRV_I2CS_FillTxFIFO((_v1)); DRV_I2CS_FillTxFIFO((_v2)); } while (0)

#define DRV_I2CS_SetSlaveAddr1(_v)      do { pADI_I2C0->I2CID0 = (UINT8)(_v); } while (0)
#define DRV_I2CS_SetSlaveAddr2(_v)      do { pADI_I2C0->I2CID1 = (UINT8)(_v); } while (0)
#define DRV_I2CS_SetSlaveAddr3(_v)      do { pADI_I2C0->I2CID2 = (UINT8)(_v); } while (0)
#define DRV_I2CS_SetSlaveAddr4(_v)      do { pADI_I2C0->I2CID3 = (UINT8)(_v); } while (0)

#define DRV_I2CS_GetMatchAddrID(_v) 	(((_v) & I2CSSTA_IDMAT_MSK) >> 11)

#define DRV_I2CS_SetAutoStretchSCL(_v)	do {                                                \
                                             pADI_I2C0->I2CASSCL &= ~I2C0ASSCL_SSTRCON_MSK; \
	                                         pADI_I2C0->I2CASSCL |= (_v)<<4;                \
                                           } while (0)

#define DRV_I2CS_ClearFlags()			do {                                   \
	                                        UINT16 _data;                      \
	                                                                           \
	                                        /* read clear I2C flags */         \
                                            _data = DRV_I2CS_ReadStatus();     \
                                            NO_WARNING(_data);                 \
                                        } while (0)

#define DRV_I2CS_DisableACK()			do { I2C0SCON_NACK_BBA = 1; } while (0)
#define DRV_I2CS_EnableACK()			do { I2C0SCON_NACK_BBA = 0; DRV_I2CS_ClearFlags(); } while (0)

#define DRV_I2CS_Flush_TxFIFO()         do { I2C0FSTA_SFLUSH_BBA = 1; } while (0)
#define DRV_I2CS_Flush_RxFIFO()                                 \
    do {                                                        \
        volatile UINT8 _data;                                   \
                                                                \
        /* ADuCM320i has 2 Byte FIFO,                           \
         * so read twice to make sure flush Rx FIFO. */         \
        _data = DRV_I2CS_ReceiveByte();                         \
        _data = DRV_I2CS_ReceiveByte();                         \
        NO_WARNING(_data);                                      \
    } while (0)


#define DRV_I2CS_Disable()				do {                                                   \
											/* disable I2CS slave  */				           \
	                                        I2C0SCON_SLVEN_BBA = 0;                            \
	                                                                                           \
	                                         /* disable I2CS slave interrupt */				   \
                                            DRV_VECTOR_DisableInterrupt(I2C0S_IRQn);           \
                                        } while (0)
#define DRV_I2CS_Enable()				do {                                                   \
											/* I2CS initialization:							   \
											 *	-> Enable repeated start interrupt;	           \
											 *	-> Enable slave Transmit request interrupt;	   \
											 *	-> Enable slave Receive request interrupt; 	   \
											 *	-> Enable stop condition detected interrupt;   \
											 *	-> Enable indefinite automatic clock stretch;  \
											 *  -> Reset START STOP detect circuit;            \
											 *  -> Clear flags;                                \
											 *  -> Flush Tx&Rx FIFO;                           \
											 *  -> Enable I2C slave;                           \
											 */ 											   \
											pADI_I2C0->I2CSCON = (I2C0SCON_IENREPST_EN |       \
											                      I2C0SCON_IENSTX_EN   |       \
											                      I2C0SCON_IENSRX_EN   |       \
											                      I2C0SCON_IENSTOP_EN  |       \
											                      I2C0SCON_EARLYTXR_EN);       \
											DRV_I2CS_SetAutoStretchSCL(I2CS_AutoStretchSCL_Indefinite);\
											                                                   \
                                            I2C0SHCON_RESET_BBA = 1;                           \
	                                        DRV_I2CS_ClearFlags();                             \
	                                        DRV_I2CS_Flush_TxFIFO();                           \
	                                        DRV_I2CS_Flush_RxFIFO();                           \
                                            I2C0SCON_SLVEN_BBA = 1;                            \
                                                                                               \
											/* enable I2CS slave interrupt */				   \
                                            DRV_VECTOR_EnableInterrupt(I2C0S_IRQn);            \
                                        } while (0)

#endif


/******************************************************************************
 * FUNCTION NAME:
 * 	 DRV_I2CS_Init
 * DESCRIPTION:
 * 	 I2C slave init.
 * PARAMETERS:
 * 	 N/A
 * RETURN:
 * 	 N/A
 * NOTES:
 * 	 N/A
 * HISTORY:
 * 	 2017.3.10 	   Melinda.Lu		   Create/Update
 *****************************************************************************/
void DRV_I2CS_Init(void);

#endif /* __DRV_I2CS_H */

