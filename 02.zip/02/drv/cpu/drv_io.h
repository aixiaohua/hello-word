/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_io.h
 * DESCRIPTION:
 *   GPIO driver.
 * HISTORY:
 *   2013.12.30        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#ifndef __DRV_IO_H__
#define __DRV_IO_H__


#if DRV_IO_SUPPORT
/* Add 3 virtual ports,
 * for the related registers are not sequential between port 4 and port 5,
 * 256 bytes are reserved;
 * to simplify the register definition, reserve 3 virtual ports to occupy the reserved 256 bytes.
 */
typedef enum
{
	DRV_GPIO_PORT_0  = 0,
	DRV_GPIO_PORT_1  = 1,
	DRV_GPIO_PORT_2  = 2,
	DRV_GPIO_PORT_3  = 3,
	DRV_GPIO_PORT_4  = 4,
	DRV_GPIO_PORT_5  = 9,
}DRV_GPIO_PORT_T;

#define MODE_IO                     	0x0
#define MODE_IRQ                    	0x0
#define MODE_AUX1						0x1
#define MODE_AUX2                   	0x2
#define MODE_PLA                    	0x3

#define IO_TRI_STATE                	0x0
#define IO_INPUT_PULLUP_DISABLE     	0x1
#define IO_INPUT_PULLUP_ENABLE      	0x2
#define IO_OUTPUT_PUSHPULL          	0x3
#define IO_OUTPUT_OPENDRAIN         	0x4

#define IO_BITS_PER_PORT				8   /* bits of one IO port */
#define IO_PORT_START_ID				0
#define IO_PORT_MAX						(DRV_GPIO_PORT_5 + 1)	/* 6 physical ports + 4 virtual ports */

#define IO_PORT(_port)                  (DRV_GPIO_PORT_##_port)
#define IO_BIT(_bit)                    (_bit)

#define GPIO_MODE_MASK  				0x3

typedef struct
{
   UINT16    GPCON;        /* GPIO configuration     */
   UINT8     Reserved0[2];
   UINT8     GPOE;         /* GPIO output enable     */
   UINT8     Reserved1[3];
   UINT8     GPPUL;        /* GPIO pull-up enable    */
   UINT8     Reserved2[3];
   UINT8     GPIE;         /* GPIO input path enable */
   UINT8     Reserved3[3];
   UINT8     GPIN;         /* GPIO data input        */
   UINT8     Reserved4[3];
   UINT8     GPOUT;        /* GPIO data output       */
   UINT8     Reserved5[3];
   UINT8     GPSET;        /* GPIO data out set      */
   UINT8     Reserved6[3];
   UINT8     GPCLR;        /* GPIO data out clear    */
   UINT8     Reserved7[3];
   UINT8     GPTGL;        /* GPIO pin toggle        */
   UINT8     Reserved8[3];
   UINT8     GPODE;        /* GPIO open drain enable */
   UINT8     Reserved9[27];
} DRV_GPIO_BANK_T;

typedef struct
{
   DRV_GPIO_BANK_T GPIOxREG[IO_PORT_MAX]; /* 6 physical ports + 3 virtual ports */
} DRV_GPIO_REG_T;

#define DRV_GPIO_REG_BASE_ADDR		(0x40020000UL)
#define GPIO_REG             		((volatile DRV_GPIO_REG_T *)(DRV_GPIO_REG_BASE_ADDR))
#define GPIO_CONFIG(vPort)			(GPIO_REG->GPIOxREG[(vPort)].GPCON)
#define GPIO_OUTPUT_EN(vPort)		(GPIO_REG->GPIOxREG[(vPort)].GPOE)
#define GPIO_PULL_EN(vPort)			(GPIO_REG->GPIOxREG[(vPort)].GPPUL)
#define GPIO_INPUT_EN(vPort)		(GPIO_REG->GPIOxREG[(vPort)].GPIE)
#define GPIO_INPUT(vPort)			(GPIO_REG->GPIOxREG[(vPort)].GPIN)
#define GPIO_OUT(vPort)				(GPIO_REG->GPIOxREG[(vPort)].GPOUT)
#define GPIO_SET(vPort)				(GPIO_REG->GPIOxREG[(vPort)].GPSET)
#define GPIO_CLR(vPort)				(GPIO_REG->GPIOxREG[(vPort)].GPCLR)
#define GPIO_TOGGLE(vPort)			(GPIO_REG->GPIOxREG[(vPort)].GPTGL)
#define GPIO_OD_EN(vPort)			(GPIO_REG->GPIOxREG[(vPort)].GPODE)

#define IO_PIN_PORT(name)			IO_PIN_PORT_##name
#define IO_PIN_BIT(name)			IO_PIN_BIT_##name
#define IO(name)					IO_PIN_PORT(name), IO_PIN_BIT(name)

/* GPIO pin definition */
#define DECLARE_IO(_name, _port, _bit, _mode, _dir, _init, _desc)     \
            				IO_PIN_PORT(_name) = (_port),             \
            				IO_PIN_BIT(_name)  = (_bit),
typedef enum
{
#include "def_hardware.h"
} DRV_IO_PIN_T;
#undef DECLARE_IO

/* IO Pin low-level API */
#define drv_io_EnableOutput(_port, _bit)			SET_BIT(GPIO_OUTPUT_EN(_port), (_bit))
#define drv_io_DisableOutput(_port, _bit)			CLR_BIT(GPIO_OUTPUT_EN(_port), (_bit))
#define drv_io_EnablePull(_port, _bit)				SET_BIT(GPIO_PULL_EN(_port), (_bit))
#define drv_io_DisablePull(_port, _bit)				CLR_BIT(GPIO_PULL_EN(_port), (_bit))
#define drv_io_EnableInput(_port, _bit)				SET_BIT(GPIO_INPUT_EN(_port), (_bit))
#define drv_io_DisableInput(_port, _bit)			CLR_BIT(GPIO_INPUT_EN(_port), (_bit))
#define drv_io_EnableOpenDrain(_port, _bit)			SET_BIT(GPIO_OD_EN(_port), (_bit))
#define drv_io_DisableOpenDrain(_port, _bit)		CLR_BIT(GPIO_OD_EN(_port), (_bit))
#define drv_io_Toggle(_port, _bit)					SET_BIT(GPIO_TOGGLE(_port), (_bit))

#define drv_io_Read(_port, _bit)					READ_BIT(GPIO_INPUT(_port), (_bit))
#define drv_io_Set(_port, _bit)						SET_BIT(GPIO_SET(_port), (_bit))
#define drv_io_Clear(_port, _bit)					SET_BIT(GPIO_CLR(_port), (_bit))

/******************************************************************************
 * FUNCTION NAME:
 *		DRV_IO_SetMode
 * DESCRIPTION:
 *		Set IO pin modes.
 * PARAMETERS:
 *		vPort : port
 *		vBit  : bit
 *		vMode : mode
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.6.1		Melinda.Lu 		Create/Update
 *****************************************************************************/
void DRV_IO_SetMode
(
	IN UINT8	vPort,
	IN UINT8	vBit,
	IN UINT8	vMode
);

/******************************************************************************
 * FUNCTION NAME:
 *		DRV_IO_Read
 * DESCRIPTION:
 *		Read IO pin state.
 * PARAMETERS:
 *		vPort : port
 *		vBit  : bit
 * RETURN:
 *		IO data
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.6.1		Melinda.Lu 		Create/Update
 *****************************************************************************/
BOOL DRV_IO_Read
(
	IN UINT8	vPort,
	IN UINT8	vBit
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IO_Write
 * DESCRIPTION:
 *      Write IO pin output data.
 * PARAMETERS:
 *      vPort : port
 *      vBit  : bit
 *      vData : =1, output high;
 *              =0, output low.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.6.1        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_IO_Write
(
    IN UINT8    vPort,
    IN UINT8    vBit,
    IN BOOL     vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_IO_Init
 * DESCRIPTION:
 *      IO Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_IO_Init(void);

#endif


#endif /* __DRV_IO_H */

