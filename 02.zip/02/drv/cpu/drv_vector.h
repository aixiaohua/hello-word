/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_vector.h
 * DESCRIPTION:
 *   Vector related.
 * HISTORY:
 *   2014.10.22        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_VECTOR_H__
#define __DRV_VECTOR_H__


#if DRV_VECTOR_SUPPORT

/* external interrupt trigger mode */
#define IRQ_MODE_POS_EDGE       0x0
#define IRQ_MODE_NEG_EDGE       0x1
#define IRQ_MODE_BOTH_EDGE      0x2
#define IRQ_MODE_HIGH_LEVEL     0x3
#define IRQ_MODE_LOW_LEVEL      0x4

/* vector name definition */
#define VECTOR(n)       COMBINE(VECTOR_, n)
#define DECLARE_VECTOR(_name, _id, _handler, _priority, _cookie, _desc) VECTOR(_name) = (_id),
typedef enum
{
    DRV_VECTOR_NAME_START = -1,
    #include "def_vector.h"
    DRV_VECTOR_NAME_END
} DRV_VECTOR_NAME_T;
#undef  DECLARE_VECTOR


/* external interrupt related */
#define __IRQ_REG_ADDR(reg, n)  ((UINT32)&(pADI_INTERRUPT->reg) + ((n)&(~0x3)))
#define EXTERNAL_INT_SET_MODE(n, mode)                                      \
    do {                                                                    \
        (VP16(__IRQ_REG_ADDR(EI0CFG, (n)-1))) =                             \
            ( (VP16(__IRQ_REG_ADDR(EI0CFG, (n)-1))                          \
                & ~(0x7UL << ((((n)-1)&0x3)*4)))                            \
            | ((UINT32)((mode)<<0) << ((((n)-1)&0x3)*4)) );                 \
    } while (0)
#define EXTERNAL_INT_SET_STATE(n, enable)                                   \
    do {                                                                    \
        (VP16(__IRQ_REG_ADDR(EI0CFG, (n)-1))) =                             \
            ( (VP16(__IRQ_REG_ADDR(EI0CFG, (n)-1))                          \
                & ~(0x8UL << ((((n)-1)&0x3)*4)))                            \
            | ((UINT32)((enable)<<3) << ((((n)-1)&0x3)*4)) );               \
    } while (0)
#define EXTERNAL_INT_CLR_FLAG(n)                                            \
    do {                                                                    \
        /* write 1 to clear IRQ flag */                                     \
        WRITE_BIT(pADI_INTERRUPT->EICLR, (((n)-1)&0xF), 1);                 \
    } while (0)


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_SetInterrupt
 * DESCRIPTION:
 *      Vector Set Interrupt Flag.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_VECTOR_SetInterrupt(_id)    do {                                \
                                            NVIC->STIR = (_id);             \
                                        } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_ClearInterrupt
 * DESCRIPTION:
 *      Vector Clear Interrupt Flag.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_VECTOR_ClearInterrupt(_id)  do {                                \
                                            NVIC_ClearPendingIRQ(_id);      \
                                        } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_EnableInterrupt
 * DESCRIPTION:
 *      Vector Enable Interrupt.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_VECTOR_EnableInterrupt(_id)                                     \
    do {                                                                    \
        DRV_VECTOR_ClearInterrupt(_id);                                     \
        NVIC_EnableIRQ(_id);                                                \
                                                                            \
        switch (_id)                                                        \
        {                                                                   \
            case EINT0_IRQn:                                                \
            case EINT1_IRQn:                                                \
            case EINT2_IRQn:                                                \
            case EINT3_IRQn:                                                \
            case EINT4_IRQn:                                                \
            case EINT5_IRQn:                                                \
            case EINT6_IRQn:                                                \
            case EINT7_IRQn:                                                \
            case EINT8_IRQn:                                                \
                /* external interrupt */                                    \
                EXTERNAL_INT_CLR_FLAG(_id);                                 \
                EXTERNAL_INT_SET_STATE((_id), ENABLE);                      \
                break;                                                      \
                                                                            \
            default:                                                        \
                /* do nothing */                                            \
                break;                                                      \
        }                                                                   \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_DisableInterrupt
 * DESCRIPTION:
 *      Vector Disable Interrupt.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_VECTOR_DisableInterrupt(_id)                                    \
    do {                                                                    \
        NVIC_DisableIRQ(_id);                                               \
        DRV_VECTOR_ClearInterrupt(_id);                                     \
                                                                            \
        switch (_id)                                                        \
        {                                                                   \
            case EINT0_IRQn:                                                \
            case EINT1_IRQn:                                                \
            case EINT2_IRQn:                                                \
            case EINT3_IRQn:                                                \
            case EINT4_IRQn:                                                \
            case EINT5_IRQn:                                                \
            case EINT6_IRQn:                                                \
            case EINT7_IRQn:                                                \
            case EINT8_IRQn:                                                \
                /* external interrupt */                                    \
                EXTERNAL_INT_SET_STATE((_id), DISABLE);                     \
                EXTERNAL_INT_CLR_FLAG(_id);                                 \
                break;                                                      \
                                                                            \
            default:                                                        \
                /* do nothing */                                            \
                break;                                                      \
        }                                                                   \
    } while (0)


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_LockInterrupt
 * DESCRIPTION:
 *      Vector Lock Interrupt.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_VECTOR_LockInterrupt(_id)       ( (NVIC_GetEnable(_id)!=0) ?    \
                                              (NVIC_DisableIRQ(_id),TRUE) : \
                                              FALSE )

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_UnlockInterrupt
 * DESCRIPTION:
 *      Vector Unlock Interrupt.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_VECTOR_UnlockInterrupt(_id, _s) ( (_s) ?                        \
                                              NVIC_EnableIRQ(_id) :         \
                                              NVIC_DisableIRQ(_id) )

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VECTOR_Init
 * DESCRIPTION:
 *      Vector Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.22        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_VECTOR_Init(void);

#endif
#endif

