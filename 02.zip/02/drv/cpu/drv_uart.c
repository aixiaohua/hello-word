/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_uart.c
 * DESCRIPTION:
 *   UART driver.
 * HISTORY:
 *   2014.9.24        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_UART_SUPPORT

/* UART RX FIFO related */
#define UART_RXFIFO_LEN 250
static UINT8   aRxBuf[UART_RXFIFO_LEN];
static UINT8  *pRxBufPop;
static UINT8  *pRxBufPush;


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_IsRxEmpty
 * DESCRIPTION:
 *      Check UART RX is empty or not.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      =TRUE : UART RX is empty;
 *      =FALSE: UART RX is not empty;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.24        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_UART_IsRxEmpty(void)
{
    return (pRxBufPush == pRxBufPop);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_ReadByte
 * DESCRIPTION:
 *      Read Byte from UART RX FIFO.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      The read byte data.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.24        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT8 DRV_UART_ReadByte(void)
{
    UINT8   vTmpData;
    BOOL    bIntState = DRV_INT_LockUartInterrupt();

    vTmpData = *pRxBufPop++;
    if (pRxBufPop == (aRxBuf + sizeof(aRxBuf)))
    {
        pRxBufPop = aRxBuf;
    }

    DRV_INT_UnlockUartInterrupt(bIntState);
    return vTmpData;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_ISR
 * DESCRIPTION:
 *      UART ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2010.3.24        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_UART_ISR(void)
{
    *pRxBufPush++ = drv_uart_ReadByte();
    if (pRxBufPush == (aRxBuf + sizeof(aRxBuf)))
    {
        pRxBufPush = aRxBuf;
    }

    if (pRxBufPush == pRxBufPop)
    {
        DBG_LOG_WARN("UART RX BUFFER ... OVERFLOW");
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_UART_Init
 * DESCRIPTION:
 *      UART Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.24        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_UART_Init(void)
{
    /* init UART TX */
  #if 1
    UINT8   vDiv = (1 << ((pADI_CLKCTL->CLKCON1>>8)&0x7));

    /* enable UART Tx ASAP */
    DRV_IO_SetMode(IO(UART_TXD), MODE_AUX1);

    /* init UART related registers */
    pADI_UART->COMDIV = (CORE_CLOCK / (32*vDiv)) / DRV_UART_BAUDRATE;
    pADI_UART->COMFBR = (0x8800
                        | (((((2048 / (32*vDiv)) * CORE_CLOCK)
                            / pADI_UART->COMDIV)
                            / DRV_UART_BAUDRATE) - 2048));
	pADI_UART->COMLCR = (COMLCR_BRK_DIS
	                    | COMLCR_SP_DIS
	                    | COMLCR_EPS_ODD
	                    | COMLCR_PEN_DIS
	                    | COMLCR_STOP_DIS
	                    | COMLCR_WLS_EIGHTBITS);
  #endif

    /* init UART RX */
  #if 1
    /* enable Rx buffer full Interrupts */
    pADI_UART->COMIEN = COMIEN_ERBFI;

  #if DRV_VECTOR_SUPPORT
    /* enable UART interrupt */
    DRV_VECTOR_EnableInterrupt(VECTOR(Vector_UART));
  #endif

    /* set no RX data received */
    pRxBufPop = pRxBufPush = aRxBuf;
  #endif
}

#endif

