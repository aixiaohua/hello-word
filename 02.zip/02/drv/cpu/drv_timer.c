/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_timer.c
 * DESCRIPTION:
 *   Timer driver.
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "msa.h"
#include "app_adj.h"
#include "app_tec.h"

#if DRV_TIMER_SUPPORT

/* timer configuration table */
#define DECLARE_VECTOR_TIMER(_name, _tick, _callback, _desc)    { (_tick), (_callback) },
typedef void (*TIMER_HANDLER_FUNC)(void);
static struct
{
    DRV_TIMER_COUNTER_T vReload;
    TIMER_HANDLER_FUNC  pHandler;
} __code aTimerCfgTable[] =
{
    #include "def_vector.h"
};
#undef  DECLARE_VECTOR_TIMER

/* timer real-time table */
#define DECLARE_VECTOR_TIMER(_name, _tick, _callback, _desc)    { DISABLE, (_tick), },
static struct
{
    BOOL                bEnable;
    DRV_TIMER_COUNTER_T vCounter;
} aTimerRTTable[] =
{
    #include "def_vector.h"
};
#undef  DECLARE_VECTOR_TIMER

volatile SYSTICK_T   vSystemTickCount;
volatile SINT16      vDelayTickCount;

#if SYSTEM_TICK_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_SystemTick_Timer
 * DESCRIPTION:
 *      System Tick Timer.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_SystemTick_Timer(void)
{
    DRV_Timer_UpdateSystemTick();
}
#endif


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_SetState
 * DESCRIPTION:
 *      Set Simulated Timer State.
 * PARAMETERS:
 *      vName  : Timer Name;
 *      bState : ENABLE/DISABLE.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_SetState
(
    IN DRV_TIMER_NAME_T vName,
    IN BOOL             bState
)
{
    if (bState == ENABLE)
    {
        /* call this timer handler once, if this timer is enabled */
        aTimerCfgTable[vName].pHandler();
    }

    /* reload counter value for this timer */
    aTimerRTTable[vName].vCounter = aTimerCfgTable[vName].vReload;

    /* set timer state */
    aTimerRTTable[vName].bEnable  = bState;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_GetState
 * DESCRIPTION:
 *      Get Simulated Timer State.
 * PARAMETERS:
 *      vName  : Timer Name;
 * RETURN:
 *      TRUE : ENABLED;
 *      FALSE: DISABLE;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.5.27        Panda.Xiong        Create/Update
 *****************************************************************************/
BOOL DRV_Timer_GetState(IN DRV_TIMER_NAME_T vName)
{
    return aTimerRTTable[vName].bEnable;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_ISR
 * DESCRIPTION:
 *      Simulated Timer Dispatcher ISR.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_ISR(void)
{
    UINT32  vLoop;

    /* clear interrupt flag */
    DRV_Timer_ClearTimeoutFlag();

    for (vLoop = 0; vLoop < COUNT_OF(aTimerRTTable); vLoop++)
    {
        if (aTimerRTTable[vLoop].bEnable == ENABLE)
        {
            if (--aTimerRTTable[vLoop].vCounter == 0)
            {
                /* timer reached */

                /* reload counter value for this timer */
                aTimerRTTable[vLoop].vCounter = aTimerCfgTable[vLoop].vReload;

                /* handle this timer */
                aTimerCfgTable[vLoop].pHandler();
            }
        }
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Timer_Init
 * DESCRIPTION:
 *      Timer Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Timer_Init(void)
{
  #if TIME_MEASURE_SUPPORT
    /* Timer 1 (Short Time-Measure Timer) :
     *
     * count up
     * free-running mode
     * prescale: 16
     * source clock: HFXTAL (16MHz OSC)
     */
    pADI_TMR1->TCON = ( T1CON_EVENTEN_DIS
                      | T1CON_RLD_DIS
                      | T1CON_CLK_HFXTAL
                      | T1CON_ENABLE_DIS
                      | T1CON_MOD_FREERUN
                      | T1CON_UP_EN
                      | T1CON_PRE_DIV16 );
  #endif


    /* Timer Dispatcher */
  #if 1
    /* Cortex-M3 SysTick Timer (Timer Dispatcher) */
    SysTick_Config(DRV_Timer_SysTickInterval * (CORE_CLOCK / 1000));

   #if SYSTEM_TICK_SUPPORT
    /* reset System Tick Counter */
    vSystemTickCount = 0;

    /* enable System Tick Timer */
    DRV_Timer_SetState(TIMER(Timer_SystemTick), ENABLE);
   #endif
  #endif
}

#endif

