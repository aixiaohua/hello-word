/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_int.h
 * DESCRIPTION:
 *   N/A
 * HISTORY:
 *   2013.5.27        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#ifndef __DRV_INT_H
#define __DRV_INT_H


/* enable/disable global interrupt */
#define DRV_INT_GlobalEnableInterrupt()     __enable_irq()
#define DRV_INT_GlobalDisableInterrupt()    __disable_irq()

/* lock/unlock global interrupt */
#define DRV_INT_LockGlobalInterrupt()       (DRV_INT_IsGlobalInterruptLocked()? TRUE : (DRV_INT_GlobalDisableInterrupt(), FALSE))
#define DRV_INT_UnlockGlobalInterrupt(_s)   __set_PRIMASK(_s)
#define DRV_INT_IsGlobalInterruptLocked()   (__get_PRIMASK() == 1)

/* lock/unlock uart interrupt */
#define DRV_INT_LockUartInterrupt()         (DRV_INT_IsUartInterruptLocked()? FALSE : (NVIC_DisableIRQ(UART_IRQn), TRUE))
#define DRV_INT_UnlockUartInterrupt(_s)     do { if (_s) {NVIC_EnableIRQ(UART_IRQn);} else {NVIC_DisableIRQ(UART_IRQn);} } while (0)
#define DRV_INT_IsUartInterruptLocked()     (NVIC_GetEnable(UART_IRQn) == 0)


#endif /* __DRV_INT_H */

