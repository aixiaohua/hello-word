/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_vdac.h
 * DESCRIPTION:
 *   VDAC Driver.
 * HISTORY:
 *   2013.12.30        Panda.Xiong           Create/Update
 *
*****************************************************************************/

#ifndef __DRV_VDAC_H__
#define __DRV_VDAC_H__


#if DRV_VDAC_SUPPORT

#define _VDAC(_ch)				_ch

/* DAC channel definition */
#define DECLARE_VDAC(_name, _src, _ch, _cfg, _init, _desc)                     \
                                        DAC_CH_S(_name) = (_src),              \
                                        DAC_CH_N(_name) = (_ch),
typedef enum
{
    #include "def_hardware.h"
} DAC_VDAC_CH_T;
#undef DECLARE_VDAC

typedef enum
{
	VDAC_CH0 = 0,
	VDAC_CH1,
	VDAC_CH2,
	VDAC_CH3,
	VDAC_CH4,
	VDAC_CH5,
	VDAC_CH6,
	VDAC_CH7,
	VDAC_CH_MAX
}DRV_VDAC_CH_T;

/* 12-bit VDAC */
#define DRV_VDAC_Resolution     12
#define DRV_VDAC_MaxValue       0x0FFF

/* VDAC voltage output settling timing */
#define DRV_VDAC_SettlingTime   10      /* us */

#define VDAC_POWER_DOWN_BIT     8       /* power-down bit in DACxCON register */
#define VDAC_DISABLE            0x0100  /* VDAC is disabled, and output is floating */
#define VDAC_ENABLE_REF_2V5     0x0010  /* VDAC is enabled and the 2.5V Internal Reference is selected as the VDAC reference */
#define VDAC_ENABLE_REF_AVDD    0x0013  /* VDAC is enabled and AVDD is selected as the VDAC reference */

#define VDAC_DAT_START_BIT		16		/* DAC data: bit[27:16]  */
#define VDAC_DAT_MSK			(0xFFF << 16 )

/* VDAC registers:
 * DACxCON, address 0x40082400 - 0x4008241C, 16-bit, align to 32-bit, define as left-justify;
 * DACxDAT, address 0x40086404 - 0x40086420, 32-bit;
 */
typedef struct
{
   UINT16    VDACCON;     /* VDAC control register */
   UINT16    RESERVED;    /* reserved              */
} DRV_VDAC_CTRL_T;

typedef struct
{
   DRV_VDAC_CTRL_T  VDACxCTRL[VDAC_CH_MAX];
   UINT16           RESERVED[8178];
   UINT32           VDACxDAT[VDAC_CH_MAX];
} DRV_VDAC_REG_T;

#define DRV_VDAC_REG_BASE_ADDR	(0x40082400UL)
#define VDAC_REG             	((volatile DRV_VDAC_REG_T *)(DRV_VDAC_REG_BASE_ADDR))
#define VDAC_CONTROL(_ch)  		(VDAC_REG->VDACxCTRL[(_ch)].VDACCON)
#define VDAC_DAT(_ch)      		(VDAC_REG->VDACxDAT[(_ch)])

/* convert VDAC output to the format of VDACxDAT */
#define GET_VDACDAT(_data)		((UINT32)(_data)<<VDAC_DAT_START_BIT)

/* convert DACxDAT to the format of VDAC output */
#define GET_VDACOUT(_vdac)		(((UINT32)(_vdac) & VDAC_DAT_MSK) >> VDAC_DAT_START_BIT)

/* internl VDAC API */
#define drv_vdac_Get(_ch)				(GET_VDACOUT(VDAC_DAT(_ch)))
#define drv_vdac_SetConfig(_ch, _data)	do { VDAC_CONTROL(_ch) = (UINT16)(_data); } while (0)
#define drv_vdac_Set(_ch, _data)	    do { VDAC_DAT(_ch) = (UINT32)GET_VDACDAT(_data); } while (0)
/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VDAC_Get
 * DESCRIPTION:
 *      Get VDAC Data;
 * PARAMETERS:
 *      vChannel: channel
 *      vData   : data to be set;
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL DRV_VDAC_Get
(
	IN UINT8  vChannel,
    IN UINT16 *pData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VDAC_Set
 * DESCRIPTION:
 *      Set VDAC Data;
 * PARAMETERS:
 *      vData : data to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_VDAC_Set
(
	IN UINT8  vChannel,
    IN UINT16 vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_VDAC_Init
 * DESCRIPTION:
 *      VDAC driver init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.12.30        Panda.Xiong           Create/Update
 *****************************************************************************/
void DRV_VDAC_Init(void);

#endif


#endif /* __DRV_VDAC_H */

