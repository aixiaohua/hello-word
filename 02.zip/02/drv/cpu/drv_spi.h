/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_spi.h
 * DESCRIPTION:
 *   Simulated SPI(Serial Peripheral Interface) Driver.
 * HISTORY:
 *   2013.6.25        Panda.Xiong         Create/Update
 *
*****************************************************************************/

#ifndef __DRV_SPI_H
#define __DRV_SPI_H


#if DRV_SPI_SUPPORT


/* default, the SPI_CS pin is active low */
#ifdef DRV_SPI_CS_ACTIVE_HIGH
 #define IO_SPI_CS_ACTIVE      HIGH
 #define IO_SPI_CS_INACTIVE    LOW
#else
 #define IO_SPI_CS_ACTIVE      LOW
 #define IO_SPI_CS_INACTIVE    HIGH
#endif

/* default, the SPI_SCK pin is active high */
#ifdef DRV_SPI_SCK_ACTIVE_LOW
 #define IO_SPI_SCK_ACTIVE     LOW
 #define IO_SPI_SCK_INACTIVE   HIGH
#else
 #define IO_SPI_SCK_ACTIVE     HIGH
 #define IO_SPI_SCK_INACTIVE   LOW
#endif


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_Open
 * DESCRIPTION:
 *      Open SPI bus.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_SPI_Open()                                                      \
    do {                                                                    \
        if (DRV_IO_Read(IO(SPI_CS)) == IO_SPI_CS_ACTIVE)                    \
        {                                                                   \
            /* SPI has been opened, we should close it first,               \
             *  to force aborting the previous transmitting.                \
             */                                                             \
            DRV_SPI_Close();                                                \
        }                                                                   \
                                                                            \
        /* enable SPI transfer */                                           \
        DRV_IO_Write(IO(SPI_CS), IO_SPI_CS_ACTIVE);                         \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_Close
 * DESCRIPTION:
 *      Close SPI bus.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_SPI_Close()                                                     \
    do {                                                                    \
        /* Set SPI_CS as high to deactive the transaxtion */                \
        DRV_IO_Write(IO(SPI_CS), IO_SPI_CS_INACTIVE);                       \
    } while (0)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_IsSuccess
 * DESCRIPTION:
 *      Check this transmitting is successful or not.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      TRUE  : Success;
 *      FALSE : Fail.
 * NOTES:
 *      If SPI_CS is not active, means this SPI transfering has been interrupted,
 *       thus, assume this SPI transfering fail.
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_SPI_IsSuccess()    (DRV_IO_Read(IO(SPI_CS)) == IO_SPI_CS_ACTIVE)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_ReadBytes
 * DESCRIPTION:
 *      Read n Bytes data, via SPI Bus.
 * PARAMETERS:
 *      vByteLen  : Read data byte length.
 *      pBuf      : Read data buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SPI_ReadBytes
(
    IN  UINT8   vByteLen,
    OUT UINT8  *pBuf
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_WriteBytes
 * DESCRIPTION:
 *      Write n Bytes data, via SPI Bus.
 * PARAMETERS:
 *      vByteLen  : Write data byte length.
 *      pBuf      : Write data buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SPI_WriteBytes
(
    IN       UINT8  vByteLen,
    IN const UINT8 *pBuf
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_ReadByte
 * DESCRIPTION:
 *      Read 1 Bytes data, via SPI Bus.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      return the read data
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT8 DRV_SPI_ReadByte(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_WriteByte
 * DESCRIPTION:
 *      Write 1 Bytes data, via SPI Bus.
 * PARAMETERS:
 *      vData      : Write data buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_SPI_WriteByte(IN UINT8 vData);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_SPI_Init
 * DESCRIPTION:
 *      SPI Driver Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.25        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_SPI_Init()                                                      \
    do {                                                                    \
        /* Close SPI Bus, to disable SPI transfer */                        \
        DRV_SPI_Close();                                                    \
                                                                            \
        /* Make sure the SCK pin is inactive state */                       \
        DRV_IO_Write(IO(SPI_SCK), IO_SPI_SCK_INACTIVE);                     \
    } while (0)

#endif


#endif /* __DRV_SPI_H */

