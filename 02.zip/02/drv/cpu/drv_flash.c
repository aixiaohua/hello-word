/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_flash.c
 * DESCRIPTION:
 *   Flash driver.
 * HISTORY:
 *   2014.6.23        Panda.Xiong        Create/Update
 *
*****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_FLASH_SUPPORT

/* flash keys, used for protection */
#define FLASH_KEY_ENABLE    0xF123F456UL
#define FLASH_KEY_DISABLE   0x00000000UL

/* flash page size mask */
#define FLASH_PAGE_MASK     (~FLASH_PAGE_SIZE + 1)

/* flash fail retry count */
#define FLASH_RETRY_COUNT   (2)

/******************************************************************************
 * FUNCTION NAME:
 *      drv_flash_ExecCmd
 * DESCRIPTION:
 *      Execute flash command.
 * PARAMETERS:
 *      vCmd : Flash command to be executed.
 * RETURN:
 *      TRUE : Execute flash command successfully;
 *      FALSE: Execute flash command unsuccessfully;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.6.23        Panda.Xiong        Create/Update
 *****************************************************************************/
static __ram __noinline BOOL drv_flash_ExecCmd(IN UINT32 vCmd)
{
    /* enable executing command */
    pADI_FEE->FEEKEY = FLASH_KEY_ENABLE;

    /* set command */
    pADI_FEE->FEECMD = vCmd;

    /* add this to work-around ADuCM320 flash issue:
     *  the MDIO ISR will not be serviced sometimes,
     *  while updating flash contents.
     */
    (void)(*(volatile uint32_t *)0x4);

    /* wait for command finished */
    while (FEESTA_CMDBUSY_BBA == 1)
    {}

    /* check command result */
    return ((pADI_FEE->FEESTA & FEESTA_CMDRES_MSK) == FEESTA_CMDRES_SUCCESS);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_flash_ErasePage
 * DESCRIPTION:
 *      Erase Flash Page.
 * PARAMETERS:
 *      vAddr: Flash address in the page to be erased.
 * RETURN:
 *      TRUE : Flash block is erased successfully;
 *      FALSE: Flash block is erased unsuccessfully;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.6.23        Panda.Xiong        Create/Update
 *****************************************************************************/
static BOOL drv_flash_ErasePage(IN UINT32 vAddr)
{
    /* set flash address */
    pADI_FEE->FEEADR0 = vAddr;

    /* execute flash command: page erase */
    return drv_flash_ExecCmd(FEECMD_CMD_PAGEERASE);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_flash_ReadUnit
 * DESCRIPTION:
 *      Read one unit(64-bit) data from flash.
 * PARAMETERS:
 *      _vAddr : Flash address to be read.
 * RETURN:
 *      The read one unit flash data.
 * NOTES:
 *      The (_vAddr) must be aligned to unit base address,
 *      else, the result is unknown.
 * HISTORY:
 *      2014.6.23        Panda.Xiong        Create/Update
 *****************************************************************************/
#define drv_flash_ReadUnit(_vAddr)  (VP64(_vAddr))


/******************************************************************************
 * FUNCTION NAME:
 *      drv_flash_WriteUnit
 * DESCRIPTION:
 *      Write one unit(64-bit) into flash.
 * PARAMETERS:
 *      vAddr : Flash address to be written.
 *      vData : Word to be written.
 * RETURN:
 *      TRUE  : Flash write success;
 *      FALSE : Flash write fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.6.23        Panda.Xiong        Create/Update
 *****************************************************************************/
static BOOL drv_flash_WriteUnit(IN UINT32 vAddr, IN UINT64 vData)
{
    /* set flash address */
    pADI_FEE->FEEFLADR = vAddr;

    /* set flash data */
    pADI_FEE->FEEFLDATA0 = (UINT32)(vData >>  0);
    pADI_FEE->FEEFLDATA1 = (UINT32)(vData >> 32);

    /* execute flash command: write unit */
    return drv_flash_ExecCmd(FEECMD_CMD_WRITE);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_flash_UpdatePage
 * DESCRIPTION:
 *      Flash update driver.
 *      i.e., if the update area is not empty, will auto-erase it,
 *            then write the new data into it.
 * PARAMETERS:
 *      vAddr   : Flash Address.
 *      vLen    : Flash Update Data Length.
 *      bMemset : =TRUE, memset flash area, the memset data should be *pBuf.
 *      pBuf    : Flash Update Data Buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      Only support update one flash page, if overlap flash pages,
 *       the result is unknown.
 * HISTORY:
 *      2015.1.16        Panda.Xiong        Create/Update
 *****************************************************************************/
static void drv_flash_UpdatePage
(
    IN       UINT32  vAddr,
    IN       UINT16  vLen,
    IN       BOOL    bMemset,
    IN const UINT8  *pBuf
)
{
    static UINT64 aPageBuf[FLASH_PAGE_SIZE/sizeof(UINT64)];

    BOOL    bEqual;     /* =TRUE, no need to update flash; */
    BOOL    bErase;     /* =TRUE, need to erase flash;     */
    UINT64 *pPageBase;
    UINT32  vPageOffset;
    UINT32  vLoop;

    /* calculate flash page base address & offset */
    pPageBase   = (UINT64 *)(vAddr & FLASH_PAGE_MASK);
    vPageOffset = vAddr & ~FLASH_PAGE_MASK;

    /* add flash protection for image field */
  #if 1
    if ((((UINT32)pPageBase+1) >= (IMAGE_BASE+1))
        && ((UINT32)pPageBase < (IMAGE_BASE+IMAGE_SIZE)))
    {
        /* can't write image field, force skipped */
        return;
    }
  #endif

    /* load entire flash page contents into buffer */
    FLASH_MEMDMP(aPageBuf, pPageBase, sizeof(aPageBuf));

    /* update the flash page buffer */
    if (bMemset)
    {
        memset((UINT8 *)aPageBuf+vPageOffset, *pBuf, vLen);
    }
    else
    {
        memcpy((UINT8 *)aPageBuf+vPageOffset, pBuf, vLen);
    }

    /* for ADuCM320, the flash has this limitation:
     *  if writing to the flash unit address whose data is not all 0xFF,
     *  the reading data will be incorrect after writing.
     *
     * so, we must check the flash data first,
     *  if the flash data is all 0xFF, no need to erase;
     *  else, erase this flash page first,
     *   then write the new page data into flash.
     */
    bEqual = TRUE;
    bErase = FALSE;
    for (vLoop = 0; vLoop < COUNT_OF(aPageBuf); vLoop++)
    {
        UINT64  vSrc = aPageBuf[vLoop];
        UINT64  vDst = drv_flash_ReadUnit(pPageBase+vLoop);

        if (vDst != vSrc)
        {
            bEqual = FALSE;
            if (vDst != (UINT64)(~0ULL))
            {
                bErase = TRUE;
                break;
            }
        }
    }

    if (!bEqual)
    {
        UINT8   vFailCount = 0;

      _retry:
        if (vFailCount++ > FLASH_RETRY_COUNT)
        {
            DBG_LOG_ERROR("flash update page %#X ... FAIL", (UINT32)pPageBase);
            return;
        }

        /* erase flash page */
        if (bErase)
        {
            if (!drv_flash_ErasePage((UINT32)pPageBase))
            {
                goto _retry;
            }
        }

        /* write & verify flash page contents */
        for (vLoop = 0; vLoop < COUNT_OF(aPageBuf); vLoop++)
        {
            UINT64  vSrc = aPageBuf[vLoop];
            UINT64  vDst = drv_flash_ReadUnit(pPageBase+vLoop);

            if (vDst != vSrc)
            {
                /* write unit */
                if (!drv_flash_WriteUnit((UINT32)(pPageBase+vLoop), vSrc))
                {
                    bErase = TRUE;
                    goto _retry;
                }

                /* verify unit */
                vDst = drv_flash_ReadUnit(pPageBase+vLoop);
                if (vDst != vSrc)
                {
                    bErase = TRUE;
                    goto _retry;
                }
            }
        }
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_Update
 * DESCRIPTION:
 *      Flash update driver.
 *      i.e., if the update area is not empty, will auto-erase it,
 *            then write the new data into it.
 * PARAMETERS:
 *      vAddr   : Flash Address.
 *      vLen    : Flash Update Data Length.
 *      bMemset : =TRUE, memset flash area, the memset data should be *pBuf.
 *      pBuf    : Flash Update Data Buffer.
 * RETURN:
 *      N/A
 * NOTES:
 *      Support update one or more flash pages.
 * HISTORY:
 *      2015.1.16        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Flash_Update
(
    IN       UINT32  vAddr,
    IN       UINT32  vLen,
    IN       BOOL    bMemset,
    IN const UINT8  *pBuf
)
{
    while (vLen != 0)
    {
        UINT16  vUpdateLen;

        /* calculate the update length within this flash page */
        vUpdateLen = ((vAddr+FLASH_PAGE_SIZE)&FLASH_PAGE_MASK) - vAddr;
        if (vUpdateLen > vLen)
        {
            vUpdateLen = vLen;
        }

        /* update this flash page */
        drv_flash_UpdatePage(vAddr, vUpdateLen, bMemset, pBuf);

        /* prepare for next flash page */
        vAddr += vUpdateLen;
        vLen  -= vUpdateLen;
        if (!bMemset)
        {
            pBuf += vUpdateLen;
        }

      #if DRV_WATCHDOG_SUPPORT
        DRV_WATCHDOG_Kick();
      #endif
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_Init
 * DESCRIPTION:
 *      Flash init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.12.2        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_Flash_Init(void)
{
  #if RELEASE_MODE
    if (!DRV_Reset_IsWatchdogReset())
    {
        /* disable JTAG interface */
        DRV_CPU_SetJTAG(DISABLE);
    }
    else
  #endif
    {
        /* enable JTAG interface */
        DRV_CPU_SetJTAG(ENABLE);
    }
}


#if SECURE_MODE_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_EnterDownloadMode
 * DESCRIPTION:
 *      Enter download mode.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.11.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_Flash_EnterDownloadMode(void)
{
    /* set below memories to 0xFFs, to enter download mode:
     *  -> K1B0
     *  -> K2B0
     *  -> K1B1
     *  -> K2B1
     */
    FLASH_SET_KEY(FLASH_K1B0, 0xFFFFFFFF);
    FLASH_SET_KEY(FLASH_K2B0, 0xFFFFFFFF);
    FLASH_SET_KEY(FLASH_K1B1, 0xFFFFFFFF);
    FLASH_SET_KEY(FLASH_K2B1, 0xFFFFFFFF);

    /* force system reset */
    DRV_CPU_Reset();

    /* make sure the P2.3 is connected to GND,
     * after reboot, the ADuCM320 will auto-enter MCU internal MDIO bootloader.
     */
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Flash_ExitSecureMode
 * DESCRIPTION:
 *      Exit Secure Mode.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.11.7        Panda.Xiong         Create/Update
 *****************************************************************************/
__ram __noinline void DRV_Flash_ExitSecureMode(void)
{
  #if DRV_WATCHDOG_SUPPORT
    DRV_WATCHDOG_Kick();
  #endif

    /* erase entire flash spaces */
    drv_flash_ExecCmd(FEECMD_CMD_MASSERASE0);
    drv_flash_ExecCmd(FEECMD_CMD_MASSERASE1);

    /* force system reset */
    DRV_CPU_Reset();

    /* make sure the P2.3 is connected to GND,
     * after reboot, the ADuCM320 will auto-enter MCU internal MDIO bootloader.
     */
}

#endif

#endif

