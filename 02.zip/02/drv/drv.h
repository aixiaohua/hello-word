/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv.h
 * DESCRIPTION:
 *   N/A
 * HISTORY:
 *   2014.1.8        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_H__
#define __DRV_H__


#include "def_boot.h"
#include "dbg.h"

#include "drv_cpu.h"
#include "drv_reset.h"
#include "drv_int.h"
#include "drv_vector.h"
#include "drv_watchdog.h"
#include "drv_uart.h"
#include "drv_timer.h"
#include "drv_io.h"
#include "drv_swi.h"
#include "drv_flash.h"
#include "drv_i2cm.h"
#include "drv_mdios.h"
#include "drv_pla.h"
#include "drv_spi.h"
#include "drv_vref.h"
#include "drv_adc.h"
#include "drv_i2cs.h"

#include "drv_dac.h"
#include "drv_vdac.h"
#include "drv_idac.h"
#include "drv_dac_ad5629r.h"
#include "drv_dac_ad5691r.h"

#include "drv_cdr_gn2104.h"
#include "drv_cdr_gn2104s.h"
#include "drv_cdr_maom037057.h"


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_Retrieve
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_Retrieve(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_HighPowerDownState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_HighPowerDownState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_HighPowerState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_HighPowerState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_HighPowerUpState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_HighPowerUpState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_LowPowerState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_LowPowerState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_InitializeState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_InitializeState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_ResetState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void DRV_ResetState(void);


#endif /* __DRV_H */

