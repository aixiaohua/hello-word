/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_dac_ad5691r.h
 * DESCRIPTION:
 *   AD5691R DAC Chip Driver: 12-bit DAC. (left-justified to 16-bit)
 *   Maximum support 2-chip (2 channel) with different I2C address.
 * HISTORY:
 *   2017.4.27        Melinda.Lu         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_DAC_AD5691R_H__
#define __DRV_DAC_AD5691R_H__


#if DRV_DAC_AD5691R_SUPPORT

#define _AD5691R(_ch)					_ch

/* DAC channel definition */
#define DECLARE_DAC_AD5691R(_name, _src, _ch, _cfg, _init, _desc)               \
                                        DAC_CH_S(_name) = (_src),               \
                                        DAC_CH_N(_name) = (_ch),
typedef enum
{
    #include "def_hardware.h"
} DAC_AD5691R_CH_T;
#undef DECLARE_DAC_AD5691R

#define DAC_AD5691R_NO(name)			DAC_AD5691R_NO_##name

/* DAC channel definition */
#define DECLARE_DAC_AD5691R(_name, _src, _ch, _cfg, _init, _desc)               \
                                        DAC_AD5691R_NO(_name),
typedef enum
{
    #include "def_hardware.h"
	DAC_AD5691R_NO_MAX
} DAC_AD5691R_NO_T;
#undef DECLARE_DAC_AD5691R

/* control register */
#define DAC_AD5691R_RESET_BIT			15
 #define DAC_AD5691R_RESET_EN			(0x1<<DAC_AD5691R_RESET_BIT)

/* DAC mode set */
#define DAC_AD5691R_MODESELECT_BIT		13
 #define DAC_AD5691R_ENABLE             (0x0<<DAC_AD5691R_MODESELECT_BIT)
 #define DAC_AD5691R_DISABLE_1Kohm      (0x1<<DAC_AD5691R_MODESELECT_BIT)
 #define DAC_AD5691R_DISABLE_100Kohm    (0x2<<DAC_AD5691R_MODESELECT_BIT)
 #define DAC_AD5691R_DISABLE_Tristate   (0x3<<DAC_AD5691R_MODESELECT_BIT)

#define DAC_AD5691R_REF_BIT				12
 #define DAC_AD5691R_REF_EN				(0x0<<DAC_AD5691R_REF_BIT)
 #define DAC_AD5691R_REF_DIS			(0x1<<DAC_AD5691R_REF_BIT)

#define DAC_AD5691R_GAIN_BIT			11
 #define DAC_AD5691R_GAIN_VREF			(0x0<<DAC_AD5691R_GAIN_BIT)
 #define DAC_AD5691R_GAIN_2VREF		    (0x1<<DAC_AD5691R_GAIN_BIT)

/* DAC data buffer */
typedef struct
{
    UINT16  aRTVal[DAC_AD5691R_NO_MAX]; /* DAC real-time value */
} DAC_AD5691R_CACHE_T;
extern DAC_AD5691R_CACHE_T  vAD5691R_Cache;

#define DAC_AD5691R_RT_VAL(_ch)   		(vAD5691R_Cache.aRTVal[(_ch)])

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5691R_Get
 * DESCRIPTION:
 *      Get DAC_AD5691R Channel Data;
 * PARAMETERS:
 *      vChannel  : DAC_AD5691R Channel ID;
 * RETURN:
 *      Current DAC channel data;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_DAC_AD5691R_Get(_ch)  DAC_AD5691R_RT_VAL(_ch)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5691R_Set
 * DESCRIPTION:
 *      Set DAC_AD5691R Data;
 * PARAMETERS:
 *      vData     : data to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5691R_Set
(
	IN UINT8  vChannel,
    IN UINT16 vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5691R_Init
 * DESCRIPTION:
 *      AD5691R DAC Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5691R_Init(void);

#endif
#endif

