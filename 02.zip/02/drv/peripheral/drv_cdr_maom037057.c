/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cdr_maom037057.c
 * DESCRIPTION:
 *   CDR chip driver for MAOM037057.
 * HISTORY:
 *   2013.10.18          Panda.Xiong            Create/Update
 *
 *****************************************************************************/
#include "cfg.h"
#include "drv.h"


#if DRV_CDR_MAOM037057_SUPPORT

#define DRV_CDR_MAOM037057_STARTUP_TIME   		(10)    /* ms, TBD */

#define DRV_CDR_MAOM037057_I2C_ADDR       		(0x1A)
#define DRV_CDR_MAOM037057_REG_WIDTH      		(1)     /* Byte(s) */

/* GN2104S Config API */
#define MAOM037057_CONFIG_SETx(_name, _v)		CFG_SET8 (_name, (_v))
#define MAOM037057_CONFIG_SETxO(_name, _o, _v)	CFG_SETO8(_name, (_o)*DRV_CDR_MAOM037057_REG_WIDTH, (_v))
#define MAOM037057_CONFIG_GETx(_name)			CFG_GET8 (_name)
#define MAOM037057_CONFIG_GETxO(_name, _o)		CFG_GETO8(_name, (_o)*DRV_CDR_MAOM037057_REG_WIDTH)
#define MAOM037057_REG(x)						CFG_OFFSET(x)

typedef struct
{
    UINT16  vPhyReg;        /* Phisical register number              */
    UINT8   vRegRetrieve;   /* Register retrieve value               */
    UINT8   vWriteMask;     /* when one bit is writable, set it to 1 */
} MAOM037057_REG_T;

static __code MAOM037057_REG_T _maom037057_InitTable[] =
{
    /* physical_reg   retrieve_value   write_mask */
    {      0x00,        0x8A,        0x00,     },   /* Addr 00(0x00) : CHIPID */
    {      0x01,        0x00,        0x00,     },   /* Addr 01(0x01) : REVID */
    {      0x02,        0x00,        0xFF,     },   /* Addr 02(0x02) : Reset */
    {      0x03,        0x00,        0x0F,     },   /* Addr 03(0x03) : Alarm Type */
    {      0x04,        0x00,        0x07,     },   /* Addr 04(0x04) : CDRbias */
    {      0x05,        0x00,        0x01,     },   /* Addr 05(0x05) : I2C_address_mode */
    {      0x10,        0x00,        0x07,     },   /* Addr 06(0x06) : PRBSGEN */
    {      0x11,        0x00,        0x9C,     },   /* Addr 07(0x07) : PRBSGEN PLL */
    {      0x12,        0x00,        0x00,     },   /* Addr 08(0x08) : PRBSGEN PLL LOCK */
    {      0x14,        0x00,        0x00,     },   /* Addr 09(0x09) : LOS/LOL Status */
    {      0x15,        0x00,        0x00,     },   /* Addr 10(0x0A) : LOL_OR_LOS/LOS Status */
    {      0x16,        0x00,        0xFF,     },   /* Addr 11(0x0B) : LOS/LOL alarm */
    {      0x30,        0x00,        0xFF,     },   /* Addr 12(0x0C) : Mode_CH */
    {      0x31,        0x00,        0x03,     },   /* Addr 13(0x0D) : LOS_LOL_MASK_CH */
    {      0x32,        0x04,        0x1C,     },   /* Addr 14(0x0E) : LOS_THRS_CH */
    {      0x33,        0x10,        0x70,     },   /* Addr 15(0x0F) : CTLE_CH */
    {      0x34,        0x35,        0xFF,     },   /* Addr 16(0x10) : OUTPUT_SWING_CH */
    {      0x35,        0x00,        0xFF,     },   /* Addr 17(0x11) : OUTPUT X-Point CH */
    {      0x36,        0xA8,        0x00,     },   /* Addr 18(0x12) : EMLDRV MISCL CH */
    {      0x39,        0x00,        0x01,     },   /* Addr 19(0x13) : PRBSCHK */
    {      0x3A,        0x00,        0x1B,     },   /* Addr 20(0x14) : PRBSCHK BANK */
    {      0x3B,        0x00,        0x0D,     },   /* Addr 21(0x15) : PRBSCHK MODE */
    {      0x3C,        0x00,        0x3F,     },   /* Addr 22(0x16) : PRBSCHK Eye */
    {      0x3D,        0x00,        0x7F,     },   /* Addr 23(0x17) : PRBSCHK DELAY */
    {      0x40,        0x00,        0xFF,     },   /* Addr 24(0x18) : Mode_CH_0 */
    {      0x50,        0x00,        0xFF,     },   /* Addr 25(0x19) : Mode_CH_1 */
    {      0x60,        0x00,        0xFF,     },   /* Addr 26(0x1A) : Mode_CH_2 */
    {      0x70,        0x00,        0xFF,     },   /* Addr 27(0x1B) : Mode_CH_3 */
    {      0x41,        0x00,        0x03,     },   /* Addr 25(0x19) : LOS_LOL_CH_0 */
    {      0x51,        0x00,        0x03,     },   /* Addr 26(0x1A) : LOS_LOL_CH_1 */
    {      0x61,        0x00,        0x03,     },   /* Addr 27(0x1B) : LOS_LOL_CH_2 */
    {      0x71,        0x00,        0x03,     },   /* Addr 28(0x1C) : LOS_LOL_CH_3 */
    {      0x42,        0x04,        0x1C,     },   /* Addr 26(0x1A) : LOS_THRS_CH_0 */
    {      0x52,        0x04,        0x1C,     },   /* Addr 27(0x1B) : LOS_THRS_CH_1 */
    {      0x62,        0x04,        0x1C,     },   /* Addr 28(0x1C) : LOS_THRS_CH_2 */
    {      0x72,        0x04,        0x1C,     },   /* Addr 29(0x1D) : LOS_THRS_CH_3 */
    {      0x43,        0x10,        0x70,     },   /* Addr 27(0x1B) : CTLE_CH_0 */
    {      0x53,        0x10,        0x70,     },   /* Addr 28(0x1C) : CTLE_CH_1 */
    {      0x63,        0x10,        0x70,     },   /* Addr 29(0x1D) : CTLE_CH_2 */
    {      0x73,        0x10,        0x70,     },   /* Addr 30(0x1E) : CTLE_CH_3 */
    {      0x44,        0x35,        0xFF,     },   /* Addr 28(0x1C) : OUTPUT_SWING_CH_0 */
    {      0x54,        0x35,        0xFF,     },   /* Addr 29(0x1D) : OUTPUT_SWING_CH_1 */
    {      0x64,        0x35,        0xFF,     },   /* Addr 30(0x1E) : OUTPUT_SWING_CH_2 */
    {      0x74,        0x35,        0xFF,     },   /* Addr 31(0x1F) : OUTPUT_SWING_CH_3 */
    {      0x45,        0x00,        0xFF,     },   /* Addr 29(0x1D) : OUTPUT X-Point CH_0 */
    {      0x55,        0x00,        0xFF,     },   /* Addr 30(0x1E) : OUTPUT X-Point CH_1 */
    {      0x65,        0x00,        0xFF,     },   /* Addr 31(0x1F) : OUTPUT X-Point CH_2 */
    {      0x75,        0x00,        0xFF,     },   /* Addr 32(0x20) : OUTPUT X-Point CH_3 */
    {      0x46,        0xA8,        0x00,     },   /* Addr 30(0x1E) : EMLDRV MISCL CH_0 */
    {      0x56,        0xA8,        0x00,     },   /* Addr 31(0x1F) : EMLDRV MISCL CH_1 */
    {      0x66,        0xA8,        0x00,     },   /* Addr 32(0x20) : EMLDRV MISCL CH_2 */
    {      0x76,        0xA8,        0x00,     },   /* Addr 33(0x21) : EMLDRV MISCL CH_3 */
    {      0x49,        0x00,        0x01,     },   /* Addr 31(0x1F) : PRBSCHK_0 */
    {      0x59,        0x00,        0x01,     },   /* Addr 32(0x20) : PRBSCHK_1 */
    {      0x69,        0x00,        0x01,     },   /* Addr 33(0x21) : PRBSCHK_2 */
    {      0x79,        0x00,        0x01,     },   /* Addr 34(0x22) : PRBSCHK_3 */
    {      0x4A,        0x00,        0x1B,     },   /* Addr 32(0x20) : PRBSCHK BANK_0 */
    {      0x5A,        0x00,        0x1B,     },   /* Addr 33(0x21) : PRBSCHK BANK_1 */
    {      0x6A,        0x00,        0x1B,     },   /* Addr 34(0x22) : PRBSCHK BANK_2 */
    {      0x7A,        0x00,        0x1B,     },   /* Addr 35(0x23) : PRBSCHK BANK_3 */
    {      0x4B,        0x00,        0x0D,     },   /* Addr 33(0x21) : PRBSCHK MODE CH_0 */
    {      0x5B,        0x00,        0x0D,     },   /* Addr 34(0x22) : PRBSCHK MODE CH_1 */
    {      0x6B,        0x00,        0x0D,     },   /* Addr 35(0x23) : PRBSCHK MODE CH_2 */
    {      0x7B,        0x00,        0x0D,     },   /* Addr 36(0x24) : PRBSCHK MODE CH_3 */
    {      0x4C,        0x00,        0x3F,     },   /* Addr 34(0x22) : PRBSCHK Eye CH_0 */
    {      0x5C,        0x00,        0x3F,     },   /* Addr 35(0x23) : PRBSCHK Eye CH_1 */
    {      0x6C,        0x00,        0x3F,     },   /* Addr 36(0x24) : PRBSCHK Eye CH_2 */
    {      0x7C,        0x00,        0x3F,     },   /* Addr 37(0x25) : PRBSCHK Eye CH_3 */
    {      0x4D,        0x00,        0x7F,     },   /* Addr 35(0x23) : PRBSCHK DELAY_0 */
    {      0x5D,        0x00,        0x7F,     },   /* Addr 36(0x24) : PRBSCHK DELAY_1 */
    {      0x6D,        0x00,        0x7F,     },   /* Addr 37(0x25) : PRBSCHK DELAY_2 */
    {      0x7D,        0x00,        0x7F,     },   /* Addr 38(0x26) : PRBSCHK DELAY_3 */
    {      0x4E,        0x00,        0x00,     },   /* Addr 36(0x24) : PRBSCHK ERROR 1_0 */
    {      0x5E,        0x00,        0x00,     },   /* Addr 37(0x25) : PRBSCHK ERROR 1_1 */
    {      0x6E,        0x00,        0x00,     },   /* Addr 38(0x26) : PRBSCHK ERROR 1_2 */
    {      0x7E,        0x00,        0x00,     },   /* Addr 39(0x27) : PRBSCHK ERROR 1_3 */
    {      0x4F,        0x00,        0x00,     },   /* Addr 37(0x25) : PRBSCHK ERROR 2_0 */
    {      0x5F,        0x00,        0x00,     },   /* Addr 38(0x26) : PRBSCHK ERROR 2_1 */
    {      0x6F,        0x00,        0x00,     },   /* Addr 39(0x27) : PRBSCHK ERROR 2_2 */
    {      0x7F,        0x00,        0x00,     },   /* Addr 40(0x28) : PRBSCHK ERROR 2_3 */
};

#define DRV_CDR_MAOM037057_REG_NO_MAX			(COUNT_OF(_maom037057_InitTable) - 1)
#define MAOM037057_TRAN_PHY_OFFSET(_offset)    	(_maom037057_InitTable[(_offset)].vPhyReg)
#define MAOM037057_GET_RETRIEVE_VALUE(_offset) 	(_maom037057_InitTable[(_offset)].vRegRetrieve)
#define MAOM037057_GET_WRITE_MASK(_offset)     	(_maom037057_InitTable[(_offset)].vWriteMask)

#define DRV_CDR_MAOM037057_INIT_RETRY_COUNT		8

/* Check GN2104S is ready */
#define DRV_CDR_MAOM037057_IsReady()  				DRV_I2CM_Detect(DRV_CDR_MAOM037057_I2C_ADDR)

#if 1

#define drv_cdr_maom037057_MaskNonWritableBits(_reg_no, _v)                    \
    do {                                                                    \
        UINT8   _data;                                                      \
        UINT8   _write_mask = MAOM037057_GET_WRITE_MASK(_reg_no);              \
                                                                            \
        switch (_write_mask)                                                \
        {                                                                   \
            case 0:                                                         \
                /* read-only register */                                    \
                return TRUE;                                                \
                                                                            \
            case (UINT8)(~0):                                               \
                /* all bits are writable */                                 \
                _data = 0;                                                  \
                break;                                                      \
                                                                            \
            default:                                                        \
                /* not all bits are writable */                             \
                if (!drv_cdr_maom037057_ReadRegister(MAOM037057_TRAN_PHY_OFFSET(_reg_no),\
                                                   &_data))                 \
                {                                                           \
                    return FALSE;                                           \
                }                                                           \
                break;                                                      \
        }                                                                   \
                                                                            \
        /* only accept the writable bits */                                 \
        (_v) = (_data & ~_write_mask) | ((_v) & _write_mask);               \
    } while (0)


/******************************************************************************
 * FUNCTION NAME:
 *      drv_cdr_maom037057_ReadRegister
 * DESCRIPTION:
 *      Read CDR Chip register, low level API.
 * PARAMETERS:
 *      vRegNo : Physical register number of CDR Chip.
 *      pData  : Read register value, only valid when return TRUE.
 * RETURN:
 *      TRUE   : Read register success.
 *      FALSE  : Read register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
static BOOL drv_cdr_maom037057_ReadRegister
(
    IN  UINT8  vRegNo,
    OUT UINT8  *pData
)
{
    UINT8   aOffsetBuf[1];

    /* create offset buffer */
    aOffsetBuf[0] = vRegNo;

    return DRV_I2CM_Read(DRV_CDR_MAOM037057_I2C_ADDR,
                         (UINT8)COUNT_OF(aOffsetBuf),
                         aOffsetBuf,
                         1,
                         pData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_cdr_maom037057_WriteRegister
 * DESCRIPTION:
 *      Write CDR Chip register, low level API.
 * PARAMETERS:
 *      vRegNo  : Physical register number of CDR Chip.
 *      vRegVal : Register value to be set.
 * RETURN:
 *      TRUE    : Write register success.
 *      FALSE   : Write register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
static BOOL drv_cdr_maom037057_WriteRegister
(
    IN UINT8   vRegNo,
    IN UINT8   vRegValue
)
{
    UINT8   aOffsetBuf[1];

    /* create offset buffer */
    aOffsetBuf[0] = vRegNo;

    return DRV_I2CM_Write(DRV_CDR_MAOM037057_I2C_ADDR,
                          (UINT8)COUNT_OF(aOffsetBuf),
                          aOffsetBuf,
                          1,
                          &vRegValue);
}

/******************************************************************************
 * FUNCTION NAME:
 *		drv_cdr_maom037057_InitAllRegisters
 * DESCRIPTION:
 *		Init vall of CDR registers
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.04.05		  Melinda.Lu		 Create/Update
 *****************************************************************************/
static void drv_cdr_maom037057_InitAllRegisters(void)
{
    UINT16  vLoop;
	UINT8   vCount;
    UINT8   vRegVal;

    /* init GN2104S registers */
    for (vLoop = 0; vLoop <= DRV_CDR_MAOM037057_REG_NO_MAX; vLoop++)
    {
		if (MAOM037057_GET_WRITE_MASK(vLoop) == 0)
		{
			/* skip read-only register */
			continue;
		}

        vRegVal = MAOM037057_CONFIG_GETxO(Init_MAOM37057_TX_Reg_00, vLoop);

		for (vCount = 0; vCount < DRV_CDR_MAOM037057_INIT_RETRY_COUNT; vCount++)
		{
			if (DRV_CDR_MAOM037057_WriteRegister(vLoop, vRegVal))
			{
				/* success and exit */
				break;
			}
		}

		if (vCount >= DRV_CDR_MAOM037057_INIT_RETRY_COUNT)
		{
			/* Write failed, reset MCU */
			DRV_CPU_Reset();
		}
		
		#if DRV_WATCHDOG_SUPPORT
        DRV_WATCHDOG_Kick();
		#endif
    }
}

#endif


#if 1
BOOL DRV_CDR_MAOM037057_GetLOSL(OUT UINT8 *pRegVal)
{
    return drv_cdr_maom037057_ReadRegister(MAOM037057_LOSL_STATUS_REG, pRegVal);
}

void DRV_CDR_MAOM037057_SetOutputDis(IN UINT8 vChannel, IN BOOL bDisable)
{
    UINT8   vRegOffset;
    UINT8   vRegValue;

	vRegOffset = MAOM037057_OutputSwing_REG_L0 + vChannel*MAOM037057_REG_NO_PER_LANE;

    if (!drv_cdr_maom037057_ReadRegister(vRegOffset, &vRegValue))
    {
		return;
	}
	
	if (bDisable)
	{
		vRegValue |= (0x1<<MAOM037057_ForceMute_BIT);
	}
	else
	{
		vRegValue &= ~(0x01<<MAOM037057_ForceMute_BIT);
	}
	
    (void)drv_cdr_maom037057_WriteRegister(vRegOffset, vRegValue);
}

BOOL DRV_CDR_MAOM037057_GetCDRBypass(IN UINT8 vChannel)
{
	UINT8 	vRegOffset;
    UINT8   vRegValue;
    BOOL    vRetValue;

    vRegOffset = MAOM037057_MODE_REG_L0 + vChannel * MAOM037057_REG_NO_PER_LANE;

    /* bit[5] bypass */
    if (!drv_cdr_maom037057_ReadRegister(vRegOffset, &vRegValue))
    {
        vRetValue = FALSE;
    }

    if (((vRegValue & 0x20) >> MAOM037057_BypassAndPDown_BIT) == 1)
    {
        vRetValue = TRUE;
    }
    else
    {
        vRetValue = FALSE;
    }

    return vRetValue;
}

void DRV_CDR_MAOM037057_SetCDRBypass(IN UINT8 vChannel, IN BOOL bByPassN)
{
    UINT8   vRegOffset;
    UINT8   vRegValue;

	vRegOffset = MAOM037057_MODE_REG_L0 + vChannel * MAOM037057_REG_NO_PER_LANE;
	/* write "l0_cdr_force_bypass" bit of l0_cdr_reg_0 register:
     *  -> cdr bypass control;
     */
    if (!drv_cdr_maom037057_ReadRegister(vRegOffset, &vRegValue))
    {
		return;
	}

	if (bByPassN)
	{
		/* CDR works, set bit 0 to 0 */
		vRegValue &= ~(0x1<<MAOM037057_BypassAndPDown_BIT);
	}
	else
	{
		/* CDR bypass, set bit 0 to 1 */
		vRegValue |= (0x01<<MAOM037057_BypassAndPDown_BIT);
	}
	
    (void)drv_cdr_maom037057_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_MAOM037057_SetSquelchDis(IN UINT8 vChannel, IN BOOL bDisable)
{
    UINT8   vRegOffset;
    UINT8   vRegValue;

    vRegOffset = MAOM037057_OutputSwing_REG_L0 + vChannel*MAOM037057_REG_NO_PER_LANE;

    /* write "l0_drv_mute_on_los" bit of l0_drv_reg_0 register:
     *  -> Output driver auto-mute on LOS.
     */
    if (!drv_cdr_maom037057_ReadRegister(vRegOffset, &vRegValue))
	{
		return;
	}
	
    if (bDisable)
	{
		vRegValue &= ~(0x1<<MAOM037057_MuteOnLos_BIT);
	}
	else
	{
		vRegValue |= (0x01<<MAOM037057_MuteOnLos_BIT);
	}
	
	(void)drv_cdr_maom037057_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_MAOM037057_SetEqualization(IN UINT8 vChannel, IN UINT8 vData)
{
	UINT8 	vRegOffset;
	UINT8	vRegValue;
	
	vRegOffset = MAOM037057_CTLE_REG_L0 + vChannel*MAOM037057_REG_NO_PER_LANE;

	/* bit[6:4] ch_ctle */
	if (!drv_cdr_maom037057_ReadRegister(vRegOffset, &vRegValue))
	{
		return;
	}
	vRegValue = (vRegValue & 0x8F) | ((UINT8)((UINT16)vData<<4) & 0x70);
	(void)drv_cdr_maom037057_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_MAOM037057_SetRateSelect(IN UINT8 vRate)
{
	UINT8 	vRegOffset;
	UINT8	vRegValue;
	
	vRegOffset = MAOM037057_MODE_CONFIG_REG;

	/* bit[6] rate_select */
	if (!drv_cdr_maom037057_ReadRegister(vRegOffset, &vRegValue))
	{
		return;
	}
	
	if (vRate)
	{
		/* 28G */
		vRegValue |= (0x1<<MAOM037057_Rate_Select_BIT);
	}
	else
	{
		/* 26G */
		vRegValue &= ~(0x1<<MAOM037057_Rate_Select_BIT);
	}
	
	(void)drv_cdr_maom037057_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_MAOM037057_SetRateSelectByChannel(IN UINT8 vChannel, IN UINT8 vRate)
{
	UINT8 	vRegOffset;
	UINT8	vRegValue;
	
	vRegOffset = MAOM037057_MODE_REG_L0 + vChannel * MAOM037057_REG_NO_PER_LANE;

	/* bit[6] rate_select */
	if (!drv_cdr_maom037057_ReadRegister(vRegOffset, &vRegValue))
	{
		return;
	}
	
	if (vRate)
	{
		/* 28G */
		vRegValue |= (0x1<<MAOM037057_Rate_Select_BIT);
	}
	else
	{
		/* 26G */
		vRegValue &= ~(0x1<<MAOM037057_Rate_Select_BIT);
	}
	
	(void)drv_cdr_maom037057_WriteRegister(vRegOffset, vRegValue);
}

#endif

#if 1

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_DAC_Get
 * DESCRIPTION:
 *      Get LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      pData   : Get value.
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.10         Melinda.Lu           Create/Update
 *****************************************************************************/
BOOL DRV_CDR_MAOM037057_DAC_Get
(
	IN DAC_TYPE_T vType,
	IN UINT16    *pData
)
{
	NO_WARNING(pData);
	
	switch (vType)
	{
		default:
			*pData = 0x0000;
			return FALSE;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_DAC_Set
 * DESCRIPTION:
 *      Set LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      vData   : Set value.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.10         Melinda.Lu           Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_DAC_Set
(
	IN DAC_TYPE_T vType,
	IN UINT16     vData
)
{
	NO_WARNING(vType);
	NO_WARNING(vData);
	
	switch (vType)
	{
		default:
			/* do nothing */
			break;
	}
}
#endif

#if 1

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_ReadRegister
 * DESCRIPTION:
 *      Read CDR Chip register.
 * PARAMETERS:
 *      vRegNo : Logical register number of CDR Chip.
 *      pData  : Read register value, only valid when return TRUE.
 * RETURN:
 *      TRUE   : Read register success.
 *      FALSE  : Read register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_MAOM037057_ReadRegister
(
    IN  UINT8   vRegNo,
    OUT UINT8  *pData
)
{
    return drv_cdr_maom037057_ReadRegister(MAOM037057_TRAN_PHY_OFFSET(vRegNo), pData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_WriteRegister
 * DESCRIPTION:
 *      Write CDR Chip register.
 * PARAMETERS:
 *      vRegNo  : Logical register number of CDR Chip.
 *      vRegVal : Register value to be set.
 * RETURN:
 *      TRUE    : Write register success.
 *      FALSE   : Write register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_MAOM037057_WriteRegister
(
    IN UINT8    vRegNo,
    IN UINT8    vRegValue
)
{
    /* only accept the writable bits */
    drv_cdr_maom037057_MaskNonWritableBits(vRegNo, vRegValue);

    return drv_cdr_maom037057_WriteRegister(MAOM037057_TRAN_PHY_OFFSET(vRegNo), vRegValue);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_Entry
 * DESCRIPTION:
 *      MAOM037057 Entry.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_Entry(void)
{
    /* CDR registers command interface supporting */
  #if 1
    typedef enum
    {
        CMD_READ_MAOM037057          = 0x01,
        CMD_WRITE_MAOM037057         = 0x02,

        RESULT_BUSY = 0x80,
        RESULT_DONE = 0x81,
        RESULT_FAIL = 0x82,
    } MAOM037057_CMD_RESULT_T;

    #define MAOM037057_SET_RESULT(x)   CFG_SET8(CDR_RT_CmdResult, (x))
    #define MAOM037057_IS_CMD(x)       (((x) >= CMD_READ_MAOM037057) && ((x) <= CMD_WRITE_MAOM037057))
    #define MAOM037057_GET_CMD()       CFG_GET8(CDR_RT_CmdResult)
    #define MAOM037057_GET_REG_NO()    CFG_GET16(CDR_RT_RegNo)
    #define MAOM037057_GET_REG_DATA()  CFG_GET8(CDR_RT_RegVal)
    #define MAOM037057_SET_REG_DATA(x) CFG_SET8(CDR_RT_RegVal, (x))

    MAOM037057_CMD_RESULT_T vCmd = MAOM037057_GET_CMD();

    if (!CFG_GET_BIT(CDR_Ctrl_TX_CmdInterface_Dis) && MAOM037057_IS_CMD(vCmd))
    {
        BOOL    bResult = FALSE;
        UINT8   vData;

        MAOM037057_SET_RESULT(RESULT_BUSY);

        switch (vCmd)
        {
            case CMD_READ_MAOM037057:
                bResult = drv_cdr_maom037057_ReadRegister((UINT8)MAOM037057_GET_REG_NO(), &vData);
                if (bResult)
                {
                    MAOM037057_SET_REG_DATA(vData);
                }
                break;

            case CMD_WRITE_MAOM037057:
                bResult = drv_cdr_maom037057_WriteRegister((UINT8)MAOM037057_GET_REG_NO(), MAOM037057_GET_REG_DATA());
                break;

            default:
                break;
        }

        MAOM037057_SET_RESULT(bResult? RESULT_DONE : RESULT_FAIL);
    }
  #endif
  }


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_Retrieve
 * DESCRIPTION:
 *      Retrieve default MAOM037057 CDR Chip register value.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_Retrieve(void)
{
	UINT8   vLoop;

    /* no register value setting, use default register value */
    for (vLoop = 0; vLoop <= DRV_CDR_MAOM037057_REG_NO_MAX; vLoop++)
    {	
		CFG_Retrieve_MemSet8(CFG_PAGE(Init_MAOM37057_TX_Reg_00),
			                 CONFIG(Init_MAOM37057_TX_Reg_00)+vLoop,
			                 MAOM037057_GET_RETRIEVE_VALUE(vLoop),
			                 1);
    }

	/* save to flash */
	CFG_Retrieve_SaveConfig(CFG_PAGE(Init_MAOM37057_TX_Reg_00));
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_Init
 * DESCRIPTION:
 *      MAOM037057 CDR Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_Init(void)
{
	UINT16 vLoop;

	for (vLoop = 0; vLoop < CHIP_RETRY_MAX_TIME/CHIP_RETRY_INTERVAL; vLoop++)
	{
		if (DRV_CDR_MAOM037057_IsReady())
		{
		    /* MAOM037057 is ready, continue the following initializing */
		    break;
		}

		/* delay some time, to wait for MAOM037057 responding */
		DRV_CPU_DelayMs(CHIP_RETRY_INTERVAL);
	}
	
	if (!DRV_CDR_MAOM037057_IsReady())
	{
		/* CDR is not ready, reset MCU */
		DRV_CPU_Reset();
	}

    /* init MAOM037057 registers */
    drv_cdr_maom037057_InitAllRegisters();
}

#endif

#endif


