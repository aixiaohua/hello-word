/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_dac_ad5629r.h
 * DESCRIPTION:
 *   AD5629R DAC Chip Driver: 12-bit DAC. (left-justified to 16-bit)
 *   Maximum support 3-chip (24 channel) with different I2C address.
 * HISTORY:
 *   2013.6.7        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_DAC_AD5629R_H__
#define __DRV_DAC_AD5629R_H__


#if DRV_DAC_AD5629R_SUPPORT

/* ID is determined by A0 pin connection of DAC_AD5629R:
 * A0 pin connection is GND, ID is 3;
 * A0 pin connection is NC,  ID is 2;
 * A0 pin connection is VDD, ID is 0;
 */
#define AD5629R_CHIP_A          0x00
#define AD5629R_CHIP_B          0x02
#define AD5629R_CHIP_C          0x03

/* AD5629R voltage reference value */
#define DRV_DAC_AD5629R_RefVoltage      2.50    /* voltage */

#define _AD5629R(_ch)					_ch

/* DAC channel definition */
#define DECLARE_DAC_AD5629R(_name, _src, _ch, _cfg, _init, _desc)              \
                                        DAC_CH_S(_name) = (_src),              \
                                        DAC_CH_N(_name) = (_ch),
typedef enum
{
    #include "def_hardware.h"
} DAC_AD5629R_CH_T;
#undef DECLARE_DAC_AD5629R

#define DAC_AD5629R_NO(name)			DAC_AD5629R_NO_##name

/* DAC channel definition */
#define DECLARE_DAC_AD5629R(_name, _src, _ch, _cfg, _init, _desc)               \
                                        DAC_AD5629R_NO(_name),
typedef enum
{
    #include "def_hardware.h"
	DAC_AD5629R_NO_MAX
} DAC_AD5629R_NO_T;
#undef DECLARE_DAC_AD5629R

/* AD5629R LDAC definition: all channel */
#define DAC_AD5629_LDAC_BIT				0
 #define DAC_AD5629R_LDAC_Hardware		0x00
 #define DAC_AD5629R_LDAC_Software		0xFF

/* AD5629R Clear Code definition */
#define DAC_AD5629R_ClearCode_BIT		0
 #define DAC_AD5629R_ClearCode_0x0000	0x0
 #define DAC_AD5629R_ClearCode_0x8000	0x1
 #define DAC_AD5629R_ClearCode_0xFFFF	0x2

/* AD5629R internal REF definition */
#define DAC_AD5629R_InternalREF_BIT		0
 #define DAC_AD5629R_InternalREF_ON		1
 #define DAC_AD5629R_InternalREF_OFF	0

/* AD5629R channel state */
#define DAC_AD5629R_PDOWN_MODE_BIT		8
#define DAC_AD5629R_ENABLE              0x0
#define DAC_AD5629R_DISABLE_1Kohm       0x1
#define DAC_AD5629R_DISABLE_100Kohm     0x2
#define DAC_AD5629R_DISABLE_Tristate    0x3

/* AD5629R multi-byte mode: bit 2 of command */
#define DAC_AD5629R_MultiByteMode_BIT	2
 #define DAC_AD5629R_TwoBytesMode		1
 #define DAC_AD5629R_StandardMode		0

/* 12-bit DAC */
#define DRV_DAC_AD5629R_Resolution      12
#define DRV_DAC_AD5629R_MaxValue        0x0FFF


/* DAC data buffer */
typedef struct
{
    UINT16  aRTVal[DAC_AD5629R_NO_MAX]; /* DAC real-time value */
} DRV_DAC_AD5629R_CACHE_T;

extern DRV_DAC_AD5629R_CACHE_T       vAD5629R_Cache;
#define DAC_AD5629R_RT_VAL(_name)   (vAD5629R_Cache.aRTVal[(_name)])

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5629R_Get
 * DESCRIPTION:
 *      Get DAC_AD5629R Channel Data;
 * PARAMETERS:
 *      vChannel  : DAC_AD5629R Channel ID;
 * RETURN:
 *      Current DAC channel data;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
#define DRV_DAC_AD5629R_Get(_vChannel)  DAC_AD5629R_RT_VAL(_vChannel)

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5629R_Set
 * DESCRIPTION:
 *      Set DAC_AD5629R Data;
 * PARAMETERS:
 *      vData : data to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5629R_Set
(
	IN UINT8  vChannel,
    IN UINT16 vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5629R_Reset
 * DESCRIPTION:
 *      AD5629R DAC Chip Reset.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5629R_Reset(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5629R_Init
 * DESCRIPTION:
 *      AD5629R DAC Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5629R_Init(void);

#endif
#endif

