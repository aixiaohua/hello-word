/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cdr_gn2104rx.h
 * DESCRIPTION:
 *   CDR chip driver for GN2104RX.
 * HISTORY:
 *   2013.10.18          Panda.Xiong            Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_CDR_GN2104S_H__
#define __DRV_CDR_GN2104S_H__


#if DRV_CDR_GN2104S_SUPPORT

#define DRV_CDR_GN2104S_I2C_ADDR       (0x2C)

/* additional API, for SFF-8636 usage */
#if 1
BOOL DRV_CDR_GN2104S_GetLOSL               (OUT UINT8 *pRegVal);
void DRV_CDR_GN2104S_SetEmphasis         (IN UINT8 vChannel, IN UINT8 vData);
void DRV_CDR_GN2104S_SetAmplitude        (IN UINT8 vChannel, IN UINT8 vData);
void DRV_CDR_GN2104S_SetCDRBypass        (IN UINT8 vChannel, IN BOOL  bByPassN);
void DRV_CDR_GN2104S_SetSquelchDis       (IN UINT8 vChannel, IN BOOL  bDisable);
void DRV_CDR_GN2104S_SetOutputDis        (IN UINT8 vChannel, IN BOOL  bDisable);
void DRV_CDR_GN2104S_SetSliceLevelAdjust(IN UINT8 vChannel, IN UINT8 vData);
#endif

/* additional API, for LOS adjustment */
#if 1
void DRV_CDR_GN2104S_SetRxLOSThreshold     (IN UINT8 vChannel, IN UINT8 vData);
void DRV_CDR_GN2104S_SetRxLOSHysteresis    (IN UINT8 vChannel, IN UINT8 vData);
#endif

#define GN2104S_REG_NO_PER_LANE			(256)

#define GN2104S_DRV_REG_0_L0			(50)
 #define GN2104S_ForceMute_BIT			(0)
 #define GN2104S_MuteOnLos_BIT			(1)

#define GN2104S_CDR_REG_0_L0			(0)
 #define GN2104S_ForceBypass_BIT		(0)

#define GN2104S_DRV_REG_2_L0			(52)

#define GN2104S_LOSL_OUTPUT_REG_0		(1041)
 #define GN2104S_LOS_START_BIT			(0)
 #define GN2104S_LOL_START_BIT			(4)

/* LOS threshold */
#define GN2104S_LOS_REG_0_L0			(1)

/* LOS hysteresis */
#define GN2104S_LOS_REG_1_L0			(2)

/* Equalization  */
#define GN2104S_EQ_REG_2_L0				(11)

/* DAC channel definition */
#define DECLARE_DAC_GN2104RX(_name, _src, _ch, _cfg, _init, _desc)             \
                                        DAC_CH_S(_name) = (_src),              \
                                        DAC_CH_N(_name) = (_ch),
typedef enum
{
    #include "def_hardware.h"
} DAC_GN2104RX_CH_T;
#undef DECLARE_DAC_GN2104RX

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_ReadRegister
 * DESCRIPTION:
 *      Read CDR Chip register.
 * PARAMETERS:
 *      vRegNo : Register number of CDR Chip.
 *      pData  : Read register value, only valid when return TRUE.
 * RETURN:
 *      TRUE   : Read register success.
 *      FALSE  : Read register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104S_ReadRegister
(
    IN  UINT16  vRegNo,
    OUT UINT8  *pData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_WriteRegister
 * DESCRIPTION:
 *      Write CDR Chip register.
 * PARAMETERS:
 *      vRegNo  : Register number of CDR Chip.
 *      vRegVal : Register value to be set.
 * RETURN:
 *      TRUE    : Write register success.
 *      FALSE   : Write register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104S_WriteRegister
(
    IN UINT16   vRegNo,
    IN UINT8    vRegValue
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_DAC_Get
 * DESCRIPTION:
 *      Get LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      pData   : Get value.
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.8.31         Dennis.Long           Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104S_DAC_Get
(
	IN DAC_TYPE_T vType,
	IN UINT16    *pData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_DAC_Set
 * DESCRIPTION:
 *      Set LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      vData   : Set value.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.10         Melinda.Lu           Create/Update
 *      2017.8.31         Dennis.Long        Update
 *****************************************************************************/
void DRV_CDR_GN2104S_DAC_Set
(
	IN DAC_TYPE_T vType,
	IN UINT16     vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_Entry
 * DESCRIPTION:
 *      GN2104S Entry.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_GN2104S_Entry(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_Retrieve
 * DESCRIPTION:
 *      Retrieve default GN2104S CDR Chip register value.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_GN2104S_Retrieve(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_Init
 * DESCRIPTION:
 *      GN2104S CDR Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_GN2104S_Init(void);

#endif
#endif

