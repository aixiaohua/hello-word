/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_dac_ad5691r.h
 * DESCRIPTION:
 *   AD5691R DAC Chip Driver: 12-bit DAC. (left-justified to 16-bit)
 *   Maximum support 2-chip (2 channel) with different I2C address.
 * HISTORY:
 *   2017.4.27        Melinda.Lu         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_DAC_AD5691R_SUPPORT

/* maximum channel per AD5691R chip */
#define DRV_DAC_AD5691R_CHANNEL_MAX      	1

/* 12-bit DAC */
#define DRV_DAC_AD5691R_Resolution      	12
#define DRV_DAC_AD5691R_MaxValue       		0x0FFF

/* AD5691R power-up time, coming out of power-down mode */
#define DRV_DAC_AD5691R_PowerUpTime     	4   /* us */

/* DAC Voltage Output Settling timing, 10us;
 *  which is defined in Page21 of "AD5691R_5669R.pdf".
 */
#define DRV_DAC_AD5691R_SettlingTime    	10  /* us */

/* retry count: 8 */
#define DRV_DAC_AD5691R_RETRY_COUNT			8
#define DRV_DAC_AD5691R_RETRY_DELAY			4   /* us */


/* Command Table:
 *  Command Byte               Data High Byte          Data Low Byte              Operation
 *  DB7 DB6 DB5 DB4 [DB3:DB0]  [DB7:DB3]   [DB2:DB0]   [DB7:DB4] DB3 DB2 DB1 DB0
 *  0   0   0   0    xxxx      xxxxx       xxx         xxxx      x   x   x   x    NOP: do nothing
 *  0   0   0   1    xxxx      DB15:DB11   DB10:BD8    DB7:DB4   x   x   x   x    Write input register
 *  0   0   1   0    xxxx      xxxxx       xxx         xxxx      x   x   x   x    Update DAC register(LDAC software)
 *  0   0   1   1    xxxx      DB15:DB11   DB10:BD8    DB7:DB4   x   x   x   x    Write DAC and input registers
 *  0   1   0   0    xxxx      DB15:DB11   000         0000      0   0   0   0    Write control register
 */

/* Control Register:
 * D15   D14   D13   D12   D11
 * Reset PD1   PD0   REF   Gain
 */

typedef enum
{
    AD5691R_CMD_NOP = 0x0,           /* do nothing                        */
    AD5691R_CMD_WriteInput,          /* Write to Input Register           */
    AD5691R_CMD_UpdateDAC,           /* Update DAC Register(LDAC software */
    AD5691R_CMD_WriteInputAndUpdate, /* Write DAC and input registers     */
    AD5691R_CMD_WriteControl,        /* Write control register            */
} AD5691R_CMD_T;

/* The AD5691R has a 7-bit slave address.
 * The parts have a slave address whose five MSBs are 10011,
 * the second last bit set by the state of the A0 address pin,
 * and the LSB is 0.
 * which determines the state of the A0 and A1 address bits.
 *
 *    A0 Pin Connection     A0    I2C Address
 *   --------------------  ----  -------------
 *          GND             0       0x98
 *          VLOGIC			1		0x9C
 */
#define AD5691R_I2C_ADDR_GND		0x98
#define AD5691R_I2C_ADDR_VDD		0x9C

/* maximum slave ID */
#define AD5691R_I2C_ADDRESS_MAX		2


static UINT8 aAd5691r_I2cAddress[AD5691R_I2C_ADDRESS_MAX] = {AD5691R_I2C_ADDR_GND, AD5691R_I2C_ADDR_VDD};
static UINT8 vAd5691rNo = 0x00;
static UINT8 vAd5691rChipId[AD5691R_I2C_ADDRESS_MAX];

DAC_AD5691R_CACHE_T  vAD5691R_Cache;

/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5691r_ExecuteCmd
 * DESCRIPTION:
 *      Execute commands
 * PARAMETERS:
 *      vCmd    : command
 *      vChannel: channel
 *      vData   : data
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5691r_ExecuteCmd
(
	IN UINT8    vSlaveId,
    IN UINT8    vCmd,
    IN UINT16   vData
)
{
    UINT8   vCmdByte;
    UINT8   aBuf[2];

	/* left-justified command to 8-bit */
    vCmdByte = (UINT8)((UINT16)vCmd << 4);

	/* left-justified data to 16-bit */
    SET_BE_16(aBuf, vData);

    if (!DRV_I2CM_WriteBytes(vSlaveId,
                             vCmdByte,
                             sizeof(aBuf),
                             aBuf))
    {
        return FALSE;
    }

	return TRUE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5691R_SetConfig
 * DESCRIPTION:
 *      Set DAC_AD5691R control register;
 * PARAMETERS:
 *      vChannel  : channel
 *      vData     : data to be set;
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL drv_dac_ad5691r_SetConfig
(
	IN UINT8  vChannel,
    IN UINT16 vData
)
{
	UINT8 vSlaveId;

	/* get I2C address */
	vSlaveId = aAd5691r_I2cAddress[(vChannel/DRV_DAC_AD5691R_CHANNEL_MAX)];

    /* output DAC value */
	return drv_dac_ad5691r_ExecuteCmd(vSlaveId, AD5691R_CMD_WriteControl, vData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5691R_Reset
 * DESCRIPTION:
 *      AD5691R DAC Chip Reset.
 * PARAMETERS:
 *      vSlaveId: I2C address
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5691r_Reset
(
	IN UINT8 vSlaveId
)
{
	NO_WARNING(vSlaveId);
	return TRUE;//drv_dac_ad5691r_ExecuteCmd(vSlaveId, AD5691R_CMD_WriteControl, DAC_AD5691R_RESET_EN);
}

/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5691R_ScanId
 * DESCRIPTION:
 *      Scan AD5691R DAC Chip ID.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.5.2        Melinda.Lu         Create/Update
 *****************************************************************************/
static void drv_dac_ad5691r_ScanId(void)
{
	UINT8 vSelectedId;

	vAd5691rNo = 0x00;

/* Slave Address is determined by A0 pin connection of DAC_AD5691R:
 * A0 pin connection is GND, Channel is _AD5691R(0);
 * A0 pin connection is VDD, Channel is _AD5691R(1);
 */

#define DECLARE_DAC_AD5691R(_name, _src, _ch, _cfg, _init, _desc)           \
	do {																	\
		if (((_ch)%DRV_DAC_AD5691R_CHANNEL_MAX) == 0)                       \
		{                                                                   \
			/* new chip is detected */                                      \
			vSelectedId = (UINT8)(_ch)/DRV_DAC_AD5691R_CHANNEL_MAX; 		\
			                                                                \
			/* record slave address */										\
			vAd5691rChipId[vAd5691rNo] = aAd5691r_I2cAddress[vSelectedId];  \
			vAd5691rNo++;                                                   \
		}                                                                   \
	} while (0);

#include "def_hardware.h"

#undef DECLARE_DAC_AD5691R
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5691R_Set
 * DESCRIPTION:
 *      Set DAC_AD5691R Data;
 * PARAMETERS:
 *      vData     : data to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5691R_Set
(
	IN UINT8  vChannel,
    IN UINT16 vData
)
{
	UINT8 vSlaveId;
	BOOL  bResult;

	if (vData >= DRV_DAC_AD5691R_MaxValue)
	{
		vData = DRV_DAC_AD5691R_MaxValue;
	}

	/* record current DAC value */
    DAC_AD5691R_RT_VAL(vChannel) = vData;

	/* get I2C address */
	vSlaveId = aAd5691r_I2cAddress[(vChannel/DRV_DAC_AD5691R_CHANNEL_MAX)];

    /* output DAC value, 12-bit left-aligned */
	vData = (UINT16)((UINT32)vData << 4);
	bResult = drv_dac_ad5691r_ExecuteCmd(vSlaveId, AD5691R_CMD_WriteInputAndUpdate, vData);

    if (!bResult)
    {
        DBG_LOG_INFO("Set DAC_AD5691R CH%d to %.4X ... FAIL", vChannel, vData);
    }

	/* delay */
	DRV_CPU_DelayUs(DRV_DAC_AD5691R_SettlingTime);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5691R_Init
 * DESCRIPTION:
 *      AD5691R DAC Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5691R_Init(void)
{
	UINT8  vLoop;
	UINT8  vRetryCnt;

  #if HOT_RESET_NSA_SUPPORT
    if (PLF_RESET_IsPrevHotResetNSA())
    {
        DBG_LOG_INFO("AD5691R init skipped!");
        return;
    }
  #endif

    memset(&vAD5691R_Cache, 0x0, sizeof(vAD5691R_Cache));

	/* scan chip slave ID selected */
	drv_dac_ad5691r_ScanId();

	/* init chip */
	for (vLoop = 0; vLoop < vAd5691rNo; vLoop++)
	{
	    /* write control register to reset AD5691 */
		for (vRetryCnt = 0; vRetryCnt < DRV_DAC_AD5691R_RETRY_COUNT; vRetryCnt++)
		{
			if (drv_dac_ad5691r_Reset(vAd5691rChipId[vLoop]))
	        {
				break;
			}

			/* add delay */
			DRV_CPU_DelayUs(DRV_DAC_AD5691R_PowerUpTime);
		}

		if (vRetryCnt >= DRV_DAC_AD5691R_RETRY_COUNT)
		{
			/* reset MCU */
			DRV_CPU_Reset();
		}

	    /* add delay to guarantee reset is completed */
		DRV_CPU_DelayUs(DRV_DAC_AD5691R_PowerUpTime);
	}

	/* init each channel */
#define DECLARE_DAC_AD5691R(_name, _src, _ch, _cfg, _init, _desc)           \
    do {                                                                    \
        /* set DAC channel state */                                         \
        (void)drv_dac_ad5691r_SetConfig((_ch), (_cfg));                     \
                                                                            \
        /* set DAC channel data */                                          \
        DRV_DAC_AD5691R_Set((_ch), (_init));                                \
    } while (0);

#include "def_hardware.h"

#undef DECLARE_DAC_AD5691R
}

#endif

