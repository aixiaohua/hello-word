/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cdr_gn2104.c
 * DESCRIPTION:
 *   GN2104 CDR driver.
 * HISTORY:
 *   2014.9.19        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"

#if DRV_CDR_GN2104_SUPPORT

#define DRV_CDR_GN2104_LOAD_MACRO_INTERVAL      100         /* us */
#define DRV_CDR_GN2104_LOAD_MACRO_MAX_TIME      1000000UL   /* us */
#define DRV_CDR_GN2104_EXEC_MACRO_INTERVAL      10          /* us */
#define DRV_CDR_GN2104_EXEC_MACRO_MAX_TIME      5000000UL   /* us */

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_LoadMacro
 * DESCRIPTION:
 *      Load macro file into CDR_GN2104.
 * PARAMETERS:
 *      vI2cAddr: GN2104 I2C slave address;
 * RETURN:
 *      TRUE : Load macro file pass;
 *      FALSE: Load macro file fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.18        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_LoadMacro(IN UINT8 vI2cAddr)
{
    FILE_INFO_T *pMacroInfo;
    UINT8        aOffsetBuf[3];
    UINT32       vLoop;

	pMacroInfo = &vImageInfo.aFile[FILE_ID_MACRO];

    /* validate macro file */
    if (!pMacroInfo->bValid)
    {
        DBG_LOG_INFO("Invalid macro file detected!");
        goto _exit;
    }

    /* load macro file */
  #if 1
   #if TIME_MEASURE_SUPPORT
    DRV_Timer_LongTimeMeasure_Start();
   #endif
    aOffsetBuf[0] = 0xFB;
    aOffsetBuf[1] = 0x00;
    aOffsetBuf[2] = 0x00;
    if (!DRV_I2CM_Write(vI2cAddr,
                        sizeof(aOffsetBuf),
                        aOffsetBuf,
                        pMacroInfo->pSig->vFileContentSize,
                        pMacroInfo->pContent))
    {
        DBG_LOG_INFO("Sending macro file ... FAIL");
        goto _exit;
    }

    /* read macro file loading return code */
    for (vLoop = 0;
         vLoop < DRV_CDR_GN2104_LOAD_MACRO_MAX_TIME;
         vLoop += DRV_CDR_GN2104_LOAD_MACRO_INTERVAL)
    {
        UINT8   vResult;

        /* wait for GN2104 macro loading */
        DRV_CPU_DelayUs(DRV_CDR_GN2104_LOAD_MACRO_INTERVAL);

        /* read macro file loading return code */
        aOffsetBuf[0] = 0xFE;
        aOffsetBuf[1] = 0x00;
        aOffsetBuf[2] = 0x46;
        if (!DRV_I2CM_Read(vI2cAddr,
                          sizeof(aOffsetBuf),
                          aOffsetBuf,
                          sizeof(vResult),
                          &vResult))
        {
            continue;
        }

        switch (vResult)
        {
            case 0xFF:  /* macro file has been loaded successfully      */
               #if TIME_MEASURE_SUPPORT
               {
                UINT32  vTime = (UINT32)DRV_Timer_LongTimeMeasure_Stop();
                NO_WARNING(vTime);
                DBG_LOG_INFO("Macro load time: %d(ms)", vTime);
               }
               #endif
                return TRUE;

            case 0x00:  /* no macro file has been loaded                */
                DBG_LOG_INFO("err_code: no macro file has been loaded");
                goto _exit;

            case 0x02:  /* macro file is not compatible with the device */
                DBG_LOG_INFO("err_code: macro file is not compatible with the device");
                goto _exit;

            default:
                /* invalid response */
            case 0x0F:  /* macro file loading is in progress            */
                /* do nothing */
                break;
        }
    }
    if (vLoop >= DRV_CDR_GN2104_LOAD_MACRO_MAX_TIME)
    {
        DBG_LOG_INFO("Load macro ... TIMEOUT");
    }
  #endif

_exit:
    /* load macro file failed */
    DBG_LOG_INFO("CDR [%.2X] Load macro ... FAIL", vI2cAddr);
    return FALSE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ExecMacro
 * DESCRIPTION:
 *      Execute macro for CDR_GN2104.
 * PARAMETERS:
 *      vI2cAddr: GN2104 I2C slave address;
 *      pMacro  : Macro parameters;
 * RETURN:
 *      TRUE : Execute macro pass;
 *      FALSE: Execute macro fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.18        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ExecMacro(IN UINT8 vI2cAddr, IN OUT GN2104_MACRO_T *pMacro)
{
    UINT8   vCmd = pMacro->vCmd;
    UINT8   aOffsetBuf[2];
    UINT32  vLoop;

    NO_WARNING(vCmd);

    DBG_LOG_DEBUG("Exec Macro:"
            "\n\r vI2cAddr=%.2X  vCmd=%.2X"
            "\n\r aInBuf=%.2X %.2X %.2X %.2X",
            vI2cAddr, pMacro->vCmd,
            pMacro->aInBuf[0], pMacro->aInBuf[1],
            pMacro->aInBuf[2], pMacro->aInBuf[3]);

    /* write macro input buffer & command */
    SET_BE_16(aOffsetBuf, 0x0C00);
    if (!DRV_I2CM_Write(vI2cAddr,
                        COUNT_OF(aOffsetBuf),
                        aOffsetBuf,
                        sizeof(pMacro->aInBuf)+1,
                        pMacro->aInBuf))
    {
        DBG_LOG_WARN("CDR [%.2X] write macro [%.2X] in_buf & command ... FAIL",
                  vI2cAddr, vCmd);
        return FALSE;
    }

    /* waiting for macro executing */
    for (vLoop = 0;
         vLoop < DRV_CDR_GN2104_EXEC_MACRO_MAX_TIME;
         vLoop += DRV_CDR_GN2104_EXEC_MACRO_INTERVAL)
    {
        SET_BE_16(aOffsetBuf, 0x0C10);
        if (DRV_I2CM_Read(vI2cAddr,
                          COUNT_OF(aOffsetBuf),
                          aOffsetBuf,
                          sizeof(pMacro->vCmd),
                          &(pMacro->vCmd)))
        {
            if (pMacro->vCmd == GN2104_MACRO_SuccessACK)
            {
                break;
            }
            else if (pMacro->vCmd == GN2104_MACRO_ErrorACK)
            {
                DBG_LOG_WARN("CDR [%.2X] exec macro [%.2X] ... FAIL",
                          vI2cAddr, vCmd);
                break;
            }
            else
            {
                /* invalid result, do nothing */
            }
        }

        /* wait for GN2104 macro executing */
        DRV_CPU_DelayUs(DRV_CDR_GN2104_EXEC_MACRO_INTERVAL);
    }
    if (vLoop >= DRV_CDR_GN2104_EXEC_MACRO_MAX_TIME)
    {
        DBG_LOG_WARN("CDR [%.2X] exec macro [%.2X] ... TIMEOUT",
                  vI2cAddr, vCmd);
    }

    /* read macro output buffer */
    for (vLoop = 0;
         vLoop < DRV_CDR_GN2104_EXEC_MACRO_MAX_TIME;
         vLoop += DRV_CDR_GN2104_EXEC_MACRO_INTERVAL)
    {
        SET_BE_16(aOffsetBuf, 0x0C11);
        if (DRV_I2CM_Read(vI2cAddr,
                          COUNT_OF(aOffsetBuf),
                          aOffsetBuf,
                          sizeof(pMacro->aOutBuf),
                          pMacro->aOutBuf))
        {
            break;
        }

        /* wait for GN2104 macro executing */
        DRV_CPU_DelayUs(DRV_CDR_GN2104_EXEC_MACRO_INTERVAL);
    }
    if (vLoop >= DRV_CDR_GN2104_EXEC_MACRO_MAX_TIME)
    {
        DBG_LOG_WARN("CDR [%.2X] read macro [%.2X] out_buf ... TIMEOUT",
                  vI2cAddr, vCmd);
        return FALSE;
    }

    /* macro executing finish */
    if (pMacro->vCmd != GN2104_MACRO_SuccessACK)
    {
        DBG_LOG_WARN("CDR [%.2X] execute macro [%.2X] ... FAIL",
                  vI2cAddr, vCmd);
        return FALSE;
    }

    DBG_LOG_DEBUG("aOutBuf=%.2X %.2X %.2X %.2X",
            pMacro->aOutBuf[0], pMacro->aOutBuf[1],
            pMacro->aOutBuf[2], pMacro->aOutBuf[3]);

    return TRUE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_GetMacroVersion
 * DESCRIPTION:
 *      Get macro version.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 * RETURN:
 *      0x0000: Get macro version failed;
 *      Else  : The gotten macro version; (format: 0x1E0C means 1-E-0-C)
 * NOTES:
 *      N/A
 * HISTORY:
 *      2015.08.06        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT16 DRV_CDR_GN2104_GetMacroVersion(IN UINT8 vI2cAddr)
{
    GN2104_MACRO_T    vMacro;

    memset(&vMacro, 0x00, sizeof(vMacro));
    vMacro.vCmd = GN2104_MACRO_QueryMacroVersion;
    if (!DRV_CDR_GN2104_ExecMacro(vI2cAddr, &vMacro))
    {
        /* get macro version failed */
        return 0x0000;
    }

    if (vMacro.aOutBuf[3] <= 0x9)
    {
        return (UINT16)( ((vMacro.aOutBuf[0]             & 0xF) << 12)
                       | ((((vMacro.aOutBuf[1]-'A')+0xA) & 0xF) <<  8)
                       | ((vMacro.aOutBuf[2]             & 0xF) <<  4)
                       | ((vMacro.aOutBuf[3]             & 0xF) <<  0) );
    }
    else
    {
        return (UINT16)( ((vMacro.aOutBuf[0]             & 0xF) << 12)
                       | ((((vMacro.aOutBuf[1]-'A')+0xA) & 0xF) <<  8)
                       | ((vMacro.aOutBuf[2]             & 0xF) <<  4)
                       | ((((vMacro.aOutBuf[3]-'A')+0xA) & 0xF) <<  0) );
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ResetDeviceMode
 * DESCRIPTION:
 *      Reset Device Mode.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 * RETURN:
 *      TRUE : Reset Device Mode pass;
 *      FALSE: Reset Device Mode fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.13        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ResetDeviceMode(IN UINT8 vI2cAddr)
{
    GN2104_MACRO_T    vMacro;

    memset(&vMacro, 0x00, sizeof(vMacro));
    vMacro.vCmd = GN2104_MACRO_ResetDeviceMode;
    return DRV_CDR_GN2104_ExecMacro(vI2cAddr, &vMacro);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ConfigDeviceMode
 * DESCRIPTION:
 *      Config Device Mode.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 *      vMode    : Device Mode;
 * RETURN:
 *      TRUE : Config Device Mode pass;
 *      FALSE: Config Device Mode fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.13        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ConfigDeviceMode
(
    IN UINT8                vI2cAddr,
    IN GN2104_DeviceMode_T  vMode
)
{
    GN2104_MACRO_T    vMacro;

    memset(&vMacro, 0x00, sizeof(vMacro));
    vMacro.vCmd      = GN2104_MACRO_ConfigDeviceMode;
    vMacro.aInBuf[0] = (UINT8)vMode;
    return DRV_CDR_GN2104_ExecMacro(vI2cAddr, &vMacro);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ConfigLaneMode
 * DESCRIPTION:
 *      Config Lane Mode.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 *      vLane    : Lane ID;
 *      vMode    : Lane Mode;
 *      vFreqDiv : Frequency Divider;
 * RETURN:
 *      TRUE : Config Lane Mode pass;
 *      FALSE: Config Lane Mode fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.13        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ConfigLaneMode
(
    IN UINT8                vI2cAddr,
    IN UINT8                vLane,
    IN GN2104_LaneMode_T    vMode,
    IN GN2104_LaneFreq_T    vFreqDiv
)
{
    GN2104_MACRO_T    vMacro;

    memset(&vMacro, 0x00, sizeof(vMacro));
    vMacro.vCmd      = GN2104_MACRO_ConfigLaneMode;
    vMacro.aInBuf[0] = ((vLane<<0) | ((UINT8)vMode<<2) | ((UINT8)vFreqDiv<<5));
    return DRV_CDR_GN2104_ExecMacro(vI2cAddr, &vMacro);
}

#endif

