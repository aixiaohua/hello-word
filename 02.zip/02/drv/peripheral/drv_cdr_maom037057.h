/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cdr_maom037057.h
 * DESCRIPTION:
 *   CDR chip driver for MAOM037057.
 * HISTORY:
 *   2013.10.18          Panda.Xiong            Create/Update
 *
 *****************************************************************************/

#ifndef __DRV_CDR_MAOM037057_H
#define __DRV_CDR_MAOM037057_H


#if DRV_CDR_MAOM037057_SUPPORT

/* additional API */
#if 1
BOOL DRV_CDR_MAOM037057_GetLOSL(OUT UINT8 *pRegVal);
void DRV_CDR_MAOM037057_SetOutputDis(IN UINT8 vChannel, IN BOOL bDisable);
BOOL DRV_CDR_MAOM037057_GetCDRBypass(IN UINT8 vChannel);
void DRV_CDR_MAOM037057_SetCDRBypass(IN UINT8 vChannel, IN BOOL bByPassN);
void DRV_CDR_MAOM037057_SetSquelchDis(IN UINT8 vChannel, IN BOOL bDisable);
void DRV_CDR_MAOM037057_SetEqualization(IN UINT8 vChannel, IN UINT8 vData);
void DRV_CDR_MAOM037057_SetRateSelect(IN UINT8 vRate);
void DRV_CDR_MAOM037057_SetRateSelectByChannel(IN UINT8 vChannel, IN UINT8 vRate);
#endif

#define MAOM037057_REG_NO_PER_LANE		0x10

/* LOSL status: bit[7:4] - LOL; bit[3:0]- LOS */
#define MAOM037057_LOSL_STATUS_REG		0x14
 #define MAOM037057_LOL_START_BIT		4
 #define MAOM037057_LOS_START_BIT		0

#define MAOM037057_OutputSwing_REG_L0	0x44
 #define MAOM037057_MuteOnLos_BIT		7
 #define MAOM037057_ForceMute_BIT		6

#define MAOM037057_MODE_REG_L0			0x40
 #define MAOM037057_BypassAndPDown_BIT	5

/* bit[6:4] ch_ctle */
#define MAOM037057_CTLE_REG_L0			0x43

/* bit[6] ch_x_rate_select */
#define MAOM037057_MODE_CONFIG_REG		0x30
 #define MAOM037057_Rate_Select_BIT		6
 #define MAOM037057_Rate_26G			0x0
 #define MAOM037057_Rate_28G			0x1

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_DAC_Get
 * DESCRIPTION:
 *      Get LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      pData   : Get value.
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.10         Melinda.Lu           Create/Update
 *****************************************************************************/
BOOL DRV_CDR_MAOM037057_DAC_Get
(
	IN DAC_TYPE_T vType,
	IN UINT16    *pData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_DAC_Set
 * DESCRIPTION:
 *      Set LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      vData   : Set value.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.10         Melinda.Lu           Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_DAC_Set
(
	IN DAC_TYPE_T vType,
	IN UINT16     vData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_ReadRegister
 * DESCRIPTION:
 *      Read CDR Chip register.
 * PARAMETERS:
 *      vRegNo : Register number of CDR Chip.
 *      pData  : Read register value, only valid when return TRUE.
 * RETURN:
 *      TRUE   : Read register success.
 *      FALSE  : Read register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_MAOM037057_ReadRegister
(
    IN  UINT8   vRegNo,
    OUT UINT8  *pData
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_WriteRegister
 * DESCRIPTION:
 *      Write CDR Chip register.
 * PARAMETERS:
 *      vRegNo  : Register number of CDR Chip.
 *      vRegVal : Register value to be set.
 * RETURN:
 *      TRUE    : Write register success.
 *      FALSE   : Write register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_MAOM037057_WriteRegister
(
    IN UINT8    vRegNo,
    IN UINT8    vRegValue
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_Entry
 * DESCRIPTION:
 *      MAOM037057 Entry.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_Entry(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_Retrieve
 * DESCRIPTION:
 *      Retrieve default MAOM037057 CDR Chip register value.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_Retrieve(void);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_MAOM037057_Init
 * DESCRIPTION:
 *      MAOM037057 CDR Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_MAOM037057_Init(void);

#endif


#endif /* __DRV_CDR_MAOM037057_H */

