/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cdr_gn2104.h
 * DESCRIPTION:
 *   GN2104 CDR driver.
 * HISTORY:
 *   2014.9.19        Panda.Xiong         Create/Update
 *
 *****************************************************************************/


#ifndef __DRV_CDR_GN2104_H
#define __DRV_CDR_GN2104_H


#if DRV_CDR_GN2104_SUPPORT

/* GN2104 supported macro list */
#if 1

/* Acknowledge */
#define GN2104_MACRO_SuccessACK             0x00    /* Success Acknowledgement */
#define GN2104_MACRO_ErrorACK               0x01    /* Error Acknowledgement */

/* General Purpose Macro */
#define GN2104_MACRO_QueryMacroVersion      0x18    /* Query Macros Version */
#define GN2104_MACRO_QueryVCCL              0x20    /* Query VCCL Monitor Reading */
#define GN2104_MACRO_QueryTEMP              0x28    /* Query Temperature Sensor Reading */
#define GN2104_MACRO_ConfigSliceMode        0x5E    /* Configure Slice Level Adjust or Offset Correction Mode */
#define GN2104_MACRO_QuerySliceMode         0x5F    /* Query Slice Level Adjust or Offset Correction Mode */
#define GN2104_MACRO_ConfigDeviceMode       0x60    /* Configure Device Mode */
#define GN2104_MACRO_ConfigSwing            0x61    /* Configure Output Driver Main Swing */
#define GN2104_MACRO_ConfigSlice            0x62    /* Configure Slice Level Adjust */
#define GN2104_MACRO_ConfigLaneMode         0x63    /* Configure Device Lane Mode */
#define GN2104_MACRO_ConfigMulticastMode    0x64    /* Configure Device Multicast Mode */
#define GN2104_MACRO_ResetDeviceMode        0x65    /* Reset Device Configuration Modes */
#define GN2104_MACRO_ConfigCrossPoint       0x66    /* Configure Output Driver Cross Point Adjust */
#define GN2104_MACRO_QueryDeviceMode        0x68    /* Query Device Mode */
#define GN2104_MACRO_QuerySwing             0x69    /* Query Output Driver Main Swing */
#define GN2104_MACRO_QuerySlice             0x6A    /* Query Slice Level Adjust */
#define GN2104_MACRO_QueryLaneMode          0x6B    /* Query Device Lane Mode */
#define GN2104_MACRO_QueryMulticastMode     0x6C    /* Query Device Multicast Mode */
#define GN2104_MACRO_QueryCrossPoint        0x6D    /* Query Output Driver Cross Point Adjust */

/* PRBS Macro */
#define GN2104_MACRO_ConfigPrbsRx           0x50    /* Configure and Enable PRBS Checker */
#define GN2104_MACRO_QueryPrbsRx            0x51    /* Query PRBS Checker Setting */
#define GN2104_MACRO_SetPrbsRxState         0x52    /* Control PRBS Checker Enable */
#define GN2104_MACRO_QueryPrbsRxCount       0x53    /* Query PRBS Checker Reading */
#define GN2104_MACRO_ConfigPrbsTx           0x58    /* Configure and Enable PRBS Generator */
#define GN2104_MACRO_QueryPrbsTx            0x59    /* Query PRBS Generator Setting */
#define GN2104_MACRO_SetPrbsTxState         0x5A    /* Control PRBS Generator */

/* Eye Scanner Macro */
#define GN2104_MACRO_QueryEyeScanAttr       0x41    /* Query Eye Scanner Output Memory Attributes */
#define GN2104_MACRO_CtrlEyeSweep           0x42    /* Control Eye Sweep */

/* Adaptive EQ */
#define GN2104_MACRO_ConfigAdaptiveEQ       0x11    /* Configure One-time Adaptive EQ Auto-retry on Fail (only available on 1-E-1-A or later) */
#define GN2104_MACRO_StartAdaptiveEQ        0x12    /* Request One-Time Adaptive EQ */
#define GN2104_MACRO_QueryAdaptiveEQ        0x13    /* Query   One-Time Adaptive EQ Status */
#define GN2104_MACRO_RestartLaneAdaptiveEQ  0x14    /* Request One-time Adaptive EQ on Single Lane */
#define GN2104_MACRO_QueryAdaptiveEQErrCode 0x15    /* Query One-time Adaptive EQ Error Codes (only available on 1-E-1-A or later) */

typedef struct
{
    UINT8   aInBuf[16];
    UINT8   vCmd;
    UINT8   aOutBuf[16];
} GN2104_MACRO_T;

#endif

#if 1

/* GN2104 supported device mode */
typedef enum
{
    GN2104_DeviceMode_MissionLowPower = 0x01,
    GN2104_DeviceMode_LB2MCK          = 0x02,
    GN2104_DeviceMode_LB2MCKInvert    = 0x03,
    GN2104_DeviceMode_MCK2LB          = 0x04,
    GN2104_DeviceMode_MCK2LBInvert    = 0x05,
    GN2104_DeviceMode_MCK2PRBS        = 0x06,
    GN2104_DeviceMode_MCK2PRBSInvert  = 0x07,
    GN2104_DeviceMode_LB2PRBS         = 0x08,
    GN2104_DeviceMode_LB2PRBSInvert   = 0x09,
    GN2104_DeviceMode_PRBS2LB         = 0x0A,
    GN2104_DeviceMode_PRBS2LBInvert   = 0x0B,
} GN2104_DeviceMode_T;

/* GN2104 supported lane mode */
typedef enum
{
    GN2104_LaneMode_RecoveredCLK2MCK     = 0x00,
    GN2104_LaneMode_RecoveredCLK2LB      = 0x01,
    GN2104_LaneMode_RecoveredCLK2PRBS    = 0x02,
    GN2104_LaneMode_RetimedData2LB       = 0x03,
    GN2104_LaneMode_RetimedData2LBInvert = 0x04,
} GN2104_LaneMode_T;

/* GN2104 supported lane frenqucy divider */
typedef enum
{
    GN2104_DeviceLaneFreq_1div2   = 0x00,
    GN2104_DeviceLaneFreq_1div4   = 0x01,
    GN2104_DeviceLaneFreq_1div8   = 0x02,
    GN2104_DeviceLaneFreq_1div16  = 0x03,
    GN2104_DeviceLaneFreq_1div64  = 0x04,
    GN2104_DeviceLaneFreq_1div256 = 0x05,
} GN2104_LaneFreq_T;

/* GN2104 supported multicast lane */
typedef enum
{
    GN2104_MulticastLane_0        = (1<<0),
    GN2104_MulticastLane_1        = (1<<1),
    GN2104_MulticastLane_2        = (1<<2),
    GN2104_MulticastLane_3        = (1<<3),

    GN2104_MulticastLane_None     = 0x00,
    GN2104_MulticastLane_All      = ( GN2104_MulticastLane_0
                                    | GN2104_MulticastLane_1
                                    | GN2104_MulticastLane_2
                                    | GN2104_MulticastLane_3 ),
} GN2104_MulticastLane_T;

/* GN2104 supported multicast mode */
typedef enum
{
    GN2104_MulticastMode_LB2CDR   = (0<<4),
    GN2104_MulticastMode_PRBS2CDR = (1<<4),
} GN2104_MulticastMode_T;

#endif

/* PRBS generator related */
#if 1

/* PRBS generator source select */
typedef enum
{
    GN2104_PrbsTxSrc_ExtClock       = ((0<<1) | (0<<2)),
    GN2104_PrbsTxSrc_VCO_25dot59GHz = ((1<<1) | (2<<2)),
    GN2104_PrbsTxSrc_VCO_26dot16GHz = ((1<<1) | (3<<2)),
    GN2104_PrbsTxSrc_VCO_26dot81GHz = ((1<<1) | (4<<2)),
    GN2104_PrbsTxSrc_VCO_27dot46GHz = ((1<<1) | (5<<2)),
    GN2104_PrbsTxSrc_VCO_28dot16GHz = ((1<<1) | (6<<2)),
} GN2104_PrbsTxSrc_T;

/* PRBS generator pattern sequence */
typedef enum
{
    GN2104_PrbsTxPattern_9       = (0<<5),
    GN2104_PrbsTxPattern_15      = (1<<5),
    GN2104_PrbsTxPattern_31      = (2<<5),
    GN2104_PrbsTxPattern_Div1    = (3<<5),
    GN2104_PrbsTxPattern_Div2    = (4<<5),
    GN2104_PrbsTxPattern_Div4    = (5<<5),
    GN2104_PrbsTxPattern_Div8    = (6<<5),
    GN2104_PrbsTxPattern_Div32   = (7<<5),
    GN2104_PrbsTxPattern_Invalid = 0xFF,    /* extended CDR unsupported pattern */
} GN2104_PrbsTxPattern_T;

#endif

/* PRBS checker related */
#if 1

/* GN2104 PRBS checker state */
typedef enum
{
    GN2104_PrbsRxState_Disable    = ((0<<0) | (0<<1) | (0<<4) | (0<<5)),
    GN2104_PrbsRxState_Enable_0   = ((1<<0) | (0<<1)),
    GN2104_PrbsRxState_Enable_1   = ((1<<0) | (1<<1)),
    GN2104_PrbsRxState_Enable_2   = ((1<<4) | (0<<5)),
    GN2104_PrbsRxState_Enable_3   = ((1<<4) | (1<<5)),
    GN2104_PrbsRxState_Enable_0_2 = (GN2104_PrbsRxState_Enable_0 | GN2104_PrbsRxState_Enable_2),
    GN2104_PrbsRxState_Enable_1_3 = (GN2104_PrbsRxState_Enable_1 | GN2104_PrbsRxState_Enable_3),
} GN2104_PrbsRxState_T;

/* GN2104 PRBS checker pattern */
typedef enum
{
    GN2104_PrbsRxPattern_9       = ((0<<2) | (0<<6)),
    GN2104_PrbsRxPattern_15      = ((1<<2) | (1<<6)),
    GN2104_PrbsRxPattern_31      = ((2<<2) | (2<<6)),
    GN2104_PrbsRxPattern_Unknown = ((3<<2) | (3<<6)),
    GN2104_PrbsRxPattern_Invalid = 0xFF,    /* extended CDR unsupported pattern */
} GN2104_PrbsRxPattern_T;

typedef struct
{
    UINT16  vTotalCount;
    UINT16  vErrorCount;
} GN2104_PRBS_RX_LANE_COUNT_T;
typedef struct
{
    GN2104_PRBS_RX_LANE_COUNT_T aLane[2];
} GN2104_PRBS_RX_COUNT_T;

#endif

#if 1

typedef enum
{
    GN2104_AdaptiveEQState_Reset        = 0x00,
    GN2104_AdaptiveEQState_CheckPower   = 0x01,
    GN2104_AdaptiveEQState_CheckSignal1 = 0x02,
    GN2104_AdaptiveEQState_CheckSignal2 = 0x03,
    GN2104_AdaptiveEQState_Adapting1    = 0x04,
    GN2104_AdaptiveEQState_Adapting2    = 0x05,
    GN2104_AdaptiveEQState_Adapting3    = 0x06,
    GN2104_AdaptiveEQState_Adapting4    = 0x07,
    GN2104_AdaptiveEQState_Adapting5    = 0x08,
    GN2104_AdaptiveEQState_DoneAdaption = 0x09,
    GN2104_AdaptiveEQState_Error        = 0x0A,

    /* internal extended state, to restart AdaptiveEQ */
    GN2104_AdaptiveEQState_Restart      = 0x0F,
} GN2104_AdaptiveEQState_T;

#endif

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_LoadMacro
 * DESCRIPTION:
 *      Load macro file into CDR_GN2104.
 * PARAMETERS:
 *      vI2cAddr: GN2104 I2C slave address;
 * RETURN:
 *      TRUE : Load macro file pass;
 *      FALSE: Load macro file fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.18        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_LoadMacro(IN UINT8 vI2cAddr);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ExecMacro
 * DESCRIPTION:
 *      Execute macro for CDR_GN2104.
 * PARAMETERS:
 *      vI2cAddr: GN2104 I2C slave address;
 *      pMacro  : Macro parameters;
 * RETURN:
 *      TRUE : Execute macro pass;
 *      FALSE: Execute macro fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.9.18        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ExecMacro(IN UINT8 vI2cAddr, IN OUT GN2104_MACRO_T *pMacro);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_GetMacroVersion
 * DESCRIPTION:
 *      Get macro version.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 * RETURN:
 *      0x0000: Get macro version failed;
 *      Else  : The gotten macro version; (format: 0x1E0C means 1-E-0-C)
 * NOTES:
 *      N/A
 * HISTORY:
 *      2015.08.06        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT16 DRV_CDR_GN2104_GetMacroVersion(IN UINT8 vI2cAddr);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ResetDeviceMode
 * DESCRIPTION:
 *      Reset Device Mode.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 * RETURN:
 *      TRUE : Reset Device Mode pass;
 *      FALSE: Reset Device Mode fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.13        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ResetDeviceMode(IN UINT8 vI2cAddr);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ConfigDeviceMode
 * DESCRIPTION:
 *      Config Device Mode.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 *      vMode    : Device Mode;
 * RETURN:
 *      TRUE : Config Device Mode pass;
 *      FALSE: Config Device Mode fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.13        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ConfigDeviceMode
(
    IN UINT8                vI2cAddr,
    IN GN2104_DeviceMode_T  vMode
);

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104_ConfigLaneMode
 * DESCRIPTION:
 *      Config Lane Mode.
 * PARAMETERS:
 *      vI2cAddr : GN2104 I2C slave address;
 *      vLane    : Lane ID;
 *      vMode    : Lane Mode;
 *      vFreqDev : Frequency Devider;
 * RETURN:
 *      TRUE : Config Lane Mode pass;
 *      FALSE: Config Lane Mode fail;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.10.13        Panda.Xiong         Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104_ConfigLaneMode
(
    IN UINT8                vI2cAddr,
    IN UINT8                vLane,
    IN GN2104_LaneMode_T    vMode,
    IN GN2104_LaneFreq_T    vFreqDev
);

#endif


#endif /* __DRV_CDR_GN2104_H */

