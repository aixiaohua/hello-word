/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_cdr_gn2104s.c
 * DESCRIPTION:
 *   CDR chip driver for GN2104S.
 * HISTORY:
 *   2013.10.18          Panda.Xiong            Create/Update
 *
 *****************************************************************************/

#define _DRV_CDR_GN2104S_INTERNAL_
#include "cfg.h"
#include "drv.h"


#if DRV_CDR_GN2104S_SUPPORT


#define DRV_CDR_GN2104S_RESET_TIME     (10)     /* us, t_chip_reset */
#define DRV_CDR_GN2104S_STARTUP_TIME   (700)    /* us */

#define DRV_CDR_GN2104S_REG_WIDTH      (1)     /* Byte(s) */

/* GN2104S Config API */
#define GN2104S_CONFIG_SETx(_name, _v)       CFG_SET8 (_name, (_v))
#define GN2104S_CONFIG_SETxO(_name, _o, _v)  CFG_SETO8(_name, (_o)*DRV_CDR_GN2104S_REG_WIDTH, (_v))
#define GN2104S_CONFIG_GETx(_name)           CFG_GET8 (_name)
#define GN2104S_CONFIG_GETxO(_name, _o)      CFG_GETO8(_name, (_o)*DRV_CDR_GN2104S_REG_WIDTH)

typedef struct
{
    UINT16  vPhyReg;        /* Phisical register number              */
    UINT8   vRegRetrieve;   /* Register retrieve value               */
    UINT8   vWriteMask;     /* when one bit is writable, set it to 1 */
} GN2104S_REG_T;

static __code GN2104S_REG_T _gn2104s_InitTable[] =
{
    /* physical_reg   retrieve_value   write_mask */
    {      0x0000,        0x00,        0x07,     },   /* Addr 00(0x00) : l0_cdr_reg_0 */
    {      0x0001,        0x08,        0x3F,     },   /* Addr 01(0x01) : l0_los_reg_0 */
    {      0x0002,        0x03,        0x07,     },   /* Addr 02(0x02) : l0_los_reg_1 */
    {      0x000B,        0x10,        0x7F,     },   /* Addr 04(0x04) : l0_eq_reg_2 */
    {      0x0032,        0x04,        0x07,     },   /* Addr 06(0x06) : l0_drv_reg_0 */
    {      0x0034,        0x00,        0x1F,     },   /* Addr 07(0x07) : l0_drv_reg_2 */
    {      0x003C,        0x00,        0x01,     },   /* Addr 09(0x09) : l0_pd_reg_0 */
    {      0x003D,        0x00,        0x01,     },   /* Addr 10(0x0A) : l0_pd_reg_1 */
    {      0x003F,        0x00,        0x01,     },   /* Addr 11(0x0B) : l0_pd_reg_3 */
    {      0x0042,        0x00,        0x03,     },   /* Addr 12(0x0C) : l0_pd_reg_6 */
    {      0x0100,        0x00,        0x07,     },   /* Addr 13(0x0D) : l1_cdr_reg_0 */
    {      0x0101,        0x14,        0x3F,     },   /* Addr 14(0x0E) : l1_los_reg_0 */
    {      0x0102,        0x06,        0x07,     },   /* Addr 15(0x0F) : l1_los_reg_1 */
    {      0x010B,        0x10,        0x7F,     },   /* Addr 17(0x11) : l1_eq_reg_2 */
    {      0x0132,        0x04,        0x07,     },   /* Addr 19(0x13) : l1_drv_reg_0 */
    {      0x0134,        0x00,        0x1F,     },   /* Addr 20(0x14) : l1_drv_reg_2 */
    {      0x013C,        0x00,        0x01,     },   /* Addr 22(0x16) : l1_pd_reg_0 */
    {      0x013D,        0x00,        0x01,     },   /* Addr 23(0x17) : l1_pd_reg_1 */
    {      0x013F,        0x00,        0x01,     },   /* Addr 24(0x18) : l1_pd_reg_3 */
    {      0x0142,        0x00,        0x03,     },   /* Addr 25(0x19) : l1_pd_reg_6 */
    {      0x0200,        0x00,        0x07,     },   /* Addr 26(0x1A) : l2_cdr_reg_0 */
    {      0x0201,        0x14,        0x3F,     },   /* Addr 27(0x1B) : l2_los_reg_0 */
    {      0x0202,        0x06,        0x07,     },   /* Addr 28(0x1C) : l2_los_reg_1 */
    {      0x020B,        0x10,        0x7F,     },   /* Addr 30(0x1E) : l2_eq_reg_2 */
    {      0x0232,        0x04,        0x07,     },   /* Addr 32(0x20) : l2_drv_reg_0 */
    {      0x0234,        0x00,        0x1F,     },   /* Addr 33(0x21) : l2_drv_reg_2 */
    {      0x023C,        0x00,        0x01,     },   /* Addr 35(0x23) : l2_pd_reg_0 */
    {      0x023D,        0x00,        0x01,     },   /* Addr 36(0x24) : l2_pd_reg_1 */
    {      0x023F,        0x00,        0x01,     },   /* Addr 37(0x25) : l2_pd_reg_3 */
    {      0x0242,        0x00,        0x03,     },   /* Addr 38(0x26) : l2_pd_reg_6 */
    {      0x0300,        0x00,        0x07,     },   /* Addr 39(0x27) : l3_cdr_reg_0 */
    {      0x0301,        0x14,        0x3F,     },   /* Addr 40(0x28) : l3_los_reg_0 */
    {      0x0302,        0x06,        0x07,     },   /* Addr 41(0x29) : l3_los_reg_1 */
    {      0x030B,        0x10,        0x7F,     },   /* Addr 43(0x2B) : l3_eq_reg_2 */
    {      0x0332,        0x04,        0x07,     },   /* Addr 45(0x2D) : l3_drv_reg_0 */
    {      0x0334,        0x00,        0x1F,     },   /* Addr 46(0x2E) : l3_drv_reg_2 */
    {      0x033C,        0x00,        0x01,     },   /* Addr 48(0x30) : l3_pd_reg_0 */
    {      0x033D,        0x00,        0x01,     },   /* Addr 49(0x31) : l3_pd_reg_1 */
    {      0x033F,        0x00,        0x01,     },   /* Addr 50(0x32) : l3_pd_reg_3 */
    {      0x0342,        0x00,        0x03,     },   /* Addr 51(0x33) : l3_pd_reg_6 */
    {      0x0404,        0x01,        0x03,     },   /* Addr 52(0x34) : LoS_Reg_0 */
    {      0x0408,        0x00,        0xFF,     },   /* Addr 53(0x35) : Los_reg_4 */
    {      0x040A,        0x00,        0x0F,     },   /* Addr 54(0x36) : Los_reg_6 */
    {      0x040B,        0x00,        0xFF,     },   /* Addr 56(0x38) : LoL_reg_0 */
    {      0x040D,        0x00,        0x0F,     },   /* Addr 58(0x3A) : LOL_Reg_2 */
    {      0x040E,        0x0F,        0xFF,     },   /* Addr 59(0x3B) : LOS_OUTPUT_CTRL_reg_0 */
    {      0x040F,        0x00,        0xFF,     },   /* Addr 61(0x3D) : LOL_OUTPUT_CTRL_Reg_0 */
    {      0x0410,        0x00,        0x03,     },   /* Addr 62(0x3E) : LOSL_OUTPUT_CTRL_Reg_0 */
    {      0x0411,        0xFF,        0x00,     },   /* Addr 63(0x3F) : LOSL_OUTPUT_Reg_0 */
    {      0x0412,        0xF0,        0x00,     },   /* Addr 64(0x40) : LOSL_Latched_outPut_reg_0 */
    {      0x0471,        0x40,        0xFF,     },   /* Addr 65(0x41) : BBUF_Reg_0 */
    {      0x0476,        0x00,        0x01,     },   /* Addr 66(0x42) : PD_Reg_0 */
    {      0x0008,        0x00,        0x08,     },   /* Addr 67(0x43) : l0_offset_correction_reg_2 */
    {      0x0108,        0x08,        0x08,     },   /* Addr 69(0x45) : l1_offset_correction_reg_2 */
    {      0x0208,        0x00,        0x08,     },   /* Addr 71(0x47) : l2_offset_correction_reg_2 */
    {      0x0308,        0x08,        0x08,     },   /* Addr 72(0x48) : l3_offset_correction_reg_2 */
    {      0x0009,        0x00,        0x01,     },   /* Addr 74(0x4A) : l0_eq_reg_0 */
    {      0x0109,        0x01,        0x01,     },   /* Addr 75(0x4B) : l1_eq_reg_0 */
    {      0x0209,        0x00,        0x01,     },   /* Addr 76(0x4C) : l2_eq_reg_0 */
    {      0x0309,        0x01,        0x01,     },   /* Addr 77(0x4D) : l3_eq_reg_0 */
};

#define DRV_CDR_GN2104S_REG_NO_MAX (COUNT_OF(_gn2104s_InitTable) - 1)
#define GN2104S_TRAN_PHY_OFFSET(_offset)    (_gn2104s_InitTable[(_offset)].vPhyReg)
#define GN2104S_GET_RETRIEVE_VALUE(_offset) (_gn2104s_InitTable[(_offset)].vRegRetrieve)
#define GN2104S_GET_WRITE_MASK(_offset)     (_gn2104s_InitTable[(_offset)].vWriteMask)

#define DRV_CDR_GN2104S_INIT_RETRY_COUNT	8

/* Check GN2104S is ready */
#define DRV_CDR_GN2104S_IsReady()  DRV_I2CM_Detect(DRV_CDR_GN2104S_I2C_ADDR)

#if 1

#define drv_cdr_gn2104s_MaskNonWritableBits(_reg_no, _v)                    \
    do {                                                                    \
        UINT8   _data;                                                      \
        UINT8   _write_mask = GN2104S_GET_WRITE_MASK(_reg_no);              \
                                                                            \
        switch (_write_mask)                                                \
        {                                                                   \
            case 0:                                                         \
                /* read-only register */                                    \
                return TRUE;                                                \
                                                                            \
            case (UINT8)(~0):                                               \
                /* all bits are writable */                                 \
                _data = 0;                                                  \
                break;                                                      \
                                                                            \
            default:                                                        \
                /* not all bits are writable */                             \
                if (!drv_cdr_gn2104s_ReadRegister(GN2104S_TRAN_PHY_OFFSET(_reg_no),\
                                                   &_data))                 \
                {                                                           \
                    return FALSE;                                           \
                }                                                           \
                break;                                                      \
        }                                                                   \
                                                                            \
        /* only accept the writable bits */                                 \
        (_v) = (_data & ~_write_mask) | ((_v) & _write_mask);               \
    } while (0)


/******************************************************************************
 * FUNCTION NAME:
 *      drv_cdr_gn2104s_ReadRegister
 * DESCRIPTION:
 *      Read CDR Chip register, low level API.
 * PARAMETERS:
 *      vRegNo : Physical register number of CDR Chip.
 *      pData  : Read register value, only valid when return TRUE.
 * RETURN:
 *      TRUE   : Read register success.
 *      FALSE  : Read register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
static BOOL drv_cdr_gn2104s_ReadRegister
(
    IN  UINT16  vRegNo,
    OUT UINT8  *pData
)
{
    UINT8   aOffsetBuf[2];

    /* create offset buffer */
    SET_BE_16(aOffsetBuf, vRegNo);

    return DRV_I2CM_Read(DRV_CDR_GN2104S_I2C_ADDR,
                         (UINT8)COUNT_OF(aOffsetBuf),
                         aOffsetBuf,
                         1,
                         pData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_cdr_gn2104s_WriteRegister
 * DESCRIPTION:
 *      Write CDR Chip register, low level API.
 * PARAMETERS:
 *      vRegNo  : Physical register number of CDR Chip.
 *      vRegVal : Register value to be set.
 * RETURN:
 *      TRUE    : Write register success.
 *      FALSE   : Write register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
static BOOL drv_cdr_gn2104s_WriteRegister
(
    IN UINT16  vRegNo,
    IN UINT8   vRegValue
)
{
    UINT8   aOffsetBuf[2];

    /* create offset buffer */
    SET_BE_16(aOffsetBuf, vRegNo);

    return DRV_I2CM_Write(DRV_CDR_GN2104S_I2C_ADDR,
                          (UINT8)COUNT_OF(aOffsetBuf),
                          aOffsetBuf,
                          1,
                          &vRegValue);
}

/******************************************************************************
 * FUNCTION NAME:
 *		drv_cdr_gn2104s_InitAllRegisters
 * DESCRIPTION:
 *		Init vall of CDR registers
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.04.05		  Melinda.Lu		 Create/Update
 *****************************************************************************/
static void drv_cdr_gn2104s_InitAllRegisters(void)
{
	UINT16  vLoop;
	UINT8   vCount;
	UINT8   vRegVal;

	/* init GN2104S registers */
	for (vLoop = 0; vLoop <= DRV_CDR_GN2104S_REG_NO_MAX; vLoop++)
	{
		if (GN2104S_GET_WRITE_MASK(vLoop) == 0)
		{
			/* skip read-only register */
			continue;
		}

		vRegVal = GN2104S_CONFIG_GETxO(Init_GN2104S_RX_Reg_0, vLoop);

		for (vCount = 0; vCount < DRV_CDR_GN2104S_INIT_RETRY_COUNT; vCount++)
		{
			if (DRV_CDR_GN2104S_WriteRegister(vLoop, vRegVal))
			{
				/* success and exit */
				break;
			}
		}

		if (vCount >= DRV_CDR_GN2104S_INIT_RETRY_COUNT)
		{
			/* Write failed, reset MCU */
			DRV_CPU_Reset();
		}

#if DRV_WATCHDOG_SUPPORT
		DRV_WATCHDOG_Kick();
#endif
	}
}

#endif


#if 1	
/******************************************************************************
 * FUNCTION NAME:
 *		drv_cdr_gn2104s_ConfigDeviceMode
 * DESCRIPTION:
 *		Configure Device Mode
 * PARAMETERS:
 *		bMode: Mode select
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.04.05		  Melinda.Lu		 Create/Update
 *****************************************************************************/
static BOOL drv_cdr_gn2104s_ConfigDeviceMode(IN UINT8 vMode)
{
	return DRV_CDR_GN2104_ConfigDeviceMode(DRV_CDR_GN2104S_I2C_ADDR, vMode);
}


/******************************************************************************
 * FUNCTION NAME:
 *		drv_cdr_gn2104s_ConfigOutputSwing
 * DESCRIPTION:
 *		Configure Output Swing
 * PARAMETERS:
 *		vData: output Swing
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.04.05		  Melinda.Lu		 Create/Update
 *****************************************************************************/
static void drv_cdr_gn2104s_ConfigOutputSwing(IN UINT8 vChannel, IN UINT8 vData)
{
	static UINT8 aSwingBackup[SYSTEM_CHANNEL_NUM]= {0, 0, 0, 0};
	GN2104_MACRO_T	  vMacro;

	(void)memset(&vMacro, 0x00, sizeof(vMacro));

    /* 4 lanes are updated at one time */
	aSwingBackup[vChannel] = vData;
	
	vMacro.aInBuf[0] = aSwingBackup[0];
	vMacro.aInBuf[1] = aSwingBackup[1];
	vMacro.aInBuf[2] = aSwingBackup[2];
	vMacro.aInBuf[3] = aSwingBackup[3];

	/* update output swing */
	vMacro.vCmd = GN2104_MACRO_ConfigSwing;
	(void)DRV_CDR_GN2104_ExecMacro(DRV_CDR_GN2104S_I2C_ADDR, &vMacro);
}


/******************************************************************************
 * FUNCTION NAME:
 *		drv_cdr_gn2104s_ConfigSliceLevelAdjust
 * DESCRIPTION:
 *		Configure Slice Level Adjust
 * PARAMETERS:
 *		vData: slice level adjust
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.04.05		  Melinda.Lu		 Create/Update
 *****************************************************************************/
static void drv_cdr_gn2104s_ConfigSliceLevelAdjust(IN UINT8 vChannel, IN UINT8 vData)
{
	static UINT8 aSLABackup[SYSTEM_CHANNEL_NUM]= {0, 0, 0, 0};
	GN2104_MACRO_T	  vMacro;

	(void)memset(&vMacro, 0x00, sizeof(vMacro));

    /* 4 lanes are updated at one time */
	aSLABackup[vChannel] = vData;

	vMacro.aInBuf[0] = aSLABackup[0];
	vMacro.aInBuf[1] = aSLABackup[1];
	vMacro.aInBuf[2] = aSLABackup[2];
	vMacro.aInBuf[3] = aSLABackup[3];

	/* update output swing */
	vMacro.vCmd = GN2104_MACRO_ConfigSlice;
	(void)DRV_CDR_GN2104_ExecMacro(DRV_CDR_GN2104S_I2C_ADDR, &vMacro);
}
#endif

#if 1
BOOL DRV_CDR_GN2104S_GetLOSL(OUT UINT8 *pRegVal)
{
    return drv_cdr_gn2104s_ReadRegister(GN2104S_LOSL_OUTPUT_REG_0, pRegVal);
}

void DRV_CDR_GN2104S_SetOutputDis(IN UINT8 vChannel, IN BOOL bDisable)
{
    UINT16  vRegOffset;
    UINT8   vRegValue;

	vRegOffset = GN2104S_DRV_REG_0_L0 + vChannel*GN2104S_REG_NO_PER_LANE;

    /* write "l0_drv_force_mute" bit of l0_drv_reg_0 register:
     *  -> Output driver mute control.
     */
    if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegValue))
    {
		return;
	}
	
	if (bDisable)
	{
		vRegValue |= (0x1<<GN2104S_ForceMute_BIT);
	}
	else
	{
		vRegValue &= ~(0x01<<GN2104S_ForceMute_BIT);
	}
	
    (void)drv_cdr_gn2104s_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_GN2104S_SetCDRBypass(IN UINT8 vChannel, IN BOOL bByPassN)
{
    UINT16  vRegOffset;
    UINT8   vRegValue;

	vRegOffset = GN2104S_CDR_REG_0_L0 + vChannel * GN2104S_REG_NO_PER_LANE;
	/* write "l0_cdr_force_bypass" bit of l0_cdr_reg_0 register:
     *  -> cdr bypass control;
     */
    if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegValue))
    {
		return;
	}

	if (bByPassN)
	{
		/* CDR works, set bit 0 to 0 */
		vRegValue &= ~(0x1<<GN2104S_ForceBypass_BIT);
	}
	else
	{
		/* CDR bypass, set bit 0 to 1 */
		vRegValue |= (0x01<<GN2104S_ForceBypass_BIT);
	}
	
    (void)drv_cdr_gn2104s_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_GN2104S_SetSquelchDis(IN UINT8 vChannel, IN BOOL bDisable)
{
    UINT16  vRegOffset;
    UINT8   vRegValue;

    vRegOffset = GN2104S_DRV_REG_0_L0 + vChannel*GN2104S_REG_NO_PER_LANE;

    /* write "l0_drv_mute_on_los" bit of l0_drv_reg_0 register:
     *  -> Output driver auto-mute on LOS.
     */
    if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegValue))
    {
		return;
	}
	
    if (bDisable)
	{
		vRegValue &= ~(0x1<<GN2104S_MuteOnLos_BIT);
	}
	else
	{
		vRegValue |= (0x01<<GN2104S_MuteOnLos_BIT);
	}
	
    (void)drv_cdr_gn2104s_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_GN2104S_SetAmplitude(IN UINT8 vChannel, IN UINT8 vData)
{
    drv_cdr_gn2104s_ConfigOutputSwing(vChannel, vData);
}

void DRV_CDR_GN2104S_SetEmphasis(IN UINT8 vChannel, IN UINT8 vData)
{
	UINT16  vRegOffset;
	UINT8	vRegValue;
	
	vRegOffset = GN2104S_DRV_REG_2_L0 + vChannel*GN2104S_REG_NO_PER_LANE;

	/* bit[4:1] */
	if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegValue))
	{
		return;
	}
	vRegValue = (vRegValue & 0xE1) | ((vData & 0xF) << 1);
	(void)drv_cdr_gn2104s_WriteRegister(vRegOffset, vRegValue);
}

void DRV_CDR_GN2104S_SetSliceLevelAdjust(IN UINT8 vChannel, IN UINT8 vData)
{
    drv_cdr_gn2104s_ConfigSliceLevelAdjust(vChannel, vData);
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_DAC_Get
 * DESCRIPTION:
 *      Get LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      pData   : Get value.
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.8.31         Dennis.Long           Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104S_DAC_Get
(
	IN DAC_TYPE_T vType,
	IN UINT16    *pData
)
{
	UINT16 vRegOffset;
	UINT8  vRegVal;
	UINT8  vChannel;

	switch (vType)
	{
		case DAC_TYPE_LOSTHRESSET_CH0:
		case DAC_TYPE_LOSTHRESSET_CH1:
		case DAC_TYPE_LOSTHRESSET_CH2:
		case DAC_TYPE_LOSTHRESSET_CH3:
			/* LOS threshold:
			 * Lx_LOS_REG_0[5:0] - 0x01
			 */
			vChannel = vType - DAC_TYPE_LOSTHRESSET_CH0;
			vRegOffset = GN2104S_LOS_REG_0_L0 + vChannel * GN2104S_REG_NO_PER_LANE;
			if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegVal))
			{
				return FALSE;
			}
			
			vRegVal &= 0x3F;;
			break;

		case DAC_TYPE_LOSHYSTSET_CH0:
		case DAC_TYPE_LOSHYSTSET_CH1:
		case DAC_TYPE_LOSHYSTSET_CH2:
		case DAC_TYPE_LOSHYSTSET_CH3:
			/* LOS hysteresis:
			 * Lx_LOS_REG_1[2:0] - 0x02
			 */
			vChannel = vType - DAC_TYPE_LOSHYSTSET_CH0;
			vRegOffset = GN2104S_LOS_REG_1_L0 + vChannel * GN2104S_REG_NO_PER_LANE;
			if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegVal))
			{
				return FALSE;
			}
			
			vRegVal &= 0x07;
			break;

		case DAC_TYPE_RXEQSET_CH0:
		case DAC_TYPE_RXEQSET_CH1:
		case DAC_TYPE_RXEQSET_CH2:
		case DAC_TYPE_RXEQSET_CH3:
			/* RX Equalization:
			 * Lx_EQ_REG_2[6:0] - 0x0B
			 */
			vChannel = vType - DAC_TYPE_RXEQSET_CH0;
			vRegOffset = GN2104S_EQ_REG_2_L0 + vChannel * GN2104S_REG_NO_PER_LANE;
			if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegVal))
			{
				return FALSE;
			}
			
			vRegVal &= 0x7F;
			break;
			
		default:
			vRegVal = 0x00;
			*pData = vRegVal;
			return FALSE;
	}

	*pData = vRegVal;
	return TRUE;
}

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_DAC_Set
 * DESCRIPTION:
 *      Set LD Chip register.
 * PARAMETERS:
 *      vType   : DAC type.
 *      vData   : Set value.
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.10         Melinda.Lu           Create/Update
 *      2017.8.31         Dennis.Long        Update
 *****************************************************************************/
void DRV_CDR_GN2104S_DAC_Set
(
	IN DAC_TYPE_T vType,
	IN UINT16     vData
)
{
	UINT16 vRegOffset;
	UINT8  vRegVal;
	UINT8  vChannel;
	
	switch (vType)
	{
		case DAC_TYPE_LOSTHRESSET_CH0:
		case DAC_TYPE_LOSTHRESSET_CH1:
		case DAC_TYPE_LOSTHRESSET_CH2:
		case DAC_TYPE_LOSTHRESSET_CH3:
			/* LOS threshold:
			 * Lx_LOS_REG_0[5:0] - 0x01
			 */
			vChannel = vType - DAC_TYPE_LOSTHRESSET_CH0;
			vRegOffset = GN2104S_LOS_REG_0_L0 + vChannel * GN2104S_REG_NO_PER_LANE;
			if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegVal))
			{
				return;
			}
			vRegVal = (vRegVal & 0xC0) | ((UINT8)vData & 0x3F);
			
			(void)drv_cdr_gn2104s_WriteRegister(vRegOffset, vRegVal);
			break;

		case DAC_TYPE_LOSHYSTSET_CH0:
		case DAC_TYPE_LOSHYSTSET_CH1:
		case DAC_TYPE_LOSHYSTSET_CH2:
		case DAC_TYPE_LOSHYSTSET_CH3:
			/* LOS hysteresis:
			 * Lx_LOS_REG_1[2:0] - 0x02
			 */
			vChannel = vType - DAC_TYPE_LOSHYSTSET_CH0;
			vRegOffset = GN2104S_LOS_REG_1_L0 + vChannel * GN2104S_REG_NO_PER_LANE;
			if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegVal))
			{
				return;
			}
			vRegVal = (vRegVal & 0xF8) | ((UINT8)vData & 0x07);
			
			(void)drv_cdr_gn2104s_WriteRegister(vRegOffset, vRegVal);
			break;

		case DAC_TYPE_RXEQSET_CH0:
		case DAC_TYPE_RXEQSET_CH1:
		case DAC_TYPE_RXEQSET_CH2:
		case DAC_TYPE_RXEQSET_CH3:
			/* RX Equalization:
			 * Lx_EQ_REG_2[6:0] - 0x0B
			 */
			vChannel = vType - DAC_TYPE_RXEQSET_CH0;
			vRegOffset = GN2104S_EQ_REG_2_L0 + vChannel * GN2104S_REG_NO_PER_LANE;
			if (!drv_cdr_gn2104s_ReadRegister(vRegOffset, &vRegVal))
			{
				return;
			}
			vRegVal = (vRegVal & 0x80) | ((UINT8)vData & 0x7F);
			
			(void)drv_cdr_gn2104s_WriteRegister(vRegOffset, vRegVal);
			break;
			
		default:
			/* do nothing */
			break;
	}
}
#endif

#if 1

/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_ReadRegister
 * DESCRIPTION:
 *      Read CDR Chip register.
 * PARAMETERS:
 *      vRegNo : Logical register number of CDR Chip.
 *      pData  : Read register value, only valid when return TRUE.
 * RETURN:
 *      TRUE   : Read register success.
 *      FALSE  : Read register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104S_ReadRegister
(
    IN  UINT16  vRegNo,
    OUT UINT8  *pData
)
{
    return drv_cdr_gn2104s_ReadRegister(GN2104S_TRAN_PHY_OFFSET(vRegNo), pData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_WriteRegister
 * DESCRIPTION:
 *      Write CDR Chip register.
 * PARAMETERS:
 *      vRegNo  : Logical register number of CDR Chip.
 *      vRegVal : Register value to be set.
 * RETURN:
 *      TRUE    : Write register success.
 *      FALSE   : Write register fail.
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
BOOL DRV_CDR_GN2104S_WriteRegister
(
    IN UINT16   vRegNo,
    IN UINT8    vRegValue
)
{
    /* only accept the writable bits */
    drv_cdr_gn2104s_MaskNonWritableBits(vRegNo, vRegValue);

    return drv_cdr_gn2104s_WriteRegister(GN2104S_TRAN_PHY_OFFSET(vRegNo), vRegValue);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_Entry
 * DESCRIPTION:
 *      GN2104S Entry.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_GN2104S_Entry(void)
{
    /* CDR registers command interface supporting */
  #if 1
    typedef enum
    {
        CMD_READ_GN2104S          = 0x11,
        CMD_WRITE_GN2104S         = 0x12,

        RESULT_BUSY = 0x80,
        RESULT_DONE = 0x81,
        RESULT_FAIL = 0x82,
    } GN2104S_CMD_RESULT_T;

    #define GN2104S_SET_RESULT(x)   CFG_SET8(CDR_RT_CmdResult, (x))
    #define GN2104S_IS_CMD(x)       (((x) >= CMD_READ_GN2104S) && ((x) <= CMD_WRITE_GN2104S))
    #define GN2104S_GET_CMD()       CFG_GET8(CDR_RT_CmdResult)
    #define GN2104S_GET_REG_NO()    CFG_GET16(CDR_RT_RegNo)
    #define GN2104S_GET_REG_DATA()  CFG_GET8(CDR_RT_RegVal)
    #define GN2104S_SET_REG_DATA(x) CFG_SET8(CDR_RT_RegVal, (x))

    GN2104S_CMD_RESULT_T vCmd = GN2104S_GET_CMD();

    if (!CFG_GET_BIT(CDR_Ctrl_RX_CmdInterface_Dis) && GN2104S_IS_CMD(vCmd))
    {
        BOOL    bResult = FALSE;
        UINT8   vData;

        GN2104S_SET_RESULT(RESULT_BUSY);

        switch (vCmd)
        {
            case CMD_READ_GN2104S:
                bResult = drv_cdr_gn2104s_ReadRegister(GN2104S_GET_REG_NO(), &vData);
                if (bResult)
                {
                    GN2104S_SET_REG_DATA(vData);
                }
                break;

            case CMD_WRITE_GN2104S:
                bResult = drv_cdr_gn2104s_WriteRegister(GN2104S_GET_REG_NO(), GN2104S_GET_REG_DATA());
                break;

            default:
                break;
        }

        GN2104S_SET_RESULT(bResult? RESULT_DONE : RESULT_FAIL);
    }
  #endif
  
#if 1
	/* macro interface supporting */
	UINT8 vMacroCmd = CFG_GET8(CDR_RX_Macro_Cmd);

	if ((vMacroCmd != GN2104_MACRO_SuccessACK)
		&& (vMacroCmd != GN2104_MACRO_ErrorACK))
	{
		UINT8 vLoop;
		GN2104_MACRO_T	vMacro;

		memset(&vMacro, 0x00, sizeof(vMacro));

		/* fill macro code */
		vMacro.vCmd	   = vMacroCmd;

		/* fill macro input buffer */
		for (vLoop=0; vLoop<sizeof(vMacro.aInBuf); vLoop++)
		{
			vMacro.aInBuf[vLoop] = CFG_GETO8(CDR_RX_Macro_InBuf, vLoop);
		}

		/* execut macro */
		if (DRV_CDR_GN2104_ExecMacro(DRV_CDR_GN2104S_I2C_ADDR, &vMacro))
		{
			/* successfully */
			CFG_SET8(CDR_RX_Macro_Cmd, GN2104_MACRO_SuccessACK);
		}
		else
		{
			/* failed */
			CFG_SET8(CDR_RX_Macro_Cmd, GN2104_MACRO_ErrorACK);
		}

		/* update macro output buffer */
		for (vLoop=0; vLoop<sizeof(vMacro.aOutBuf); vLoop++)
		{
			CFG_SETO8(CDR_RX_Macro_OutBuf, vLoop, vMacro.aOutBuf[vLoop]);
		}
	}
#endif
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_Retrieve
 * DESCRIPTION:
 *      Retrieve default GN2104S CDR Chip register value.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_GN2104S_Retrieve(void)
{
	UINT8   vLoop;

	/* no register value setting, use default register value */
	for (vLoop = 0; vLoop <= DRV_CDR_GN2104S_REG_NO_MAX; vLoop++)
	{
		CFG_Retrieve_MemSet8(CFG_PAGE(Init_GN2104S_RX_Reg_0),
			                 CONFIG(Init_GN2104S_RX_Reg_0)+vLoop,
			                 GN2104S_GET_RETRIEVE_VALUE(vLoop),
			                 1);
	}

	/* save to flash */
	CFG_Retrieve_SaveConfig(CFG_PAGE(Init_GN2104S_RX_Reg_0));
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_CDR_GN2104S_Init
 * DESCRIPTION:
 *      GN2104S CDR Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.10.18          Panda.Xiong            Create/Update
 *****************************************************************************/
void DRV_CDR_GN2104S_Init(void)
{
	UINT16 vLoop;
	
	/* force reset mode */
	DRV_IO_Write(IO(IO_RESET_RXCDR), LOW);

    /* t_chip_reset */
    DRV_CPU_DelayUs(DRV_CDR_GN2104S_RESET_TIME);

	/* exit reset mode */
	DRV_IO_Write(IO(IO_RESET_RXCDR), HIGH);

    /* wait until the GN2104RX startup OK, then initialize it */
    DRV_CPU_DelayUs(DRV_CDR_GN2104S_STARTUP_TIME);
	for (vLoop = 0; vLoop < CHIP_RETRY_MAX_TIME/CHIP_RETRY_INTERVAL; vLoop++)
	{
		if (DRV_CDR_GN2104S_IsReady())
		{
		    /* GN2104S is ready, continue the following initializing */
		    break;
		}

		/* delay some time, to wait for GN2104S responding */
		DRV_CPU_DelayMs(CHIP_RETRY_INTERVAL);
	}
	
	if (!DRV_CDR_GN2104S_IsReady())
	{
		/* CDR is not ready */
		DRV_CPU_Reset();
	}
	
#if 1
	/* Load macro file */
	if (!CFG_GET_BIT(CDR_Ctrl_RX_AutoLoadMacro_Dis))
	{		
		for (vLoop=CFG_GET8(CDR_LoadMacro_RetryCount); vLoop>0; vLoop--)
		{
			if (DRV_CDR_GN2104_LoadMacro(DRV_CDR_GN2104S_I2C_ADDR))
			{
				/* load successfully, exit */
				break;
			}
		}

		if (vLoop != 0)
		{
			/* load macro successfully */
			CFG_SET_BIT(CDR_RT_Status_RXLoadMacro, TRUE);

			/* report macro information */
			CFG_SETO32(CDR_MacroFile_Version, 0, CFG_Image_GetImageID(FILE_ID_MACRO));
			CFG_SETO32(CDR_MacroFile_Version, 4, CFG_Image_GetImageVersion(FILE_ID_MACRO));
		}
		else
		{
			/* load macro failed, reset GN2104RX before re-init it */
			
			/* enter reset mode */
			DRV_IO_Write(IO(IO_RESET_RXCDR), LOW);

			/* reset hold time: minimum pulse width */
			DRV_CPU_DelayUs(DRV_CDR_GN2104S_RESET_TIME);

			/* exit reset mode */
			DRV_IO_Write(IO(IO_RESET_RXCDR), HIGH);

		    /* t_chip_reset */
		    DRV_CPU_DelayUs(DRV_CDR_GN2104S_RESET_TIME);

		    /* wait until the GN2104RX startup OK, then initialize it */
		    DRV_CPU_DelayUs(DRV_CDR_GN2104S_STARTUP_TIME);
			for (vLoop = 0; vLoop < CHIP_RETRY_MAX_TIME/CHIP_RETRY_INTERVAL; vLoop++)
			{
				if (DRV_CDR_GN2104S_IsReady())
				{
				    /* GN2104S is ready, continue the following initializing */
				    break;
				}

				/* delay some time, to wait for GN2104S responding */
				DRV_CPU_DelayMs(10);
			}
			
			if (!DRV_CDR_GN2104S_IsReady())
			{
				/* CDR is not ready, reset MCU */
				DRV_CPU_Reset();
			}
		}
	}
#endif

    /* bring up GN2104S for basic mission mode operation */
	for (vLoop = 0; vLoop < DRV_CDR_GN2104S_INIT_RETRY_COUNT; vLoop++)
    {

        if (drv_cdr_gn2104s_ConfigDeviceMode(GN2104_DeviceMode_MissionLowPower))
	    {
			break;
		}
    }

	if (vLoop >= DRV_CDR_GN2104S_INIT_RETRY_COUNT)
	{
		/* write failed, reset MCU */
		DRV_CPU_Reset();
	}

    /* init GN2104S registers */
    drv_cdr_gn2104s_InitAllRegisters();

    /* init Slice Level Adjust */
    for (vLoop = 0; vLoop < SYSTEM_CHANNEL_NUM; vLoop++)
    {
        DRV_CDR_GN2104S_SetSliceLevelAdjust(vLoop, CFG_GETO8(Init_GN2104S_RX_SLA_CH1, vLoop * I2C_LEN(Init_GN2104S_RX_SLA_CH1)));
    }
}

#endif

#endif

