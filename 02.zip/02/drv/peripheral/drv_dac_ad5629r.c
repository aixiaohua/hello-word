/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   drv_dac_ad5629r.c
 * DESCRIPTION:
 *   AD5629R DAC Chip Driver: 12-bit DAC. (left-justified to 16-bit)
 *   Maximum support 3-chip (24 channel) with different I2C address.
 * HISTORY:
 *   2013.6.7        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"


#if DRV_DAC_AD5629R_SUPPORT

/* maximum channel per AD5629R chip */
#define DRV_DAC_AD5629R_CHANNEL_MAX      	8

/* maximum slave ID */
#define DRV_DAC_AD5629R_I2C_ADDRESS_MAX		3

/* AD5629R power-up time, coming out of power-down mode */
#define DRV_DAC_AD5629R_PowerUpTime     4   /* us */

/* DAC Voltage Output Settling timing, 10us;
 *  which is defined in Page21 of "AD5629R_5669R.pdf".
 */
#define DRV_DAC_AD5629R_SettlingTime    10  /* us */

/* retry count: 8 */
#define DRV_DAC_AD5629R_RETRY_COUNT			8
#define DRV_DAC_AD5629R_RETRY_DELAY			4   /* us */

/* The AD5629R/AD5669R each have a 7-bit slave address.
 * The parts have a slave address whose five MSBs are 10101,
 * and the two LSBs are set by the state of the A0 address pin,
 * which determines the state of the A0 and A1 address bits.
 *
 *    A0 Pin Connection     A1   A0    I2C Address
 *   --------------------  ---- ----  -------------
 *          VDD              0    0       0xA8
 *          NC               1    0       0xAC
 *          GND              1    1       0xAE
 */
#define AD5629R_I2C_ADDR_GND		0xAE
#define AD5629R_I2C_ADDR_NC			0xAC
#define AD5629R_I2C_ADDR_VDD 		0xA8

/* maximum slave ID */
#define AD5629R_I2C_ADDRESS_MAX		3

static UINT8 aAd5629r_I2cAddress[AD5629R_I2C_ADDRESS_MAX] = {AD5629R_I2C_ADDR_GND, AD5629R_I2C_ADDR_NC, AD5629R_I2C_ADDR_VDD};

static UINT8 vAd5629rNo = 0x00;
static UINT8 vAd5629rChipId[AD5629R_I2C_ADDRESS_MAX];

typedef enum
{
    AD5629R_CMD_WriteInput = 0x0,       /* Write to Input Register n         */
    AD5629R_CMD_UpdateDAC,              /* Update DAC Register n             */
    AD5629R_CMD_WriteInputAndUpdateAll, /* Write to Input Register n; update all (software LDAC) */
    AD5629R_CMD_WriteAndUpdateDAC,      /* Write to and update DAC Channel n */
    AD5629R_CMD_PowerDAC,               /* Power down/power up DAC           */
    AD5629R_CMD_LoadClearCode,          /* Load clear code register          */
    AD5629R_CMD_LoadLDAC,               /* Load LDAC register                */
    AD5629R_CMD_Reset,                  /* Reset (power-on reset)            */
    AD5629R_CMD_SetInternalRef,         /* Set up internal REF register      */
    AD5629R_CMD_SetMultiByte,           /* Enable multiple byte mode         */
} AD5629R_CMD_T;

#define AD5629R_DATA_ANY    		0x0000
#define AD5629R_CHANNEL_ALL 		0xFF

/* Command byte: Command      Address (Selected DAC Channel)
 *               C3 C2 C1 C0  A3 A2 A1 A0
 */
#define GET_CMD_BYTE(_cmd, _ch)		((UINT8)((UINT16)(_cmd) << 4) | ((UINT8)(_ch) & 0x0F))

DRV_DAC_AD5629R_CACHE_T  vAD5629R_Cache;
/******************************************************************************
 * FUNCTION NAME:
 *		drv_dac_ad5629r_ExecuteCmd
 * DESCRIPTION:
 *		Execute commands
 * PARAMETERS:
 *		vCmd  : command
 *		vData : data
 * RETURN:
 *		TRUE/FALSE
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.4.27		 Melinda.Lu 		Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5629r_ExecuteCmd
(
	IN UINT8    vSlaveId,
	IN UINT8	vCmd,
	IN UINT8	vChannel,
	IN UINT16	vData
)
{
	UINT8	vCmdByte;
	UINT8	aBuf[2];

	/* command byte: 4-bit command + 4-bit channel */
	vCmdByte = (UINT8)GET_CMD_BYTE(vCmd, vChannel);

	/* left-justified data to 16-bit */
	SET_BE_16(aBuf, vData);

	if (!DRV_I2CM_WriteBytes(vSlaveId,
							 vCmdByte,
							 sizeof(aBuf),
							 aBuf))
	{
		return FALSE;
	}

	return TRUE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5629r_SetRefState
 * DESCRIPTION:
 *      Set AD5629R Ref on/off.
 * PARAMETERS:
 *      vSlaveId: I2C address
 *      vState:   Internal REF state
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5629r_SetRefState
(
	IN UINT8 vSlaveId,
	IN UINT8 vState
)
{
	/* set AD5629R internal REF:
	 * Command: AD5629R_CMD_SetInternalRef;
	 * Channel: do not care;
	 * Data   : DB15 to DB1    DB0
	 *          do not care    1/0 (Internal REF on/off)
	 */
	UINT16 vData;

	/* get DB15 to DB0 */
	vData = (UINT16)vState << DAC_AD5629R_InternalREF_BIT;
	return drv_dac_ad5629r_ExecuteCmd(vSlaveId, AD5629R_CMD_SetInternalRef, AD5629R_CHANNEL_ALL, vData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5629r_SetLDAC
 * DESCRIPTION:
 *      Set AD5629R LDAC.
 * PARAMETERS:
 *      vSlaveId: I2C address
 *      vMask   : LDAC mask value
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5629r_SetLDAC
(
	IN UINT8 vSlaveId,
	IN UINT8 vMask
)
{
	/* set AD5629R LDAC register:
	 * Command: AD5629R_CMD_LoadLDAC;
	 * Channel: do not care;
	 * Data   : DB15 to DB8    DB7 to DB0
	 *          do not care    DACH to DACA(Setting LDAC bit to 1 overrides LDAC pin)
	 */
	UINT16 vData;

	/* get DB15 to DB0 */
	vData = (UINT16)vMask << DAC_AD5629_LDAC_BIT;
	return drv_dac_ad5629r_ExecuteCmd(vSlaveId, AD5629R_CMD_LoadLDAC, AD5629R_CHANNEL_ALL, vData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5629r_SetClearCode
 * DESCRIPTION:
 *      Set AD5629R DAC Chip clear codes.
 * PARAMETERS:
 *      vSlaveId: I2C address
 *      vCode   : Clear code
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5629r_SetClearCode
(
	IN UINT8 vSlaveId,
	IN UINT8 vCode
)
{
	/* set AD5629R clear code:
	 * Command: AD5629R_CMD_LoadClearCode;
	 * Channel: do not care;
	 * Data   : DB15 to DB2   DB1 DB0
	 *          do not care   CR1 CR0(clear code register)
	 */
	UINT16 vData;

	/* get DB15 to DB0 */
	vData = (UINT16)vCode << DAC_AD5629R_ClearCode_BIT;
	return drv_dac_ad5629r_ExecuteCmd(vSlaveId, AD5629R_CMD_LoadClearCode, AD5629R_CHANNEL_ALL, vData);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5629r_SetMultiByteMode
 * DESCRIPTION:
 *      Set AD5629R DAC Multi-Byte Mode.
 * PARAMETERS:
 *      vSlaveId: I2C address
 *      vState  : state
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5629r_SetMultiByteMode
(
	IN UINT8 vSlaveId,
	IN UINT8 vState
)
{
	/* set AD5629R multi-byte mode:
	 * Command: C3 C2 C1 C0
	 *          1  S  0  1 (S=1, 2-byte mode; S=0, standard 3-byte and 4-byte operation)
	 * Channel: do not care;
	 * Data   : do not care;
	 */
	UINT16 vCmd;

	/* get command */
	vCmd = (AD5629R_CMD_SetMultiByte | (vState<<DAC_AD5629R_MultiByteMode_BIT));
	return drv_dac_ad5629r_ExecuteCmd(vSlaveId, vCmd, AD5629R_CHANNEL_ALL, AD5629R_DATA_ANY);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5629r_Reset
 * DESCRIPTION:
 *      AD5629R DAC Chip Reset.
 * PARAMETERS:
 *      vSlaveId: I2C address
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5629r_Reset
(
	IN UINT8 vSlaveId
)
{
	/* reset AD5629R:
     * Command: AD5629R_CMD_Reset;
     * Channel: do not care;
     * Data   : do not care;
     */
	return drv_dac_ad5629r_ExecuteCmd(vSlaveId, AD5629R_CMD_Reset, AD5629R_CHANNEL_ALL, AD5629R_DATA_ANY);
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5629r_SetChannelState
 * DESCRIPTION:
 *      Set AD5629R DAC Power Down Mode.
 * PARAMETERS:
 *      vChannel: channel
 *      vState  : power down mode
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
static BOOL drv_dac_ad5629r_SetChannelState
(
	IN UINT8 vChannel,
	IN UINT8 vState
)
{
	/* set AD5629R power down mode:
	 * Command: AD5629R_CMD_PowerDAC;
	 * Channel: do not care;
	 * Data   : DB15 to DB10    DB9         DB8  DB7 to DB0
	 *          do not care     Power down mode  DACH to DACA
	 */
	UINT8  vSlaveId;
	UINT8  vIntChannel;
	UINT16 vData;
	BOOL   bResult;

	/* get I2C address */
	vSlaveId = aAd5629r_I2cAddress[(vChannel/DRV_DAC_AD5629R_CHANNEL_MAX)];

	/* channel in one chip */
	vIntChannel = vChannel % DRV_DAC_AD5629R_CHANNEL_MAX;

	/* get DB15 to DB0 */
	vData = ((UINT16)vState << DAC_AD5629R_PDOWN_MODE_BIT) | (0x1 << vIntChannel);
	bResult = drv_dac_ad5629r_ExecuteCmd(vSlaveId, AD5629R_CMD_PowerDAC, AD5629R_CHANNEL_ALL, vData);

	if (vState == DAC_AD5629R_ENABLE)
	{
		DRV_CPU_DelayUs(DRV_DAC_AD5629R_SettlingTime);
	}

	return bResult;
}


/******************************************************************************
 * FUNCTION NAME:
 *      drv_dac_ad5629R_ScanId
 * DESCRIPTION:
 *      Scan AD5629R DAC Chip ID.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.5.2        Melinda.Lu         Create/Update
 *****************************************************************************/
static void drv_dac_ad5629r_ScanId(void)
{
	UINT8 vSelectedId;

	vAd5629rNo = 0x00;

/* Slave address is determined by A0 pin connection of DAC_AD5629R:
 * A0 pin connection is GND, Channel is from 0 to 7;
 * A0 pin connection is NC,  Channel is from 8 to 15;
 * A0 pin connection is VDD, Channel is from 16 to 23;
 */

#define DECLARE_DAC_AD5629R(_name, _src, _ch, _cfg, _init, _desc)           \
	do {																	\
		if (((_ch)%DRV_DAC_AD5629R_CHANNEL_MAX) == 0)                       \
		{                                                                   \
			/* new chip is detected */                                      \
			vSelectedId = (UINT8)(_ch)/DRV_DAC_AD5629R_CHANNEL_MAX; 		\
			                                                                \
			/* record slave address */										\
			vAd5629rChipId[vAd5629rNo] = aAd5629r_I2cAddress[vSelectedId];  \
			vAd5629rNo++;                                                   \
		}                                                                   \
	} while (0);

#include "def_hardware.h"

#undef DECLARE_DAC_AD5629R
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5629R_Set
 * DESCRIPTION:
 *      Set DAC_AD5629R Data;
 * PARAMETERS:
 *      vData : data to be set;
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.4.27        Melinda.Lu         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5629R_Set
(
	IN UINT8  vChannel,
    IN UINT16 vData
)
{
	BOOL  bResult;
	UINT8 vSlaveId;
	UINT8 vIntChannel;

	if (vData > DRV_DAC_AD5629R_MaxValue)
	{
		vData = DRV_DAC_AD5629R_MaxValue;
	}

	/* record current DAC value */
    DAC_AD5629R_RT_VAL(vChannel) = vData;

	/* get I2C address */
	vSlaveId = aAd5629r_I2cAddress[(vChannel/DRV_DAC_AD5629R_CHANNEL_MAX)];

	/* channel in one chip */
	vIntChannel = vChannel % DRV_DAC_AD5629R_CHANNEL_MAX;

    /* output DAC value, 12-bit data is left-aligned */
	vData = (UINT16)((UINT32)vData << 4);
	bResult = drv_dac_ad5629r_ExecuteCmd(vSlaveId, AD5629R_CMD_WriteAndUpdateDAC, vIntChannel, vData);

    if (!bResult)
    {
        DBG_LOG_INFO("Set DAC_AD5629R CH%d to %.4X ... FAIL", vChannel, vData);
    }

	/* delay */
	DRV_CPU_DelayUs(DRV_DAC_AD5629R_SettlingTime);
}


/******************************************************************************
 * FUNCTION NAME:
 *      DRV_DAC_AD5629R_Init
 * DESCRIPTION:
 *      AD5629R DAC Chip Init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.7        Panda.Xiong         Create/Update
 *****************************************************************************/
void DRV_DAC_AD5629R_Init(void)
{
	UINT8  vLoop;
	UINT8  vRetryCnt;

#if HOT_RESET_NSA_SUPPORT
	if (PLF_RESET_IsPrevHotResetNSA())
	{
		DBG_LOG_INFO("AD5629R init skipped!");
		return;
	}
#endif

	memset(&vAD5629R_Cache, 0x0, sizeof(vAD5629R_Cache));

	/* scan chip slave ID selected */
	drv_dac_ad5629r_ScanId();

	/* init chip state */
	for (vLoop = 0; vLoop < vAd5629rNo; vLoop++)
	{
		/* reset chip */
		for (vRetryCnt = 0; vRetryCnt < DRV_DAC_AD5629R_RETRY_COUNT; vRetryCnt++)
		{
			if (drv_dac_ad5629r_Reset(vAd5629rChipId[vLoop]))
	        {
				break;
			}

			/* add delay */
			DRV_CPU_DelayUs(DRV_DAC_AD5629R_PowerUpTime);
		}

		if (vRetryCnt >= DRV_DAC_AD5629R_RETRY_COUNT)
		{
			/* reset MCU */
			DRV_CPU_Reset();
		}

		DRV_CPU_DelayUs(DRV_DAC_AD5629R_PowerUpTime);

		/* disable multi-byte operation */
		for (vRetryCnt = 0; vRetryCnt < DRV_DAC_AD5629R_RETRY_COUNT; vRetryCnt++)
		{
			if (drv_dac_ad5629r_SetMultiByteMode(vAd5629rChipId[vLoop], DAC_AD5629R_StandardMode))
	        {
				break;
			}

			/* add delay */
			DRV_CPU_DelayUs(DRV_DAC_AD5629R_RETRY_DELAY);
		}

		if (vRetryCnt >= DRV_DAC_AD5629R_RETRY_COUNT)
		{
			/* reset MCU */
			DRV_CPU_Reset();
		}

		/* set internal reference state */
		for (vRetryCnt = 0; vRetryCnt < DRV_DAC_AD5629R_RETRY_COUNT; vRetryCnt++)
		{
			if (drv_dac_ad5629r_SetRefState(vAd5629rChipId[vLoop], DAC_AD5629R_InternalREF_ON))
	        {
				break;
			}

			/* add delay */
			DRV_CPU_DelayUs(DRV_DAC_AD5629R_RETRY_DELAY);
		}

		if (vRetryCnt >= DRV_DAC_AD5629R_RETRY_COUNT)
		{
			/* reset MCU */
			DRV_CPU_Reset();
		}

		/* force using software to update DAC channel */
		for (vRetryCnt = 0; vRetryCnt < DRV_DAC_AD5629R_RETRY_COUNT; vRetryCnt++)
		{
			if (drv_dac_ad5629r_SetLDAC(vAd5629rChipId[vLoop], DAC_AD5629R_LDAC_Software))
	        {
				break;
			}

			/* add delay */
			DRV_CPU_DelayUs(DRV_DAC_AD5629R_RETRY_DELAY);
		}

		if (vRetryCnt >= DRV_DAC_AD5629R_RETRY_COUNT)
		{
			/* reset MCU */
			DRV_CPU_Reset();
		}

		/* Load clear code */
		for (vRetryCnt = 0; vRetryCnt < DRV_DAC_AD5629R_RETRY_COUNT; vRetryCnt++)
		{
			if (drv_dac_ad5629r_SetClearCode(vAd5629rChipId[vLoop], DAC_AD5629R_ClearCode_0x0000))
	        {
				break;
			}

			/* add delay */
			DRV_CPU_DelayUs(DRV_DAC_AD5629R_RETRY_DELAY);
		}

		if (vRetryCnt >= DRV_DAC_AD5629R_RETRY_COUNT)
		{
			/* reset MCU */
			DRV_CPU_Reset();
		}
	}

	/* init each channel */
#define DECLARE_DAC_AD5629R(_name, _src, _ch, _cfg, _init, _desc)           \
    do {                                                                    \
        /* set DAC channel state */                                         \
        (void)drv_dac_ad5629r_SetChannelState((_ch), (_cfg));               \
                                                                            \
        /* set DAC channel data */                                          \
        (void)DRV_DAC_AD5629R_Set((_ch), (_init));                          \
    } while (0);

#include "def_hardware.h"

#undef DECLARE_DAC_AD5629R
}

#endif

