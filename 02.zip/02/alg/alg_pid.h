/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apl_pid.h
 *
 * DESCRIPTION:
 *	 pid algorithm.
 *
 * HISTORY:
 *	 2017/05/15 	   Hank.He		   Create/Update
 *
 *****************************************************************************/

#ifndef __ALG_PID_H__
#define __ALG_PID_H__

#include "typedef.h"

/* PID Parameter definition */
typedef struct
{
	/* Public parameters */
	SINT32	vSumError;				/* Sum of errors					*/
	SINT16	vPreError;				/* previous of errors				*/
	SINT16	vLastError; 			/* last of errors					*/
	SINT16	vKp;					/* Proportional 					*/
	SINT16	vKi;					/* Integral 						*/
	SINT16	vKd;					/* vDerivative						*/
	UINT8	vKp_ZoomIn; 			/* Proportional ZoomIn times		*/
	UINT8	vKi_ZoomIn; 			/* Integral ZoomIn times			*/
	UINT8	vKd_ZoomIn; 			/* Derivative ZoomIn times			*/
	UINT8	vCounter;				/* PID operation interval counter	*/
	UINT8	vInterval;				/* PID operation interval			*/
	UINT8	reserved;				/* Used for alignment of structures */
} ALG_PID_PARAM_T;

/******************************************************************************
 * FUNCTION NAME:
 *		ALG_PID_Reset
 *
 * DESCRIPTION:
 *		PID Reset.
 *
 * PARAMETERS:
 *		pPid : PID Parameters;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.05.15		  Hank.He		 Create
 *****************************************************************************/
void ALG_PID_Reset(ALG_PID_PARAM_T *pPid);

/******************************************************************************
 * FUNCTION NAME:
 *		ALG_PID_Location
 *
 * DESCRIPTION:
 *		Location PID Compensate.
 *
 * PARAMETERS:
 *		vSetpoint : PID Setpoint;
 *		vCurrent : PID Current;
 *		pPid : PID Parameters;
 *
 * RETURN:
 *		The Delta Change value;
 *		If no delta, 0 will be returned.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.05.15		  Hank.He		 Create
 *****************************************************************************/
SINT16 ALG_PID_Location(SINT32 vSetpoint,SINT32 vCurrent,ALG_PID_PARAM_T *pPid);

/******************************************************************************
 * FUNCTION NAME:
 *		ALG_PID_Incremental
 *
 * DESCRIPTION:
 *		Incremental PID Compensate.
 *
 * PARAMETERS:
 *		vSetpoint : PID Setpoint;
 *		vCurrent : PID Current;
 *		pPid : PID Parameters;
 *
 * RETURN:
 *		The Delta Change value;
 *		If no delta, 0 will be returned.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.05.15		  Hank.He		 Create
 *****************************************************************************/
SINT16 ALG_PID_Incremental(SINT32 vSetpoint,SINT32 vCurrent,ALG_PID_PARAM_T *pPid);

#endif

