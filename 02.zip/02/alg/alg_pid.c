/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 algl_pid.h
 *
 * DESCRIPTION:
 *	 pid algorithm.
 *
 * HISTORY:
 *	 2017/05/15 	   Hank.He		   Create/Update
 *
 *****************************************************************************/

#include "alg_pid.h"

/******************************************************************************
 * FUNCTION NAME:
 *		ALG_PID_Reset
 *
 * DESCRIPTION:
 *		PID Reset.
 *
 * PARAMETERS:
 *		pPid : PID Parameters;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.05.15		  Hank.He		 Create
 *****************************************************************************/
void ALG_PID_Reset(ALG_PID_PARAM_T *pPid)
{
	memset(pPid, 0x0, sizeof(ALG_PID_PARAM_T));
}

/******************************************************************************
 * FUNCTION NAME:
 *		ALG_PID_Location
 *
 * DESCRIPTION:
 *		Location PID Compensate.
 *
 * PARAMETERS:
 *		vSetpoint : PID Setpoint;
 *		vCurrent : PID Current;
 *		pPid : PID Parameters;
 *
 * RETURN:
 *		The Delta Change value;
 *		If no delta, 0 will be returned.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.05.15		  Hank.He		 Create
 *****************************************************************************/
SINT16 ALG_PID_Location(SINT32 vSetpoint,SINT32 vCurrent,ALG_PID_PARAM_T *pPid)
{
	SINT16	vError;
	SINT16	vDelta;

	vDelta = 0x00;

	if ((pPid->vKp_ZoomIn) && (pPid->vKi_ZoomIn))
	{
		/* Calculate the current error & error sum */
		vError = (SINT16)(vSetpoint- vCurrent);
		pPid->vSumError += vError;

		/* Use a counter to control the integral length */
		pPid->vCounter++;
		if (pPid->vCounter >= pPid->vInterval)
		{
			/* Calculate the delta value, which is according to PID arithmetic */
			vDelta = (SINT16)(((SINT32)(pPid->vKp) * vError) / (pPid->vKp_ZoomIn)
					  + ((SINT32)(pPid->vKi) * pPid->vSumError) / (pPid->vKi_ZoomIn));

			/* Reset PID internal parameters */
			pPid->vCounter = 0;
			pPid->vSumError = 0;
		}
	}

	return vDelta;
}

/******************************************************************************
 * FUNCTION NAME:
 *		ALG_PID_Incremental
 *
 * DESCRIPTION:
 *		Incremental PID Compensate.
 *
 * PARAMETERS:
 *		vSetpoint : PID Setpoint;
 *		vCurrent : PID Current;
 *		pPid : PID Parameters;
 *
 * RETURN:
 *		The Delta Change value;
 *		If no delta, 0 will be returned.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.05.15		  Hank.He		 Create
 *****************************************************************************/
SINT16 ALG_PID_Incremental(SINT32 vSetpoint,SINT32 vCurrent,ALG_PID_PARAM_T *pPid)
{
	SINT16	vError;
	SINT16	vDelta;
	SINT32	pError;
	SINT32	iError;
	SINT32	dError;

	vDelta = 0;

	if ((pPid->vKp_ZoomIn) && (pPid->vKi_ZoomIn) && (pPid->vKd_ZoomIn))
	{
		pPid->vCounter++;
		if (pPid->vCounter >= pPid->vInterval)
		{
			/* Calculate the current error */
			vError = (SINT16)(vSetpoint - vCurrent);
			pError = (SINT32)vError - (SINT32)pPid->vLastError;
			iError = vError;
			dError = (SINT32)vError - 2 * (SINT32)pPid->vLastError + (SINT32)pPid->vPreError;

			/* Calculate the delta value, which is according to PID arithmetic */
			vDelta = (SINT16)(((SINT32)pPid->vKp * pError) / pPid->vKp_ZoomIn
							+ ((SINT32)pPid->vKi * iError) / pPid->vKi_ZoomIn
							+ ((SINT32)pPid->vKd * dError) / pPid->vKd_ZoomIn);

			/* Reset PID internal parameters */
			pPid->vPreError = pPid->vLastError;
			pPid->vLastError = vError;
			pPid->vCounter = 0;
		}
	}

	return vDelta;
}

