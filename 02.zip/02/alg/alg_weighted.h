/*
**********************************************************************************
*
* COPYRIGHT:
*	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
*
*	 This is unpublished proprietary source code of Source Photonics Inc.
*	 The copyright notice above does not evidence any actual or intended
*	 publication of such source code.
*
* FILE NAME:
*	 alg_weighted.h
*
* DESCRIPTION:
*	 weighted algorithm
*
* HISTORY:
*	 2018/07/09 	   Harry.Huang		   Create/Update
*
**********************************************************************************
*/

#ifndef __ALG_WEIGHTED_H__
#define __ALG_WEIGHTED_H__

#include "typedef.h"

/*
**********************************************************************************
* FUNCTION NAME:
*	 ALG_Weighted_GetValue
*
* DESCRIPTION:
*	 Get weighted value.
*
* PARAMETERS:
*	 vCurrent			: Current DAC value
*	 vTarget			: Target DAC value
*	 vTargetCoefficient : Targe weight coefficient(zoom in 100)
*
* RETURN:
*	 The result
*
* NOTES:
*	 vOutput = vTarget * vTargetCoefficient + vCurrent * (100 - vTargetCoefficient)
*	 It support UINT16 only.
*
* HISTORY:
*	 2017/02/16 	   Nolan.Yang		  Create/Update
**********************************************************************************
*/
UINT16 ALG_Weighted_GetValue
(
	IN	UINT16	vCurrent,
	IN	UINT16	vTarget,
	IN	UINT8	vTargetCoefficient
);

#endif
