/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 alg_calibrate.h
 *
 * DESCRIPTION:
 *	 Calibration algorithm
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#ifndef __ALG_CALIBRATE_H__
#define __ALG_CALIBRATE_H__

/******************************************************************************
* FUNCTION NAME:
*	 ALG_CALIBRATE_Calculate
*
* DESCRIPTION:
*	 Calibrate: Output = vAdcData * vSlope + vOffset
*	 The raw vSlope must be greater or equal to -2^9 and less or equal to 2^9,
*	 the raw vOffset must be greater or equal to -2^24 and less or equal to 2^24 to get a exact calibrated value;
*	 Note, ADC value can not be greater than 2^15 if ADC is unsigned 16-bit.
*
* PARAMETERS:
*	 vAdcData		   : ADC Value.
*	 vAdcSlope		   : Slope, used for calibrating
*	 vAdcOffset 	   : Offset, used for calibrating
*	 bSignedFormatting : =TRUE,  signed formatting
*						 =FALSE, unsigned formatting
* RETURN:
*	 N/A
*
* NOTES:
*	 N/A
*
* HISTORY:
*	 2017.3.28		  Kimberry.Wang 		Create/Update
*****************************************************************************/
UINT16 ALG_CALIBRATE_Calculate
(
	IN SINT16	vAdcData,
	IN SINT32	vSlope,
	IN SINT32	vOffset,
	IN BOOL		bSignedFormatting
);

/******************************************************************************
* FUNCTION NAME:
*	 ALG_CALIBRATE_CalculateByLUT
*
* DESCRIPTION:
*	 Get slope and offset in lookup table and calibrate
*
* PARAMETERS:
*	 vMemCfgPageID	   : Page ID.
*	 vAdcData		   : ADC value.
*	 bSignedFormatting : =TRUE,  signed formatting
*						 =FALSE, unsigned formatting
*
* RETURN:
*	 The result value
*
* NOTES:
*	 N/A
*
* HISTORY:
*	 2017.4.1		 Kimberry.Wang		   Create/Update
*****************************************************************************/
UINT16 ALG_CALIBRATE_CalculateByLUT
(
	IN	UINT8	vMemCfgPageID,
	IN	SINT16	vAdcData,
	IN	BOOL	bSignedFormatting
);

/******************************************************************************
 * FUNCTION NAME:
 *		apl_msa_GetPWRSlopeOffset
 *
 * DESCRIPTION:
 *		Get TxPower and RxPower calibrate slope/offset.
 *
 * PARAMETERS:
 *		vAdcData  : ADC data;
 *		vPage	  : Page id of calibration LUT;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2015.6.03		 Melinda.Lu 		Create/Update
 *****************************************************************************/
// TODO: linear interpolation is not implemented in low temperature rang, check it later
UINT16 ALG_CALIBRATE_CalculateByPWRLUT
(
	IN	CFG_PAGE_T	vPage,
	IN	SINT16		vAdcData
);

#endif

