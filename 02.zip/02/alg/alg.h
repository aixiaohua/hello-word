/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 alg.c
 *
 * DESCRIPTION:
 *	 algothrim related function
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#ifndef __ALG_H__
#define __ALG_H__

#include "alg_calibrate.h"
#include "alg_pid.h"
#include "alg_weighted.h"

#endif

