/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 alg_calibrate.c
 *
 * DESCRIPTION:
 *	 Calibration algorithm
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "alg_calibrate.h"

/* Calibration LUT define */
#define CAL_LUT_ADCGATE_SIZE		(2)					/* SINT16				*/
#define CAL_LUT_SLOPE_SIZE			(4)					/* SINT32				*/
#define CAL_LUT_OFFSET_SIZE			(4)					/* SINT32				*/
#define CAL_LUT_PAGE_SIZE			(0x80)				/* One page size		*/
#define CAL_LUT_SLOPE_ZOOMIN		(256)				/* Slope zoom in 256	*/
#define CAL_LUT_OFFSET_ZOOMIN		(1)					/* Offset zoom in 1 	*/

/* Calibration LUT define */
#define CAL_LUT_NODE_SIZE			(CAL_LUT_ADCGATE_SIZE + CAL_LUT_SLOPE_SIZE + CAL_LUT_OFFSET_SIZE)
#define CAL_LUT_NODE_NUM_MAX		(CAL_LUT_PAGE_SIZE / CAL_LUT_NODE_SIZE)
#define CAL_LUT_NODE_INDEX_MAX		(CAL_LUT_NODE_NUM_MAX - 1)

/* API for ALG_CALIBRATE_CalculateByLUT() */
#define CAL_LUT_Get_ADCGate(vPageID, vIndex)	((SINT16)CFG_GETV16((vPageID), (vIndex)*CAL_LUT_NODE_SIZE + 0))
#define CAL_LUT_Get_Slope(vPageID, vIndex)		((SINT32)CFG_GETV32((vPageID), (vIndex)*CAL_LUT_NODE_SIZE + CAL_LUT_ADCGATE_SIZE))
#define CAL_LUT_Get_Offset(vPageID, vIndex)		((SINT32)CFG_GETV32((vPageID), (vIndex)*CAL_LUT_NODE_SIZE + CAL_LUT_ADCGATE_SIZE + CAL_LUT_SLOPE_SIZE))

/* TxPower & RxPowe calibration LUT:
 * The distance between two entries for calibration LUT:
 * (see "LUT Description" of InternalMemoryMap for details)
 *   --> Power ADC Value (2B)
 *   --> Slope           (4B)
 *   --> Offset          (4B)
 *   --> TEMP ADC Value  (2B)
 */
#define LUT_PWR_ADCINDEX_SIZE    (10)    /* Bytes  */
#define LUT_PWR_TEMPINDEX_SIZE   (42)    /* Bytes  */
#define LUT_PWR_TEMPINDEX_MAX	 (3)     /* Total section of one LUT */
#define LUT_PWR_ADCINDEX_MAX     (4)     /* Total points of one temperature section */

#define LUT_PWR_GetTEMPADC(_page, _tempindex)                                   \
	    (SINT16)CFG_Memget16(_page,                                            \
	                          (((_tempindex)*LUT_PWR_TEMPINDEX_SIZE)            \
	                           +(LUT_PWR_ADCINDEX_MAX*LUT_PWR_ADCINDEX_SIZE)))  \

#define LUT_PWR_GetPWRADC(_page, _tempindex, _adcindex)                \
	    (SINT16)CFG_Memget16(_page,                                   \
	                          (((_tempindex)*LUT_PWR_TEMPINDEX_SIZE)   \
	                           +((_adcindex)*LUT_PWR_ADCINDEX_SIZE)))  \

#define LUT_PWR_GetSlope(_page, _tempindex, _adcindex)                 \
	    (SINT32)CFG_Memget32(_page,                                   \
	                          (((_tempindex)*LUT_PWR_TEMPINDEX_SIZE)   \
	                           +((_adcindex)*LUT_PWR_ADCINDEX_SIZE+2)))

#define LUT_PWR_GetOffset(_page, _tempindex, _adcindex)                \
	    (SINT32)CFG_Memget32(_page,                                   \
	                          (((_tempindex)*LUT_PWR_TEMPINDEX_SIZE)   \
	                           +((_adcindex)*LUT_PWR_ADCINDEX_SIZE+6)))


/******************************************************************************
 * FUNCTION NAME:
 *      alg_calibrate_GetPWRLUTAdcIndex
 *
 * DESCRIPTION:
 *      Get TxPower and RxPower calibrate slope/offset.
 *
 * PARAMETERS:
 *      vAdcData  : ADC data;
 *      vPage     : Page id of calibration LUT;
 *      vTempIndex: Temperature index value;
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2015.6.03        Melinda.Lu         Create/Update
 *****************************************************************************/
static UINT8 alg_calibrate_GetPWRLUTAdcIndex
(
	IN	CFG_PAGE_T vPage,
	IN	SINT16	   vAdcData,
	IN  UINT8      vTempIndex
)
{
	UINT8 vAdcIndex;

	for (vAdcIndex = 0; vAdcIndex < (LUT_PWR_ADCINDEX_MAX-1); vAdcIndex++)
	{
		if (vAdcData <= LUT_PWR_GetPWRADC(vPage, vTempIndex, vAdcIndex))
		{
			break;
		}
	}

	return vAdcIndex;
}



/******************************************************************************
* FUNCTION NAME:
*	 ALG_CALIBRATE_Calculate
*
* DESCRIPTION:
*	 Calibrate: Output = vAdcData * vSlope + vOffset
*	 The raw vSlope must be greater or equal to -2^9 and less or equal to 2^9,
*	 the raw vOffset must be greater or equal to -2^24 and less or equal to 2^24 to get a exact calibrated value;
*	 Note, ADC value can not be greater than 2^15 if ADC is unsigned 16-bit.
*
* PARAMETERS:
*	 vAdcData		   : ADC Value.
*	 vAdcSlope		   : Slope, used for calibrating
*	 vAdcOffset 	   : Offset, used for calibrating
*	 bSignedFormatting : =TRUE,  signed formatting
*						 =FALSE, unsigned formatting
* RETURN:
*	 N/A
*
* NOTES:
*	 N/A
*
* HISTORY:
*	 2017.3.28		  Kimberry.Wang 		Create/Update
*****************************************************************************/
UINT16 ALG_CALIBRATE_Calculate
(
	IN SINT16	vAdcData,
	IN SINT32	vSlope,
	IN SINT32	vOffset,
	IN BOOL		bSignedFormatting
)
{
	float vTmpData;

	/* Calculate the result
	 * Use floating point type to prevent overflow, and improve the calibrating accuracy.
	 */
	vTmpData = ((float)vSlope / CAL_LUT_SLOPE_ZOOMIN) * (float)vAdcData + (float)vOffset / CAL_LUT_OFFSET_ZOOMIN;

	if (bSignedFormatting)
	{
		/* signed formatting.
		 *
		 * If calibrated value over than maximum value +32767, return +32767 (0x7FFF);
		 * If calibrated value less than minimum value -32768, return -32768 (0x8000).
		 */
		return LIMIT_S16(vTmpData);
	}
	else
	{
		/* unsigned formatting.
		*
		* If calibrated value over than maximum value 65535, return 65535 (0xFFFF);
		* If calibrated value less than minimum value	  0, return 	0 (0x0000).
		*/
		return LIMIT_U16(vTmpData);
	}
}

/******************************************************************************
* FUNCTION NAME:
*	 ALG_CALIBRATE_CalculateByLUT
*
* DESCRIPTION:
*	 Get slope and offset in lookup table and calibrate
*
* PARAMETERS:
*	 vMemCfgPageID	   : Page ID.
*	 vAdcData		   : ADC value.
*	 bSignedFormatting : =TRUE,  signed formatting
*						 =FALSE, unsigned formatting
*
* RETURN:
*	 The result value
*
* NOTES:
*	 N/A
*
* HISTORY:
*	 2017.4.1		 Kimberry.Wang		   Create/Update
*****************************************************************************/
UINT16 ALG_CALIBRATE_CalculateByLUT
(
	IN UINT8	vMemCfgPageID,
	IN SINT16	vAdcData,
	IN BOOL		bSignedFormatting
)
{
	UINT8  vIndex;
	SINT32 vSlope, vOffset;

	/* Compare the vAdcData to ADC_Gate one by one, if vAdcData less than or equal to ADC_Gate, it's the correct ADC_Gate,
	 * if vIndex is greater than 10, see it as 11.
	 */
	for (vIndex = 0; vIndex < CAL_LUT_NODE_INDEX_MAX; vIndex++)
	{
		if (vAdcData <= CAL_LUT_Get_ADCGate(vMemCfgPageID, vIndex))
		{
			break;
		}
	}
	/* According to the vIndex to find the Slope and Offset */
	vSlope = CAL_LUT_Get_Slope(vMemCfgPageID, vIndex);
	vOffset = CAL_LUT_Get_Offset(vMemCfgPageID, vIndex);

	return ALG_CALIBRATE_Calculate(vAdcData, vSlope, vOffset, bSignedFormatting);
}

/******************************************************************************
 * FUNCTION NAME:
 *		ALG_CALIBRATE_CalculateByPWRLUT
 *
 * DESCRIPTION:
 *		Get slope and offset in power lookup table and calibrate
 *
 * PARAMETERS:
 *		vAdcData  : ADC data;
 *		vPage	  : Page id of calibration LUT;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2015.6.03		 Melinda.Lu 		Create/Update
 *****************************************************************************/
UINT16 ALG_CALIBRATE_CalculateByPWRLUT
(
	IN CFG_PAGE_T	vPage,
	IN SINT16		vAdcData
)
{
	UINT8 vTempIndex, vAdcIndex;
	SINT16 vRtTempAdc;
	SINT32 vSlope, vOffset;
	UINT16 vPower;

	// TODO: check it later
	/* Get real-time temperature */
	vRtTempAdc = (SINT16)CFG_GET16(Debug_RT_ChipTEMP);

	/* Get temperature index */
	for (vTempIndex = 0; vTempIndex < LUT_PWR_TEMPINDEX_MAX; vTempIndex++)
	{
		if (vRtTempAdc < LUT_PWR_GetTEMPADC(vPage, vTempIndex))
		{
			break;
		}
	}

	switch (vTempIndex)
	{
		case 3:
			/* Beyond temperature range setting, use the last section for claibration */
			vTempIndex = vTempIndex - 1;
			/* no break here */
		case 0:
			vAdcIndex= alg_calibrate_GetPWRLUTAdcIndex(vPage, vAdcData, vTempIndex);
			vSlope = LUT_PWR_GetSlope(vPage, vTempIndex, vAdcIndex);
			vOffset = LUT_PWR_GetOffset(vPage, vTempIndex, vAdcIndex);
			vPower = ALG_CALIBRATE_Calculate(vAdcData, vSlope, vOffset, FALSE);
			break;

		case 2:
		case 1:
			{
				UINT16 vPower1, vPower2;
				SINT16 vTempAdc1, vTempAdc2;

				/* add linear interpolation between temperature index1 and index 2 */
				vAdcIndex = alg_calibrate_GetPWRLUTAdcIndex(vPage, vAdcData, (vTempIndex-1));
				vSlope = LUT_PWR_GetSlope(vPage, (vTempIndex-1), vAdcIndex);
				vOffset = LUT_PWR_GetOffset(vPage, (vTempIndex-1), vAdcIndex);
				vPower1 = ALG_CALIBRATE_Calculate(vAdcData, vSlope, vOffset, FALSE);
				vTempAdc1 = LUT_PWR_GetTEMPADC(vPage,(vTempIndex-1));

				vAdcIndex = alg_calibrate_GetPWRLUTAdcIndex(vPage, vAdcData, vTempIndex);
				vSlope = LUT_PWR_GetSlope(vPage, vTempIndex, vAdcIndex);
				vOffset = LUT_PWR_GetOffset(vPage, vTempIndex, vAdcIndex);
				vPower2 = ALG_CALIBRATE_Calculate(vAdcData, vSlope, vOffset, FALSE);
				vTempAdc2 = LUT_PWR_GetTEMPADC(vPage,vTempIndex);

				// TODO: Replace it with linear interpolation algorithm
				vPower = (UINT16)((SINT32)vPower1 + ((((SINT32)vRtTempAdc - (SINT32)vTempAdc1)
							* ((SINT32)vPower2 - (SINT32)vPower1))
							/((SINT32)vTempAdc2 - (SINT32)vTempAdc1)));
			}
			break;

		default:
			vPower = 0;;
			break;
	}

	return vPower;
}


