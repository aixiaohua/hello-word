/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 cfg_mem_map.h
 *
 * DESCRIPTION:
 *	 Config memory map related.
 *
 * HISTORY:
 *	 2014.3.17		  Panda.Xiong		 Create/Update
 *
 *****************************************************************************/

#ifndef __CFG_MEM_MAP_H__
#define __CFG_MEM_MAP_H__

#define CFG_PAGE_INVALID_ID				CFG_PAGE_FLASH_INVALID

#define CFG_PAGE_TABLE(addr, page)		CFG_PAGE_ ## addr ## _ ## page
#define CFG_PAGE(name)					CFG_PAGE_ ## name
#define I2C_BIT(name)					I2C_BIT_ ## name
#define I2C_LEN(name)					I2C_LEN_ ## name
#define I2C_OFFSET(name)				I2C_OFFSET_ ## name
#define CONFIG(name)					I2C_OFFSET(name)


/* I2C Byte defintion */
#define DECLARE_I2C_MEMORY(addr, page, name, offset, length, type, default, character, description) 		   name = offset, I2C_OFFSET(name) = offset,
#define DECLARE_I2C_MEMORY_BIT(addr, page, name, offset, begin, width, type, default, character, description)  name = offset, I2C_OFFSET(name) = offset,
enum MemBytes
{
#include "def_i2c_register.h"
	I2C_MEM_END
};
#undef DECLARE_I2C_MEMORY
#undef DECLARE_I2C_MEMORY_BIT


/* I2C Bit defintion */
#define DECLARE_I2C_MEMORY(addr, page, name, offset, length, type, default, character, description) 		   /* nothing */
#define DECLARE_I2C_MEMORY_BIT(addr, page, name, offset, begin, width, type, default, character, description)  I2C_BIT(name) = begin,
enum MemBits
{
#include "def_i2c_register.h"
	I2C_BIT_END
};
#undef DECLARE_I2C_MEMORY
#undef DECLARE_I2C_MEMORY_BIT


/*******************************************************************************
 * I2C Length defintion
 ******************************************************************************/
#define DECLARE_I2C_MEMORY(addr, page, name, offset, length, type, default, character, description) 		   I2C_LEN(name) = length,
#define DECLARE_I2C_MEMORY_BIT(addr, page, name, offset, begin, width, type, default, character, description)  I2C_LEN(name) = width,
typedef enum
{
#include "def_i2c_register.h"
	I2C_LEN_END
} I2C_LEN_T;
#undef DECLARE_I2C_MEMORY
#undef DECLARE_I2C_MEMORY_BIT


/* I2C Page defintion */
#define DECLARE_I2C_MEMORY(addr, page, name, offset, length, type, default, character, description) 		   CFG_PAGE(name) = CFG_PAGE_TABLE(addr, page),
#define DECLARE_I2C_MEMORY_BIT(addr, page, name, offset, begin, width, type, default, character, description)  CFG_PAGE(name) = CFG_PAGE_TABLE(addr, page),
enum ConfigPage
{
#include "def_i2c_register.h"
	CONFIG_PAGE_END
};
#undef DECLARE_I2C_MEMORY
#undef DECLARE_I2C_MEMORY_BIT

#endif

