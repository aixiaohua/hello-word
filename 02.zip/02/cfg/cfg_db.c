/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   cfg_db.c
 *
 * DESCRIPTION:
 *   Config database related.
 *
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/
#include "cfg.h"
#include "drv.h"


/******************************************************************************
 * FUNCTION NAME:
 *      cfg_db_LoadConfig
 *
 * DESCRIPTION:
 *      Load configuration from ROM to RAM.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
static void cfg_db_LoadConfig(void)
{
    /* load page contents */
    CFG_PAGE_T   vPageId;

	/* reset RAM configuration buffer */
	(void)memset((UINT8 *)&aCfgInRamBuf, 0x00, sizeof(aCfgInRamBuf));

	/* only load RAM_MAP page from flash into RAM */
    for (vPageId = CFG_PAGE_RAMMAP_START;
	     vPageId <= CFG_PAGE_RAMMAP_END;
		 vPageId++)
    {
		FLASH_MEMDMP(aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)],
	                 GET_PAGE_ADDR_IN_FLASH(vPageId),
                     MSA_PAGE_SIZE);
	}
}


/******************************************************************************
 * FUNCTION NAME:
 *      CFG_DB_Init
 *
 * DESCRIPTION:
 *      Configuration dataBase init.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void CFG_DB_Init(void)
{
    UINT32  vFirmwareID, vFirmwareVersion;

    vFirmwareID      = CFG_Image_GetImageID(FILE_ID_FW);
    vFirmwareVersion = CFG_Image_GetImageVersion(FILE_ID_FW);

    /* check whether the configuration is valid */
    if (CFG_GET32(Project_ID) != vFirmwareID)
    {
        /* incorrect firmware ID,
         *  i.e. no valid configuration found,
         *  retrieve default configuration database.
         */

        /* configuration internal retrieving */
        DRV_Retrieve();
        CFG_Retrieve();

        /* update firmware ID */
        CFG_SET32(Project_ID, vFirmwareID);
    }

    /* update firmware version */
    CFG_SET32(Major_Rev, vFirmwareVersion);

    /* load configuration */
    cfg_db_LoadConfig();
}

