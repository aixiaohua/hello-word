/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   cfg_retrieve.c
 *
 * DESCRIPTION:
 *   APIs to retrieve default configuration for a page
 *
 * HISTORY:
 *   2017.7.21        Melinda.Lu        Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"

#define RETRIEVE_DEFAULT_VALUE			0xFF

typedef union
{
	UINT32	aPage_U32[MSA_PAGE_SIZE/4];
	UINT16	aPage_U16[MSA_PAGE_SIZE/2];
	UINT8	aPage_U8[MSA_PAGE_SIZE];
} CFG_RETRIEVE_PAGE_T;

typedef struct
{
    CFG_PAGE_T				vPageId;
	CFG_RETRIEVE_PAGE_T		aRetrievePage;
} CFG_RETRIEVE_T;

static CFG_RETRIEVE_T vRetrieveBuf;

/******************************************************************************
 * FUNCTION NAME:
 *      cfg_retrieve_CheckAndInit
 *
 * DESCRIPTION:
 *      Init config retrieve buffer.
 *
 * PARAMETERS:
 *      vPageId: retrieve page ID
 *      vOffset: retrieve offset
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
static BOOL cfg_retrieve_CheckAndInit(IN CFG_PAGE_T vPageId, IN UINT8 vOffset)
{
	CFG_RETRIEVE_T *pBuf = &vRetrieveBuf;
	CFG_RETRIEVE_PAGE_T *pPage = &vRetrieveBuf.aRetrievePage;

    /* Check input parameters */
    if (!(IS_FLASH_PAGE(vPageId)))
    {
        return FALSE;
    }
    if (vOffset > MSA_PAGE_SIZE)
    {
        return FALSE;
    }

    /* Check whether the setting is the same page, if not, clear RAM */
    if ((pBuf->vPageId == CFG_PAGE_INVALID_ID) || (pBuf->vPageId != vPageId))
    {
        pBuf->vPageId = vPageId;
        memset(pPage->aPage_U8, RETRIEVE_DEFAULT_VALUE, MSA_PAGE_SIZE);
    }

    return TRUE;
}

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_MemSet8
 *
 * DESCRIPTION:
 *      Write 8-bit to config retrieve buffer.
 *
 * PARAMETERS:
 *      vPageId: retrieve page ID
 *      vOffset: retrieve offset
 *      vData: data
 *      vLen: length
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_MemSet8(IN CFG_PAGE_T vPageId, IN UINT8 vOffset, IN UINT8 vData, IN UINT8 vLen)
{
	UINT8 vLoop;
	CFG_RETRIEVE_PAGE_T *pPage = &vRetrieveBuf.aRetrievePage;

	/* first Check and Initialize the retrieve buffer */
    if (cfg_retrieve_CheckAndInit(vPageId, vOffset))
	{
		/* write data to retrieve buffer */
		for (vLoop = vOffset; vLoop < (vOffset+vLen); vLoop++)
		{
			pPage->aPage_U8[vLoop] = vData;
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_MemSet16
 *
 * DESCRIPTION:
 *      Write 16-bit to config retrieve buffer.
 *
 * PARAMETERS:
 *      vPageId        : retrieve page ID
 *      vOffset        : retrieve offset
 *      vData          : data
 *      vLen           : length
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_MemSet16(IN CFG_PAGE_T vPageId, IN UINT8 vOffset, IN UINT16 vData, IN UINT8 vLen)
{
	UINT8 vLoop;
	CFG_RETRIEVE_PAGE_T *pPage = &vRetrieveBuf.aRetrievePage;

	/* first Check and Initialize the retrieve buffer */
    if (cfg_retrieve_CheckAndInit(vPageId, vOffset))
	{
		vOffset = vOffset/sizeof(UINT16);

		/* write data to retrieve buffer */
		for (vLoop = vOffset; vLoop < (vOffset+vLen); vLoop++)
		{
			pPage->aPage_U16[vLoop] = ENDIAN_SWAP_16(vData);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_MemSet32
 *
 * DESCRIPTION:
 *      Write 32-bit to config retrieve buffer.
 *
 * PARAMETERS:
 *      vPageId        : retrieve page ID
 *      vOffset        : retrieve offset
 *      vData          : data
 *      vLen           : length
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_MemSet32(IN CFG_PAGE_T vPageId, IN UINT8 vOffset, IN UINT32 vData, IN UINT8 vLen)
{
	UINT8 vLoop;
	CFG_RETRIEVE_PAGE_T *pPage = &vRetrieveBuf.aRetrievePage;

	/* first Check and Initialize the retrieve buffer */
    if (cfg_retrieve_CheckAndInit(vPageId, vOffset))
	{
		vOffset = vOffset/sizeof(UINT32);

		/* write data to retrieve buffer */
        for (vLoop = vOffset; vLoop < (vOffset+vLen); vLoop++)
		{
			pPage->aPage_U32[vLoop] = ENDIAN_SWAP_32(vData);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_SaveConfig
 *
 * DESCRIPTION:
 *      Save retrieve data.
 *
 * PARAMETERS:
 *      vPageId: retrieve page ID
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_SaveConfig(IN CFG_PAGE_T vPageId)
{
	UINT8				*pMemAddr;
	CFG_RETRIEVE_T		*pBuf = &vRetrieveBuf;
	CFG_RETRIEVE_PAGE_T	*pPage = &vRetrieveBuf.aRetrievePage;;

	if (pBuf->vPageId == vPageId)
	{
		pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPageId);
		FLASH_MEMCPY(pMemAddr, pPage->aPage_U8, MSA_PAGE_SIZE);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve
 *
 * DESCRIPTION:
 *      Retrieve default configuration for a new module
 *
 * PARAMETERS:
 *      vPageId: retrieve page ID
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve(void)
{
	APT_CFG_Retrieve();
}

