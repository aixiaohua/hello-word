/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   cfg.c
 * DESCRIPTION:
 *   config API related.
 *
 *   Note: The configuration is always saved as big-endian,
 *          to strictly follow all MSA.
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"

#if 1
/* Configuration stored in RAM, including RAM Page & RAM_MAP Page */
CFG_PAGE_IN_RAM_T           aCfgInRamBuf;
#define GET_PAGE_ADDR_IN_RAM(page_id)	((UINT8 *)(&aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(page_id)]))

#endif

/* configuration operation API releted */
#if 1
UINT8 CFG_Memget8(IN CFG_PAGE_T vPage, IN UINT8 vOffset)
{
    UINT8 *pMemAddr;
    UINT8  vData;

    if (IS_RAM_PAGE(vPage))
    {
		/* RAM page */
		pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage)+vOffset;
		vData = P8(pMemAddr);
    }
    else
    {
		/* Flash page */
		pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage)+vOffset;
        FLASH_MEMDMP(&vData, pMemAddr, 1);
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, vData);

    return vData;
}


UINT16 CFG_Memget16(IN CFG_PAGE_T vPage, IN UINT8 vOffset)
{
    UINT8  *pMemAddr;
    UINT16  vData;

    if (IS_RAM_PAGE(vPage))
    {
        pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + vOffset;
      #if defined(__cortex_m3__)
        vData = ENDIAN_SWAP_16(P16(pMemAddr));
      #else
        if (((UINT32)pMemAddr & 0x1) == 0)
        {
            vData = ENDIAN_SWAP_16(P16(pMemAddr));
        }
        else
        {
            vData = GET_BE_16(pMemAddr);
        }
      #endif
    }
    else
    {
        UINT8   aBuf[sizeof(UINT16)];

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMDMP(aBuf, pMemAddr, sizeof(aBuf));
        vData = GET_BE_16(aBuf);
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, vData);

    return vData;
}

UINT32 CFG_Memget32(IN CFG_PAGE_T vPage, IN UINT8 vOffset)
{
    UINT8  *pMemAddr;
    UINT32  vData;

    if (IS_RAM_PAGE(vPage))
    {
        pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + vOffset;
      #if defined(__cortex_m3__)
        vData = ENDIAN_SWAP_32(P32(pMemAddr));
      #else
        if (((UINT32)pMemAddr & 0x3) == 0)
        {
            vData = ENDIAN_SWAP_32(P32(pMemAddr));
        }
        else
        {
            vData = GET_BE_32(pMemAddr);
        }
      #endif
    }
    else
    {
        UINT8   aBuf[sizeof(UINT32)];

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMDMP(aBuf, pMemAddr, sizeof(aBuf));
        vData = GET_BE_32(aBuf);
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.8X",
            vPage, vOffset, (UINT32)pMemAddr, vData);

    return vData;
}

UINT64 CFG_Memget64(IN CFG_PAGE_T vPage, IN UINT8 vOffset)
{
    UINT8  *pMemAddr;
    UINT64  vData;

    if (IS_RAM_PAGE(vPage))
    {
        pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + vOffset;
      #if defined(__cortex_m3__)
        vData = ENDIAN_SWAP_64(P64(pMemAddr));
      #else
        if (((UINT64)pMemAddr & 0x7) == 0)
        {
            vData = ENDIAN_SWAP_64(P64(pMemAddr));
        }
        else
        {
            vData = GET_BE_64(pMemAddr);
        }
      #endif
    }
    else
    {
        UINT8   aBuf[sizeof(UINT64)];

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMDMP(aBuf, pMemAddr, sizeof(aBuf));
        vData = GET_BE_64(aBuf);
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.8X_%.8X",
            vPage, vOffset, (UINT32)pMemAddr,
            (UINT32)(vData>>32), (UINT32)(vData>>0));

    return vData;
}

void CFG_Memset8(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT8 vData)
{
    UINT8 *pMemAddr;

    if (IS_RAM_PAGE(vPage))
    {
        pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + vOffset;
		P8(pMemAddr) = vData;
    }
    else
    {
        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, &vData, 1);
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, vData);
}

void CFG_Memset16(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT16 vData)
{
    UINT8 *pMemAddr;

    if (IS_RAM_PAGE(vPage))
    {
        pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + vOffset;
      #if !defined(__cortex_m3__)
        if (((UINT32)pMemAddr & 0x1) != 0)
        {
            SET_BE_16(pMemAddr, vData);
        }
        else
      #endif
        {
            (P16(pMemAddr)) = ENDIAN_SWAP_16(vData);
        }
    }
    else
    {
        UINT16  vDataBuf;

        /* update buffer */
		vDataBuf = ENDIAN_SWAP_16(vData);

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, &vDataBuf, sizeof(vDataBuf));
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, vData);
}

void CFG_Memset32(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT32 vData)
{
    UINT8 *pMemAddr;

    if (IS_RAM_PAGE(vPage))
    {
        pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + vOffset;
      #if !defined(__cortex_m3__)
        if (((UINT32)pMemAddr & 0x3) != 0)
        {
            SET_BE_32(pMemAddr, vData);
        }
        else
      #endif
        {
            (P32(pMemAddr)) = ENDIAN_SWAP_32(vData);
        }
    }
    else
    {
        UINT16  aDataBuf[2];

        /* update buffer */
		aDataBuf[0] = ENDIAN_SWAP_16(vData>>16);
		aDataBuf[1] = ENDIAN_SWAP_16(vData>> 0);

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, &aDataBuf, sizeof(vData));
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.8X",
            vPage, vOffset, (UINT32)pMemAddr, vData);
}

void CFG_Memset64(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT64 vData)
{
    UINT8 *pMemAddr;

    if (IS_RAM_PAGE(vPage))
    {
        pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + vOffset;
      #if !defined(__cortex_m3__)
        if (((UINT32)pMemAddr & 0x7) != 0)
        {
            SET_BE_64(pMemAddr, vData);
        }
        else
      #endif
        {
            (P64(pMemAddr)) = ENDIAN_SWAP_64(vData);
        }
    }
    else
    {
        UINT16  aDataBuf[4];

        /* update buffer */
        aDataBuf[0] = ENDIAN_SWAP_16(vData>>48);
        aDataBuf[1] = ENDIAN_SWAP_16(vData>>32);
        aDataBuf[2] = ENDIAN_SWAP_16(vData>>16);
        aDataBuf[3] = ENDIAN_SWAP_16(vData>> 0);

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, &aDataBuf, sizeof(vData));
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.8X_%.8X",
            vPage, vOffset, (UINT32)pMemAddr,
            (UINT32)(vData>>32), (UINT32)(vData>>0));
}

void CFG_Memset(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT8 vData, IN UINT8 vLen)
{
    UINT8 *pMemAddr;
    UINT16  vLoop;

    if (IS_RAM_PAGE(vPage))
    {
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + (vOffset+vLoop);
			P8(pMemAddr) = vData;
        }
    }
    else
    {
		UINT8 aPageBuf[MSA_PAGE_SIZE];

        /* update buffer */
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            aPageBuf[vLoop] = vData;
        }

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, aPageBuf, vLen);
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X data=%.4X len=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, vData, vLen);
}

void CFG_Memdmp8(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT8 *pBuf, IN UINT8 vLen)
{
    while (vLen--)
    {
        *pBuf++ = CFG_Memget8(vPage, vOffset++);
    }
}

void CFG_Memdmp16(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT16 *pBuf, IN UINT8 vLen)
{
    while (vLen--)
    {
        *pBuf++ = CFG_Memget16(vPage, vOffset);
		vOffset += sizeof(UINT16);
    }
}

void CFG_Memdmp32(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT32 *pBuf, IN UINT8 vLen)
{
    while (vLen--)
    {
        *pBuf++ = CFG_Memget32(vPage, vOffset);
		vOffset += sizeof(UINT32);
    }
}

void CFG_Memdmp64(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT64 *pBuf, IN UINT8 vLen)
{
    while (vLen--)
    {
        *pBuf++ = CFG_Memget64(vPage, vOffset);
		vOffset += sizeof(UINT64);
    }
}

void CFG_Memcpy8(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT8 *pBuf, IN UINT8 vLen)
{
    UINT8  *pMemAddr;
    UINT8   vData;
    UINT8   vLoop;

    if (IS_RAM_PAGE(vPage))
    {
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            vData = pBuf[vLoop];

            pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + (vOffset+vLoop);
			P8(pMemAddr) = vData;
        }
    }
    else
    {
        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, pBuf, vLen);
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X buf=%.8X len=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, (UINT32)pBuf, vLen);
}

void CFG_Memcpy16(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT16 *pBuf, IN UINT8 vLen)
{
    UINT8  *pMemAddr;
    UINT16  vData;
    UINT8   vLoop;

    if (IS_RAM_PAGE(vPage))
    {
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            vData = pBuf[vLoop];

            pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + (vOffset+vLoop);
          #if !defined(__cortex_m3__)
            if (((UINT32)pMemAddr & 0x1) != 0)
            {
                SET_BE_16(pMemAddr, vData);
            }
            else
          #endif
            {
                (P16(pMemAddr)) = ENDIAN_SWAP_16(vData);
            }
        }
    }
    else
    {
        UINT16  aPageBuf[MSA_PAGE_SIZE/sizeof(UINT16)];

        /* update buffer */
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            vData = pBuf[vLoop];
            aPageBuf[vLoop] = ENDIAN_SWAP_16(vData);
        }

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, &aPageBuf, vLen*sizeof(vData));
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X buf=%.8X len=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, (UINT32)pBuf, vLen);
}

void CFG_Memcpy32(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT32 *pBuf, IN UINT8 vLen)
{
    UINT8  *pMemAddr = 0;
    UINT32  vData;
    UINT8   vLoop;

    if (IS_RAM_PAGE(vPage))
    {
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            vData = pBuf[vLoop];

            pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + (vOffset+vLoop);
          #if !defined(__cortex_m3__)
            if (((UINT32)pMemAddr & 0x3) != 0)
            {
                SET_BE_32(pMemAddr, vData);
            }
            else
          #endif
            {
                (P32(pMemAddr)) = ENDIAN_SWAP_32(vData);
            }
        }
    }
    else
    {
        UINT16  aPageBuf[MSA_PAGE_SIZE/sizeof(UINT16)];

        /* update buffer */
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            vData = pBuf[vLoop];
            aPageBuf[vLoop+0] = ENDIAN_SWAP_32(vData>>16);
            aPageBuf[vLoop+1] = ENDIAN_SWAP_32(vData>> 0);
        }

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, &aPageBuf, vLen*sizeof(vData));
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X buf=%.8X len=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, (UINT32)pBuf, vLen);
}

void CFG_Memcpy64(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT64 *pBuf, IN UINT8 vLen)
{
    UINT8  *pMemAddr;
    UINT64  vData;
    UINT8   vLoop;

    if (IS_RAM_PAGE(vPage))
    {
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            vData = pBuf[vLoop];

            pMemAddr = GET_PAGE_ADDR_IN_RAM(vPage) + (vOffset+vLoop);
          #if !defined(__cortex_m3__)
            if (((UINT64)pMemAddr & 0x7) != 0)
            {
                SET_BE_64(pMemAddr, vData);
            }
            else
          #endif
            {
                (P64(pMemAddr)) = ENDIAN_SWAP_64(vData);
            }
        }
    }
    else
    {
        UINT16  aPageBuf[MSA_PAGE_SIZE/sizeof(UINT16)];

        /* update buffer */
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            vData = pBuf[vLoop];
            aPageBuf[vLoop+0] = ENDIAN_SWAP_16(vData>>48);
            aPageBuf[vLoop+1] = ENDIAN_SWAP_16(vData>>32);
            aPageBuf[vLoop+2] = ENDIAN_SWAP_16(vData>>16);
            aPageBuf[vLoop+3] = ENDIAN_SWAP_16(vData>> 0);
        }

        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vPage) + vOffset;
        FLASH_MEMCPY(pMemAddr, &aPageBuf, vLen*sizeof(vData));
    }

    DBG_LOG_DEBUG("page=%.2X offset=%.4X addr=%.8X buf=%.8X len=%.4X",
            vPage, vOffset, (UINT32)pMemAddr, (UINT32)pBuf, vLen);
}

void CFG_Memcpy
(
    IN CFG_PAGE_T   vDstPage,
    IN UINT8        vDstOffset,
    IN CFG_PAGE_T   vSrcPage,
    IN UINT8        vSrcOffset,
    IN UINT8        vLen
)
{
    UINT8       aPageBuf[MSA_PAGE_SIZE];
    UINT8      *pMemAddr;
    UINT8       vLoop;

    /* first, read source data into buffer */
    for (vLoop = 0; vLoop < vLen; vLoop++)
    {
        aPageBuf[vLoop] = CFG_Memget8(vSrcPage, vSrcOffset+vLoop);
    }

    /* second, write buffer data into database */
    if (IS_RAM_PAGE(vDstPage))
    {
        for (vLoop = 0; vLoop < vLen; vLoop++)
        {
            pMemAddr = GET_PAGE_ADDR_IN_RAM(vDstPage) + (vDstOffset+vLoop);
			P8(pMemAddr) = aPageBuf[vLoop];
        }
    }
    else
    {
        pMemAddr = GET_PAGE_ADDR_IN_FLASH(vDstPage) + vDstOffset;
        FLASH_MEMCPY(pMemAddr, &aPageBuf, vLen);
    }

    DBG_LOG_DEBUG("srcPage=%.2X srcOffset=%.4X dstPage=%.2X dstOffset=%.4X addr=%.8X len=%.4X",
            vSrcPage, vSrcOffset, vDstPage, vDstOffset, (UINT32)pMemAddr, vLen);
}


/* Note: CFG_SetBuf() is called in CFG_MSA_FlushPage() after write via I2C */
void CFG_SetBuf
(
    IN       CFG_PAGE_T vPageId,
    IN       UINT8      vOffset,
    IN       UINT16     vLen,
	IN const UINT8	   *pDataSrc
)
{
	if (IS_FLASH_PAGE(vPageId))
	{
		if (IS_RAMMAP_PAGE(vPageId))
		{
			/* Note: the RAM-MAP page, the data has been flush to RAM in CFG_MSA_FlushPage(),
			 *       for each register would have different requirement.
			 *       Now, flush data to flash from RAM,
			 *       for not all of the data needs to be saved to flash.
			 */
			pDataSrc = &aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vOffset];
		}

		/* flush data to flash */
		FLASH_MEMCPY(GET_PAGE_ADDR_IN_FLASH(vPageId)+vOffset, pDataSrc, vLen);
	}
	else
	{
		/* RAM page */
		(void)memcpy(&aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vOffset], pDataSrc, vLen);
	}
}

#endif


/* state machine related */
#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      CFG_InitializeState
 * DESCRIPTION:
 *      Configuration Initialize State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void CFG_InitializeState(void)
{
	CFG_Image_Init();
    CFG_DB_Init();
    CFG_Security_Init();
}


/******************************************************************************
 * FUNCTION NAME:
 *      CFG_ResetState
 * DESCRIPTION:
 *      Configuration Reset State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2015.7.31        Panda.Xiong        Create/Update
 *****************************************************************************/
void CFG_ResetState(void)
{
    /* do nothing */
}

#endif

