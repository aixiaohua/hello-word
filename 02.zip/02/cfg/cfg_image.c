/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   cfg_image.c
 *
 * DESCRIPTION:
 *   Image related.
 *
 * HISTORY:
 *   2015.1.19        Panda.Xiong         Create/Update
 *
 *****************************************************************************/
#include "cfg.h"
#include "drv.h"

#if IMAGE_SUPPORT

typedef struct
{
    SINT32  vSigOffset;
    UINT32  vClass;
    UINT32  vSubClass;
} IMAGE_PARAM_T;

static __code IMAGE_PARAM_T aImageParam[FILE_COUNT] =
{
    { FILE0_SIG_OFFSET, FILE0_CLASS, FILE0_SUBCLASS, },
    { FILE1_SIG_OFFSET, FILE1_CLASS, FILE1_SUBCLASS, },
};

/* file(firmware) signature definition, don't try to remove it !!! */
static __signature __code FILE_SIG_T   vSigFileFW;

// TODO: Change vImageInfo to static
IMAGE_INFO_T   vImageInfo;

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Image_Refresh
 *
 * DESCRIPTION:
 *      Refresh image id information.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.5.25        Melinda.Lu         Create/Update
 *****************************************************************************/
void CFG_Image_Refresh(void)
{
    const UINT8    *pBase;
    IMAGE_INFO_T    vImageIdInfo;
    UINT32          vLoop;

    memset(&vImageIdInfo, 0x0, sizeof(vImageIdInfo));

	/* get image base address */
	pBase = (const UINT8 *)IMAGE_BASE;

    /* do slow check for image status */
    for (vLoop = 0; vLoop < COUNT_OF(vImageIdInfo.aFile); vLoop++)
    {
        FILE_INFO_T         *pFileInfo   = &(vImageIdInfo.aFile[vLoop]);
        const IMAGE_PARAM_T *pImageParam = &(aImageParam[vLoop]);
        UINT32               vSum;
        UINT32               vLoop2;

        pFileInfo->pBase = pBase;
        if (pImageParam->vSigOffset >= 0)
        {
            pFileInfo->pSig     = (FILE_SIG_T *)((UINT32)(pFileInfo->pBase)
                                                 + pImageParam->vSigOffset);
            pFileInfo->pContent = pFileInfo->pBase;
        }
        else
        {
            pFileInfo->pSig     = (FILE_SIG_T *)((UINT32)(pFileInfo->pBase));
            pFileInfo->pContent = pFileInfo->pBase - pImageParam->vSigOffset;
        }

        /* validate file */
        if ((pFileInfo->pSig->vFileClass != pImageParam->vClass)
            || (pFileInfo->pSig->vFileSubclass != pImageParam->vSubClass))
        {
            vImageIdInfo.vStatus = IMAGE_STATUS_Bad;
            goto _exit;
        }

        for (vLoop2 = 0, vSum = 0;
             vLoop2 < pFileInfo->pSig->vFileAlignedSize;
             vLoop2++)
        {
            vSum += pFileInfo->pBase[vLoop2];
        }

        vSum -= ((pFileInfo->pSig->vFileChecksum >> 24) & 0xFF);
        vSum -= ((pFileInfo->pSig->vFileChecksum >> 16) & 0xFF);
        vSum -= ((pFileInfo->pSig->vFileChecksum >>  8) & 0xFF);
        vSum -= ((pFileInfo->pSig->vFileChecksum >>  0) & 0xFF);

        if (vSum != pFileInfo->pSig->vFileChecksum)
        {
            vImageIdInfo.vStatus = IMAGE_STATUS_Bad;
            goto _exit;
        }
        else
        {
            pFileInfo->bValid = TRUE;
        }

        /* point to next file */
        pBase += pFileInfo->pSig->vFileAlignedSize;
    }

    /* image is valid */
    vImageIdInfo.vStatus = IMAGE_STATUS_Valid;

_exit:
    /* update image status */
    memcpy(&vImageInfo, &vImageIdInfo, sizeof(vImageIdInfo));
}


/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Image_Init
 *
 * DESCRIPTION:
 *      Image init.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2015.1.19        Panda.Xiong         Create/Update
 *****************************************************************************/
void CFG_Image_Init(void)
{
    memset(&vImageInfo, 0x0, sizeof(vImageInfo));

    /* refresh current running image information */
    CFG_Image_Refresh();

  #if RELEASE_MODE
    /* validate current running image status,
     *  it should never be invalid.
     */
    if (vImageInfo.vStatus != IMAGE_STATUS_Valid)
    {
        DBG_LOG_FATAL("Invalid running image detected!");
    }
  #endif
}

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Image_GetImageID
 *
 * DESCRIPTION:
 *      Get image id.
 *
 * PARAMETERS:
 *      vFileId: File ID
 *
 * RETURN:
 *      Converted image id.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.5.25        Melinda.Lu         Create/Update
 *****************************************************************************/
UINT32 CFG_Image_GetImageID(IN FILE_ID_T vFileId)
{
	FILE_INFO_T  *pFileInfo;
	UINT8 vTemp[4];

	pFileInfo   = &vImageInfo.aFile[vFileId];

	vTemp[0] = (UINT32)pFileInfo->pSig->aFileRev[0];
	vTemp[1] = (UINT32)pFileInfo->pSig->aFileRev[1];
	vTemp[2] = (UINT32)pFileInfo->pSig->aFileRev[2];
	vTemp[3] = (UINT32)pFileInfo->pSig->aFileRev[3];

	return GET_BE_32(vTemp);
}


/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Image_GetImageVersion
 *
 * DESCRIPTION:
 *      Get image version.
 *
 * PARAMETERS:
 *      vFileId: File ID
 *
 * RETURN:
 *      Converted image version.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.5.25        Melinda.Lu         Create/Update
 *****************************************************************************/
UINT32 CFG_Image_GetImageVersion(IN FILE_ID_T vFileId)
{
	FILE_INFO_T  *pFileInfo;
	UINT8 vTemp[4];

	pFileInfo	= &vImageInfo.aFile[vFileId];

	vTemp[0] = (UINT32)pFileInfo->pSig->aFileRev[4];
	vTemp[1] = (UINT32)pFileInfo->pSig->aFileRev[5];
	vTemp[2] = (UINT32)pFileInfo->pSig->aFileRev[6];
	vTemp[3] = (UINT32)pFileInfo->pSig->aFileRev[7];

	return GET_BE_32(vTemp);
}

#endif

