/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 cfg_security.c
 *
 * DESCRIPTION:
 *	 Configuration security related.
 *
 * HISTORY:
 *	 2014.3.17		  Panda.Xiong		 Create/Update
 *
 *****************************************************************************/
#include "cfg.h"
#include "drv.h"

/* I2C Security Level */
static SECURITY_LEVEL_T vSecurityLevel;

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_GetLevel
 *
 * DESCRIPTION:
 *		Get config security level.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.13		 Panda.Xiong		Create/Update
 *****************************************************************************/
SECURITY_LEVEL_T CFG_Security_GetLevel(void)
{
	return vSecurityLevel;
}

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_UpdateLevel
 *
 * DESCRIPTION:
 *		Update config security level.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void CFG_Security_UpdateLevel(void)
{
	UINT32				vPasswd;
	SECURITY_LEVEL_T	vNewLevel;
	SECURITY_LEVEL_T	vMinLevel;

	vPasswd   = CFG_GET32(PWD_Entry);
	vMinLevel = CFG_GET8(SecurityLevelMin);
	vNewLevel = SECURITY_LEVEL_NORMAL;

	switch (vMinLevel)
	{
		case SECURITY_LEVEL_NORMAL:
		case SECURITY_LEVEL_USER_RO:
		case SECURITY_LEVEL_USER_RW:
		case SECURITY_LEVEL_OEM:
		case SECURITY_LEVEL_FACTORY:
			break;

		default:
			vMinLevel = SECURITY_LEVEL_NORMAL;
	}

	switch (vPasswd)
	{
		case PASSWD_REBOOT:   /* reboot  */
			break;

#if SECURE_MODE_SUPPORT
		case PASSWD_EnterSecureMode:  /* enter secure mode */
			break;

		case PASSWD_ExitSecureMode:   /* exit secure mode */
			break;

		case PASSWD_EnterDownloadMode:	/* enter download mode */
			break;
#endif

		case PASSWD_FACTORY:  /* Factory Password */
			vNewLevel = SECURITY_LEVEL_FACTORY;
			break;

		case PASSWD_OEM:	  /* OEM Password	  */
			vNewLevel = SECURITY_LEVEL_OEM;
			break;

		default:
			if (vPasswd == CFG_GET32(USER_RW_PWD))
			{
				/* User R/W Password matched */
				vNewLevel = SECURITY_LEVEL_USER_RW;
			}
			else if (vPasswd == PASSWD_USER_RO)
			{
				/* User Read-Only Password */
				vNewLevel = SECURITY_LEVEL_USER_RO;
			}
			break;
	}

	/* Limit minimum security level */
	if (vNewLevel < vMinLevel)
	{
		vNewLevel = vMinLevel;
	}

	/* Accept new security level */
	vSecurityLevel = vNewLevel;
}


/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_SavePasswd
 *
 * DESCRIPTION:
 *		Save current security level new password.
 *
 * PARAMETERS:
 *		vPassword: New password input
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void CFG_Security_SavePasswd(UINT32  vPassword)
{
	switch (vSecurityLevel)
	{
		case SECURITY_LEVEL_USER_RW:
			/* For User R/W password, the highest bit should always be 0 */
			if (vPassword <= 0x7FFFFFFFUL)
			{
				CFG_SET32(USER_RW_PWD, vPassword);
			}
			break;

		default:
			/* Can't change password */
			break;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_Init
 *
 * DESCRIPTION:
 *		Configuration Security Init.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void CFG_Security_Init(void)
{
	/* Set default password */
	CFG_SET32(PWD_Entry, PASSWD_DEFAULT);

	/* Init password level */
	CFG_Security_UpdateLevel();
}

