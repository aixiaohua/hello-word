/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   cfg_db.h
 *
 * DESCRIPTION:
 *   Config database related.
 *
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#ifndef __CFG_DB_H__
#define __CFG_DB_H__

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_DB_Init
 * DESCRIPTION:
 *      Configuration dataBase init.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void CFG_DB_Init(void);


#endif

