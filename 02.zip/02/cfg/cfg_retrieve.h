/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   cfg_retrieve.h
 *
 * DESCRIPTION:
 *   retrieve all the value based on pages
 *
 * HISTORY:
 *   2017.7.21        Melinda.Lu        Create/Update
 *
 *****************************************************************************/
#ifndef __CFG_RETRIEVE_H__
#define __CFG_RETRIEVE_H__

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_MemSet8
 *
 * DESCRIPTION:
 *      Write 8-bit to config retrieve buffer.
 *
 * PARAMETERS:
 *      vPageId: retrieve page ID
 *      vOffset: retrieve offset
 *      vData: data
 *      vLen: length
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_MemSet8(IN CFG_PAGE_T vPageId, IN UINT8 vOffset, IN UINT8 vData, IN UINT8 vLen);

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_MemSet16
 *
 * DESCRIPTION:
 *      Write 16-bit to config retrieve buffer.
 *
 * PARAMETERS:
 *      vPageId        : retrieve page ID
 *      vOffset        : retrieve offset
 *      vData          : data
 *      vLen           : length
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_MemSet16(IN CFG_PAGE_T vPageId, IN UINT8 vOffset, IN UINT16 vData, IN UINT8 vLen);

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_MemSet32
 *
 * DESCRIPTION:
 *      Write 32-bit to config retrieve buffer.
 *
 * PARAMETERS:
 *      vPageId        : retrieve page ID
 *      vOffset        : retrieve offset
 *      vData          : data
 *      vLen           : length
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_MemSet32(IN CFG_PAGE_T vPageId, IN UINT8 vOffset, IN UINT32 vData, IN UINT8 vLen);

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve_SaveConfig
 *
 * DESCRIPTION:
 *      Save retrieve data.
 *
 * PARAMETERS:
 *      vPageId: retrieve page ID
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve_SaveConfig(IN CFG_PAGE_T vPageId);

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_Retrieve
 *
 * DESCRIPTION:
 *      Retrieve default configuration for a new module
 *
 * PARAMETERS:
 *      vPageId: retrieve page ID
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.21        Melinda.Lu        Create/Update
 *****************************************************************************/
void CFG_Retrieve(void);

#endif

