/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 cfg_security.h
 *
 * DESCRIPTION:
 *	 N/A
 *
 * HISTORY:
 *	 2014.3.17		  Panda.Xiong		 Create/Update
 *
 *****************************************************************************/

#ifndef __CFG_SECURITY_H__
#define __CFG_SECURITY_H__

/* Config security level definition:
 *	-> NORMAL  : Default security level.
 *	-> USER_RO : For customer read-only  User EEPROM fields usage.
 *	-> USER_RW : For customer read/write User EEPROM fields usage.
 *	-> OEM	   : For OEM write vendor fields usage.
 *	-> FACTORY : For factory calibration/debugging usage.
 */
#define PASSWD_DEFAULT				0xFFFFFFFF	/* default power-up password	*/
#define PASSWD_USER_RO				0x00000000	/* user read-only  password 	*/
#define PASSWD_USER_RW				0x00001011	/* user read/write password 	*/
#define PASSWD_OEM					0xCF454D20	/* OEM password 				*/
#define PASSWD_FACTORY				0xFE755D4F	/* factory password 			*/
#define PASSWD_REBOOT				0xF2656274	/* reboot password				*/
#if SECURE_MODE_SUPPORT
#define PASSWD_EnterSecureMode		0xCC4F434B	/* enter secure mode password	*/
#define PASSWD_ExitSecureMode		0xD54E4C43	/* exit  secure mode password	*/
#define PASSWD_EnterDownloadMode	0xF54E4254	/* enter download mode password */
#endif

typedef UINT8 SECURITY_LEVEL_T;
#define SECURITY_LEVEL_NORMAL		0x00		/* for normal user usage	  */
#define SECURITY_LEVEL_USER_RO		0x05		/* for user read-only  usage  */
#define SECURITY_LEVEL_USER_RW		0x10		/* for user read/write usage  */
#define SECURITY_LEVEL_OEM			0x15		/* for OEM usage			  */
#define SECURITY_LEVEL_FACTORY		0x20		/* for factory usage		  */
#define SECURITY_LEVEL_ROOT 		0xFF		/* unused top security level  */

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_GetLevel
 *
 * DESCRIPTION:
 *		Get config security level.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.13		 Panda.Xiong		Create/Update
 *****************************************************************************/
SECURITY_LEVEL_T CFG_Security_GetLevel(void);

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_UpdateLevel
 * DESCRIPTION:
 *		Update config security level.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void CFG_Security_UpdateLevel(void);

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_SavePasswd
 *
 * DESCRIPTION:
 *		Save current security level new password.
 *
 * PARAMETERS:
 *		vPassword: New password input
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void CFG_Security_SavePasswd(UINT32  vPassword);

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Security_Init
 *
 * DESCRIPTION:
 *		Configuration Security Init.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2014.3.17		 Panda.Xiong		Create/Update
 *****************************************************************************/
void CFG_Security_Init(void);

#endif

