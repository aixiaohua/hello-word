/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   cfg.h
 *
 * DESCRIPTION:
 *   config API related.
 *
 *   Note: The configuration is always saved as big-endian,
 *          to strictly follow all MSA.
 *
 * HISTORY:
 *   2014.3.17        Panda.Xiong        Create/Update
 *
 *****************************************************************************/

#ifndef __CFG_H__
#define __CFG_H__

#include "typedef.h"
#include "def_boot.h"
#include "apt_cfg_retrieve.h"
#include "cfg_mem_layout.h"
#include "cfg_mem_map.h"
#include "cfg_retrieve.h"
#include "cfg_security.h"
#include "cfg_db.h"
#include "cfg_image.h"

/* the configuration is always saved as big-endian,
 *  so, if CPU is running at little-endian,
 *   we need to swap all the input/output data;
 *  else, no need to swap.
 */
#ifdef __little_endian__
 /* little-endian */
 #define ENDIAN_SWAP_16(x)      SWAP_16(x)
 #define ENDIAN_SWAP_32(x)      SWAP_32(x)
 #define ENDIAN_SWAP_64(x)      SWAP_64(x)
#else
 /* big-endian */
 #define ENDIAN_SWAP_16(x)      (UINT16)(x)
 #define ENDIAN_SWAP_32(x)      (UINT32)(x)
 #define ENDIAN_SWAP_64(x)      (UINT64)(x)
#endif

#if 1
#define MSA_PAGE_SIZE				0x80
#define MSA_INVALID_DATA			0xAA
#define MSA_PAGE_OFFSET_MSK			(MSA_PAGE_SIZE - 1)
#define MSA_PAGE_OFFSET(vOffset)	((vOffset) & MSA_PAGE_OFFSET_MSK)
#endif

/* configuration name alias */
#if 1
 #define CFG_OFFSET(name)       	I2C_OFFSET(name)
 #define CFG_OFFSET_START(name)     CFG_OFFSET(name)
 #define CFG_OFFSET_END(name)       ((CFG_OFFSET_START(name) + I2C_LEN(name)) - 1)
#endif

#if 1
/* Configuration formatting, stored in RAM */
#define CFG_PAGE_NO_IN_RAM		(((UINT8)CFG_PAGE_IN_RAM_END - (UINT8)CFG_PAGE_IN_RAM_START) + 1)

/*lint ++flb*/
typedef union
{
	UINT32	vPages_U32[CFG_PAGE_NO_IN_RAM][MSA_PAGE_SIZE/4];
	UINT16	vPages_U16[CFG_PAGE_NO_IN_RAM][MSA_PAGE_SIZE/2];
	UINT8	vPages_U8[CFG_PAGE_NO_IN_RAM][MSA_PAGE_SIZE];
} CFG_PAGE_IN_RAM_T;
/*lint --flb*/

extern CFG_PAGE_IN_RAM_T				aCfgInRamBuf;

#endif

#if 1
/* Configuration formatting, stored in Flash */
#define CFG_PAGE_NO_PER_FLASH_PAGE		(FLASH_PAGE_SIZE/MSA_PAGE_SIZE)

/* aligned to 8 pages per block */
#define CFG_PAGE_NO_IN_FLASH			((((((UINT8)CFG_PAGE_IN_FLASH_END - (UINT8)CFG_PAGE_IN_FLASH_START) + 1)   \
											  + (CFG_PAGE_NO_PER_FLASH_PAGE-1)) / CFG_PAGE_NO_PER_FLASH_PAGE) 	 \
											 * CFG_PAGE_NO_PER_FLASH_PAGE)


/*lint ++flb*/
typedef struct
{
	UINT8	vPages[CFG_PAGE_NO_IN_FLASH][MSA_PAGE_SIZE];
} CFG_PAGE_IN_FLASH_T;
/*lint --flb*/

#define GET_PAGE_ADDR_IN_FLASH(page_id)	((UINT8 *)(CONFIG_BASE + MSA_PAGE_SIZE*GET_FLASH_PAGE_ID(page_id)))
#endif

/* configuration operation API */
#if 1

/******************************************************************************
 * 8-bit operation:
 ******************************************************************************/
UINT8  CFG_Memget8(IN CFG_PAGE_T vPage, IN UINT8 vOffset);
void   CFG_Memset8(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT8 vData);
void   CFG_Memdmp8(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT8 *pBuf, IN UINT8 vLen);
void   CFG_Memcpy8(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT8 *pBuf, IN UINT8 vLen);

/* access 8-bit data, based on name and offset of this name */
#define CFG_GETO8(name, off)               CFG_Memget8(CFG_PAGE(name), (UINT8)((name)+(off)))
#define CFG_SETO8(name, off, val)          CFG_Memset8(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT8)(val))

/* access 8-bit data, based on the actual offset of this input page */
#define CFG_GETV8(page, off)               CFG_Memget8((CFG_PAGE_T)(page), (UINT8)(off))
#define CFG_SETV8(page, off, val)          CFG_Memset8((CFG_PAGE_T)(page), (UINT8)(off), (UINT8)(val))

/* access bulk 8-bit data, based on name and offset of this name */
#define CFG_MEMDMPO8(name, off, dst, len)  CFG_Memdmp8(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT8 *)(dst),       (UINT8)(len))
#define CFG_MEMCPYO8(name, off, src, len)  CFG_Memcpy8(CFG_PAGE(name), (UINT8)((name)+(off)), (const UINT8 *)(src), (UINT8)(len))

/* access 8-bit data, based on directly */
#define CFG_GET8(name)                     CFG_GETO8(name, 0)
#define CFG_SET8(name, val)                CFG_SETO8(name, 0, (val))

/* access bulk 8-bit data, based on directly */
#define CFG_MEMDMP8(name, dst, len)        CFG_MEMDMPO8(name, 0, (dst), (len))
#define CFG_MEMCPY8(name, src, len)        CFG_MEMCPYO8(name, 0, (src), (len))


/******************************************************************************
 * 16-bit operation:
 ******************************************************************************/
UINT16 CFG_Memget16(IN CFG_PAGE_T vPage, IN UINT8 vOffset);
void   CFG_Memset16(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT16 vData);
void   CFG_Memdmp16(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT16 *pBuf, IN UINT8 vLen);
void   CFG_Memcpy16(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT16 *pBuf, IN UINT8 vLen);

/* access 16-bit data, based on name and offset of this name */
#define CFG_GETO16(name, off)               CFG_Memget16(CFG_PAGE(name), (UINT8)((name)+(off)))
#define CFG_SETO16(name, off, val)          CFG_Memset16(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT16)(val))

/* access 16-bit data, based on the actual offset of this input page */
#define CFG_GETV16(page, off)               CFG_Memget16((CFG_PAGE_T)(page), (UINT8)(off))
#define CFG_SETV16(page, off, val)          CFG_Memset16((CFG_PAGE_T)(page), (UINT8)(off), (UINT16)(val))

/* access bulk 16-bit data, based on name and offset of this name */
#define CFG_MEMDMPO16(name, off, dst, len)  CFG_Memdmp16(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT16 *)(dst),       (UINT8)(len))
#define CFG_MEMCPYO16(name, off, src, len)  CFG_Memcpy16(CFG_PAGE(name), (UINT8)((name)+(off)), (const UINT16 *)(src), (UINT8)(len))

/* access 16-bit data, based on directly */
#define CFG_GET16(name)                     CFG_GETO16(name, 0)
#define CFG_SET16(name, val)                CFG_SETO16(name, 0, (val))

/* access bulk 16-bit data, based on directly */
#define CFG_MEMDMP16(name, dst, len)        CFG_MEMDMPO16(name, 0, (dst), (len))
#define CFG_MEMCPY16(name, src, len)        CFG_MEMCPYO16(name, 0, (src), (len))


/******************************************************************************
 * 32-bit operation:
 ******************************************************************************/
UINT32 CFG_Memget32(IN CFG_PAGE_T vPage, IN UINT8 vOffset);
void   CFG_Memset32(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT32 vData);
void   CFG_Memdmp32(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT32 *pBuf, IN UINT8 vLen);
void   CFG_Memcpy32(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT32 *pBuf, IN UINT8 vLen);

/* access 32-bit data, based on name and offset of this name */
#define CFG_GETO32(name, off)               CFG_Memget32(CFG_PAGE(name), (UINT8)((name)+(off)))
#define CFG_SETO32(name, off, val)          CFG_Memset32(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT32)(val))

/* access 32-bit data, based on the actual offset of this input page */
#define CFG_GETV32(page, off)               CFG_Memget32((CFG_PAGE_T)(page), (UINT8)(off))
#define CFG_SETV32(page, off, val)          CFG_Memset32((CFG_PAGE_T)(page), (UINT8)(off), (UINT32)(val))

/* access bulk 16-bit data, based on name and offset of this name */
#define CFG_MEMDMPO32(name, off, dst, len)  CFG_Memdmp32(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT32 *)(dst),       (UINT8)(len))
#define CFG_MEMCPYO32(name, off, src, len)  CFG_Memcpy32(CFG_PAGE(name), (UINT8)((name)+(off)), (const UINT32 *)(src), (UINT8)(len))

/* access 32-bit data, based on directly */
#define CFG_GET32(name)                     CFG_GETO32(name, 0)
#define CFG_SET32(name, val)                CFG_SETO32(name, 0, (val))

/* access bulk 32-bit data, based on directly */
#define CFG_MEMDMP32(name, dst, len)        CFG_MEMDMPO32(name, 0, (dst), (len))
#define CFG_MEMCPY32(name, src, len)        CFG_MEMCPYO32(name, 0, (src), (len))


/******************************************************************************
 * 64-bit operation:
 ******************************************************************************/
UINT64 CFG_Memget64(IN CFG_PAGE_T vPage, IN UINT8 vOffset);
void   CFG_Memset64(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT64 vData);
void   CFG_Memdmp64(IN CFG_PAGE_T vPage, IN UINT8 vOffset, OUT UINT64 *pBuf, IN UINT8 vLen);
void   CFG_Memcpy64(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN const UINT64 *pBuf, IN UINT8 vLen);

/* access 64-bit data, based on name and offset of this name */
#define CFG_GETO64(name, off)               CFG_Memget64(CFG_PAGE(name), (UINT8)((name)+(off)))
#define CFG_SETO64(name, off, val)          CFG_Memset64(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT64)(val))

/* access 64-bit data, based on the actual offset of this input page */
#define CFG_GETV64(page, off)               CFG_Memget64((CFG_PAGE_T)(page), (UINT8)(off))
#define CFG_SETV64(page, off, val)          CFG_Memset64((CFG_PAGE_T)(page), (UINT8)(off), (UINT64)(val))

/* access bulk 64-bit data, based on name and offset of this name */
#define CFG_MEMDMPO64(name, off, dst, len)  CFG_Memdmp64(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT64 *)(dst),       (UINT8)(len))
#define CFG_MEMCPYO64(name, off, src, len)  CFG_Memcpy64(CFG_PAGE(name), (UINT8)((name)+(off)), (const UINT64 *)(src), (UINT8)(len))

/* access 64-bit data, based on directly */
#define CFG_GET64(name)                     CFG_GETO64(name, 0)
#define CFG_SET64(name, val)                CFG_SETO64(name, 0, (val))

/* access bulk 64-bit data, based on directly */
#define CFG_MEMDMP64(name, dst, len)        CFG_MEMDMPO64(name, 0, (dst), (len))
#define CFG_MEMCPY64(name, src, len)        CFG_MEMCPYO64(name, 0, (src), (len))


/******************************************************************************
 * bit-field operation:
 ******************************************************************************/
#if 0
#define CFG_GET_BITO(name, off, bit_off)    ((CFG_GETO8(name,(off))                                \
	                                          >> (I2C_BIT(name)+((UINT8)(bit_off)*I2C_LEN(name)))) \
	                                         & GET_MASK(0,I2C_LEN(name)))
#define CFG_SET_BITO(name, off, bit_off, v) do {                                                                                        \
                                                UINT16  _v = (v);                                                                       \
                                                if (CFG_GET_BITO(name,(off),(bit_off)) != (_v))                                         \
                                                {                                                                                       \
                                                    CFG_SETO8(name,                                                                     \
                                                               (off),                                                                   \
                                                               ( (CFG_GETO8(name,(off))                                                 \
                                                                    & ~((GET_MASK(I2C_BIT(name),I2C_LEN(name)))                         \
                                                                         <<((UINT8)(bit_off)*I2C_LEN(name))))                           \
                                                                 | (((_v) & GET_MASK(0,I2C_LEN(name)))                                  \
                                                                    << (I2C_BIT(name)+((UINT8)(bit_off)*I2C_LEN(name)))) ) );           \
                                                }                                                                                       \
                                            } while (0)
#define CFG_GET_BIT(name)                   CFG_GET_BITO(name, 0, 0)
#define CFG_SET_BIT(name, val)              CFG_SET_BITO(name, 0, 0, (val))
#endif
#define CFG_GET_BIT(name)					((CFG_GET8(name) & (UINT8)GET_MASK(I2C_BIT(name),I2C_LEN(name))) >> (UINT8)I2C_BIT(name))
#define CFG_SET_BIT(name, val)				CFG_SET8(name, ( CFG_GET8(name) & (UINT8)(~(GET_MASK(I2C_BIT(name),I2C_LEN(name)))))             \
                                                            | (((UINT8)(val) << (UINT8)I2C_BIT(name))                                        \
                                                               & (UINT8)(GET_MASK(I2C_BIT(name),I2C_LEN(name)))))
/* the length must equal to I2C_LEN(name) */
#define CFG_GET_BITO(name, offset)			((CFG_GET8(name) & (UINT8)GET_MASK(((UINT8)I2C_BIT(name)+(UINT8)(offset)),(UINT8)I2C_LEN(name))) \
	                                           >> ((UINT8)I2C_BIT(name)+(UINT8)(offset)))
#define CFG_SET_BITO(name,  offset, val)	CFG_SET8(name, ( CFG_GET8(name)                                                                  \
                                                             & (UINT8)(~(GET_MASK(((UINT8)I2C_BIT(name)+(UINT8)(offset)),                    \
                                                                                   (UINT8)I2C_LEN(name)))))                                  \
																| (((UINT8)(val) << ((UINT8)I2C_BIT(name)+(UINT8)(offset)))                  \
																   & (UINT8)(GET_MASK(((UINT8)I2C_BIT(name)+(UINT8)(offset)),                \
																                       (UINT8)I2C_LEN(name)))))

/******************************************************************************
 * Data to Config operation:
 ******************************************************************************/
void CFG_Memset(IN CFG_PAGE_T vPage, IN UINT8 vOffset, IN UINT8 vData, IN UINT8 vLen);

/* config to config memcpy */
#define CFG_MEMSETO(name,off,val,len) 		CFG_Memset(CFG_PAGE(name), (UINT8)((name)+(off)), (UINT8)(val), (UINT8)(len))
#define CFG_MEMSET(name, val, len)			CFG_MEMSETO(name, 0, val, len)

/******************************************************************************
 * Config to Config operation:
 ******************************************************************************/
void CFG_Memcpy(IN CFG_PAGE_T vDstPage, IN UINT8 vDstOffset, IN CFG_PAGE_T vSrcPage, IN UINT8 vSrcOffset, IN UINT8 vLen);

/* config to config memcpy */
#define CFG_MEMCPYO(dst,off1,src,off2,len)  CFG_Memcpy(CFG_PAGE(dst), (UINT8)((dst)+(off1)), CFG_PAGE(src), (UINT8)((src)+(off2)), (UINT8)(len))
#define CFG_MEMCPY(dst, src, len)           CFG_MEMCPYO(dst, 0, src, 0, (len))
#endif

#if 1
/******************************************************************************
 * Buffer operation:
 ******************************************************************************/
void CFG_SetBuf(IN CFG_PAGE_T vPageId, IN UINT8 vOffset, IN UINT16 vLen, IN const UINT8 *pDataSrc);
#endif

/* state machine related */
#if 1

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_InitializeState
 * DESCRIPTION:
 *      Configuration Initialize State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.3.17        Panda.Xiong        Create/Update
 *****************************************************************************/
void CFG_InitializeState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      CFG_ResetState
 * DESCRIPTION:
 *      Configuration Reset State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2015.7.31        Panda.Xiong        Create/Update
 *****************************************************************************/
void CFG_ResetState(void);

#endif
#endif

