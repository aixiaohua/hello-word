/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 cfg_image.h
 *
 * DESCRIPTION:
 *	 Image related definition.
 *
 * HISTORY:
 *	 2015.1.19		  Panda.Xiong		  Create/Update
 *
 *****************************************************************************/

#ifndef __CFG_IMAGE_H__
#define __CFG_IMAGE_H__

#if IMAGE_SUPPORT

/* image signature related */
typedef struct
{
	UINT32	vFileClass; 		/* file class		 */
	UINT32	vFileSubclass;		/* file sub-class	 */
	UINT32	vFileAlignedSize;	/* file aligned size */
	UINT32	vFileChecksum;		/* file checksum	 */
	UINT8	aFileRev[8];		/* file revision	 */
	UINT32	vFileContentSize;	/* file content size */
	UINT32	vFileCookie;		/* file cookie		 */
} FILE_SIG_T;

/* file id */
typedef enum
{
	FILE_ID_FW	  = 0,		/* firmware  */
	FILE_ID_MACRO = 1,		/* CDR macro */
	FILE_ID_MAX,
} FILE_ID_T;

/* image information related */
typedef struct
{
	BOOL			  bValid;
	const UINT8 	 *pBase;
	const FILE_SIG_T *pSig;
	const UINT8 	 *pContent;
} FILE_INFO_T;

/* image status */
typedef enum
{
	IMAGE_STATUS_NoImage = 0,
	IMAGE_STATUS_Valid	 = 1,
	IMAGE_STATUS_Bad	 = 2,
} IMAGE_STATUS_T;

/* image id information related */
typedef struct
{
	IMAGE_STATUS_T	vStatus;
	FILE_INFO_T 	aFile[FILE_COUNT];
} IMAGE_INFO_T;

extern IMAGE_INFO_T   vImageInfo;

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Image_GetImageID
 * DESCRIPTION:
 *		Get image id.
 * PARAMETERS:
 *		vFileId: File ID
 * RETURN:
 *		Converted image id.
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.5.25		 Melinda.Lu 		Create/Update
 *****************************************************************************/
UINT32 CFG_Image_GetImageID(IN FILE_ID_T vFileId);

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Image_GetImageVersion
 * DESCRIPTION:
 *		Get image version.
 * PARAMETERS:
 *		vFileId: File ID
 * RETURN:
 *		Converted image version.
 * NOTES:
 *		N/A
 * HISTORY:
 *		2017.5.25		 Melinda.Lu 		Create/Update
 *****************************************************************************/
UINT32 CFG_Image_GetImageVersion(IN FILE_ID_T vFileId);

/******************************************************************************
 * FUNCTION NAME:
 *		CFG_Image_Init
 * DESCRIPTION:
 *		Image init.
 * PARAMETERS:
 *		N/A
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2015.1.19		 Panda.Xiong		 Create/Update
 *****************************************************************************/
void CFG_Image_Init(void);

#endif
#endif

