/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   _stdlib.c
 * DESCRIPTION:
 *   Extended stdlib.
 * HISTORY:
 *   2013.12.23        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "typedef.h"


#if 1

#define NUMBER_OF_DIGITS 16

void _uitoa(unsigned int value, char *string, unsigned char radix)
{
    unsigned char index, i;

    index = NUMBER_OF_DIGITS;
    i = 0;

    do {
        string[--index] = '0' + (value % radix);
        if (string[index] > '9')
            string[index] += 'A' - '9' - 1;
        value /= radix;
    } while (value != 0);

    do {
        string[i++] = string[index++];
    } while (index < NUMBER_OF_DIGITS);

    /* string terminator */
    string[i] = '\0';
}

void _itoa(int value, char *string, unsigned char radix)
{
    if ((value < 0) && (radix == 10))
    {
        *string++ = '-';
        _uitoa(-value, string, radix);
    }
    else
    {
        _uitoa(value, string, radix);
    }
}

void _ftoa(double value, char *string, int digits, char e_notation)
{
    signed int integer;
    signed int decimal;
    signed int multiple;
    signed int exponent = 0;

    if (e_notation)
    {
        double v_tmp = value;

        if (value < 0)
        {
            v_tmp = -v_tmp;
        }

        if (v_tmp >= 10)
        {
            while (v_tmp >= 10)
            {
                v_tmp /= 10;
                exponent++;
            }
        }
        else if (fabs(v_tmp) < 1E-100)
        {
            /* almost equal to 0, do nothing */
        }
        else if (v_tmp < 1)
        {
            while (v_tmp < 1)
            {
                v_tmp *= 10;
                exponent--;
            }
        }

        value = ((value<0)?(-v_tmp):v_tmp);
    }

    /* integer part */
    integer = (signed int)value;
    if ((integer == 0) && (value < 0))
    {
        strcpy(string, "-");
    }
    else
    {
        strcpy(string, "");
    }
    _itoa(integer, string+strlen(string), 10);

    /* float point */
    strcat(string, ".");

    /* decimal part */
    multiple = 1;
    while (digits--)
    {
        multiple *= 10;
    }
    value  -= integer;
    if (value < 0)
    {
        value = -value;
    }
    decimal = (value * multiple *10 +5) /10;
    if (decimal == 0)
    {
        while (multiple != 1)
        {
            strcat(string, "0");
            multiple /= 10;
        }
    }
    else
    {
        for (integer = decimal*10; integer < multiple; integer *= 10)
        {
            strcat(string, "0");
        }
        _uitoa((unsigned int)decimal, string+strlen(string), 10);
    }

    if (e_notation)
    {
        strcat(string, "E");
        if (exponent >= 0)
        {
            strcat(string, "+");
        }
        _itoa(exponent, string+strlen(string), 10);
    }
}

#endif


/* adhoc float related */
#if 1

#define ADHOC_EXP_WIDTH     6
#define ADHOC_MAN_WIDTH     10
#define ADHOC_EXP_MAX       (1U << ADHOC_EXP_WIDTH)
#define ADHOC_EXP_MASK      (ADHOC_EXP_MAX - 1)
#define ADHOC_MAN_MAX       (1U << ADHOC_MAN_WIDTH)
#define ADHOC_MAN_MASK      (ADHOC_MAN_MAX - 1)
#define _adhoc_Exponent(_v) (((UINT16)(_v) >> ADHOC_MAN_WIDTH) & ADHOC_EXP_MASK)
#define _adhoc_Mantissa(_v) ((UINT16)(_v) & ADHOC_MAN_MASK)

UINT64 _adhoc_ToReal(UINT16 v)
{
    return ((UINT64)_adhoc_Mantissa(v) << _adhoc_Exponent(v));
}

UINT16 _adhoc_ToFloat(UINT64 v)
{
    UINT16  _mantissa;
    UINT16  _exponent;

    /* calculate exponent */
    _exponent = 0;
    while (v >= ADHOC_MAN_MAX)
    {
        _exponent++;
        v >>= 1;
    }

    /* calculate mantissa */
    _mantissa = (v & ADHOC_MAN_MASK);

    /* combine exponent & mantissa, to get adhoc float value */
    return ((_exponent << ADHOC_MAN_WIDTH) | _mantissa);
}

/* adhoc float add: v1+v2 */
UINT16 _adhoc_add(UINT16 v1, UINT16 v2)
{
    UINT64  _v1  = _adhoc_ToReal(v1);
    UINT64  _v2  = _adhoc_ToReal(v2);
    UINT64  _val = _v1 + _v2;

    if (_val < _v1)
    {
        /* overflow */
        _val = (UINT64)(~0ULL);
    }

    return _adhoc_ToFloat(_val);
}

/* adhoc float sub: v1-v2 */
UINT16 _adhoc_sub(UINT16 v1, UINT16 v2)
{
    UINT64  _v1  = _adhoc_ToReal(v1);
    UINT64  _v2  = _adhoc_ToReal(v2);
    UINT64  _val = _v1 - _v2;

    if (_val > _v1)
    {
        /* underflow */
        _val = (UINT64)(0);
    }

    return _adhoc_ToFloat(_val);
}

#endif

