/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   _stdlib.h
 * DESCRIPTION:
 *   Extended stdlib.
 * HISTORY:
 *   2013.12.23        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef ___STDLIB_H
#define ___STDLIB_H


#if 1

void _uitoa(unsigned int value, char *string, unsigned char radix);
void _itoa(int value, char *string, unsigned char radix);
void _ftoa(double value, char *string, int digits, char e_notation);

#endif


/* adhoc float related */
#if 1

UINT64  _adhoc_ToReal(UINT16 v);
UINT16  _adhoc_ToFloat(UINT64 v);
UINT16  _adhoc_add(UINT16 v1, UINT16 v2);
UINT16  _adhoc_sub(UINT16 v1, UINT16 v2);

#endif


/* memory allocation related */
#if 1

#define _malloc(_n)     ({                                                      \
                            void *_p = (void *)malloc((int)(_n));               \
                            if ((UINT32)_p == (UINT32)NULL)                     \
                            {                                                   \
                                DBG_LOG_FATAL("malloc %d(B) failed!", (UINT32)(_n));  \
                            }                                                   \
                            memset(_p, 0x0, (UINT32)(_n));                      \
                            _p;                                                 \
                        })
#define _free(_p)       do {                                                    \
                            free(_p);                                           \
                            _p = NULL;                                          \
                        } while (0)

#endif


#endif /* ___STDLIB_H */

