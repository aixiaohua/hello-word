/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   _stdio.h
 * DESCRIPTION:
 *   Extended stdio.
 * HISTORY:
 *   2013.12.23        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef ___STDIO_H
#define ___STDIO_H


#if STDIO_SUPPORT

#define NO_PENDING  (0)
#define PENDING     (-1)

int  _getchar(int pending);
void _putchar(char ch);
void _puts(const char *str);
int  _sprintf(char *buffer, const char *fmt, ...)  __attribute__((format(printf,2,3)));
int  _printf(const char *fmt, ...)                 __attribute__((format(printf,1,2)));
void _usleep(int x);

#define getchar(...)            _getchar(__VA_ARGS__)
#define putchar(...)            _putchar(__VA_ARGS__)
#define puts(...)               _puts(__VA_ARGS__)
#define sprintf(...)            _sprintf(__VA_ARGS__)
#define printf(...)             _printf(__VA_ARGS__)
#define usleep(x)             	_usleep(x)

#else
#define getchar(...)            /* do nothing */
#define putchar(...)            /* do nothing */
#define puts(...)               /* do nothing */
#define sprintf(...)            /* do nothing */
#define printf(...)             /* do nothing */
#define usleep(...)             /* do nothing */
#endif


#endif /* ___STDIO_H */

