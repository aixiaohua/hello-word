/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 app.c
 *
 * DESCRIPTION:
 *	 Application related function
 *
 * HISTORY:
 *	 2018.8.10		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "app.h"

/******************************************************************************
 * FUNCTION NAME:
 *      APP_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_PwrDnState(void)
{
#if APP_ADJ_SUPPORT
	APP_ADJ_HighPowerDownState();
#endif

#if APP_TEC_SUPPORT
	APP_TEC_PwrDnState();
#endif
}

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_ReadyState(void)
{
#if APP_ADJ_SUPPORT
	APP_ADJ_HighPowerState();
#endif
}

/******************************************************************************
 * FUNCTION NAME:
 *      APP_PwrUpState
 *
 * DESCRIPTION:
 *      Pwrup state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_PwrUpState(void)
{
#if APP_TEC_SUPPORT
	APP_TEC_PwrUpState();
#endif

#if APP_ADJ_SUPPORT
	APP_ADJ_HighPowerUpState();
#endif

}

/******************************************************************************
 * FUNCTION NAME:
 *      APP_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_LowPwrState(void)
{
}

/******************************************************************************
 * FUNCTION NAME:
 *      APP_MgmtInit
 *
 * DESCRIPTION:
 *      MgmtInit state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_MgmtInit(void)
{
}

