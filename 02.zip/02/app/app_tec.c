/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   app_tec.c
 *
 * DESCRIPTION:
 *   TEC Related.
 *
 * HISTORY:
 *   2013.6.19        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "alg.h"
#include "app_adj.h"

#if APP_TEC_SUPPORT

#define TEC_ENABLE		HIGH
#define TEC_DISABLE		LOW

#define SWITCH_ON		LOW
#define SWITCH_OFF		HIGH

#if 1
/* Hardware control interface */
#define app_tec_Enable()						DRV_IO_Write(IO(IO_TECEN_OUT), TEC_ENABLE)
#define app_tec_Disable()						DRV_IO_Write(IO(IO_TECEN_OUT), TEC_DISABLE)
#define app_tec_GetState()						DRV_IO_Read(IO(IO_TECEN_OUT))
#define app_tec_SetSW1(bLevel)					DRV_IO_Write(IO(IO_TECSW1_OUT), (bLevel))
#define app_tec_GetSW1()						DRV_IO_Read(IO(IO_TECSW1_OUT))
#define app_tec_SetSW2(bLevel)					DRV_IO_Write(IO(IO_TECSW2_OUT), (bLevel))
#define app_tec_GetSW2()						DRV_IO_Read(IO(IO_TECSW2_OUT))
#define app_tec_SetDAC(vValue)					DRV_DAC_Set(DAC(TECSet), (vValue))
#define app_tec_GetDAC(vBuf)					DRV_DAC_Get(DAC(TECSet), (vBuf))
#define app_tec_GetADC()						((SINT16)DRV_ADC_Get(ADC(ADC_LDTEMP_Coarse)))

typedef enum
{
	TEC_MODE_DISABLE,
	TEC_MODE_ENABLE,
	TEC_MODE_MAINTAIN,
	TEC_MODE_HEAT,
	TEC_MODE_COOL,
	TEC_MODE_ERROR
}TEC_MODE_T;

#endif

static BOOL				bTECBootUp		=	TRUE;
static UINT16			vGetLockCounter	=	0;
static ALG_PID_PARAM_T	vTECPidParam;

#if 1

/******************************************************************************
 * FUNCTION NAME:
 *      aplp_tec_SetEnable
 * DESCRIPTION:
 *      Set TEC Enable/Disable.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2017.8.1        Nolan.Yang         Create/Update
 *****************************************************************************/
static void app_tec_SetEnable(TEC_MODE_T vMode)
{
	switch(vMode)
	{
		case TEC_MODE_DISABLE:
			app_tec_SetSW1(SWITCH_OFF);
			app_tec_SetSW2(SWITCH_OFF);
			app_tec_Disable();
			break;

		case TEC_MODE_ENABLE:
			app_tec_SetSW1(SWITCH_OFF);
			app_tec_SetSW2(SWITCH_OFF);
			app_tec_Enable();
			break;
			
		default:
			break;
	}	
}


/******************************************************************************
 * FUNCTION NAME:
 *      app_tec_SetMode
 *
 * DESCRIPTION:
 *      Set TEC work mode.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.8.1        Nolan.Yang         Create/Update
 *****************************************************************************/
static void app_tec_SetMode(TEC_MODE_T vMode)
{
	switch(vMode)
	{
		case TEC_MODE_MAINTAIN:
			app_tec_SetSW1(SWITCH_OFF);
			app_tec_SetSW2(SWITCH_OFF);
			break;

		case TEC_MODE_HEAT:
			app_tec_SetSW1(SWITCH_ON);
			app_tec_SetSW2(SWITCH_OFF);
			break;

		case TEC_MODE_COOL:
			app_tec_SetSW1(SWITCH_OFF);
			app_tec_SetSW2(SWITCH_ON);
			break;

		default:
			break;
	}
}


/******************************************************************************
 * FUNCTION NAME:
 *      app_tec_GetMode
 *
 * DESCRIPTION:
 *      Get TEC work mode.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.8.1        Nolan.Yang         Create/Update
 *****************************************************************************/
static TEC_MODE_T app_tec_GetMode(void)
{
	TEC_MODE_T vMode;

	if(app_tec_GetState() == TEC_DISABLE)
	{
		vMode = TEC_MODE_DISABLE;
	}
	else if((app_tec_GetSW1() == SWITCH_OFF) &&
			(app_tec_GetSW2() == SWITCH_OFF) &&
			(app_tec_GetState() == TEC_ENABLE))
	{
		vMode = TEC_MODE_MAINTAIN;
	}
	else if((app_tec_GetSW1() == SWITCH_ON) &&
			(app_tec_GetSW2() == SWITCH_OFF) &&
			(app_tec_GetState() == TEC_ENABLE))
	{
		vMode = TEC_MODE_HEAT;
	}
	else if((app_tec_GetSW1() == SWITCH_OFF) &&
			(app_tec_GetSW2() == SWITCH_ON) &&
			(app_tec_GetState() == TEC_ENABLE))
	{
		vMode = TEC_MODE_COOL;
	}
	else
	{
		vMode = TEC_MODE_ERROR;
	}

	return vMode;
}

/******************************************************************************
 * FUNCTION NAME:
 *      app_tec_Init
 *
 * DESCRIPTION:
 *      TEC init.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.04.22        Melinda.Lu         Create/Update
 *****************************************************************************/
static void app_tec_Init(void)
{
	UINT16 vLutVal;

	/* Init PID parameters */
	ALG_PID_Reset(&vTECPidParam);
	vTECPidParam.vKp = (SINT16)CFG_GET16(TEC_PID_Kp);
	vTECPidParam.vKi = (SINT16)CFG_GET16(TEC_PID_Ki);
	vTECPidParam.vKd = (SINT16)CFG_GET16(TEC_PID_Kd);
	vTECPidParam.vKp_ZoomIn = CFG_GET8(TEC_PID_Kp_Zoom);
	vTECPidParam.vKi_ZoomIn = CFG_GET8(TEC_PID_Ki_Zoom);
	vTECPidParam.vKd_ZoomIn = CFG_GET8(TEC_PID_Kd_Zoom);
	vTECPidParam.vInterval	= CFG_GET8(TEC_PID_Interval);

	/* set DACs to init value */
	DRV_DAC_Set(DAC(TECSet),		CFG_GET16(Init_TECSet_Value));

	/* init real-time registers */
	vLutVal = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
								  CFG_PAGE(LUT_LDTEMPSet_0CH),
								  TRUE);
	CFG_SET16(Debug_ADJ_LDTEMPSet_Value, vLutVal);

	CFG_SET16(Debug_ADJ_TECSet_Value,	 CFG_GET16(Init_TECSet_Value));

	/* Set TEC to maintain mode */
	app_tec_SetEnable(TEC_MODE_ENABLE);

	/* Init boot up flag */
	bTECBootUp = TRUE;

	/* Init lock counter */
	vGetLockCounter = 0;

	/* clear real-time status */
	CFG_SET_BIT(Debug_RT_Status_TEC_Ready, FALSE);
}

/******************************************************************************
 * FUNCTION NAME:
 *      app_tec_TECSet_Operate
 *
 * DESCRIPTION:
 *      TECset compensation.
 *
 * PARAMETERS:
 *      vDelta: TECSet output offset
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.04.22        Melinda.Lu         Create/Update
 *****************************************************************************/
static void app_tec_TECSet_Operate(SINT32 vDelta)
{
	SINT32 vNewData;
	SINT32 vTECSetStep;
	UINT16 vRTTECSet, vTECSetMax, vTECSetMin;
	TEC_MODE_T vMode;
	static BOOL bSign = 0;

	if (vDelta == 0)
	{
		/* Do nothing */
		return;
	}

	if(bTECBootUp)
	{
		/* First operation:
		 * if delta > 0, need to cool, IO_TEC_SW1 = 0 && IO_TEC_SW2 = 1;
		 * if delta < 0, need to heat, IO_TEC_SW1 = 1 && IO_TEC_SW2 = 0;
		 */
		bTECBootUp = FALSE;

		if (vDelta > 0)
		{
			/* The current laser temperature is lower than the setpoint: cool */
			app_tec_SetMode(TEC_MODE_COOL);

			/* Set the sign flag, which decide the sign of delta */
			bSign = 0;
		}
		else
		{
			/* The current laser temperature is higher than the setpoint: heat */
			app_tec_SetMode(TEC_MODE_HEAT);

			/* Set the sign flag, which decide the sign of delta */
			bSign = 1;
		}
	}

	/* Get current tec mode */
	vMode = app_tec_GetMode();
	if(	(vMode == TEC_MODE_DISABLE)  ||
		(vMode == TEC_MODE_MAINTAIN) ||
		(vMode == TEC_MODE_ERROR))
	{
		/* Do nothing */
		return;
	}

	if(bSign == 0)
	{
		vDelta = (-1) * vDelta;
	}

	/* TECSet will be changed in step by step mode */
	vTECSetStep = (SINT32)CFG_GET16(TEC_TECSet_Step);
	if(vDelta >= 0)
	{
		if(vDelta > vTECSetStep)
		{
			vDelta = vTECSetStep;
		}
	}
	else
	{
		vTECSetStep = (-1) * vTECSetStep;
		if(vDelta < vTECSetStep)
		{
			vDelta = vTECSetStep;
		}
	}

	/* Calculate the adjustment value output to DAC */
	app_tec_GetDAC(&vRTTECSet);
	vNewData = (SINT32)vRTTECSet + vDelta;

	/* Get TECSet maximum value */
	vTECSetMax = CFG_GET16(TEC_TECSet_Max_Value);

	/* Get TECSet minimum value */
	if(vMode == TEC_MODE_HEAT)
	{
		/* Heat mode */
		vTECSetMin = CFG_GET16(TEC_TECSet_Min_Value_Heat);
	}
	else if(vMode == TEC_MODE_COOL)
	{
		/* Cool mode */
		vTECSetMin = CFG_GET16(TEC_TECSet_Min_Value_Cool);
	}
	else
	{
		/* Do nothing */
	}

	if(vNewData < (SINT32)vTECSetMin)
	{
		vNewData = (SINT32)vTECSetMin;
	}
	else if(vNewData > (SINT32)vTECSetMax)
	{
		/* Reset the TECSet output */
		vNewData = 2 * (SINT32)vTECSetMax - vNewData;

		/* First, shut down the switches to avoid exception */
		app_tec_SetMode(TEC_MODE_MAINTAIN);

		DRV_CPU_DelayUs(10);

		/* Output new state */
		if(vMode == TEC_MODE_HEAT)
		{
			app_tec_SetMode(TEC_MODE_COOL);
		}
		else if(vMode == TEC_MODE_COOL)
		{
			app_tec_SetMode(TEC_MODE_HEAT);
		}
		else
		{
			/* Do nothing. */
		}

		/* Convert the sign */
		bSign = !bSign;
	}
	else
	{
		/* Do nothing */
	}

	/* Limit vNewData to UINT16 */
	if(vNewData < (SINT32)vTECSetMin)
	{
		vNewData = vTECSetMin;
	}
	else if(vNewData > (SINT32)vTECSetMax)
	{
		vNewData = vTECSetMax;
	}

	/* Output the new value to DAC */
	app_tec_SetDAC((UINT16)vNewData);

	/* Record real-time value */
	CFG_SET16(Debug_ADJ_TECSet_Value, (UINT16)vNewData);
}

/******************************************************************************
 * FUNCTION NAME:
 *      app_tec_UpdateTECStatus
 *
 * DESCRIPTION:
 *      Update TEC ready status.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.7.26        Melinda.Lu         Create/Update
 *****************************************************************************/
static void app_tec_UpdateTECStatus(void)
{
	SINT16  vLDTempADC;
	SINT16	vLDTEMPSet;
	UINT16  vABSLDTempError;

	/* Laser Temperature get lock or not */
	if (!CFG_GET_BIT(Debug_RT_Status_TEC_Ready))
	{
		vLDTempADC = (SINT16)CFG_GET16(Debug_RT_LDTEMP_ADC_Value);
		vLDTEMPSet = (SINT16)CFG_GET16(Debug_ADJ_LDTEMPSet_Value);
		if(vLDTEMPSet >= vLDTempADC)
		{
			vABSLDTempError = vLDTEMPSet - vLDTempADC;
		}
		else
		{
			vABSLDTempError = vLDTempADC - vLDTEMPSet;
		}

		if (vABSLDTempError <= CFG_GET16(TEC_LDTEMP_GetLock_Threshold))
		{
			/* lose lock, but need more times' check, to confirm it's stable */
			if (++vGetLockCounter >= CFG_GET16(TEC_LDTEMP_GetLock_Count))
			{
				/* the Laser Temperature is stable & really lose lock */
				CFG_SET_BIT(Debug_RT_Status_TEC_Ready, TRUE);
				vGetLockCounter = 0;
			}
		}
		else
		{
			/* get lock again, reset counter */
			vGetLockCounter = 0;
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      app_tec_TECSet
 *
 * DESCRIPTION:
 *      TECset compensation.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.04.22        Melinda.Lu         Create/Update
 *****************************************************************************/
static void app_tec_TECSet(void)
{
	SINT16 vTargetVal;
	SINT16 vCurrentVal;
	SINT16 vDeltaVal;

	if (!CFG_GET_BIT(Debug_System_Ctrl_TEC_Manual_En))
	{
		/* PID mode */

		/* Get current setpoint */
		if (CFG_GET_BIT(LUT_LDTEMPSet_Dis))
		{
			vTargetVal = (SINT16)CFG_GET16(Debug_ADJ_LDTEMPSet_Value);
		}
		else
		{
			UINT16  vBiasMinVal, vRTBiasVal;
	        UINT8   vChannelEnableCount;
	        SINT16  vPageId;

			vBiasMinVal = CFG_GET16(Init_BIASSet_Min_Value);
			vChannelEnableCount = 0;

	        /* get enabled channel count */
			(void)DRV_DAC_Get(DAC(BIASSet_CH0), &vRTBiasVal);
	        if (vRTBiasVal > vBiasMinVal)
	        {
	            vChannelEnableCount++;
	        }
	        (void)DRV_DAC_Get(DAC(BIASSet_CH1), &vRTBiasVal);
	        if (vRTBiasVal > vBiasMinVal)
	        {
	            vChannelEnableCount++;
	        }
	        (void)DRV_DAC_Get(DAC(BIASSet_CH2), &vRTBiasVal);
	        if (vRTBiasVal > vBiasMinVal)
	        {
	            vChannelEnableCount++;
	        }
	        (void)DRV_DAC_Get(DAC(BIASSet_CH3), &vRTBiasVal);
	        if (vRTBiasVal > vBiasMinVal)
	        {
	            vChannelEnableCount++;
	        }

	        /* according to enabled channel count,
	         * select different TEC LDTemp SetPoint LUT.
	         */
	        switch (vChannelEnableCount)
	        {
	            case 4 : vPageId = CFG_PAGE(LUT_LDTEMPSet_4CH); break;
	            case 3 : vPageId = CFG_PAGE(LUT_LDTEMPSet_3CH); break;
	            case 2 : vPageId = CFG_PAGE(LUT_LDTEMPSet_2CH); break;
	            case 1 : vPageId = CFG_PAGE(LUT_LDTEMPSet_1CH); break;
	            case 0 :
	            default: vPageId = CFG_PAGE(LUT_LDTEMPSet_0CH); break;
	        }

			vTargetVal = (SINT16)APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
											 vPageId,
											 TRUE);

			CFG_SET16(Debug_ADJ_LDTEMPSet_Value, (UINT16)vTargetVal);
		}

		/* Get real-time laser temperature */
		vCurrentVal = (SINT16)DRV_ADC_Get(ADC(ADC_LDTEMP_Coarse));

		/* Do PID compensation */
		vDeltaVal = ALG_PID_Incremental(vTargetVal, vCurrentVal, &vTECPidParam);
		app_tec_TECSet_Operate(vDeltaVal);
	}
	else
	{
		/* Debug mode */
		BOOL bSW1, bSW2;

		if (!CFG_GET_BIT(Debug_RT_IO_Mode))
		{
			/* Debug_RT_IO works in status mode */
			return;
		}

		bSW1 = CFG_GET_BIT(Debug_RT_IO_TECSW1_OUT);
		bSW2 = CFG_GET_BIT(Debug_RT_IO_TECSW2_OUT);

		if ((bSW1 == SWITCH_ON) && (bSW2 == SWITCH_ON))
		{
			/* If both IO_TEC_SW1 and IO_TEC_SW2 are on,
			 * do nothing;
			 */
			return;
		}

		if ((bSW1 == app_tec_GetSW1()) && (bSW2 == app_tec_GetSW2()))
		{
			/* If switches are not changed, only output TECSet */
			app_tec_SetDAC(CFG_GET16(Debug_ADJ_TECSet_Value));
			return;
		}

		/* Switch IO_TEC_SW1 & IO_TEC_SW2*/

		/* Turn-off IO_TEC_SW1 & IO_TEC_SW2 first */
		app_tec_SetSW1(SWITCH_OFF);
		app_tec_SetSW2(SWITCH_OFF);

		/* Add 1us delay before switch IO_TEC_SW1 & IO_TEC_SW2 */
		DRV_CPU_DelayUs(1);

		/* Switch IO output */
		app_tec_SetSW1(bSW1);
		app_tec_SetSW2(bSW2);


		/* Output TECSet value */
		app_tec_SetDAC(CFG_GET16(Debug_ADJ_TECSet_Value));
	}
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APP_TEC_Timer
 *
 * DESCRIPTION:
 *      TEC Timer.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2013.6.19        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_TEC_Timer(void)
{
	/* Do TEC related operations */

	/* TECSet compensation */
	app_tec_TECSet();

	/* Update TEC status */
	app_tec_UpdateTECStatus();
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APP_TEC_PwrDnState
 *
 * DESCRIPTION:
 *      N/A
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.8.27        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_TEC_PwrDnState(void)
{
	UINT16 vLutVal;

#if DRV_TIMER_SUPPORT
	/* disable TEC Control Timer */
	DRV_Timer_SetState(TIMER(Timer_TEC), DISABLE);
#endif

	/* Set TEC to maintain mode */
	app_tec_SetEnable(TEC_MODE_DISABLE);

	/* reset boot up flag */
	bTECBootUp = FALSE;

	/* set DACs to init value */
	DRV_DAC_Set(DAC(TECSet), CFG_GET16(Init_TECSet_Value));

	/* init real-time registers */
	vLutVal = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
								  CFG_PAGE(LUT_LDTEMPSet_0CH),
								  TRUE);
	CFG_SET16(Debug_ADJ_LDTEMPSet_Value, vLutVal);
	CFG_SET16(Debug_ADJ_TECSet_Value, CFG_GET16(Init_TECSet_Value));

	/* clear real-time status */
	CFG_SET_BIT(Debug_RT_Status_TEC_Ready, FALSE);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APP_TEC_PwrUpState
 *
 * DESCRIPTION:
 *      N/A
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.8.27        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_TEC_PwrUpState(void)
{
	/* TEC initialization */
	app_tec_Init();

	#if DRV_TIMER_SUPPORT
	/* enable TEC Control Timer */
	DRV_Timer_SetState(TIMER(Timer_TEC), ENABLE);
	#endif
}
#endif
#endif

