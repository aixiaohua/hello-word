/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   app_tec.h
 *
 * DESCRIPTION:
 *   TEC compensation.
 *
 * HISTORY:
 *   2013.6.19        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __APP_TEC_H__
#define __APP_TEC_H__


#if APP_TEC_SUPPORT

#define APL_TEC_TIMER_INTERVAL      20   /* ms */

/******************************************************************************
 * FUNCTION NAME:
 *      APP_TEC_Timer
 * DESCRIPTION:
 *      TEC Timer.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.19        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_TEC_Timer(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APP_TEC_PwrDnState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.8.27        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_TEC_PwrDnState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APP_TEC_PwrUpState
 * DESCRIPTION:
 *      N/A
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2014.8.27        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_TEC_PwrUpState(void);

#endif
#endif

