/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   apl_adj.c
 * DESCRIPTION:
 *   Adjust compensation.
 * HISTORY:
 *   2013.6.19        Panda.Xiong         Create/Update
 *
 *****************************************************************************/
#include "cfg.h"
#include "drv.h"
#include "app_adj.h"
#include "alg.h"

#if APP_ADJ_SUPPORT

#define RXLOS_Hysteresis_LUT_Offset (MSA_PAGE_SIZE / 2)	/* offset of LUT_RXLOSHysteresis */
static ALG_PID_PARAM_T vAPCPidParam[SYSTEM_CHANNEL_NUM];
static BOOL bAdjBootupFlag = TRUE;

#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APP_ADJ_GetLUTValue
 * DESCRIPTION:
 *      Get LUT value.
 * PARAMETERS:
 *      vTempSrc: Temperature Source;
 *      vPageId : LUT Config Page ID;
 *      bSmooth : =TRUE, use "linear interpolation" to smooth LUT value;
 *                =FALSE, skip it;
 * RETURN:
 *      LUT Value;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.19        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT16 APP_ADJ_GetLUTValue
(
    IN APP_ADJ_TEMP_SOURCE_T    vTempSrc,
    IN SINT16                   vPageId,
    IN BOOL                     bSmooth
)
{
    UINT8   vLUTIndex;
    SINT32  vCurrentTemp;
    UINT16  vPrevDAC;

    if (vTempSrc == APP_ADJ_TEMP_SOURCE_ChipTemp)
    {
        vLUTIndex    = CFG_GET8(Debug_RT_ChipTEMP_LUTIndex);
        vCurrentTemp = (SINT16)CFG_GET16(Debug_RT_ChipTEMP);
    }
    else
    {
        vLUTIndex    = CFG_GET8(Debug_RT_LDTEMP_LUTIndex);
        vCurrentTemp = (SINT16)CFG_GET16(Debug_RT_LDTEMP);
    }

	if (vLUTIndex >= LUT_TOTAL_INDEX)
	{
		vLUTIndex--;
	}
    vPrevDAC = CFG_Memget16(vPageId, LUT_INDEX_SIZE * (vLUTIndex+0));

    if (bSmooth)
    {
        UINT16  vNextDAC;
        SINT32  vResult;

        vNextDAC = CFG_Memget16(vPageId, LUT_INDEX_SIZE * (vLUTIndex+1));

        /* add limitation:
         *  if calibrated temperature is out of range,
         *  force returning the LUT value at the bound.
         */
        if (vCurrentTemp < LUT_TEMP_LOW_LIMIT)
        {
            vCurrentTemp = LUT_TEMP_LOW_LIMIT;
        }
        else if (vCurrentTemp > LUT_TEMP_HIGH_LIMIT)
        {
            vCurrentTemp = LUT_TEMP_HIGH_LIMIT;
        }

        /* calculate delta temperature */
        vResult = vCurrentTemp - (vLUTIndex*LUT_TEMP_STEP + LUT_TEMP_LOW_LIMIT);

        /* use "linear interpolation",
         * to calculate target LUT set-point value.
         */
        vResult = (SINT32)vPrevDAC
                  + (((vResult*2*((SINT32)vNextDAC - (SINT32)vPrevDAC))
                        /LUT_TEMP_STEP)+1)/2;

        return (UINT16)vResult;
    }
    else
    {
        return vPrevDAC;
    }
}


/******************************************************************************
 * FUNCTION NAME:
 *      APP_ADJ_GetSLALUTValue
 * DESCRIPTION:
 *      Get SLASet LUT value.
 * PARAMETERS:
 *      vPageId : LUT Config Page ID;
 * RETURN:
 *      LUT Value;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.19        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT8 APP_ADJ_GetSLALUTValue(IN SINT16  vPageId)
{
    UINT8  vLUTIndex;
    UINT8  vValue;

    vLUTIndex = CFG_GET8(Debug_RT_ChipTEMP_LUTIndex);

	if (vLUTIndex >= LUT_TOTAL_INDEX)
	{
		vLUTIndex--;
	}

    vValue = CFG_Memget8(vPageId, vLUTIndex);

    return vValue;
}
#endif

static void app_adj_SetAllChannel(IN APP_ADJ_SET_CHANNEL_FUNC pFunc)
{
	UINT8 vChIndex;

	for(vChIndex = CHANNEL_0; vChIndex < SYSTEM_CHANNEL_NUM ; vChIndex++)
	{
		pFunc(vChIndex);
	}
}

#if APP_ADJ_SUPPORT

#if 1
static void app_adj_FastStepOut(UINT8 vSrc, UINT8 vChannel, UINT16 vRTVal, UINT16 vSetPoint)
{
	if (vSetPoint == 0x0000)
	{
		DRV_DAC_Set(vSrc, vChannel, 0x0000);
	}
	else
	{
		/* use weight algorithm for smooth compensation, to protect LD */
	    while (vRTVal != vSetPoint)
	    {
	        /* do weight algorithm calculating */
	        vRTVal =ALG_Weighted_GetValue(vRTVal, vSetPoint, 50);

			DRV_DAC_Set(vSrc, vChannel, vRTVal);
	    }
	}
}

static void app_adj_BIASSet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aBIASLUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_BIASSet_CH1),
		CFG_PAGE(LUT_BIASSet_CH2),
		CFG_PAGE(LUT_BIASSet_CH3),
		CFG_PAGE(LUT_BIASSet_CH4),
	};

	UINT16 vSetpoint;
	UINT16 vRTVal;
	UINT16 vMaxValue;

	#if 1
	BOOL bTxDis;
	BOOL bTxDisFallEdge = FALSE;
	static BOOL aPreTxDis[SYSTEM_CHANNEL_NUM] = {TRUE, TRUE, TRUE, TRUE};

	/* get software TXDIS state */
	bTxDis  = !CFG_GET_BIT(Debug_RT_Status_TEC_Ready);
	bTxDis |= CFG_GET_BITO(Debug_RT_Status_SWTXDIS_CH1, vChannel);

	if (!bTxDis && aPreTxDis[vChannel])
	{
		/* detect falling edge of TXDIS */
		bTxDisFallEdge = TRUE;
	}
	aPreTxDis[vChannel] = bTxDis;
	#endif

	if (bTxDis)
	{
		/* TX disabled, force no DAC output */
		vSetpoint = 0x0000;
		CFG_SETO16(Debug_ADJ_BIASSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_BIASSet_Value_CH1), vSetpoint);
	}
	else
	{
		if ((bTxDisFallEdge) || CFG_GET_BIT(PID_Ctrl_APC_PID_Dis))
		{
			/* TxDisable falling edge, do one time open-loop compensation to turn on TX fast */
			if (CFG_GET_BITO(LUT_BIASSet_CH1_Dis, (vChannel*I2C_LEN(LUT_BIASSet_CH1_Dis))))
			{
				/* manual mode */
				vSetpoint = CFG_GETO16(Debug_ADJ_BIASSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_BIASSet_Value_CH1));
			}
			else
			{
				/* LUT mode */

				/* use Laser Temperature to get LUT value */
				vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
												aBIASLUTPage[vChannel],
												TRUE);

				/* record current LUT value */
				CFG_SETO16(Debug_ADJ_BIASSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_BIASSet_Value_CH1), vSetpoint);
			}
		}
		else
		{
			/* APC-PID-Mode */
			UINT16 vTargetVal, vCurrentVal;
			SINT16 vDeltaVal;

			vTargetVal  = CFG_GETO16(APC_PID_Setpoint_CH1, vChannel*I2C_LEN(APC_PID_Setpoint_CH1));
			vCurrentVal = CFG_GETO16(Debug_RT_TXPWR_ADC_Value_CH1, vChannel*I2C_LEN(Debug_RT_TXPWR_ADC_Value_CH1));

			vDeltaVal = ALG_PID_Incremental(vTargetVal, vCurrentVal, &vAPCPidParam[vChannel]);
			vSetpoint = LIMIT_U16(
			            (SINT32)CFG_GETO16(Debug_ADJ_BIASSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_BIASSet_Value_CH1))
				        + (SINT32)vDeltaVal);

			CFG_SETO16(Debug_ADJ_BIASSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_BIASSet_Value_CH1), vSetpoint);
		}
	}

	vMaxValue = CFG_GET16(Init_BIASSet_Max_Value);
	if (vSetpoint > vMaxValue)
	{
		vSetpoint = vMaxValue;
	}

	switch(vChannel)
	{
		case CHANNEL_0:
			(void)DRV_DAC_Get(DAC(BIASSet_CH0), &vRTVal);
			app_adj_FastStepOut(DAC(BIASSet_CH0), vRTVal, vSetpoint);
			break;

		case CHANNEL_1:
			(void)DRV_DAC_Get(DAC(BIASSet_CH1), &vRTVal);
			app_adj_FastStepOut(DAC(BIASSet_CH1), vRTVal, vSetpoint);
			break;

		case CHANNEL_2:
			(void)DRV_DAC_Get(DAC(BIASSet_CH2), &vRTVal);
			app_adj_FastStepOut(DAC(BIASSet_CH2), vRTVal, vSetpoint);
			break;

		case CHANNEL_3:
			(void)DRV_DAC_Get(DAC(BIASSet_CH3), &vRTVal);
			app_adj_FastStepOut(DAC(BIASSet_CH3), vRTVal, vSetpoint);
			break;

		default:
			break;
	}
}

static void app_adj_EASet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aEALUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_EASet_CH1),
		CFG_PAGE(LUT_EASet_CH2),
		CFG_PAGE(LUT_EASet_CH3),
		CFG_PAGE(LUT_EASet_CH4),
	};

	UINT16 vSetpoint;
	UINT16 vMaxValue;

	if (CFG_GET_BITO(LUT_EASet_CH1_Dis, (vChannel*I2C_LEN(LUT_EASet_CH1_Dis))))
	{
		/* manual mode */
		vSetpoint = CFG_GETO16(Debug_ADJ_EASet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_EASet_Value_CH1));
	}
	else
	{
		/* LUT mode */

		/* use Laser Temperature to get LUT value */
		vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
										aEALUTPage[vChannel],
										TRUE);

		/* record current LUT value */
		CFG_SETO16(Debug_ADJ_EASet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_EASet_Value_CH1), vSetpoint);
	}

	vMaxValue = CFG_GET16(Init_EASet_Max_Value);
	if (vSetpoint > vMaxValue)
	{
		vSetpoint = vMaxValue;
	}

	/* output DAC set-point value */
	switch(vChannel)
	{
		case CHANNEL_0:
			DRV_DAC_Set(DAC(EASet_CH0), vSetpoint);
			break;

		case CHANNEL_1:
			DRV_DAC_Set(DAC(EASet_CH1), vSetpoint);
			break;

		case CHANNEL_2:
			DRV_DAC_Set(DAC(EASet_CH2), vSetpoint);
			break;

		case CHANNEL_3:
			DRV_DAC_Set(DAC(EASet_CH3), vSetpoint);
			break;

		default:
			break;
	}
}

static void app_adj_VGSet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aVGLUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_VGSet_CH1),
		CFG_PAGE(LUT_VGSet_CH2),
		CFG_PAGE(LUT_VGSet_CH3),
		CFG_PAGE(LUT_VGSet_CH4),
	};

	UINT16 vSetpoint;
	UINT16 vMaxValue;

	if (CFG_GET_BITO(LUT_VGSet_CH1_Dis, (vChannel*I2C_LEN(LUT_VGSet_CH1_Dis))))
	{
		/* manual mode */
		vSetpoint = CFG_GETO16(Debug_ADJ_VGSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_VGSet_Value_CH1));
	}
	else
	{
		/* LUT mode */

		/* use Laser Temperature to get LUT value */
		vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aVGLUTPage[vChannel],
			                            TRUE);

		/* record current LUT value */
		CFG_SETO16(Debug_ADJ_VGSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_VGSet_Value_CH1), vSetpoint);
	}

	vMaxValue = CFG_GET16(Init_VGSet_Max_Value);
	if (vSetpoint > vMaxValue)
	{
		vSetpoint = vMaxValue;
	}

	/* output DAC set-point value */
	switch(vChannel)
	{
		case CHANNEL_0:
			DRV_DAC_Set(DAC(VGSet_CH0), vSetpoint);
			break;

		case CHANNEL_1:
			DRV_DAC_Set(DAC(VGSet_CH1), vSetpoint);
			break;

		case CHANNEL_2:
			DRV_DAC_Set(DAC(VGSet_CH2), vSetpoint);
			break;

		case CHANNEL_3:
			DRV_DAC_Set(DAC(VGSet_CH3), vSetpoint);
			break;

		default:
			break;
	}
}

static void app_adj_VCSet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aVCLUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_VCSet_CH1),
		CFG_PAGE(LUT_VCSet_CH2),
		CFG_PAGE(LUT_VCSet_CH3),
		CFG_PAGE(LUT_VCSet_CH4),
	};

	UINT16 vSetpoint;
	UINT16 vMaxValue;

	if (CFG_GET_BITO(LUT_VCSet_CH1_Dis, (vChannel*I2C_LEN(LUT_VCSet_CH1_Dis))))
	{
		/* manual mode */
		vSetpoint = CFG_GETO16(Debug_ADJ_VCSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_VCSet_Value_CH1));
	}
	else
	{
		/* LUT mode */

		/* use Laser Temperature to get LUT value */
		vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aVCLUTPage[vChannel],
			                            TRUE);

		/* record current LUT value */
		CFG_SETO16(Debug_ADJ_VCSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_VCSet_Value_CH1), vSetpoint);
	}

	vMaxValue = CFG_GET16(Init_VCSet_Max_Value);
	if (vSetpoint > vMaxValue)
	{
		vSetpoint = vMaxValue;
	}

	/* output DAC set-point value */
	switch(vChannel)
	{
		case CHANNEL_0:
			DRV_DAC_Set(DAC(VCSet_CH0), vSetpoint);
			break;

		case CHANNEL_1:
			DRV_DAC_Set(DAC(VCSet_CH1), vSetpoint);
			break;

		case CHANNEL_2:
			DRV_DAC_Set(DAC(VCSet_CH2), vSetpoint);
			break;

		case CHANNEL_3:
			DRV_DAC_Set(DAC(VCSet_CH3), vSetpoint);
			break;

		default:
			break;
	}
}

#if APP_APDPROTECTED_SUPPORT
/******************************************************************************
 * FUNCTION NAME:
 *      app_adj_UpdateAPDMode
 * DESCRIPTION:
 *      Update APD work mode.
 * PARAMETERS:
 *      vLUTIndex
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2018.5.3        Hank.He         Create/Update
 *****************************************************************************/
static void app_adj_UpdateAPDMode(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aHighPTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_RXPWRThresHigh_PT_CH1),
		CFG_PAGE(LUT_RXPWRThresHigh_PT_CH2),
		CFG_PAGE(LUT_RXPWRThresHigh_PT_CH3),
		CFG_PAGE(LUT_RXPWRThresHigh_PT_CH4),
	};

	static __code CFG_PAGE_T aLowPTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_RXPWRThresLow_PT_CH1),
		CFG_PAGE(LUT_RXPWRThresLow_PT_CH2),
		CFG_PAGE(LUT_RXPWRThresLow_PT_CH3),
		CFG_PAGE(LUT_RXPWRThresLow_PT_CH4),
	};

	static __code CFG_PAGE_T aHighPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_RXPWRThresHigh_CH1),
		CFG_PAGE(LUT_RXPWRThresHigh_CH2),
		CFG_PAGE(LUT_RXPWRThresHigh_CH3),
		CFG_PAGE(LUT_RXPWRThresHigh_CH4),
	};

	static __code CFG_PAGE_T aLowPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_RXPWRThresLow_CH1),
		CFG_PAGE(LUT_RXPWRThresLow_CH2),
		CFG_PAGE(LUT_RXPWRThresLow_CH3),
		CFG_PAGE(LUT_RXPWRThresLow_CH4),
	};


	UINT16 vRxPower;
	UINT16 vThresholdHi;
	UINT16 vThresholdLo;
	static BOOL bAPDProtected[SYSTEM_CHANNEL_NUM] = {TRUE,TRUE,TRUE,TRUE};
	static UINT8 vAPDProtectCnt[SYSTEM_CHANNEL_NUM] = {0,0,0,0};
	static UINT8 vAPDReleaseCnt[SYSTEM_CHANNEL_NUM] = {0,0,0,0};

	vRxPower = CFG_GETO16(Debug_RT_RXPWR_ADC_Value_CH1, vChannel*I2C_LEN(Debug_RT_RXPWR_ADC_Value_CH1));

	if (bAPDProtected[vChannel])
	{
		/* get threshold in protected mode */
		vThresholdHi = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aHighPTPage[vChannel],
			                            TRUE);
		vThresholdLo = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aLowPTPage[vChannel],
			                            TRUE);
		/* Judge if exit protected mode or not */
		if ((vRxPower > vThresholdLo) && (vRxPower < vThresholdHi))
		{
			vAPDReleaseCnt[vChannel]++;

			if (vAPDReleaseCnt[vChannel] >= CFG_GET16(RXPWR_Stable_Count))
			{
				vAPDReleaseCnt[vChannel] = 0;
				bAPDProtected[vChannel] = FALSE;
			}
		}
		else
		{
			vAPDReleaseCnt[vChannel] = 0;
		}
	}
	else
	{
		/* get threshold in normal mode */
		vThresholdHi = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aHighPage[vChannel],
			                            TRUE);
		vThresholdLo = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aLowPage[vChannel],
			                            TRUE);

		/* Judge if enter protected mode or not */
		if ((vRxPower < vThresholdLo) || (vRxPower > vThresholdHi))
		{
			vAPDProtectCnt[vChannel]++;

			if (vAPDProtectCnt[vChannel] >= CFG_GET16(RXPWR_Stable_Count))
			{
				vAPDProtectCnt[vChannel] = 0;
				bAPDProtected[vChannel] = TRUE;
			}
		}
		else
		{
			vAPDProtectCnt[vChannel] = 0;
		}
	}

	/* update APD status */
	CFG_SET_BITO(Debug_RT_APD_Protected_CH1, vChannel, bAPDProtected[vChannel]);
}
#endif

static void app_adj_APDSet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aAPDLUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_APDSet_CH1),
		CFG_PAGE(LUT_APDSet_CH2),
		CFG_PAGE(LUT_APDSet_CH3),
		CFG_PAGE(LUT_APDSet_CH4),
	};

	static __code CFG_PAGE_T aAPDLUTPage_PT[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_APDSet_PT_CH1),
		CFG_PAGE(LUT_APDSet_PT_CH2),
		CFG_PAGE(LUT_APDSet_PT_CH3),
		CFG_PAGE(LUT_APDSet_PT_CH4),
	};

	UINT16 vSetpoint;
	UINT16 vMinValue;

	if (CFG_GET_BITO(LUT_APDSet_CH1_Dis, (vChannel*I2C_LEN(LUT_APDSet_CH1_Dis))))
	{
		/* manual mode */
		vSetpoint = CFG_GETO16(Debug_ADJ_APDSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_APDSet_Value_CH1));
	}
	else
	{
		/* LUT mode */
	#if APP_APDPROTECTED_SUPPORT

		app_adj_UpdateAPDMode(vChannel);

		if (CFG_GET_BITO(Debug_RT_APD_Protected_CH1, vChannel))
		{
			/* use Laser Temperature to get LUT value */
			vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
				                            aAPDLUTPage_PT[vChannel],
				                            TRUE);
		}
		else
	#endif
		{

			/* use Laser Temperature to get LUT value */
			vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
				                            aAPDLUTPage[vChannel],
				                            TRUE);
		}

		/* record current LUT value */
		CFG_SETO16(Debug_ADJ_APDSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_APDSet_Value_CH1), vSetpoint);
	}

	vMinValue = CFG_GET16(Init_APDSet_Min_Value);
	if (vSetpoint <= vMinValue)
	{
		vSetpoint = vMinValue;
	}

	/* output DAC set-point value */
	switch(vChannel)
	{
		case 0:
			DRV_DAC_Set(DAC(APDSet_CH0), vSetpoint);
			break;

		case 1:
			DRV_DAC_Set(DAC(APDSet_CH1), vSetpoint);
			break;

		case 2:
			DRV_DAC_Set(DAC(APDSet_CH2), vSetpoint);
			break;

		case 3:
			DRV_DAC_Set(DAC(APDSet_CH3), vSetpoint);
			break;

		default:
			break;
	}
}

static void app_adj_RXLOSThresSet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aLOSThresLUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_LOSThresSet_CH1),
		CFG_PAGE(LUT_LOSThresSet_CH2),
		CFG_PAGE(LUT_LOSThresSet_CH3),
		CFG_PAGE(LUT_LOSThresSet_CH4),
	};

	static __code CFG_PAGE_T aLOSThresLUTPage_PT[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_LOSThresSet_PT_CH1),
		CFG_PAGE(LUT_LOSThresSet_PT_CH2),
		CFG_PAGE(LUT_LOSThresSet_PT_CH3),
		CFG_PAGE(LUT_LOSThresSet_PT_CH4),
	};

	UINT16 vSetpoint;

	if (CFG_GET_BITO(LUT_LOSThresSet_CH1_Dis, (vChannel*I2C_LEN(LUT_LOSThresSet_CH1_Dis))))
	{
		/* manual mode */
		vSetpoint = CFG_GETO16(Debug_ADJ_LOSThresSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_LOSThresSet_Value_CH1));
	}
	else
	{
		/* LUT mode */
	#if APP_APDPROTECTED_SUPPORT

		if (CFG_GET_BITO(Debug_RT_APD_Protected_CH1, vChannel))
		{
			/* use Laser Temperature to get LUT value */
			vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
		                            aLOSThresLUTPage_PT[vChannel],
		                            TRUE);
		}
		else
	#endif
		{
			/* use Laser Temperature to get LUT value */
			vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
		                            aLOSThresLUTPage[vChannel],
		                            TRUE);
		}

		/* record current LUT value */
		CFG_SETO16(Debug_ADJ_LOSThresSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_LOSThresSet_Value_CH1), vSetpoint);
	}

	/* output DAC set-point value */
	switch(vChannel)
	{
		/* for this product, the RX CDR lane is swapped at hardware side,
		 * so, we need to remap it to the correct lane:
		 *
		 *    Fiber  |   CDR
		 *  ---------+---------
		 *   Lane 0  |  Lane 3
		 *   Lane 1  |  Lane 2
		 *   Lane 2  |  Lane 1
		 *   Lane 3  |  Lane 0
		 */
		case 0:
			DRV_DAC_Set(DAC(RXLOSThresSet_CH3), vSetpoint);
			break;

		case 1:
			DRV_DAC_Set(DAC(RXLOSThresSet_CH2), vSetpoint);
			break;

		case 2:
			DRV_DAC_Set(DAC(RXLOSThresSet_CH1), vSetpoint);
			break;

		case 3:
			DRV_DAC_Set(DAC(RXLOSThresSet_CH0), vSetpoint);
			break;

		default:
			break;
	}
}

static void app_adj_RXLOSHystSet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aLOSHystLUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_LOSHystSet_CH1),
		CFG_PAGE(LUT_LOSHystSet_CH2),
		CFG_PAGE(LUT_LOSHystSet_CH3),
		CFG_PAGE(LUT_LOSHystSet_CH4),
	};

	static __code CFG_PAGE_T aLOSThresLUTPage_PT[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_LOSHystSet_PT_CH1),
		CFG_PAGE(LUT_LOSHystSet_PT_CH2),
		CFG_PAGE(LUT_LOSHystSet_PT_CH3),
		CFG_PAGE(LUT_LOSHystSet_PT_CH4),
	};

	UINT16 vSetpoint;

	if (CFG_GET_BITO(LUT_LOSHystSet_CH1_Dis, (vChannel*I2C_LEN(LUT_LOSHystSet_CH1_Dis))))
	{
		/* manual mode */
		vSetpoint = CFG_GETO16(Debug_ADJ_LOSHystSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_LOSHystSet_Value_CH1));
	}
	else
	{
		/* LUT mode */

	#if APP_APDPROTECTED_SUPPORT

		if (CFG_GET_BITO(Debug_RT_APD_Protected_CH1, vChannel))
		{
			/* use Laser Temperature to get LUT value */
			vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aLOSThresLUTPage_PT[vChannel],
			                            TRUE);
		}
		else
	#endif
		{
			/* use Laser Temperature to get LUT value */
			vSetpoint = APP_ADJ_GetLUTValue(APP_ADJ_TEMP_SOURCE_ChipTemp,
			                            aLOSHystLUTPage[vChannel],
			                            TRUE);
		}

		/* record current LUT value */
		CFG_SETO16(Debug_ADJ_LOSHystSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_LOSHystSet_Value_CH1), vSetpoint);
	}

	/* output DAC set-point value */
	switch(vChannel)
	{
		/* for this product, the RX CDR lane is swapped at hardware side,
		 * so, we need to remap it to the correct lane:
		 *
		 *    Fiber  |   CDR
		 *  ---------+---------
		 *   Lane 0  |  Lane 3
		 *   Lane 1  |  Lane 2
		 *   Lane 2  |  Lane 1
		 *   Lane 3  |  Lane 0
		 */
		case 0:
			DRV_DAC_Set(DAC(RXLOSHystSet_CH3), vSetpoint);
			break;

		case 1:
			DRV_DAC_Set(DAC(RXLOSHystSet_CH2), vSetpoint);
			break;

		case 2:
			DRV_DAC_Set(DAC(RXLOSHystSet_CH1), vSetpoint);
			break;

		case 3:
			DRV_DAC_Set(DAC(RXLOSHystSet_CH0), vSetpoint);
			break;

		default:
			break;
	}
}

static void app_adj_SLASet(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aSLALUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_SLASet_CH1),
		CFG_PAGE(LUT_SLASet_CH2),
		CFG_PAGE(LUT_SLASet_CH3),
		CFG_PAGE(LUT_SLASet_CH4),
	};

	UINT8 vSetpoint;

	if (CFG_GET_BITO(LUT_SLASet_CH1_Dis, (vChannel*I2C_LEN(LUT_SLASet_CH1_Dis))))
	{
		/* manual mode */
		vSetpoint = CFG_GETO8(Init_GN2104S_RX_SLA_CH1, vChannel*I2C_LEN(Init_GN2104S_RX_SLA_CH1));
	}
	else
	{
		/* LUT mode */

		/* use Chip Temperature to get LUT value */
		vSetpoint = APP_ADJ_GetSLALUTValue(aSLALUTPage[vChannel]);
	}

	/* set Slice Level Adjust value */
	DRV_CDR_GN2104S_SetSliceLevelAdjust(vChannel, vSetpoint);
}

#endif


/******************************************************************************
 * FUNCTION NAME:
 *      APL_ADJ_HighPowerUpState
 * DESCRIPTION:
 *      Adjust High-Power-Up State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_ADJ_HighPowerUpState(void)
{
    UINT8 vLoop;

	bAdjBootupFlag = TRUE;

	/* enable APD */
	DRV_IO_Write(IO(IO_APDEN_OUT), HIGH);

    /* enable LPower_EN */
    DRV_IO_Write(IO(IO_LPowerEN_OUT), HIGH);

#if 1
	/* init adjust registers */
	CFG_SET16(Debug_ADJ_LOSThresSet_Value_CH1, CFG_GET16(Init_GN2104S_RX_Reg_769  )&0x3F);
	CFG_SET16(Debug_ADJ_LOSThresSet_Value_CH2, CFG_GET16(Init_GN2104S_RX_Reg_513)&0x3F);
	CFG_SET16(Debug_ADJ_LOSThresSet_Value_CH3, CFG_GET16(Init_GN2104S_RX_Reg_257)&0x3F);
	CFG_SET16(Debug_ADJ_LOSThresSet_Value_CH4, CFG_GET16(Init_GN2104S_RX_Reg_1)&0x3F);

	CFG_SET16(Debug_ADJ_LOSHystSet_Value_CH1, CFG_GET16(Init_GN2104S_RX_Reg_770  )&0x07);
	CFG_SET16(Debug_ADJ_LOSHystSet_Value_CH2, CFG_GET16(Init_GN2104S_RX_Reg_514)&0x07);
	CFG_SET16(Debug_ADJ_LOSHystSet_Value_CH3, CFG_GET16(Init_GN2104S_RX_Reg_258)&0x07);
	CFG_SET16(Debug_ADJ_LOSHystSet_Value_CH4, CFG_GET16(Init_GN2104S_RX_Reg_2)&0x07);

	CFG_SET16(Debug_ADJ_BIASSet_Value_CH1, CFG_GET16(Init_BIASSet_Value_CH1));
	CFG_SET16(Debug_ADJ_BIASSet_Value_CH2, CFG_GET16(Init_BIASSet_Value_CH2));
	CFG_SET16(Debug_ADJ_BIASSet_Value_CH3, CFG_GET16(Init_BIASSet_Value_CH3));
	CFG_SET16(Debug_ADJ_BIASSet_Value_CH4, CFG_GET16(Init_BIASSet_Value_CH4));

	CFG_SET16(Debug_ADJ_EASet_Value_CH1, CFG_GET16(Init_EASet_Value_CH1));
	CFG_SET16(Debug_ADJ_EASet_Value_CH2, CFG_GET16(Init_EASet_Value_CH2));
	CFG_SET16(Debug_ADJ_EASet_Value_CH3, CFG_GET16(Init_EASet_Value_CH3));
	CFG_SET16(Debug_ADJ_EASet_Value_CH4, CFG_GET16(Init_EASet_Value_CH4));

	CFG_SET16(Debug_ADJ_APDSet_Value_CH1, CFG_GET16(Init_APDSet_Value_CH1));
	CFG_SET16(Debug_ADJ_APDSet_Value_CH2, CFG_GET16(Init_APDSet_Value_CH2));
	CFG_SET16(Debug_ADJ_APDSet_Value_CH3, CFG_GET16(Init_APDSet_Value_CH3));
	CFG_SET16(Debug_ADJ_APDSet_Value_CH4, CFG_GET16(Init_APDSet_Value_CH4));

	CFG_SET16(Debug_ADJ_VGSet_Value_CH1, CFG_GET16(Init_VGSet_Value_CH1));
	CFG_SET16(Debug_ADJ_VGSet_Value_CH2, CFG_GET16(Init_VGSet_Value_CH2));
	CFG_SET16(Debug_ADJ_VGSet_Value_CH3, CFG_GET16(Init_VGSet_Value_CH3));
	CFG_SET16(Debug_ADJ_VGSet_Value_CH4, CFG_GET16(Init_VGSet_Value_CH4));

	CFG_SET16(Debug_ADJ_VCSet_Value_CH1, CFG_GET16(Init_VCSet_Value_CH1));
	CFG_SET16(Debug_ADJ_VCSet_Value_CH2, CFG_GET16(Init_VCSet_Value_CH2));
	CFG_SET16(Debug_ADJ_VCSet_Value_CH3, CFG_GET16(Init_VCSet_Value_CH3));
	CFG_SET16(Debug_ADJ_VCSet_Value_CH4, CFG_GET16(Init_VCSet_Value_CH4));
#endif

	/* Init PID parameters */
	for (vLoop = 0; vLoop < SYSTEM_CHANNEL_NUM; vLoop++)
	{
        ALG_PID_Reset(&vAPCPidParam[vLoop]);
    	vAPCPidParam[vLoop].vKp = (SINT16)CFG_GET16(APC_PID_Kp);
	    vAPCPidParam[vLoop].vKi = (SINT16)CFG_GET16(APC_PID_Ki);
	    vAPCPidParam[vLoop].vKd = (SINT16)CFG_GET16(APC_PID_Kd);
	    vAPCPidParam[vLoop].vKp_ZoomIn = CFG_GET8(APC_PID_Kp_Zoom);
	    vAPCPidParam[vLoop].vKi_ZoomIn = CFG_GET8(APC_PID_Ki_Zoom);
	    vAPCPidParam[vLoop].vKd_ZoomIn = CFG_GET8(APC_PID_Kd_Zoom);
	    vAPCPidParam[vLoop].vInterval  = CFG_GET8(APC_PID_Interval);
	}
}


/******************************************************************************
 * FUNCTION NAME:
 *      APP_ADJ_HighPowerDownState
 * DESCRIPTION:
 *      Adjust High-Power-Down State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_ADJ_HighPowerDownState(void)
{
	/* disable APD */
	DRV_IO_Write(IO(IO_APDEN_OUT), LOW);

	/* disable LPower_EN */
	DRV_IO_Write(IO(IO_LPowerEN_OUT), LOW);

	/* high power down, disable optical output */
	DRV_DAC_Set(DAC(BIASSet_CH0), 0x0000);
	DRV_DAC_Set(DAC(BIASSet_CH1), 0x0000);
	DRV_DAC_Set(DAC(BIASSet_CH2), 0x0000);
	DRV_DAC_Set(DAC(BIASSet_CH3), 0x0000);

	/* high power down, clear the DAC */
	DRV_DAC_Set(DAC(EASet_CH0), 0x0000);
	DRV_DAC_Set(DAC(EASet_CH1), 0x0000);
	DRV_DAC_Set(DAC(EASet_CH2), 0x0000);
	DRV_DAC_Set(DAC(EASet_CH3), 0x0000);

	DRV_DAC_Set(DAC(VGSet_CH0), 0x0000);
	DRV_DAC_Set(DAC(VGSet_CH1), 0x0000);
	DRV_DAC_Set(DAC(VGSet_CH2), 0x0000);
	DRV_DAC_Set(DAC(VGSet_CH3), 0x0000);

	DRV_DAC_Set(DAC(VCSet_CH0), 0x0000);
	DRV_DAC_Set(DAC(VCSet_CH1), 0x0000);
	DRV_DAC_Set(DAC(VCSet_CH2), 0x0000);
	DRV_DAC_Set(DAC(VCSet_CH3), 0x0000);

	CFG_SET16(Debug_ADJ_EASet_Value_CH1, 0x0000);
	CFG_SET16(Debug_ADJ_EASet_Value_CH2, 0x0000);
	CFG_SET16(Debug_ADJ_EASet_Value_CH3, 0x0000);
	CFG_SET16(Debug_ADJ_EASet_Value_CH4, 0x0000);

	CFG_SET16(Debug_ADJ_VGSet_Value_CH1, 0x0000);
	CFG_SET16(Debug_ADJ_VGSet_Value_CH2, 0x0000);
	CFG_SET16(Debug_ADJ_VGSet_Value_CH3, 0x0000);
	CFG_SET16(Debug_ADJ_VGSet_Value_CH4, 0x0000);

	CFG_SET16(Debug_ADJ_VCSet_Value_CH1, 0x0000);
	CFG_SET16(Debug_ADJ_VCSet_Value_CH2, 0x0000);
	CFG_SET16(Debug_ADJ_VCSet_Value_CH3, 0x0000);
	CFG_SET16(Debug_ADJ_VCSet_Value_CH4, 0x0000);

	bAdjBootupFlag = FALSE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      APL_ADJ_HighPowerState
 * DESCRIPTION:
 *      Adjust High-Power State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_ADJ_HighPowerState(void)
{
	static UINT8 vChannel = 0;
	
	/* do EA compensation before BIAS to avoid inrush */
	app_adj_SetAllChannel(app_adj_EASet);

	app_adj_SetAllChannel(app_adj_BIASSet);

	/* do VG and VC compensation after EA and bIAS compensation */
	app_adj_SetAllChannel(app_adj_VGSet);

	app_adj_SetAllChannel(app_adj_VCSet);

	/* do RX compensation */
	app_adj_SetAllChannel(app_adj_APDSet);

	/* do Slice Level Adjust */
	app_adj_SetAllChannel(app_adj_SLASet);

	if (bAdjBootupFlag)
	{
		app_adj_SetAllChannel(app_adj_RXLOSThresSet);

		app_adj_SetAllChannel(app_adj_RXLOSHystSet);

		vChannel = 0;
		bAdjBootupFlag = FALSE;
	}
	else
	{
		/* do RX compensation */
		app_adj_RXLOSThresSet(vChannel);
		app_adj_RXLOSHystSet(vChannel);

		vChannel++;
		if (vChannel >= SYSTEM_CHANNEL_NUM)
		{
			vChannel = 0;
		}
	}
}

#endif


