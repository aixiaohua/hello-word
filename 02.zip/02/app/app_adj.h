/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2050   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   apl_adj.h
 * DESCRIPTION:
 *   Adjust compensation.
 * HISTORY:
 *   2013.6.19        Panda.Xiong         Create/Update
 *
 *****************************************************************************/

#ifndef __APP_ADJ_H
#define __APP_ADJ_H


#if 1

/* for LD Chip compensation */
#define LUT_TEMP_LOW_LIMIT      (-40 * 256L)    /* Celsius degree, -40 * 256 */
#define LUT_TEMP_HIGH_LIMIT     (119 * 256L)    /* Celsius degree, 119 * 256 */
#define LUT_TEMP_STEP           (3   * 256L)    /* Celsius degree,   3 * 256 */

/* total LUT points, and point size */
#define LUT_TOTAL_INDEX                                             \
    ((LUT_TEMP_HIGH_LIMIT-LUT_TEMP_LOW_LIMIT+LUT_TEMP_STEP-1) /LUT_TEMP_STEP)

#define LUT_INDEX_SIZE          (2)         /* LUT index size, 16-bits */


typedef enum
{
    APP_ADJ_TEMP_SOURCE_ChipTemp = 0,
    APP_ADJ_TEMP_SOURCE_LDTemp,
} APP_ADJ_TEMP_SOURCE_T;

typedef void (*APP_ADJ_SET_CHANNEL_FUNC)(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APL_ADJ_GetLUTValue
 * DESCRIPTION:
 *      Get LUT value.
 * PARAMETERS:
 *      vTempSrc: Temperature Source;
 *      vPageId : LUT Config Page ID;
 *      bSmooth : =TRUE, use "linear interpolation" to smooth LUT value;
 *                =FALSE, skip it;
 * RETURN:
 *      LUT Value;
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.19        Panda.Xiong         Create/Update
 *****************************************************************************/
UINT16 APP_ADJ_GetLUTValue
(
    IN APP_ADJ_TEMP_SOURCE_T    vTempSrc,
    IN SINT16                   vPageId,
    IN BOOL                     bSmooth
);

#endif


#if APP_ADJ_SUPPORT

/******************************************************************************
 * FUNCTION NAME:
 *      APL_ADJ_HighPowerUpState
 * DESCRIPTION:
 *      Adjust High-Power-Up State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_ADJ_HighPowerUpState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APP_ADJ_HighPowerDownState
 * DESCRIPTION:
 *      Adjust High-Power-Down State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_ADJ_HighPowerDownState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APL_ADJ_HighPowerState
 * DESCRIPTION:
 *      Adjust High-Power State.
 * PARAMETERS:
 *      N/A
 * RETURN:
 *      N/A
 * NOTES:
 *      N/A
 * HISTORY:
 *      2013.6.18        Panda.Xiong         Create/Update
 *****************************************************************************/
void APP_ADJ_HighPowerState(void);

#endif


#endif /* __APP_ADJ_H */

