/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 app.h
 *
 * DESCRIPTION:
 *	 APP related.
 *
 * HISTORY:
 *	 2018.8.10		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#ifndef __APP_H__
#define __APP_H__

#include "app_adj.h"
#include "app_tec.h"

/******************************************************************************
 * FUNCTION NAME:
 *      APP_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_PwrDnState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      MSA_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APP_PwrUpState
 *
 * DESCRIPTION:
 *      Pwrup state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_PwrUpState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APP_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.10		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_LowPwrState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APP_MgmtInit
 *
 * DESCRIPTION:
 *      MgmtInit state for APP
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APP_MgmtInit(void);

#endif


