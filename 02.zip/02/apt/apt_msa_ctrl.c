/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt_msa_ctrl.c
 *
 * DESCRIPTION:
 *	 MSA ctrl adaption layer
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "drv.h"

#define Rate_Select_25G             0x02
#define Rate_Select_28G             0x03

/* For this product, the RX CDR lane is swapped at hardware side,
 * so, we need to remap it to the correct lane:
 *
 *    Fiber  |   CDR
 *  ---------+---------
 *   Lane 0  |  Lane 3
 *   Lane 1  |  Lane 2
 *   Lane 2  |  Lane 1
 *   Lane 3  |  Lane 0
 */
#define TRAN_RXCDR_CH(_ch)            		(3 - (_ch))

/* CDR LUT related */
#define LUT_RXEMPHSET_SIZE_PER_CHANNEL		(0x10)
#define LUT_RXAMPSET_SIZE_PER_CHANNEL		(0x10)
#define LUT_TXEQSET_SIZE_PER_CHANNEL		(0x10)

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      apt_msa_ctrl_TXRateAutoMode
 *
 * DESCRIPTION:
 *      process the TX rate select auto mode
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2017.10.16        Dennis.Long         Create/Update
 *****************************************************************************/
void apt_msa_ctrl_TXRateAutoMode(void)
{
    UINT8 vLoop;
    UINT8 vRegValue;
    UINT8 vLos;
    UINT8 vLol;
    static UINT8 vState = 0;  /* can be 0/1/2, init is 0 */

    if (CFG_GET_BIT(System_Ctrl_TXRateSelectAutoMode_Dis))
    {
        vState = 0;
        return;
    }

    /* disable the bypass mode */
    for (vLoop = CHANNEL_0; vLoop < SYSTEM_CHANNEL_NUM; vLoop++)
    {
        if (DRV_CDR_MAOM037057_GetCDRBypass(vLoop))
        {
            DRV_CDR_MAOM037057_SetCDRBypass(vLoop, 1);
        }
    }

    /* get LOS/LOL status */
    vRegValue = 0;
    DRV_CDR_MAOM037057_GetLOSL(&vRegValue);
    vLos = (vRegValue & 0x01)
         | ((vRegValue & 0x02) >> 1)
         | ((vRegValue & 0x04) >> 2)
         | ((vRegValue & 0x08) >> 3);
    vLol = ((vRegValue & 0x10) >> 4)
         | ((vRegValue & 0x20) >> 5)
         | ((vRegValue & 0x40) >> 6)
         | ((vRegValue & 0x80) >> 7);

    if (vState == 0)
    {
        /* use "or" to check CH0-CH3 */
        if ((vLol == 1) && (vLos == 0))
        {
            /* LOL status is asserted */
            for (vLoop = CHANNEL_0; vLoop < SYSTEM_CHANNEL_NUM; vLoop++)
            {
                DRV_CDR_MAOM037057_SetRateSelectByChannel(vLoop, 0);
            }
            vState = 1;
        }
        else
        {
            vState = 0;
        }
    }
    else if (vState == 1)
    {
        /* LOL status is asserted, and LOS status not asserted */
        if (vLol == 1)
        {
            if (vLos == 0)
            {
                /* LOS status is not asserted */
                for (vLoop = CHANNEL_0; vLoop < SYSTEM_CHANNEL_NUM; vLoop++)
                {
                    DRV_CDR_MAOM037057_SetRateSelectByChannel(vLoop, 1);
                }
                vState = 2;
            }
            else
            {
                vState = 0;
            }
        }
        else
        {
            /* detection successful */
            vState = 0;
        }
    }
    else if (vState == 2)
    {
        /* LOL status is asserted, and LOS status not asserted */
        if (vLol == 1)
        {
            if (vLos == 0)
            {
                /* LOS status is not asserted */
                for (vLoop = CHANNEL_0; vLoop < SYSTEM_CHANNEL_NUM; vLoop++)
                {
                    DRV_CDR_MAOM037057_SetRateSelectByChannel(vLoop, 0);
                }
                vState = 1;
            }
            else
            {
                vState = 0;
            }
        }
        else
        {
            /* detection successful */
            vState = 0;
        }
    }
    else
    {
        /* do nothing */
    }
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXOutput
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Output.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bDisable: TRUE - Disable RX output
 *              FALSE - Enable RX output
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXOutput(UINT8 vChannel, BOOL bDisable)
{
	DRV_CDR_GN2104S_SetOutputDis(TRAN_RXCDR_CH(vChannel), bDisable);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXOutput
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Output.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXOutput(void)
{
	UINT8 vChannel;
	BOOL  bTxDis;

	/* TX Disable */
	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		/* get TXDIS state:
		 * a. TXDIS = SW_TXDIS | SW_TXFAULT;
		 * b. HW_TXFAULT is handled by CDR;
		 * c. If AOP needs to be disabled when TX squelch is enabled,
		 *    TXDIS = SW_TXDIS | SW_TXFAULT | TXSQ
		 */
		/* software TxDisable */
		bTxDis = CFG_GET_BITO(RT_SW_TXDIS_CH1, vChannel);

		if (!bTxDis && !CFG_GET_BIT(System_Ctrl_TXDISonTXFAULT_Dis))
		{
			/* disable when fault is active */
			bTxDis = CFG_GET_BITO(Debug_RT_Global_SWFault_CH1, vChannel);
		}

		if (!bTxDis
		    && !CFG_GET_BIT(System_Ctrl_TxSqulech_Dis)
			&& !CFG_GET_BITO(TX_SQ_Disable_CH1, vChannel)
			&& !CFG_GET_BIT(System_Ctrl_DisableAOPOnTXSQ_Dis))
		{
			/* disable AOP when TX squelch is enabled */
			bTxDis = CFG_GET_BITO(Debug_RT_TXLOS_CH1, vChannel);
		}

		/* update software TXDIS status */
		CFG_SET_BITO(Debug_RT_Status_SWTXDIS_CH1, vChannel, bTxDis);

		/* update TX state */
		#if 0
		/* do nothing for TX must be disabled by set BIASSet to 0 */
		DRV_CDR_MAOM037057_SetOutputDis(vChannel, bTxDis);
		#endif
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXSquelch
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Sequelch.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bDisable: TRUE - Disable RX Squelch
 *              FALSE - Enable RX Squelch
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXSquelch(UINT8 vChannel, BOOL bDisable)
{
	if (CFG_GET_BIT(System_Ctrl_RxSqulech_Dis))
	{
	    DRV_CDR_GN2104S_SetSquelchDis(TRAN_RXCDR_CH(vChannel), TRUE);
	}
	else
	{
    	DRV_CDR_GN2104S_SetSquelchDis(TRAN_RXCDR_CH(vChannel), bDisable);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXSquelch
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Sequelch.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bDisable: TRUE - Disable TX Squelch
 *              FALSE - Enable TX Squelch
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXSquelch(UINT8 vChannel, BOOL bDisable)
{
	/* Auto mute TX on TXLOS */
	if (CFG_GET_BIT(System_Ctrl_TxSqulech_Dis))
	{
	    DRV_CDR_MAOM037057_SetSquelchDis(vChannel, TRUE);
	}
	else
	{
	    DRV_CDR_MAOM037057_SetSquelchDis(vChannel, bDisable);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXCDRBypass
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX CDR Bypass.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bEnable: TRUE - Enable RX By Pass
 *              FALSE -Disable RX By Pass
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXCDRBypass(UINT8 vChannel, BOOL bEnable)
{
	DRV_CDR_GN2104S_SetCDRBypass(TRAN_RXCDR_CH(vChannel), bEnable);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXCDRBypass
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX CDR Bypass.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bEnable: TRUE - Enable TX By Pass
 *              FALSE -Disable TX By Pass
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXCDRBypass(UINT8 vChannel, BOOL bEnable)
{
	DRV_CDR_MAOM037057_SetCDRBypass(vChannel, bEnable);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXRate
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Rate
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vRate: RX Rate
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXRate(UINT8 vChannel, UINT8 vRate)
{
    NO_WARNING(vChannel);
	NO_WARNING(vRate);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXRate
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Rate
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vRate: TX Rate
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXRate(UINT8 vChannel, UINT8 vRate)
{
    /* If auto mode is setting, manual mode will not work */
    if (!CFG_GET_BIT(System_Ctrl_TXRateSelectAutoMode_Dis))
    {
        return;
    }

	switch (vRate)
	{
		case Rate_Select_28G:
			DRV_CDR_MAOM037057_SetRateSelectByChannel(vChannel, 1);
			break;

		case Rate_Select_25G:
			DRV_CDR_MAOM037057_SetRateSelectByChannel(vChannel, 0);
			break;

		default:
			break;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      ADAPT_MSA_UpdateRXEmphasis
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Emphasis
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vCode: RX Emphasis code
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXEmphasis(UINT8 vChannel, UINT8 vCode)
{
	UINT8 				vData;
	static __code UINT8	aRxEmphTable[] = { 0, 3, 5, 7, 9, 11, 12, 14};

	/* Note: The CDR chip support 4-bits Rx Output De-Emphasis level control,
	 *		 defined in page 52 of "GN2104RX_Data_Sheet_Rev1_Source.pdf";
	 *		 but the SFF-8636 only defines 4-bits for each channel,
	 *		 adjustable in steps of 1dB;
	 *		 so we need to convert the SFF-8636 MSA value into CDR chip value,
	 *		 by aDeEmphasisTable[] or LUT table;
	 */

	if (CFG_GET_BIT(LUT_RXEmphSet_Dis))
	{
		if (vCode >= COUNT_OF(aRxEmphTable))
		{
			/* exceeded range */
			vData = 0xFF;
		}
		else
		{
			vData = aRxEmphTable[vCode];
		}
	}
	else
	{
		/* LUT mode, the format is:
		 * 0x80 - 0x8F: for channel 0
		 * 0x90 - 0x9F: for channel 1
		 * 0xA0 - 0xAF: for channel 2
		 * 0xB0 - 0xBF: for channel 3
		 * so, the start offset for each channel is (channel*0x10).
		 */
		UINT8 vLutIndex;

		vLutIndex = (UINT8)(vChannel*LUT_RXEMPHSET_SIZE_PER_CHANNEL) + vCode;
		vData = CFG_Memget8(CFG_PAGE(LUT_RXEmphSet), vLutIndex);
	}

	if (vData != 0xFF)
	{
		DRV_CDR_GN2104S_SetEmphasis(TRAN_RXCDR_CH(vChannel), vData);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXAmplitude
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Amplitude
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vCode: RX Amplitude code
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXAmplitude(UINT8 vChannel, UINT8 vCode)
{
	UINT8 				vData;
	static __code UINT8	aRxAmpTable[] = { 60, 100, 140, 180 };

	/* Note: The CDR chip support 8-bits Rx Output Amplitude,
     *       adjustable in steps of 5mVppd;
     *       but the SFF-8636 only defines 4-bits for each channel,
     *       according to Arista's customization:
     *        0000b(200-400mVppd)  ->  300mVppd  ->  300/5=60
     *        0001b(300-600mVppd)  ->  500mVppd  ->  500/5=100
     *        0010b(400-800mVppd)  ->  700mVppd  ->  700/5=140
     *        0011b(600-1200mVppd) ->  900mVppd  ->  900/5=180
     *        Others               ->  900mVppd  ->  900/5=180
     */

	if (CFG_GET_BIT(LUT_RXAmpSet_Dis))
	{
		if (vCode >= COUNT_OF(aRxAmpTable))
		{
			/* exceeded range */
			vData = 0xFF;
		}
		else
		{
			vData = aRxAmpTable[vCode];
		}
	}
	else
	{
		/* LUT mode, the format is:
		 * 0x80 - 0x8F: for channel 0
		 * 0x90 - 0x9F: for channel 1
		 * 0xA0 - 0xAF: for channel 2
		 * 0xB0 - 0xBF: for channel 3
		 * so, the start offset for each channel is (channel*0x10).
		 */
		UINT8 vLutIndex;

		vLutIndex = (UINT8)(vChannel*LUT_RXAMPSET_SIZE_PER_CHANNEL) + vCode;
		vData = CFG_Memget8(CFG_PAGE(LUT_RXAmpSet), vLutIndex);
	}

	if (vData != 0xFF)
	{
		DRV_CDR_GN2104S_SetAmplitude(TRAN_RXCDR_CH(vChannel), vData);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXEQ
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX EQ
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vCode: TX EQ code
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXEQ(UINT8 vChannel, UINT8 vCode)
{
	UINT8 				vData;
	static __code UINT8	aTxEqTable[] = {0, 1, 2, 2, 3, 4, 4, 4, 6, 5, 7};

	if (CFG_GET_BIT(LUT_TXEQSet_Dis))
	{
		if (vCode >= (UINT8)COUNT_OF(aTxEqTable))
		{
			/* exceeded range */
			vData = 0xFF;
		}
		else
		{
			vData = aTxEqTable[vCode];
		}
	}
	else
	{
		/* LUT mode, the format is:
		 * 0x80 - 0x8F: for channel 0
		 * 0x90 - 0x9F: for channel 1
		 * 0xA0 - 0xAF: for channel 2
		 * 0xB0 - 0xBF: for channel 3
		 * so, the start offset for each channel is (channel*0x10).
		 */
		UINT8 vLutIndex;

		vLutIndex = (UINT8)(vChannel * LUT_TXEQSET_SIZE_PER_CHANNEL) + vCode;
		vData = CFG_Memget8(CFG_PAGE(LUT_TXEQSet), vLutIndex);
	}

	if (vData != 0xFF)
	{
		DRV_CDR_MAOM037057_SetEqualization(vChannel, vData);
	}
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA CTRL adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_ReadyState(void)
{
	apt_msa_ctrl_TXRateAutoMode();
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_MgmtInit
 *
 * DESCRIPTION:
 *      Management init state for MSA CTRL adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_MgmtInit(void)
{
  	/* Init TX & RX CDR bypass control bits */
	CFG_SET8(RT_Ctrl_5, CFG_GET8(Init_RT_Ctrl_5));

	/* Init RT_Optional_Ctrl_** registers */
	CFG_SET8(RT_Optional_Ctrl_1, CFG_GET8(Init_Optional_Ctrl_1));
	CFG_SET8(RT_Optional_Ctrl_2, CFG_GET8(Init_Optional_Ctrl_2));
	CFG_SET8(RT_Optional_Ctrl_3, CFG_GET8(Init_Optional_Ctrl_3));
	CFG_SET8(RT_Optional_Ctrl_4, CFG_GET8(Init_Optional_Ctrl_4));
	CFG_SET8(RT_Optional_Ctrl_5, CFG_GET8(Init_Optional_Ctrl_5));
	CFG_SET8(RT_Optional_Ctrl_6, CFG_GET8(Init_Optional_Ctrl_6));
	CFG_SET8(RT_Optional_Ctrl_7, CFG_GET8(Init_Optional_Ctrl_7));
	CFG_SET8(RT_Optional_Ctrl_8, CFG_GET8(Init_Optional_Ctrl_8));

	/* Init RX&TX CDR rate select bits */
	CFG_SET8(RT_Ctrl_2, CFG_GET8(Init_RT_Ctrl_2));
	CFG_SET8(RT_Ctrl_3, CFG_GET8(Init_RT_Ctrl_3));

	/* Power control bit */
	if (CFG_GET8(Init_HighPowerClassEn_Value))
	{
		CFG_SET_BIT(RT_HighPowerClass_En, 1);
	}
	else
	{
		CFG_SET_BIT(RT_HighPowerClass_En, 0);
	}
}
#endif
