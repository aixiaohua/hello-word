/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 adapt_msa_ddm.h
 *
 * DESCRIPTION:
 *	 MSA DDM adaption layer
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/
#ifndef __ADAPT_MSA_DDM_H__
#define __ADAPT_MSA_DDM_H__

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetTemp
 *
 * DESCRIPTION:
 *		Get Current Case Temperature value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current Case Temperature value, in unit of 1/256 degree Celsius,
 *		 to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2013.6.18		 Panda.Xiong		 Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetTemp(void);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetVCC
 *
 * DESCRIPTION:
 *		Get VCC value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current Vcc value, in unit of 100uV, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetVCC(void);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetTXBias
 *
 * DESCRIPTION:
 *		Get Tx Bias value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current channel Tx Bias value, in unit of 2uA, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetTXBias(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *		ADAPT_MSA_DDM_GetTxPower
 *
 * DESCRIPTION:
 *		Get Tx Power value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current channel TXPWR value, in unit of 0.1uW, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetTXPWR(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetRXPower
 *
 * DESCRIPTION:
 *		Get Rx Power value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current channel RXPWR value, in unit of 0.1uW, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetRXPower(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_DDM_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA DDM adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_DDM_PwrDnState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_DDM_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA DDm adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_DDM_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_LowPwrState
 *
 * DESCRIPTION:
 *		Low Power state for MSA DDM adaption layer.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_DDM_LowPwrState(void);
#endif

