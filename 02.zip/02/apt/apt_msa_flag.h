/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 adapt_msa_ddm.h
 *
 * DESCRIPTION:
 *	 MSA DDM adaption layer
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/
#ifndef __ADAPT_MSA_FLAGS_H__
#define __ADAPT_MSA_FLAGS_H__

/******************************************************************************
 * FUNCTION NAME:
 *      APL_MSA_GetFlagTXLOL
 *
 * DESCRIPTION:
 *      Get TXLOL flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      TXLOL flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXLOL(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APL_MSA_GetFlagRXLOL
 *
 * DESCRIPTION:
 *      Get Rx LOL flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOL flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetRXLOL(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetRXLOL
 *
 * DESCRIPTION:
 *      Get Rx LOL flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOL flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXLOS(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetRXLOS
 *
 * DESCRIPTION:
 *      Get Rx LOS flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOS flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetRXLOS(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetTXFault
 *
 * DESCRIPTION:
 *      Get Tx fault flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOS flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXFault(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetTXFault
 *
 * DESCRIPTION:
 *      Get Tx fault flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOS flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXEQFault(IN UINT8 vChannel);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetInitComplete
 *
 * DESCRIPTION:
 *      Get init complete flag.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      Init complete flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetInitComplete(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA flags adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_PwrDnState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA flags adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_PwrUpState
 *
 * DESCRIPTION:
 *      Power up state for MSA flags adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_PwrUpState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_LowPwrState
 *
 * DESCRIPTION:
 *      Low power state for MSA flags adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_LowPwrState(void);

#endif

