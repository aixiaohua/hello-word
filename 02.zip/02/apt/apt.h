/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt.h
 *
 * DESCRIPTION:
 *	 Adaption layer header
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#ifndef __APT_H__
#define __APT_H__


/******************************************************************************
 * FUNCTION NAME:
 *      APT_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_PwrDnState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_PwrUpState
 *
 * DESCRIPTION:
 *      Pwrup state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_PwrUpState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_LowPwrState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MgmtInit
 *
 * DESCRIPTION:
 *      MgmtInit state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MgmtInit(void);

#endif

