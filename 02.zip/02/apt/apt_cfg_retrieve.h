/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt_cfg_retrieve.h
 *
 * DESCRIPTION:
 *	 Adaption layer for cfg_retrieve.c
 *
 * HISTORY:
 *	 2018.7.6		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#ifndef __APT_CFG_RETRIEVE_H__
#define __APT_CFG_RETRIEVE_H__

/******************************************************************************
 * FUNCTION NAME:
 *		APT_CFG_Retrieve
 *
 * DESCRIPTION:
 *		Save retrieve data.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.7.21		 Melinda.Lu 	   Create/Update
 *****************************************************************************/
void APT_CFG_Retrieve(void);


#endif

