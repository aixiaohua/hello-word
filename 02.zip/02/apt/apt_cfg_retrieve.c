/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt_cfg_retrieve.c
 *
 * DESCRIPTION:
 *	 Adaption layer for cfg_retrieve.c
 *
 * HISTORY:
 *	 2018.7.6		 Harry.Huang		Create/Update
 *
 *****************************************************************************/

#include "cfg.h"
#include "drv.h"

#define INIT_BIASSET_VALUE					(0x1999)	/* 60mA: DAC = 2^14 * (60mA/150mA) */
#define INIT_VGSET_VALUE					(0x03DD)	/* 0.7V: DAC = 2^12 * (0.7V/2.5V)  */
#define INIT_VCSET_VALUE					(0x0600)	/* 1V  : DAC = 2^12 * (1V  /2.5V)  */
#define INIT_EASET_VALUE					(0x0600)	/* 1.4V: DAC = 2^12 * (1.4V/2.5V) (AD5629R) */
#define INIT_APDSET_VALUE					(0x0FFF)	/* 2.5V: DAC = 2^12 * (2.5V/2.5V) (AD5629R) */
#define INIT_LDTEMPSET_VALUE				(0x31A4)
#define INIT_TECSET_VALUE					(0x0800)
#define INIT_WEIGHTED_VALUE 				(0x0020)

#define INIT_BIASSET_MAX_VALUE				(0xFFFF)
#define INIT_BIASSET_MIN_VALUE				(0x0000)
#define INIT_EASET_MAX_VALUE				(0xFFFF)
#define INIT_APDSET_MIN_VALUE				(0x0000)
#define INIT_VGSET_MAX_VALUE				(0xFFFF)
#define INIT_VCSET_MAX_VALUE				(0xFFFF)

#define INIT_INTERNAL_TEMP_CHIP_SLOPE		(0x00000476)
#define INIT_INTERNAL_TEMP_CHIP_OFFSET		(0xFFFEF36A)
#define INIT_INTERNAL_VCC_SLOPE				(0x00000188)
#define INIT_INTERNAL_VCC_OFFSET			(0x00000000)
#define INIT_INTERNAL_TXBIAS_SLOPE			(0x00000493)
#define INIT_INTERNAL_TXBIAS_OFFSET			(0x00000000)

#define INIT_TECSET_MAX_VALUE				(0x0C00)
#define INIT_TECSET_MIN_VALUE_HEAT			(0x0000)
#define INIT_TECSET_MIN_VALUE_COOL			(0x0000)
#define INIT_TECSET_STEP					(0x0020)
#define INIT_TEC_GETLOCK_COUNT				(0x0020)
#define INIT_TEC_LOSELOCK_COUNT				(0x1194)
#define INIT_TEC_GETLOCK_THRESHOLD			(0x0106)
#define INIT_TEC_LOSELOCK_THRESHOLD			(0x0106)
#define INIT_TEC_PID_KP						(0x0019)
#define INIT_TEC_PID_KI						(0x0002)
#define INIT_TEC_PID_KD						(0x000A)
#define INIT_TEC_PID_KP_ZOOM				(0x0A)
#define INIT_TEC_PID_KI_ZOOM				(0x0A)
#define INIT_TEC_PID_KD_ZOOM				(0x0A)
#define INIT_TEC_PID_INTERVAL				(0x01)

#define INIT_APCSETPOINT_VALUE				(0x0000)
#define INIT_APC_PID_KP						(0x0001)
#define INIT_APC_PID_KI						(0x0001)
#define INIT_APC_PID_KD						(0x0001)
#define INIT_APC_PID_KP_ZOOM				(0x0A)
#define INIT_APC_PID_KI_ZOOM				(0x02)
#define INIT_APC_PID_KD_ZOOM				(0x01)
#define INIT_APC_PID_INTERVAL				(0x01)

#define INIT_SLA_SET_VALUE					(0x84)

#define INIT_BIAS_FAULT_COUNT				(0x0F)



/******************************************************************************
 * FUNCTION NAME:
 *		APT_CFG_Retrieve
 *
 * DESCRIPTION:
 *		Save retrieve data.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.7.21		 Melinda.Lu 	   Create/Update
 *****************************************************************************/
void APT_CFG_Retrieve(void)
{
	/* LUT_SLASet_CHx: A0[3C]-A0[3F] */
	CFG_Retrieve_MemSet8(CFG_PAGE(LUT_SLASet_CH1), CONFIG(LUT_SLASet_CH1), 0x00, MSA_PAGE_SIZE);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_SLASet_CH1));

	CFG_Retrieve_MemSet8(CFG_PAGE(LUT_SLASet_CH2), CONFIG(LUT_SLASet_CH2), 0x00, MSA_PAGE_SIZE);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_SLASet_CH2));

	CFG_Retrieve_MemSet8(CFG_PAGE(LUT_SLASet_CH3), CONFIG(LUT_SLASet_CH3), 0x00, MSA_PAGE_SIZE);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_SLASet_CH3));

	CFG_Retrieve_MemSet8(CFG_PAGE(LUT_SLASet_CH4), CONFIG(LUT_SLASet_CH4), 0x00, MSA_PAGE_SIZE);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_SLASet_CH4));

	/* LUT_LDTEMPSet_xCH: A0[4B]-A0[4F] */
	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_LDTEMPSet_0CH), CONFIG(LUT_LDTEMPSet_0CH), INIT_LDTEMPSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_LDTEMPSet_0CH));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_LDTEMPSet_1CH), CONFIG(LUT_LDTEMPSet_1CH), INIT_LDTEMPSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_LDTEMPSet_1CH));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_LDTEMPSet_2CH), CONFIG(LUT_LDTEMPSet_2CH), INIT_LDTEMPSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_LDTEMPSet_2CH));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_LDTEMPSet_3CH), CONFIG(LUT_LDTEMPSet_3CH), INIT_LDTEMPSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_LDTEMPSet_3CH));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_LDTEMPSet_4CH), CONFIG(LUT_LDTEMPSet_4CH), INIT_LDTEMPSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_LDTEMPSet_4CH));

	/* LUT_APDSet_CHx: A0[58]-A0[5F] */
	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_APDSet_CH1), CONFIG(LUT_APDSet_CH1), INIT_APDSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_APDSet_CH1));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_APDSet_CH2), CONFIG(LUT_APDSet_CH2), INIT_APDSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_APDSet_CH2));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_APDSet_CH3), CONFIG(LUT_APDSet_CH3), INIT_APDSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_APDSet_CH3));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_APDSet_CH4), CONFIG(LUT_APDSet_CH4), INIT_APDSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_APDSet_CH4));

	/* LUT_BIASSet_CHx: A0[60]-A0[63] */
	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_BIASSet_CH1), CONFIG(LUT_BIASSet_CH1), INIT_BIASSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_BIASSet_CH1));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_BIASSet_CH2), CONFIG(LUT_BIASSet_CH2), INIT_BIASSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_BIASSet_CH2));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_BIASSet_CH3), CONFIG(LUT_BIASSet_CH3), INIT_BIASSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_BIASSet_CH3));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_BIASSet_CH4), CONFIG(LUT_BIASSet_CH4), INIT_BIASSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_BIASSet_CH4));

	/* LUT_EASet_CHx: A0[64]-A0[67] */
	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_EASet_CH1), CONFIG(LUT_EASet_CH1), INIT_EASET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_EASet_CH1));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_EASet_CH2), CONFIG(LUT_EASet_CH2), INIT_EASET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_EASet_CH2));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_EASet_CH3), CONFIG(LUT_EASet_CH3), INIT_EASET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_EASet_CH3));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_EASet_CH4), CONFIG(LUT_EASet_CH4), INIT_EASET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_EASet_CH4));

	/* LUT_VGSet_CHx: A0[68]-A0[6B] */
	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VGSet_CH1), CONFIG(LUT_VGSet_CH1), INIT_VGSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VGSet_CH1));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VGSet_CH2), CONFIG(LUT_VGSet_CH2), INIT_VGSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VGSet_CH2));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VGSet_CH3), CONFIG(LUT_VGSet_CH3), INIT_VGSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VGSet_CH3));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VGSet_CH4), CONFIG(LUT_VGSet_CH4), INIT_VGSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VGSet_CH4));

	/* LUT_VCSet_CHx: A0[6C]-A0[6F] */
	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VCSet_CH1), CONFIG(LUT_VCSet_CH1), INIT_VCSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VCSet_CH1));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VCSet_CH2), CONFIG(LUT_VCSet_CH2), INIT_VCSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VCSet_CH2));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VCSet_CH3), CONFIG(LUT_VCSet_CH3), INIT_VCSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VCSet_CH3));

	CFG_Retrieve_MemSet16(CFG_PAGE(LUT_VCSet_CH4), CONFIG(LUT_VCSet_CH4), INIT_VCSET_VALUE, MSA_PAGE_SIZE/2);
	CFG_Retrieve_SaveConfig(CFG_PAGE(LUT_VCSet_CH4));

	/* LUT_ChipTEMP_Calibrate: A0[48] */
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x00,  0x04E1, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x02,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x04,  0xF736, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x06,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x08,  0x9881, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x0A,  0x08F0, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x0C,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x0E,  0xFB1B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x10,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x12,  0x84FD, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x14,  0x0E62, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x16,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x18,  0xFD42, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x1A,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x1C,  0x720A, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x1E,  0x174A, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x20,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x22,  0xFE53, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x24,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x26,  0x62B1, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x28,  0x2528, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x2A,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x2C,  0xFEEC, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x2E,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x30,  0x54BF, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x32,  0x3895, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x34,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x36,  0xFF3B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x38,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x3A,  0x4968, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x3C,  0x4F42, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x3E,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x40,  0xFF57, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x42,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x44,  0x4359, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x46,  0x63F9, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x48,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x4A,  0xFF47, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x4C,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x4E,  0x4847, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x50,  0x726B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x52,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x54,  0xFEF8, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x56,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x58,  0x67A0, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x5A,  0x7A58, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x5C,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x5E,  0xFE20, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x60,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x62,  0xC7F4, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x64,  0x7FFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x66,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x68,  0xFC5E, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x6A,  0x0001, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x48, 0x6C,  0x9EB9, 1);
	CFG_Retrieve_SaveConfig(CFG_PAGE_0xA0_0x48);

	/* LUT_ChipTEMP_Calibrate: A0[49] */
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x00,  0x04E1, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x02,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x04,  0xF736, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x06,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x08,  0x9881, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x0A,  0x08F0, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x0C,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x0E,  0xFB1B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x10,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x12,  0x84FD, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x14,  0x0E62, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x16,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x18,  0xFD42, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x1A,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x1C,  0x720A, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x1E,  0x174A, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x20,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x22,  0xFE53, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x24,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x26,  0x62B1, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x28,  0x2528, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x2A,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x2C,  0xFEEC, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x2E,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x30,  0x54BF, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x32,  0x3895, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x34,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x36,  0xFF3B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x38,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x3A,  0x4968, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x3C,  0x4F42, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x3E,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x40,  0xFF57, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x42,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x44,  0x4359, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x46,  0x63F9, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x48,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x4A,  0xFF47, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x4C,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x4E,  0x4847, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x50,  0x726B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x52,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x54,  0xFEF8, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x56,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x58,  0x67A0, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x5A,  0x7A58, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x5C,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x5E,  0xFE20, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x60,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x62,  0xC7F4, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x64,  0x7FFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x66,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x68,  0xFC5E, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x6A,  0x0001, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x49, 0x6C,  0x9EB9, 1);
	CFG_Retrieve_SaveConfig(CFG_PAGE_0xA0_0x49);

	/* LUT_LDTEMP_Calibrate: A0[4A] */
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x00,  0x2F2B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x02,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x04,  0xFF0B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x06,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x08,  0x6415, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x0A,  0x34D1, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x0C,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x0E,  0xFF1F, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x10,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x12,  0x6066, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x14,  0x3AD3, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x16,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x18,  0xFF2C, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x1A,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x1C,  0x5DA5, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x1E,  0x411F, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x20,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x22,  0xFF35, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x24,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x26,  0x5B83, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x28,  0x4793, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x2A,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x2C,  0xFF3A, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x2E,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x30,  0x5A4D, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x32,  0x4E0E, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x34,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x36,  0xFF3B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x38,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x3A,  0x5A35, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x3C,  0x5A8C, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x3E,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x40,  0xFF33, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x42,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x44,  0x5CB8, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x46,  0x658B, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x48,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x4A,  0xFF15, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x4C,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x4E,  0x6730, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x50,  0x6E58, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x52,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x54,  0xFEDA, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x56,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x58,  0x7F12, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x5A,  0x74CB, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x5C,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x5E,  0xFE6C, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x60,  0x0000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x62,  0xAE50, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x64,  0x7AAC, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x66,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x68,  0xFD65, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x6A,  0x0001, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x6C,  0x273C, 1);

	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x64,  0x7FFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x66,  0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x68,  0xFAA2, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x6A,  0x0002, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x4A, 0x6C,  0x7AB1, 1);
	CFG_Retrieve_SaveConfig(CFG_PAGE_0xA0_0x4A);

	/* A0[70] */
	CFG_Retrieve_MemSet32(CFG_PAGE_0xA0_0x70, CONFIG(Internal_TEMP_Chip_Slope),  INIT_INTERNAL_TEMP_CHIP_SLOPE, 1);
	CFG_Retrieve_MemSet32(CFG_PAGE_0xA0_0x70, CONFIG(Internal_TEMP_Chip_Offset), INIT_INTERNAL_TEMP_CHIP_OFFSET, 1);
	CFG_Retrieve_MemSet32(CFG_PAGE_0xA0_0x70, CONFIG(Internal_TXBIAS_Slope), INIT_INTERNAL_TXBIAS_SLOPE, 1);
	CFG_Retrieve_MemSet32(CFG_PAGE_0xA0_0x70, CONFIG(Internal_TXBIAS_Offset), INIT_INTERNAL_TXBIAS_OFFSET, 1);
	CFG_Retrieve_MemSet32(CFG_PAGE_0xA0_0x70, CONFIG(Internal_VCC_Slope), INIT_INTERNAL_VCC_SLOPE, 1);
	CFG_Retrieve_MemSet32(CFG_PAGE_0xA0_0x70, CONFIG(Internal_VCC_Offset), INIT_INTERNAL_VCC_OFFSET, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_LDTEMP_LoseLock_Count), INIT_TEC_LOSELOCK_COUNT, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_LDTEMP_GetLock_Count), INIT_TEC_GETLOCK_COUNT, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_LDTEMP_LoseLock_Threshold), INIT_TEC_LOSELOCK_THRESHOLD, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_LDTEMP_GetLock_Threshold), INIT_TEC_GETLOCK_THRESHOLD, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_LDTEMPSet_Value), INIT_LDTEMPSET_VALUE, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_PID_Kp), INIT_TEC_PID_KP, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_PID_Ki), INIT_TEC_PID_KI, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_PID_Kd), INIT_TEC_PID_KD, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(TEC_PID_Kp_Zoom), INIT_TEC_PID_KP_ZOOM, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(TEC_PID_Ki_Zoom), INIT_TEC_PID_KI_ZOOM, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(TEC_PID_Kd_Zoom), INIT_TEC_PID_KD_ZOOM, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(TEC_PID_Interval), INIT_TEC_PID_INTERVAL, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_TECSet_Step), INIT_TECSET_STEP, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_TECSet_Max_Value), INIT_TECSET_MAX_VALUE, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_TECSet_Min_Value_Heat), INIT_TECSET_MIN_VALUE_HEAT, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TEC_TECSet_Min_Value_Cool), INIT_TECSET_MIN_VALUE_COOL, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Setpoint_CH1), INIT_APCSETPOINT_VALUE, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Setpoint_CH2), INIT_APCSETPOINT_VALUE, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Setpoint_CH3), INIT_APCSETPOINT_VALUE, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Setpoint_CH4), INIT_APCSETPOINT_VALUE, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(BIAS_FaultCount), 0x0F, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(TXPWR_DDMI_Value_Min), 0x0001, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(RXPWR_DDMI_Value_Min), 0x0001, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Kp), INIT_APC_PID_KP, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Ki), INIT_APC_PID_KI, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Kd), INIT_APC_PID_KD, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Kp_Zoom), INIT_APC_PID_KP_ZOOM, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Ki_Zoom), INIT_APC_PID_KI_ZOOM, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Kd_Zoom), INIT_APC_PID_KD_ZOOM, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(APC_PID_Interval), INIT_APC_PID_INTERVAL, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_RT_Ctrl_5), 0xFF, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_1), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_2), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_3), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_4), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_5), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_6), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_7), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_Optional_Ctrl_8), 0x00, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(Init_HighPowerClassEn_Value), 0xFF, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(CDR_LoadMacro_RetryCount), 0x03, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(System_TEMP_Max), 0x7FFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(System_TEMP_Min), 0x8000, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(System_VCC_Max), 0xFFFF, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x70, CONFIG(System_VCC_Min), 0x0000, 1);
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x70, CONFIG(SecurityLevelMin), SECURITY_LEVEL_NORMAL, 1);
	CFG_Retrieve_MemSet32(CFG_PAGE_0xA0_0x70, CONFIG(USER_RW_PWD), PASSWD_USER_RW, 1);
	CFG_Retrieve_SaveConfig(CFG_PAGE_0xA0_0x70);

	/* A0[72] */
	CFG_Retrieve_MemSet8(CFG_PAGE_0xA0_0x72, CONFIG(Init_GN2104S_RX_SLA_CH1), INIT_SLA_SET_VALUE, SYSTEM_CHANNEL_NUM);
	CFG_Retrieve_SaveConfig(CFG_PAGE_0xA0_0x72);

	/* A0[73] */
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(Init_BIASSet_Value_CH1), INIT_BIASSET_VALUE, SYSTEM_CHANNEL_NUM);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(Init_EASet_Value_CH1), INIT_EASET_VALUE, SYSTEM_CHANNEL_NUM);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(Init_VGSet_Value_CH1), INIT_VGSET_VALUE, SYSTEM_CHANNEL_NUM);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(Init_VCSet_Value_CH1), INIT_VCSET_VALUE, SYSTEM_CHANNEL_NUM);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(Init_APDSet_Value_CH1), INIT_APDSET_VALUE, SYSTEM_CHANNEL_NUM);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(Init_TECSet_Value), INIT_TECSET_VALUE, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(RXPower_Weighted_Value), INIT_WEIGHTED_VALUE, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(TXPWR_DDMI_Threshold), 0x0002, 1);
	CFG_Retrieve_MemSet16(CFG_PAGE_0xA0_0x73, CONFIG(RXPWR_DDMI_Threshold), 0x0002, 1);
	CFG_Retrieve_SaveConfig(CFG_PAGE_0xA0_0x73);
}

