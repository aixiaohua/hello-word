/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt_msa_flag.c
 *
 * DESCRIPTION:
 *	 MSA flag adaption layer
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "alg.h"
#include "app_adj.h"

static UINT8	aBiasFaultCount[SYSTEM_CHANNEL_NUM] = {0, 0, 0, 0};
static UINT16	vTECLoseLockCount = 0;
static UINT16	vTECGetLockCount = 0;

#if 1
/* for this product, the RX CDR lane is swapped at hardware side,
 * so, we need to remap it to the correct lane:
 *
 *    Fiber  |   CDR
 *  ---------+---------
 *   Lane 0  |  Lane 3
 *   Lane 1  |  Lane 2
 *   Lane 2  |  Lane 1
 *   Lane 3  |  Lane 0
 */
#define TRAN_RXCDR_CH(_ch)            (3 - (_ch))

/******************************************************************************
 * FUNCTION NAME:
 *      apt_msa_flag_UpdateTXLOSL
 *
 * DESCRIPTION:
 *      Update internal TX LOS & LOL flags
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
static void apt_msa_flag_UpdateTXLOSL(void)
{
	UINT8 vTxLosl;

	if (!DRV_CDR_MAOM037057_GetLOSL(&vTxLosl))
	{
		/* read failed, do not update */
		return;
	}

	CFG_SET_BIT(Debug_RT_TXLOS_CH1, READ_BIT(vTxLosl, (0)+MAOM037057_LOS_START_BIT));
	CFG_SET_BIT(Debug_RT_TXLOS_CH2, READ_BIT(vTxLosl, (1)+MAOM037057_LOS_START_BIT));
	CFG_SET_BIT(Debug_RT_TXLOS_CH3, READ_BIT(vTxLosl, (2)+MAOM037057_LOS_START_BIT));
	CFG_SET_BIT(Debug_RT_TXLOS_CH4, READ_BIT(vTxLosl, (3)+MAOM037057_LOS_START_BIT));

	CFG_SET_BIT(Debug_RT_TXLOL_CH1, READ_BIT(vTxLosl, (0)+MAOM037057_LOL_START_BIT));
	CFG_SET_BIT(Debug_RT_TXLOL_CH2, READ_BIT(vTxLosl, (1)+MAOM037057_LOL_START_BIT));
	CFG_SET_BIT(Debug_RT_TXLOL_CH3, READ_BIT(vTxLosl, (2)+MAOM037057_LOL_START_BIT));
	CFG_SET_BIT(Debug_RT_TXLOL_CH4, READ_BIT(vTxLosl, (3)+MAOM037057_LOL_START_BIT));
}

/******************************************************************************
 * FUNCTION NAME:
 *      apt_msa_flag_UpdateRXLOSL
 *
 * DESCRIPTION:
 *      Update internal RX LOS & LOL flags
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
static void apt_msa_flag_UpdateRXLOSL(void)
{
	UINT8	vRxLosl;

	if (!DRV_CDR_GN2104S_GetLOSL(&vRxLosl))
	{
		/* read failed, do not update */
		return;
	}

	/* update RXLOL */
	CFG_SET_BIT(Debug_RT_RXLOL_CH1, READ_BIT(vRxLosl, TRAN_RXCDR_CH(0)+GN2104S_LOL_START_BIT));
	CFG_SET_BIT(Debug_RT_RXLOL_CH2, READ_BIT(vRxLosl, TRAN_RXCDR_CH(1)+GN2104S_LOL_START_BIT));
	CFG_SET_BIT(Debug_RT_RXLOL_CH3, READ_BIT(vRxLosl, TRAN_RXCDR_CH(2)+GN2104S_LOL_START_BIT));
	CFG_SET_BIT(Debug_RT_RXLOL_CH4, READ_BIT(vRxLosl, TRAN_RXCDR_CH(3)+GN2104S_LOL_START_BIT));

	/* update RXLOS */
	CFG_SET_BIT(Debug_RT_RXLOS_CH1, READ_BIT(vRxLosl, TRAN_RXCDR_CH(0)+GN2104S_LOS_START_BIT));
	CFG_SET_BIT(Debug_RT_RXLOS_CH2, READ_BIT(vRxLosl, TRAN_RXCDR_CH(1)+GN2104S_LOS_START_BIT));
	CFG_SET_BIT(Debug_RT_RXLOS_CH3, READ_BIT(vRxLosl, TRAN_RXCDR_CH(2)+GN2104S_LOS_START_BIT));
	CFG_SET_BIT(Debug_RT_RXLOS_CH4, READ_BIT(vRxLosl, TRAN_RXCDR_CH(3)+GN2104S_LOS_START_BIT));
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      apt_msa_flag_UpdateBIASFault
 *
 * DESCRIPTION:
 *      Update internal BIAS fault
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
static void apt_msa_flag_UpdateBIASFault(void)
{
	if (CFG_GET_BIT(System_Ctrl_Fault_SourceBias_Dis))
	{
		/* clear BIAS fault status */
		CFG_SET_BIT(Debug_RT_Status_BIASFault_CH1, FALSE);
		CFG_SET_BIT(Debug_RT_Status_BIASFault_CH2, FALSE);
		CFG_SET_BIT(Debug_RT_Status_BIASFault_CH3, FALSE);
		CFG_SET_BIT(Debug_RT_Status_BIASFault_CH4, FALSE);
	}
	else
	{
		UINT8  vChannel;
		UINT16 vBiasThresholdHi;

		vBiasThresholdHi = CFG_GET16(BIAS_Fault_Threshold_Hi);

		for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
		{
			if (CFG_GETO16(RT_TXBIAS_CH1, vChannel*I2C_LEN(RT_TXBIAS_CH1)) > vBiasThresholdHi)
			{
				/* BIAS is beyond limitation,
				 * but need more times' check, to confirm it's stable.
				 */
				if (aBiasFaultCount[vChannel] < CFG_GET8(BIAS_FaultCount))
				{
					aBiasFaultCount[vChannel]++;
				}
				else
				{
					/* BIAS is really beyond limitation */
					CFG_SET_BITO(Debug_RT_Status_BIASFault_CH1, vChannel, TRUE);
				}
			}
			else
			{
				/* BIAS recovers, reset counter */
				aBiasFaultCount[vChannel] = 0;
			}
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      apt_msa_flag_UpdateTECFault
 *
 * DESCRIPTION:
 *      Update internal TEC fault
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
static void apt_msa_flag_UpdateTECFault(void)
{
	UINT16 vLDTempADC;
	UINT16 vABSLDTempError;

	vLDTempADC = CFG_GET16(Debug_RT_LDTEMP_ADC_Value);
	vABSLDTempError = ABS_16((SINT16)CFG_GET16(Debug_ADJ_LDTEMPSet_Value) - (SINT16)vLDTempADC);

	/* Laser Temperature lose lock or not */
	if (vABSLDTempError >= CFG_GET16(TEC_LDTEMP_LoseLock_Threshold))
	{
		/* lose lock, but need more times' check, to confirm it's stable */

		if (++vTECLoseLockCount >= CFG_GET16(TEC_LDTEMP_LoseLock_Count))
		{
			/* the Laser Temperature is stable & really lose lock */
			CFG_SET_BIT(Debug_RT_Status_LDTEMP_LoseLock, TRUE);
			CFG_SET_BIT(Debug_RT_Status_LDTEMP_GetLock, FALSE);
			vTECLoseLockCount = 0;
		}
	}
	else
	{
		/* get lock again, reset counter */
		vTECLoseLockCount = 0;
	}

	/* Laser Temperature get lock or not */
	if (vABSLDTempError <= CFG_GET16(TEC_LDTEMP_GetLock_Threshold))
	{
		/* lose lock, but need more times' check, to confirm it's stable */

		if (++vTECGetLockCount >= CFG_GET16(TEC_LDTEMP_GetLock_Count))
		{
			/* the Laser Temperature is stable & really lose lock */
			CFG_SET_BIT(Debug_RT_Status_LDTEMP_GetLock, TRUE);
			CFG_SET_BIT(Debug_RT_Status_LDTEMP_LoseLock, FALSE);
			vTECGetLockCount = 0;
		}
	}
	else
	{
		/* get lock again, reset counter */
		vTECGetLockCount = 0;
	}

	if (CFG_GET_BIT(System_Ctrl_Fault_SourceTEC_Dis))
	{
		/* clear TEC fault status */
		CFG_SET_BIT(Debug_RT_Status_TECFault_CH1, FALSE);
		CFG_SET_BIT(Debug_RT_Status_TECFault_CH2, FALSE);
		CFG_SET_BIT(Debug_RT_Status_TECFault_CH3, FALSE);
		CFG_SET_BIT(Debug_RT_Status_TECFault_CH4, FALSE);
	}
	else
	{
		if (CFG_GET_BIT(Debug_RT_Status_LDTEMP_LoseLock))
		{
			CFG_SET_BIT(Debug_RT_Status_TECFault_CH1, TRUE);
			CFG_SET_BIT(Debug_RT_Status_TECFault_CH2, TRUE);
			CFG_SET_BIT(Debug_RT_Status_TECFault_CH3, TRUE);
			CFG_SET_BIT(Debug_RT_Status_TECFault_CH4, TRUE);
		}
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      apt_msa_flag_UpdateHWTXFault
 *
 * DESCRIPTION:
 *      Update internal HW TX fault
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
static void apt_msa_flag_UpdateHWTXFault(void)
{
	/* no hardware TxFault, do nothing */
	CFG_SET_BIT(Debug_RT_Global_HWFault_CH1, FALSE);
	CFG_SET_BIT(Debug_RT_Global_HWFault_CH2, FALSE);
	CFG_SET_BIT(Debug_RT_Global_HWFault_CH3, FALSE);
	CFG_SET_BIT(Debug_RT_Global_HWFault_CH4, FALSE);
}

/******************************************************************************
 * FUNCTION NAME:
 *      apt_msa_flag_UpdateSWTXFault
 *
 * DESCRIPTION:
 *      Update internal SW TX fault
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
static void apt_msa_flag_UpdateSWTXFault(void)
{
	/* update software TxFault */
	if (!CFG_GET_BIT(System_Ctrl_Fault_Global_Dis))
	{
		UINT8 vChannel;

		/* update fault for each channel */
		for (vChannel=CHANNEL_0; vChannel<SYSTEM_CHANNEL_NUM; vChannel++)
		{
			if (CFG_GET_BITO(RT_SW_TXDIS_CH1, vChannel))
			{
				/* disable is active, clear all fault status */
				CFG_SET_BITO(Debug_RT_Status_TECFault_CH1,  vChannel, FALSE);
				CFG_SET_BITO(Debug_RT_Status_BIASFault_CH1, vChannel, FALSE);
				CFG_SET_BITO(Debug_RT_Global_SWFault_CH1,   vChannel, FALSE);

				/* clear BIAS fault count */
				aBiasFaultCount[vChannel] = 0;

				/* clear TEC fault count */
				CFG_SET_BIT(Debug_RT_Status_LDTEMP_LoseLock, FALSE);
				vTECLoseLockCount = 0;
			}
			else
			{
				/* update BIAS fault */
				apt_msa_flag_UpdateBIASFault();

				/* update TEC fault */
				apt_msa_flag_UpdateTECFault();

				/* update the global fault status */
				CFG_SET_BITO(Debug_RT_Global_SWFault_CH1, vChannel,
					((BOOL)CFG_GET_BITO(Debug_RT_Status_BIASFault_CH1, vChannel)
					 || (BOOL)CFG_GET_BITO(Debug_RT_Status_TECFault_CH1, vChannel)));
			}
		}
	}
	else
	{
		/* reset software TxFault status */
		CFG_SET8(Debug_RT_Status_Fault, 0x00);
		CFG_SET_BIT(Debug_RT_Global_SWFault_CH1, FALSE);
		CFG_SET_BIT(Debug_RT_Global_SWFault_CH2, FALSE);
		CFG_SET_BIT(Debug_RT_Global_SWFault_CH3, FALSE);
		CFG_SET_BIT(Debug_RT_Global_SWFault_CH4, FALSE);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_flag_UpdateSaftyBootupState
 *
 * DESCRIPTION:
 *		Update safty bootup state
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2017.06.02		  Melinda.Lu		 Create/Update
 *****************************************************************************/
static void apt_msa_flag_UpdateSaftyBootupState(void)
{
	if ((!CFG_GET_BIT(System_Ctrl_SaftyBootup_Dis))
		   && (CFG_GET_BIT(RT_Data_Ready_State) == 0))
	{
		/* Force skip the first time */
		if (((SINT16)CFG_GET16(RT_TEMP) <= (SINT16)CFG_GET16(System_TEMP_Max))
			&& ((SINT16)CFG_GET16(RT_TEMP) >= (SINT16)CFG_GET16(System_TEMP_Min)) )
		{
			CFG_SET_BIT(Debug_RT_Status_TEMP_Ready, HIGH);
		}

		if (((UINT16)CFG_GET16(RT_VCC) <= (UINT16)CFG_GET16(System_VCC_Max))
			&& ((UINT16)CFG_GET16(RT_VCC) >= (UINT16)CFG_GET16(System_VCC_Min)) )
		{
			CFG_SET_BIT(Debug_RT_Status_VCC_Ready, HIGH);
		}
	}
}

#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetTXLOL
 *
 * DESCRIPTION:
 *      Get TXLOL flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      TXLOL flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXLOL(IN UINT8 vChannel)
{
	BOOL bTxLOL;

	/* Get TXLOS status */
	switch (vChannel)
	{
		case 0:
			bTxLOL = (BOOL)CFG_GET_BIT(Debug_RT_TXLOL_CH1);
			break;

		case 1:
			bTxLOL = (BOOL)CFG_GET_BIT(Debug_RT_TXLOL_CH2);
			break;

		case 2:
			bTxLOL = (BOOL)CFG_GET_BIT(Debug_RT_TXLOL_CH3);
			break;

		case 3:
			bTxLOL = (BOOL)CFG_GET_BIT(Debug_RT_TXLOL_CH4);
			break;

		default:
			bTxLOL = 0;
			break;
	}

	return bTxLOL;
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetRXLOL
 *
 * DESCRIPTION:
 *      Get Rx LOL flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOL flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetRXLOL(IN UINT8 vChannel)
{
	BOOL bRxLOL;

	/* Get RXLOL status */
	switch (vChannel)
	{
		case 0:
			bRxLOL = (BOOL)CFG_GET_BIT(Debug_RT_RXLOL_CH1);
			break;

		case 1:
			bRxLOL = (BOOL)CFG_GET_BIT(Debug_RT_RXLOL_CH2);
			break;

		case 2:
			bRxLOL = (BOOL)CFG_GET_BIT(Debug_RT_RXLOL_CH3);
			break;

		case 3:
			bRxLOL = (BOOL)CFG_GET_BIT(Debug_RT_RXLOL_CH4);
			break;

		default:
			bRxLOL = 0;
			break;
	}

	return bRxLOL;
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetTXLOS
 *
 * DESCRIPTION:
 *      Get Tx LOS flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Tx LOS flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXLOS(IN UINT8 vChannel)
{
	BOOL bTxLOS;

	/* Get TXLOS status */
	switch (vChannel)
	{
		case 0:
			bTxLOS = (BOOL)CFG_GET_BIT(Debug_RT_TXLOS_CH1);
			break;

		case 1:
			bTxLOS = (BOOL)CFG_GET_BIT(Debug_RT_TXLOS_CH2);
			break;

		case 2:
			bTxLOS = (BOOL)CFG_GET_BIT(Debug_RT_TXLOS_CH3);
			break;

		case 3:
			bTxLOS = (BOOL)CFG_GET_BIT(Debug_RT_TXLOS_CH4);
			break;

		default:
			bTxLOS = 0;
			break;
	}

	return bTxLOS;
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetRXLOS
 *
 * DESCRIPTION:
 *      Get Rx LOS flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOS flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.23        Melinda.Lu         Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetRXLOS(IN UINT8 vChannel)
{
	BOOL bRxLOS;

	/* Get RXLOS status */
	switch (vChannel)
	{
		case 0:
			bRxLOS = (BOOL)CFG_GET_BIT(Debug_RT_RXLOS_CH1);
			break;

		case 1:
			bRxLOS = (BOOL)CFG_GET_BIT(Debug_RT_RXLOS_CH2);
			break;

		case 2:
			bRxLOS = (BOOL)CFG_GET_BIT(Debug_RT_RXLOS_CH3);
			break;

		case 3:
			bRxLOS = (BOOL)CFG_GET_BIT(Debug_RT_RXLOS_CH4);
			break;

		default:
			bRxLOS = 0;
			break;
	}

	return bRxLOS;
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetTXFault
 *
 * DESCRIPTION:
 *      Get Tx fault flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOS flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXFault(IN UINT8 vChannel)
{
	if (CFG_GET_BITO(Debug_RT_Global_SWFault_CH1, vChannel)
		|| CFG_GET_BITO(Debug_RT_Global_HWFault_CH1, vChannel))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetTXFault
 *
 * DESCRIPTION:
 *      Get Tx fault flag.
 *
 * PARAMETERS:
 *      vChannel: Channel ID;
 *
 * RETURN:
 *      Rx LOS flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetTXEQFault(IN UINT8 vChannel)
{
	NO_WARNING(vChannel);

	return FALSE;
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_GetInitComplete
 *
 * DESCRIPTION:
 *      Get init complete flag.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      Init complete flag.
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
BOOL APT_MSA_FLAG_GetInitComplete(void)
{
	BOOL	bFirstRun = TRUE;

	if (bFirstRun)
	{
		if (CFG_GET_BIT(Debug_RT_Status_TEC_Ready))
		{
			bFirstRun = FALSE;

			return TRUE;
		}
	}

	return FALSE;
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA flag adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_PwrDnState(void)
{
	/* Reset software TxFault status */
	CFG_SET8(Debug_RT_Status_Fault, 0x00);
	CFG_SET8(Debug_RT_Global_Fault, 0x00);

	CFG_SET_BIT(Debug_RT_Status_LDTEMP_LoseLock, FALSE);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA flag adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_ReadyState(void)
{
	apt_msa_flag_UpdateTXLOSL();
	apt_msa_flag_UpdateRXLOSL();

	apt_msa_flag_UpdateHWTXFault();
	apt_msa_flag_UpdateSWTXFault();

	apt_msa_flag_UpdateSaftyBootupState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_PwrUpState
 *
 * DESCRIPTION:
 *      Power up state for MSA flag adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_PwrUpState(void)
{
	UINT8 vChannel;

	/* Reset BIAS fault count */
	for (vChannel=0; vChannel<SYSTEM_CHANNEL_NUM; vChannel++)
	{
		aBiasFaultCount[vChannel] = 0;
	}
	vTECLoseLockCount = 0;

	/* reset software TxFault status */
	CFG_SET8(Debug_RT_Status_Fault, 0x00);
	CFG_SET8(Debug_RT_Global_Fault, 0x00);

	/* Force sw tx dis for the first time */
	CFG_SET_BIT(Debug_RT_Status_SWTXDIS_CH1, TRUE);
	CFG_SET_BIT(Debug_RT_Status_SWTXDIS_CH2, TRUE);
	CFG_SET_BIT(Debug_RT_Status_SWTXDIS_CH3, TRUE);
	CFG_SET_BIT(Debug_RT_Status_SWTXDIS_CH4, TRUE);

	CFG_SET_BIT(Debug_RT_Status_LDTEMP_LoseLock, FALSE);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_FLAG_LowPwrState
 *
 * DESCRIPTION:
 *      Low power state for MSA flag adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_FLAG_LowPwrState(void)
{
	apt_msa_flag_UpdateSaftyBootupState();
}

#endif

