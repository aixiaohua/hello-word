/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 adapt_msa_ctrl.h
 *
 * DESCRIPTION:
 *	 MSA ctrl adaption layer
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/
#ifndef __ADAPT_MSA_CTRL_H__
#define __ADAPT_MSA_CTRL_H__

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXOutput
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Output.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bDisable: TRUE - Disable RX output
 *              FALSE - Enable RX output
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXOutput(UINT8 vChannel, BOOL bDisable);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXOutput
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Output.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXOutput(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXSquelch
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Sequelch.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bDisable: TRUE - Disable RX Squelch
 *              FALSE - Enable RX Squelch
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXSquelch(UINT8 vChannel, BOOL bDisable);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXSquelch
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Sequelch.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bDisable: TRUE - Disable TX Squelch
 *              FALSE - Enable TX Squelch
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXSquelch(UINT8 vChannel, BOOL bDisable);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXCDRBypass
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX CDR Bypass.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bEnable: TRUE - Enable Rx By Pass
 *              FALSE -Disable Rx By Pass
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXCDRBypass(UINT8 vChannel, BOOL bEnable);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXCDRBypass
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX CDR Bypass.
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		bEnable: TRUE - Enable TX By Pass
 *              FALSE -Disable TX By Pass
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXCDRBypass(UINT8 vChannel, BOOL bEnable);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXRate
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Rate
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vRate: Rx Rate
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXRate(UINT8 vChannel, UINT8 vRate);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXRate
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX Rate
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vRate: TX Rate
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXRate(UINT8 vChannel, UINT8 vRate);

/******************************************************************************
 * FUNCTION NAME:
 *      ADAPT_MSA_UpdateRXEmphasis
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Emphasis
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vCode: RX Emphasis code
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXEmphasis(UINT8 vChannel, UINT8 vCode);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateRXAmplitude
 *
 * DESCRIPTION:
 *      Update Real-Time Control of RX Amplitude
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vCode: RX Amplitude code
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateRXAmplitude(UINT8 vChannel, UINT8 vCode);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_UpdateTXEQ
 *
 * DESCRIPTION:
 *      Update Real-Time Control of TX EQ
 *
 * PARAMETERS:
 *      vChannel: Channel No.
 *		vCode: TX EQ code
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2014.10.29        Melinda.Lu         Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_UpdateTXEQ(UINT8 vChannel, UINT8 vCode);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA CTRL adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.25		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_ReadyState(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_CTRL_MgmtInit
 *
 * DESCRIPTION:
 *      Management init state for MSA CTRL adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_CTRL_MgmtInit(void);
#endif


