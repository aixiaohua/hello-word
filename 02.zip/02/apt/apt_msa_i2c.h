/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 adapt_msa_i2c.h
 *
 * DESCRIPTION:
 *	 MSA I2C adaption layer
 *
 * HISTORY:
 *	 2018.8.20		 Harry.Huang		 Create/Update
*****************************************************************************/
#ifndef __ADAPT_MSA_I2C_H__
#define __ADAPT_MSA_I2C_H__

#if DRV_I2CS_SUPPORT

#define I2C_TOTAL_ADDRESS				1


#define APT_I2C_STATE_RESTART 	 0x1
#define APT_I2C_STATE_MREAD 		 (0x1   << 1 )
#define APT_I2C_STATE_MWRITE 		 (0x1   << 2 )
#define APT_I2C_STATE_STOP 			 (0x1   << 3 )


/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_I2C_SetSlaveAddr
 *
 * DESCRIPTION:
 *      set I2C Slave addr.
 *
 * PARAMETERS:
 *      vIndex:     slave I2C Index
 *		  vI2CAddr:  slave I2C addr
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.11.14        Hayden.Ai         Create/Update
 *****************************************************************************/
void APT_MSA_I2C_SetSlaveAddr(UINT8 vIndex, UINT8 vI2CAddr);

#endif

/******************************************************************************
 * FUNCTION NAME:
 *      APT_I2C_Init
 *
 * DESCRIPTION:
 *      Reset I2C Slave State Machine.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.12.11        Luke.Yu         Create/Update
 *****************************************************************************/
void APT_I2C_Init(void);


/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_ClearIntFlag
 *
 * DESCRIPTION:
 *		Clear interrupt flags
 *
 * PARAMETERS:
 *		vOffset: I2C offset
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_ClearIntFlag(UINT8 vOffset);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_ReadByte
 *
 * DESCRIPTION:
 *		Read byte
 *
 * PARAMETERS:
 *		vOffset: I2C offset
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT8 APT_MSA_I2C_ReadByte(UINT8 vOffset);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_ReadFlush
 *
 * DESCRIPTION:
 *		Read Flush actions for I2C Read stop handler
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_ReadFlush(void);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_WriteFlush
 *
 * DESCRIPTION:
 *		Write Flush actions for I2C Read stop handler
 *
 * PARAMETERS:
 *      vOffset : write offset;
 *      vDataLen: write length;
 *      pDataBuf: data buffer;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *      Note: The API can only support 128-Byte Roll-Over with 128 bytes length.
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_WriteFlush
(
	IN UINT8	vOffset,
	IN UINT8	vDataLen,
	IN UINT8	*pDataBuf
);


/******************************************************************************
 * FUNCTION NAME:
 *      APT_I2C_Init
 *
 * DESCRIPTION:
 *      Reset I2C Slave State Machine.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.12.11        Luke.Yu         Create/Update
 *****************************************************************************/
void APT_MSA_I2C_Init(void);


/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_MgmtInit
 *
 * DESCRIPTION:
 *		MSA I2C intialization
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_MgmtInit(void);


void APT_MSA_I2C_TxFIFORefresh(IN UINT8 data1, IN UINT8 data2);

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_MgmtInit
 *
 * DESCRIPTION:
 *		MSA I2C intialization
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_GetDrvStatus(OUT UINT16* pI2CStatus);
void APT_MSA_I2C_GetDrvAddr(OUT UINT8* pI2CAddr);

void APT_MSA_I2C_UpdateSecurity(void);

void APT_MSA_I2C_SetAck(IN BOOL vEnable);
void APT_MSA_I2C_SetEn(IN BOOL vEnable);

UINT8 APT_MSA_I2C_RxByte(void);


#endif

