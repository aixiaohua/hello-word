/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt_msa_ddm.c
 *
 * DESCRIPTION:
 *	 MSA DDM adaption layer
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "alg.h"
#include "app_adj.h"

#define RECORD_ADC_VALUE(_o, _v)									\
	do {															\
		if (!CFG_GET_BIT(Debug_System_Ctrl_ADC_ADJ_En)) 			\
		{															\
			CFG_SET16(_o, (UINT16)(_v));							\
		}															\
		else														\
		{															\
			(_v) = (SINT16)CFG_GET16(_o);							\
		}															\
	} while (0)


#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_ddm_GetLDTemp
 *
 * DESCRIPTION:
 *		Get Current Laser Temperature value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current Laser Temperature value, in unit of 1/256 degree Celsius,
 *		 to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
static UINT16 apt_msa_ddm_GetLDTemp(void)
{
    SINT16     vAdcData;

	/* Get original ADC value */
    vAdcData = DRV_ADC_Get(ADC(ADC_LDTEMP_Coarse));

    /* Record Real-Time ADC value */
    RECORD_ADC_VALUE(Debug_RT_LDTEMP_ADC_Value, vAdcData);

    /* Calibrate */
	return ALG_CALIBRATE_CalculateByLUT(CFG_PAGE(LUT_LDTEMP_Calibrate), vAdcData, TRUE);
}

/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_ddm_GetChipTemp
 *
 * DESCRIPTION:
 *		Get Current Chip Temperature value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current Laser Temperature value, in unit of 1/256 degree Celsius,
 *		 to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
static UINT16 apt_msa_ddm_GetChipTemp(void)
{
    SINT16     vAdcData;

	/* Get original ADC value */
    vAdcData = DRV_ADC_Get(ADC(ADC_ChipTEMP));

    /* Record Real-Time ADC value */
    RECORD_ADC_VALUE(Debug_RT_TEMP_ADC_Value, vAdcData);

    /* Calibrate */
	return ALG_CALIBRATE_CalculateByLUT(CFG_PAGE(LUT_ChipTEMP_Calibrate), vAdcData, TRUE);
}

/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_ddm_CalcLDTempLUTIndex
 *
 * DESCRIPTION:
 *		Calculate LD Temperature LUT Index.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
static void apt_msa_ddm_CalcLDTempLUTIndex(void)
{
    UINT8   vLUTIndex;
    SINT32  vCurrentTemp;

    vCurrentTemp = (SINT16)CFG_GET16(Debug_RT_LDTEMP);

    if (vCurrentTemp < LUT_TEMP_LOW_LIMIT)
    {
        vCurrentTemp = LUT_TEMP_LOW_LIMIT;
    }
    else if (vCurrentTemp > LUT_TEMP_HIGH_LIMIT)
    {
        vCurrentTemp = LUT_TEMP_HIGH_LIMIT;
    }

    vLUTIndex = (UINT8)((vCurrentTemp - LUT_TEMP_LOW_LIMIT) / LUT_TEMP_STEP);

    CFG_SET8(Debug_RT_LDTEMP_LUTIndex, vLUTIndex);
}

/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_ddm_CalcChipTempLUTIndex
 *
 * DESCRIPTION:
 *		Calculate Chip Temperature LUT Index.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
static void apt_msa_ddm_CalcChipTempLUTIndex(void)
{
    UINT8   vLUTIndex;
    SINT32  vCurrentTemp;

    vCurrentTemp = (SINT16)CFG_GET16(Debug_RT_ChipTEMP);

    if (vCurrentTemp < LUT_TEMP_LOW_LIMIT)
    {
        vCurrentTemp = LUT_TEMP_LOW_LIMIT;
    }
    else if (vCurrentTemp > LUT_TEMP_HIGH_LIMIT)
    {
        vCurrentTemp = LUT_TEMP_HIGH_LIMIT;
    }

    vLUTIndex = (UINT8)((vCurrentTemp - LUT_TEMP_LOW_LIMIT) / LUT_TEMP_STEP);

    CFG_SET8(Debug_RT_ChipTEMP_LUTIndex, vLUTIndex);
}

#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetTemp
 *
 * DESCRIPTION:
 *		Get Current Case Temperature value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current Case Temperature value, in unit of 1/256 degree Celsius,
 *		 to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetTemp(void)
{
	SINT16	   vAdcData;

	/* Get original ADC value */
	vAdcData = CFG_GET16(Debug_RT_ChipTEMP);

	/* Calibrate */
	return ALG_CALIBRATE_CalculateByLUT(CFG_PAGE(LUT_CaseTEMP_Calibrate), vAdcData, TRUE);
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetVCC
 *
 * DESCRIPTION:
 *		Get VCC value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current Vcc value, in unit of 100uV, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetVCC(void)
{
	SINT16	vAdcData;
	SINT32	vSlope, vOffset;

	/* Get original ADC value */
	vAdcData = DRV_ADC_Get(ADC(ADC_AVDD));

	/* Record Real-Time ADC value */
	RECORD_ADC_VALUE(Debug_RT_VCC_ADC_Value, vAdcData);

	vSlope = (SINT32)CFG_GET32(Internal_VCC_Slope);
	vOffset = (SINT32)CFG_GET32(Internal_VCC_Offset);

	/* Calibrate */
	return ALG_CALIBRATE_Calculate(vAdcData, vSlope, vOffset, FALSE);
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetTXBias
 *
 * DESCRIPTION:
 *		Get Tx Bias value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current channel Tx Bias value, in unit of 2uA, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetTXBias(IN UINT8 vChannel)
{
	SINT16	vAdcData;
	SINT32	vSlope, vOffset;
	UINT16	vTxBias;

	/* Get original ADC value */
	vAdcData = (SINT16)CFG_GETO16(Debug_ADJ_BIASSet_Value_CH1, vChannel*I2C_LEN(Debug_ADJ_BIASSet_Value_CH1));

	vSlope = (SINT32)CFG_GET32(Internal_TXBIAS_Slope);
	vOffset = (SINT32)CFG_GET32(Internal_TXBIAS_Offset);

	/* Calibrate */
	vTxBias = ALG_CALIBRATE_Calculate(vAdcData, vSlope, vOffset, FALSE);
	if (CFG_GET_BITO(Debug_RT_Status_SWTXDIS_CH1, vChannel))
	{
		/* if this channel is disabled, no Tx Bias */
		vTxBias = 0;
	}

	return vTxBias;
}

/******************************************************************************
 * FUNCTION NAME:
 *		ADAPT_MSA_DDM_GetTxPower
 *
 * DESCRIPTION:
 *		Get Tx Power value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current channel TXPWR value, in unit of 0.1uW, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.9		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetTXPWR(IN UINT8 vChannel)
{
	SINT16		vAdcData;
	CFG_PAGE_T	vPage;
	UINT16		vTxPower;

	/* get original ADC value */
	switch (vChannel)
	{
		case 0 :
			vAdcData = DRV_ADC_Get(ADC(ADC_TXPWR_CH0));
			vPage	 = CFG_PAGE(LUT_TXPWR_Calibrate_CH1);
			RECORD_ADC_VALUE(Debug_RT_TXPWR_ADC_Value_CH1, vAdcData);
			break;
		case 1 :
			vAdcData = DRV_ADC_Get(ADC(ADC_TXPWR_CH1));
			vPage	 = CFG_PAGE(LUT_TXPWR_Calibrate_CH2);
			RECORD_ADC_VALUE(Debug_RT_TXPWR_ADC_Value_CH2, vAdcData);
			break;
		case 2 :
			vAdcData = DRV_ADC_Get(ADC(ADC_TXPWR_CH2));
			vPage	 = CFG_PAGE(LUT_TXPWR_Calibrate_CH3);
			RECORD_ADC_VALUE(Debug_RT_TXPWR_ADC_Value_CH3, vAdcData);
			break;
		case 3 :
			vAdcData = DRV_ADC_Get(ADC(ADC_TXPWR_CH3));
			vPage	 = CFG_PAGE(LUT_TXPWR_Calibrate_CH4);
			RECORD_ADC_VALUE(Debug_RT_TXPWR_ADC_Value_CH4, vAdcData);
			break;
		default:
			vAdcData = 0x0000;
			vPage	 = 0;
			break;
	}

	vTxPower = ALG_CALIBRATE_CalculateByPWRLUT(vPage, vAdcData);
	if (CFG_GET_BITO(Debug_RT_Status_SWTXDIS_CH1, vChannel)
		|| (vTxPower < CFG_GET16(TXPWR_DDMI_Threshold)))
	{
		/* if this channel is disabled, no TxPower */
		vTxPower = CFG_GET16(TXPWR_DDMI_Value_Min);
	}


	return vTxPower;
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_GetRXPower
 *
 * DESCRIPTION:
 *		Get Rx Power value.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		Current channel RXPWR value, in unit of 0.1uW, to follow SFF-8636.
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.10		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT16 APT_MSA_DDM_GetRXPower(IN UINT8 vChannel)
{
	static __code CFG_PAGE_T aRXPWRCalibrateLUTPage[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_RXPWR_Calibrate_CH1),
		CFG_PAGE(LUT_RXPWR_Calibrate_CH2),
		CFG_PAGE(LUT_RXPWR_Calibrate_CH3),
		CFG_PAGE(LUT_RXPWR_Calibrate_CH4),
	};

	static __code CFG_PAGE_T aRXPWRCalibrateLUTPage_PT[SYSTEM_CHANNEL_NUM] =
	{
		CFG_PAGE(LUT_RXPWR_Calibrate_PT_CH1),
		CFG_PAGE(LUT_RXPWR_Calibrate_PT_CH2),
		CFG_PAGE(LUT_RXPWR_Calibrate_PT_CH3),
		CFG_PAGE(LUT_RXPWR_Calibrate_PT_CH4),
	};

    SINT16     vAdcData;
    UINT16     vWeighted;
    CFG_PAGE_T vPage;
	UINT16     vRxPower;

    /* get the weighted value, if value is 0, set to 32, avoid division 0 */
    vWeighted = CFG_GET16(RXPower_Weighted_Value);
    if (vWeighted == 0)
    {
        vWeighted = 32;
    }

    /* get original ADC value */
    switch (vChannel)
    {
        case 0 :
            vAdcData = DRV_ADC_Get(ADC(ADC_RXPWR_CH0));
            vAdcData = (UINT16)((UINT32)CFG_GET16(Debug_RT_RXPWR_ADC_Value_CH1)
                              * (vWeighted - 1)
                              / vWeighted
                              + (vAdcData / vWeighted));
			RECORD_ADC_VALUE(Debug_RT_RXPWR_ADC_Value_CH1, vAdcData);
            break;
        case 1 :
            vAdcData = DRV_ADC_Get(ADC(ADC_RXPWR_CH1));
            vAdcData = (UINT16)((UINT32)CFG_GET16(Debug_RT_RXPWR_ADC_Value_CH2)
                              * (vWeighted - 1)
                              / vWeighted
                              + (vAdcData / vWeighted));
			RECORD_ADC_VALUE(Debug_RT_RXPWR_ADC_Value_CH2, vAdcData);
            break;
        case 2 :
            vAdcData = DRV_ADC_Get(ADC(ADC_RXPWR_CH2));
            vAdcData = (UINT16)((UINT32)CFG_GET16(Debug_RT_RXPWR_ADC_Value_CH3)
                              * (vWeighted - 1)
                              / vWeighted
                              + (vAdcData / vWeighted));
			RECORD_ADC_VALUE(Debug_RT_RXPWR_ADC_Value_CH3, vAdcData);
            break;
        case 3 :
            vAdcData = DRV_ADC_Get(ADC(ADC_RXPWR_CH3));
            vAdcData = (UINT16)((UINT32)CFG_GET16(Debug_RT_RXPWR_ADC_Value_CH4)
                              * (vWeighted - 1)
                              / vWeighted
                              + (vAdcData / vWeighted));
			RECORD_ADC_VALUE(Debug_RT_RXPWR_ADC_Value_CH4, vAdcData);
            break;
        default:
            vAdcData = 0x0000;
            vPage    = 0;
            break;
    }

#if APP_APDPROTECTED_SUPPORT
	if (CFG_GET_BITO(Debug_RT_APD_Protected_CH1, vChannel))
	{
		vPage = aRXPWRCalibrateLUTPage_PT[vChannel];
	}
	else
#endif
	{
		vPage = aRXPWRCalibrateLUTPage[vChannel];
	}

	vRxPower = ALG_CALIBRATE_CalculateByPWRLUT(vPage, vAdcData);
	if (vRxPower < CFG_GET16(RXPWR_DDMI_Threshold))
	{
		vRxPower = CFG_GET16(RXPWR_DDMI_Value_Min);
	}

	return vRxPower;
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_DDM_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for MSA DDM adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_DDM_PwrDnState(void)
{
	UINT8  vChannel;

	/* Clear TX Bias, TX Power, RX Power RAW values */
	for (vChannel = CHANNEL_0; vChannel < SYSTEM_CHANNEL_NUM; vChannel++)
	{
		CFG_SETO16(Debug_RT_TXBIAS_ADC_Value_CH1, vChannel * I2C_LEN(Debug_RT_TXBIAS_ADC_Value_CH1), 0x00);
		CFG_SETO16(Debug_RT_TXPWR_ADC_Value_CH1, vChannel * I2C_LEN(Debug_RT_TXPWR_ADC_Value_CH1), 0x00);
		CFG_SETO16(Debug_RT_RXPWR_ADC_Value_CH1, vChannel * I2C_LEN(Debug_RT_RXPWR_ADC_Value_CH1), 0x00);
	}

	/* Reset adaptive CTLE status */
	CFG_SET8(CDR_RT_Status, 0x00);
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_DDM_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for MSA DDm adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_DDM_ReadyState(void)
{
    /* Update current chip temperature value */
	CFG_SET16(Debug_RT_ChipTEMP, apt_msa_ddm_GetChipTemp());

	/* Update chip temperature LUT Index */
	apt_msa_ddm_CalcChipTempLUTIndex();

    /* Update current laser temperature value */
	CFG_SET16(Debug_RT_LDTEMP, apt_msa_ddm_GetLDTemp());

	/* Update laser temperature LUT Index */
	apt_msa_ddm_CalcLDTempLUTIndex();
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_DDM_LowPwrState
 *
 * DESCRIPTION:
 *		Low Power state for MSA DDM adaption layer.
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.27		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_DDM_LowPwrState(void)
{
    /* Update current chip temperature value */
	CFG_SET16(Debug_RT_ChipTEMP, apt_msa_ddm_GetChipTemp());

	/* Update chip temperature LUT Index */
	apt_msa_ddm_CalcChipTempLUTIndex();
}
#endif

