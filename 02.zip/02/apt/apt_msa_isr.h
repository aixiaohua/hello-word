/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 adapt_msa_isr.h
 *
 * DESCRIPTION:
 *	 MSA ISR adaption layer
 *
 * HISTORY:
 *	 2018.7.11		 Harry.Huang		 Create/Update
*****************************************************************************/
#ifndef __ADAPT_MSA_ISR_H__
#define __ADAPT_MSA_ISR_H__

typedef enum
{
	APT_DRV_LPMODE = 0x0,
	APT_DRV_RESETL,
	APT_DRV_MODSEL,
	APT_DRV_SWI	
}ISR_DRV_TYPE_T;

typedef enum
{
	APT_INT_EN = 0x0,
	APT_INT_DIS,
	APT_INT_CLR		
}ISR_INT_OPER_T;


/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_ISR_SetLPMode
 *
 * DESCRIPTION:
 *		Enter LPMode
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_ISR_SetLPMode(void);

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_ISR_MgmtInit
 *
 * DESCRIPTION:
 *      Management init state for MSA ISR adaption layer
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_ISR_MgmtInit(void);

BOOL APT_MSA_ISR_GetIOData(ISR_DRV_TYPE_T vDrvType);
void APT_MSA_ISR_SetDrvIntL(IN BOOL bHasInterrupt);
void APT_MSA_ISR_SetSWIInterrupt(void);
BOOL APT_MSA_ISR_SetInterrupt(ISR_INT_OPER_T vOper, ISR_DRV_TYPE_T vDrvType);
void APT_MSA_ISR_SetTimer(BOOL vEn, ISR_DRV_TYPE_T vDrvType);
void APT_MSA_ISR_SetState(BOOL vEn, ISR_DRV_TYPE_T vDrvType);

#endif

