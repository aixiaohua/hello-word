/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt.c
 *
 * DESCRIPTION:
 *	 adaption layer function
 *
 * HISTORY:
 *	 2018.7.9		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "apt_msa_ddm.h"
#include "apt_msa_flag.h"
#include "apt_msa_ctrl.h"
#include "apt_msa_isr.h"
#include "apt_msa_i2c.h"


/******************************************************************************
 * FUNCTION NAME:
 *      APT_PwrDnState
 *
 * DESCRIPTION:
 *      Power down state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_PwrDnState(void)
{
	APT_MSA_DDM_PwrDnState();
	APT_MSA_FLAG_PwrDnState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_ReadyState
 *
 * DESCRIPTION:
 *      Ready state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_ReadyState(void)
{
	APT_MSA_DDM_ReadyState();
	APT_MSA_FLAG_ReadyState();
	APT_MSA_CTRL_ReadyState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_PwrUpState
 *
 * DESCRIPTION:
 *      Pwrup state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_PwrUpState(void)
{
	APT_MSA_FLAG_PwrUpState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_LowPwrState
 *
 * DESCRIPTION:
 *      LowPwr state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_LowPwrState(void)
{
	APT_MSA_DDM_LowPwrState();
	APT_MSA_FLAG_LowPwrState();
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_MgmtInit
 *
 * DESCRIPTION:
 *      MgmtInit state for APT
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MgmtInit(void)
{
	APT_MSA_I2C_MgmtInit();
	APT_MSA_CTRL_MgmtInit();
	APT_MSA_ISR_MgmtInit();
}

