/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt_msa_i2c.c
 *
 * DESCRIPTION:
 *	 MSA I2C adaption layer
 *
 * HISTORY:
 *	 2018.8.20		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "apt_msa_i2c.h"

/* Password Change:
 *	Function Description:
 *	  To provide an interface for user to change the password by himself.
 *	Note:
 *	  1. The Password Change need an I2C memory pre-defined in MemoryMap,
 *		  while is named "New_PWD_Entry", occupy 4 Bytes,
 *		  to support user input new password.
 *	  2. The password change will always change the current Security Level
 *		  password!!!
 *	  3. If password changed, the current Security Level will not be updated
 *		  immediately; thus, user have the chance to regret or re-change
 *		  his password, without input the new password.
 *	  4. After password changed, user should re-input his new password,
 *		  to make sure everything works OK.
 *	  5. Only support User EEPROM change permanently, and will
 *		  be saved into flash immediately. Change other Security Level password
 *		  is meaningless, because it will only be held into RAM, and will lost
 *		  immediately after power off.
 */

static UINT8		vPWDChangeFlag = 0;
static BOOL			bIntFlagIsRead;
static CFG_PAGE_T	vSelectedPage;
BOOL     			bDataReadyIsRead;

static UINT8 aSlaveAddr[I2C_TOTAL_ADDRESS];

#define SET_PWDCHANGE_FLAG(vOffset)		do {vPWDChangeFlag |= (0x1<<(vOffset));} while (0)
#define GET_PWDCHANGE_FLAG()			(vPWDChangeFlag)
#define CLR_PWDCHANGE_FLAG()			do {vPWDChangeFlag = 0;} while (0)
#define Is_PWD_Changed()				(vPWDChangeFlag == 0x0F)	/* both 4 bytes are changed */

#define MSA_Vender_Page_Start			(4)
#define MSA_INTFLAG_START				(0x02)	/* RT_Status */
#define MSA_INTFLAG_END					(0x0E)	/* Alarm_Warning_Flag_9 */
#define MSA_INTFLAG_LEN					((MSA_INTFLAG_END - MSA_INTFLAG_START) + 1)
#define IsVenderReservedPage(vPage)		((vPage) >= MSA_Vender_Page_Start)

#if 1
static struct
{
	UINT16		vPageNo;
	CFG_PAGE_T	vPageId;
} __code aI2CPageMap[] =
{
#define DIRECT	0xFFFE
#define DECLARE_I2C_PAGE(i2c_addr, page_no, physical_page)   {page_no,  CFG_PAGE_ ## i2c_addr ## _ ## page_no},

	#include "def_i2c_page.h"

#undef DIRECT
#undef DECLARE_I2C_PAGE
};

/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_I2C_ConvertPage
 * DESCRIPTION:
 *		Convert Page_Select to internal page ID
 * PARAMETERS:
 *		vPage: Page select at A2.7F
 * RETURN:
 *		N/A
 * NOTES:
 *		N/A
 * HISTORY:
 *		2016.3.11		 Melinda Lu		Create/Update
 *****************************************************************************/
static CFG_PAGE_T apt_msa_I2C_ConvertPage(IN UINT8 vPage)
{
	CFG_PAGE_T vPageSelected;
	UINT8      vLoop;

	for (vLoop = 0; vLoop<COUNT_OF(aI2CPageMap); vLoop++)
	{
		if (vPage == aI2CPageMap[vLoop].vPageNo)
		{
			vPageSelected = aI2CPageMap[vLoop].vPageId;
			break;
		}
	}

	if (vLoop >= COUNT_OF(aI2CPageMap))
	{
		vPageSelected = CFG_PAGE_INVALID_ID;
	}

	return vPageSelected;
}

/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_I2C_FlushPage
 *
 * DESCRIPTION:
 *		Flush Page.
 *
 * PARAMETERS:
 *		vPage	  : I2C selected page;
 *		vOffset   : I2C start offset to flush;
 *		vLen	  : I2C flush data length;
 *		pDataBuf  : I2C flush data buffer;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
static void apt_msa_I2C_FlushPage
(
	IN CFG_PAGE_T	vPageId,
	IN UINT8		vOffset,
	IN UINT8		vLen,
	IN const UINT8	*pDataBuf
)
{
	UINT8 vLoop;
	const UINT8 *pDataSrc;
	BOOL bWriteProtected;

	pDataSrc = pDataBuf;
	bWriteProtected = TRUE;

	switch (vPageId)
	{
		case CFG_PAGE_0xA0_DIRECT:
			/* A0.00-7F */
			for (vLoop = vOffset;
				 vLoop < vOffset+vLen;
				 vLoop++, pDataSrc++)
			{
				UINT8	vData = *pDataSrc;

				if (vLoop >= CFG_OFFSET(RT_Status) && vLoop <= CFG_OFFSET_END(Reserved_A0_52))
				{
					/* read only, volatile */
				}
				else if ((vLoop >= CFG_OFFSET(RT_Ctrl_1) && vLoop <= CFG_OFFSET_END(Reserved_A0_6B))
						 || (vLoop >= CFG_OFFSET(Reserved_A0_6F) && vLoop <= CFG_OFFSET_END(Reserved_A0_6F))
						 || (vLoop >= CFG_OFFSET(Reserved_A0_73) && vLoop <= CFG_OFFSET_END(Reserved_A0_73)))
				{
					/* write without password, volatile */
					aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vLoop] = vData;
				}
				else if (vLoop >= CFG_OFFSET(PWD_Change_Entry) && vLoop <= CFG_OFFSET_END(PWD_Change_Entry))
				{
					/* password change, write without password, volatile */
					aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vLoop] = vData;

					/* set password change flag */
					SET_PWDCHANGE_FLAG(vLoop - CFG_OFFSET(PWD_Change_Entry));
				}
				else if (vLoop >= CFG_OFFSET(PWD_Entry) && vLoop <= CFG_OFFSET_END(PWD_Entry))
				{
					/* password input, write without password, volatile */
					aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vLoop] = vData;
				}
				else if (vLoop == CFG_OFFSET(Page_Select))
				{
					/* page select,write without password, volatile */

					/* Implement SFF-8636 rev 2.5:
					 * Pages 04-7Fh are reserved for future use.
					 * The Page Select byte shall revert to 0 and read/warite operations shall be to Upper Page 00h.
					 * Pages 80-FFh are reserved for vendor specific funtions.
					 *
					 * To simplify the design, if factory password is not input,
					 * revert Page Select byte to 0 when page 04-FFh is selected,
					 */
					if ((CFG_Security_GetLevel() < SECURITY_LEVEL_FACTORY)
						&& IsVenderReservedPage(vData))
					{
						vData = 0x00;
					}

					aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vLoop] = vData;
					vSelectedPage = apt_msa_I2C_ConvertPage(vData);
				}
				else
				{
					/* writable with OEM and Factory password, no-volatile */
					if (CFG_Security_GetLevel() >= SECURITY_LEVEL_OEM)
					{
						aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vLoop] = vData;
						bWriteProtected = FALSE;
					}
				}
			}
			break;

		case CFG_PAGE_0xA0_0x03:
			/* A0[03].80-FF */
			for (vLoop = vOffset;
				 vLoop < vOffset+vLen;
				 vLoop++, pDataSrc++)
			{
				UINT8	vData = *pDataSrc;

				if (vLoop >= CFG_OFFSET(Reserved_A0_03_E2))
				{
					/* write without password, volatile */
					aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vLoop] = vData;
				}
				else
				{
					/* writable with OEM and Factory password, no-volatile */
					if (CFG_Security_GetLevel() >= SECURITY_LEVEL_OEM)
					{
						aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(vPageId)][vLoop] = vData;
						bWriteProtected = FALSE;
					}
				}
			}
			break;

		case CFG_PAGE_0xA0_0x00:
			/* A0[00].80-FF */
			if (CFG_Security_GetLevel() >= SECURITY_LEVEL_OEM)
			{
				/* writable with OEM password */
				bWriteProtected = FALSE;
			}
			break;

		case CFG_PAGE_0xA0_0x01:
			/* A0[01].80-FF */
			if (CFG_Security_GetLevel() >= SECURITY_LEVEL_OEM)
			{
				/* writable with OEM password */
				bWriteProtected = FALSE;
			}
			break;

		case CFG_PAGE_0xA0_0x02:
			/* A0[02].80-FF, User EEPROM */
			if (CFG_Security_GetLevel() >= SECURITY_LEVEL_USER_RW)
			{
				/* writable with USER_RW, OEM and Factory password */
				bWriteProtected = FALSE;
			}
			break;

		case CFG_PAGE_0xA0_0x89:
			/* forbidden to write */
			break;

		case CFG_PAGE_INVALID_ID:
			/* forbidden to write */
			break;

		default:
			/* all other extended pages need Factory Security Level,
			 * to write.
			 */
			if (CFG_Security_GetLevel() >= SECURITY_LEVEL_FACTORY)
			{
				/* writable with Factory password */
				bWriteProtected = FALSE;
			}
			break;
	}

	if (!bWriteProtected)
	{
		CFG_SetBuf(vPageId, vOffset, vLen, pDataBuf);
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		apt_msa_I2C_ChangePassword
 *
 * DESCRIPTION:
 *		Flush Page.
 *
 * PARAMETERS:
 *		vPage	  : I2C selected page;
 *		vOffset   : I2C start offset to flush;
 *		vLen	  : I2C flush data length;
 *		pDataBuf  : I2C flush data buffer;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
static void apt_msa_I2C_ChangePassword(void)
{
    /* password change */
    if (Is_PWD_Changed())
    {
        /* the new user password received,
         * change USER_RW Security Level password.
         */
        CFG_Security_SavePasswd(CFG_GET32(PWD_Change_Entry));

        /* reset password change write flag */
        CFG_SET32(PWD_Change_Entry, 0x00000000UL);

		/* clear password change flag */
		CLR_PWDCHANGE_FLAG();
    }
}
#endif

#if 1
/******************************************************************************
 * FUNCTION NAME:
 *      APT_MSA_I2C_SetSlaveAddr
 *
 * DESCRIPTION:
 *      set I2C Slave addr.
 *
 * PARAMETERS:
 *      vIndex:     slave I2C Index
 *		  vI2CAddr:  slave I2C addr
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2018.11.14        Hayden.Ai         Create/Update
 *****************************************************************************/
void APT_MSA_I2C_SetSlaveAddr(UINT8 vIndex, UINT8 vI2CAddr)
{
	if(vIndex >= I2C_TOTAL_ADDRESS)
	{
		DBG_LOG_FATAL("Invalid I2C Index");
		return;
	}

	aSlaveAddr[vIndex]	=	vI2CAddr;
}

/******************************************************************************
 * FUNCTION NAME:
 *      APT_I2C_Init
 *
 * DESCRIPTION:
 *      Reset I2C Slave State Machine.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.12.11        Luke.Yu         Create/Update
 *****************************************************************************/
void APT_MSA_I2C_Init(void)
{
#if (I2C_TOTAL_ADDRESS >= 1)
	/* set all supported I2C Slave Address */
	DRV_I2CS_SetSlaveAddr1(aSlaveAddr[0]);
	DRV_I2CS_SetSlaveAddr2(aSlaveAddr[0]);
	DRV_I2CS_SetSlaveAddr3(aSlaveAddr[0]);
	DRV_I2CS_SetSlaveAddr4(aSlaveAddr[0]);
#endif
}


/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_ClearIntFlag
 *
 * DESCRIPTION:
 *		Clear interrupt flags
 *
 * PARAMETERS:
 *		vOffset: I2C offset
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_ClearIntFlag(UINT8 vOffset)
{
	if ((vOffset >= MSA_INTFLAG_START) && (vOffset <= MSA_INTFLAG_END))
	{
		/* interrupt flag */
		if (vOffset == MSA_INTFLAG_START)
		{
			/* data_not_ready is read,
			 * set a flag to clear the flag used to toggle the falling edge of this bit.
			 */
			bDataReadyIsRead = TRUE;
		}
		else
		{
			aCfgInRamBuf.vPages_U8[GET_RAM_PAGE_ID(CFG_PAGE_0xA0_DIRECT)][vOffset] = 0x00;
		}

		/* interrupt flag is read, set flag to update IntL output */
		bIntFlagIsRead = TRUE;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_ReadByte
 *
 * DESCRIPTION:
 *		Read byte
 *
 * PARAMETERS:
 *		vOffset: I2C offset
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
UINT8 APT_MSA_I2C_ReadByte(UINT8 vOffset)
{
	CFG_PAGE_T vPageId;
	BOOL	   bReadable;

	bReadable = FALSE;

	/* get page id */
	if (vOffset < MSA_PAGE_SIZE)
	{
		vPageId = CFG_PAGE_0xA0_DIRECT;
	}
	else
	{
		vPageId = vSelectedPage;
		vOffset -= MSA_PAGE_SIZE;
	}

	switch (vPageId)
	{
		case CFG_PAGE_0xA0_DIRECT:
			/* no password to be read */
			bReadable = TRUE;

			if (vOffset >= CFG_OFFSET(PWD_Change_Entry) && vOffset <= CFG_OFFSET_END(PWD_Change_Entry))
			{
				/* read PWD_Change_Entry, return 0x00 */
				return 0x00;
			}
			else if (vOffset >= CFG_OFFSET(PWD_Entry) && vOffset <= CFG_OFFSET_END(PWD_Entry))
			{
				/* For security reason,
				 *	the password area cannot be read via I2C.
				 * So, when read, only return the current security level.
				 */
				return (UINT8)(CFG_Security_GetLevel()>>((CFG_OFFSET_END(PWD_Entry)-vOffset)*8));
			}
			break;

		case CFG_PAGE_0xA0_0x00:
		case CFG_PAGE_0xA0_0x01:
		case CFG_PAGE_0xA0_0x03:
			/* no password to be read */
			bReadable = TRUE;
			break;

		case CFG_PAGE_0xA0_0x02:
			if (CFG_Security_GetLevel() >= SECURITY_LEVEL_USER_RO)
			{
				bReadable = TRUE;
			}
			break;

		default:
			/* all other extended pages need Factory Security Level,
			 * to write.
			 */
			if (CFG_Security_GetLevel() >= SECURITY_LEVEL_FACTORY)
			{
				bReadable = TRUE;
			}
			break;
	}

	if (bReadable)
	{
		return CFG_GETV8(vPageId, vOffset);
	}
	else
	{
		return (UINT8)MSA_INVALID_DATA;
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_ReadFlush
 *
 * DESCRIPTION:
 *		Read Flush actions for I2C Read stop handler
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_ReadFlush(void)
{
	if (bIntFlagIsRead)
	{
		bIntFlagIsRead = FALSE;

		/* trigger interrupt to update IntL output */
		DRV_SWI_SetInterrupt(SWI(SWI_IntL));
	}
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_WriteFlush
 *
 * DESCRIPTION:
 *		Write Flush actions for I2C Read stop handler
 *
 * PARAMETERS:
 *		vDataLen: write length;
 *		vOffset : write offset;
 *		pDataBuf: data buffer;
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		Note: The API can only support 128-Byte Roll-Over with 128 bytes length.
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_WriteFlush
(
	IN UINT8	vOffset,
	IN UINT8	vDataLen,
	IN UINT8	*pDataBuf
)
{
	UINT8  *pSeg1Src,	*pSeg2Src;
	UINT8	vSeg1Len,	 vSeg2Len;
	UINT8	vSeg1Offset, vSeg2Offset;

	UINT8  *pFlushSrc;
	UINT8	vFlushLen;
	UINT8	vFlushOffset;

	UINT8		vPageOffset;
	CFG_PAGE_T	vPageId;

	/* get page id */
	if (vOffset < MSA_PAGE_SIZE)
	{
		vPageId = CFG_PAGE_0xA0_DIRECT;
	}
	else
	{
		vPageId = vSelectedPage;
	}

	/* get offset in page */
	vPageOffset = MSA_PAGE_OFFSET(vOffset);

	/* update I2C written data:
	 *
	 * There are 2 cases:
	 *
	 *	1. start address is lower than end address: (only segment 1, no segment 2)
	 *
	 *		  0 					   128
	 *		   -------------------------
	 *		  | 	  |   seg1	 |		|
	 *		   -------------------------
	 *				  ^ 		 ^
	 *				(start)    (end)
	 *
	 *
	 *	2. start address is greater than end address: (segment 1 & 2)
	 *
	 *		  0 					   128
	 *		   -------------------------
	 *		  |  seg2  |		| seg1	|
	 *		   -------------------------
	 *				   ^		^
	 *				 (end)	 (start)
	 *
	 */
	if ((vPageOffset + vDataLen) <= MSA_PAGE_SIZE)
	{
		/* case 1: write without roll-over.
		 * -> write data to flash or RAM directly.
		 */
		pFlushSrc	 = pDataBuf;
		vFlushLen	 = vDataLen;
		vFlushOffset = vPageOffset;
	}
	else
	{
		/* case 2: write with roll-over.
		 * to avoid writing RAM/Flash twice, follow below steps.
		 * -> read the whole page data from RAM/Flash;
		 * -> flush the data to buffer;
		 * -> write data from buffer back to RAM/Flash;
		 */
		UINT8		 aDataBuf[MSA_PAGE_SIZE];

		pSeg1Src	= pDataBuf;
		vSeg1Len	= MSA_PAGE_SIZE - vPageOffset;
		vSeg1Offset = vPageOffset;

		pSeg2Src	= pSeg1Src+vSeg1Len;
		vSeg2Len	= vDataLen-vSeg1Len;
		vSeg2Offset = 0x00;

		/* read the whole page data from RAM/Flash */
		CFG_Memdmp8(vPageId, 0x00, aDataBuf, MSA_PAGE_SIZE);

		/* flush segment1 to buffer */
		(void)memcpy(aDataBuf+vSeg1Offset, pSeg1Src, vSeg1Len);
		/* flush segment2 to buffer */
		(void)memcpy(aDataBuf+vSeg2Offset, pSeg2Src, vSeg2Len);

		pFlushSrc = aDataBuf;
		vFlushLen = MSA_PAGE_SIZE;
		vFlushOffset = 0x00;
	}

	/* flush data back to RAM/Flash */
	apt_msa_I2C_FlushPage(vPageId, vFlushOffset, vFlushLen, pFlushSrc);

	/* password change update */
	apt_msa_I2C_ChangePassword();

	APT_MSA_I2C_UpdateSecurity();
}

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_I2C_Init
 *
 * DESCRIPTION:
 *		MSA I2C intialization
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.20		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_I2C_MgmtInit(void)
{
    /* init SFF8636 fields */
	if (CFG_GET_BIT(System_Ctrl_A0_69_6A_Nonvolatile_Dis))
	{
		/* A0.69-6A are volatile */
		CFG_MEMSET(RT_Status, 0x00, (CFG_OFFSET_END(Reserved_A0_6B) - CFG_OFFSET(RT_Status) + 1));
	}
	else
	{
		/* A0.69-6A are nonvolatile */
		CFG_MEMSET(RT_Status, 0x00, (CFG_OFFSET_END(Mask_Alarm_Warning_Flag_2) - CFG_OFFSET(RT_Status) + 1));
		CFG_SET8(Reserved_A0_6B, 0x00);
	}

	/* Init Reserved field */
	CFG_MEMSET(Reserved_A0_6F, 0x00, (CFG_OFFSET_END(Reserved_A0_6F) - CFG_OFFSET(Reserved_A0_6F) + 1));
	CFG_MEMSET(Reserved_A0_72,	0x00, MSA_PAGE_SIZE - CFG_OFFSET(Reserved_A0_72));
	CFG_MEMSET(Reserved_A0_03_E2, 0x00, MSA_PAGE_SIZE - CFG_OFFSET(Reserved_A0_03_E2));

	/* Default page select is A0[00].80-FF */
	vSelectedPage = CFG_PAGE_0xA0_0x00;

	bDataReadyIsRead = FALSE;
	bIntFlagIsRead = FALSE;
}


/******************************************************************************
 * FUNCTION NAME:
 *      msa_i2c_TxFIFORefresh
 *
 * DESCRIPTION:
 *      Refresh I2C TX FIFO.
 *
 * PARAMETERS:
 *      N/A
 *
 * RETURN:
 *      N/A
 *
 * NOTES:
 *      N/A
 *
 * HISTORY:
 *      2009.12.11        Luke.Yu         Create/Update
 *****************************************************************************/
void APT_MSA_I2C_TxFIFORefresh(IN UINT8 data1, IN UINT8 data2)
{
	/* refresh Tx FIFO */
	DRV_I2CS_Flush_TxFIFO();
	DRV_I2CS_FillTxFIFO(data1);
	DRV_I2CS_FillTxFIFO(data2);
}

void APT_MSA_I2C_UpdateSecurity(void)
{
	UINT32				vPasswd;
	
	vPasswd   = CFG_GET32(PWD_Entry);
	
	switch (vPasswd)
	{
		case PASSWD_REBOOT:   /* reboot  */
			DRV_CPU_Reset();
			break;

#if SECURE_MODE_SUPPORT
		case PASSWD_EnterSecureMode:  /* enter secure mode */
			/* Secure Mode can only be activated at factory level */
			if (CFG_Security_GetLevel() == SECURITY_LEVEL_FACTORY)
			{
				DRV_Flash_EnterSecureMode();
			}
			break;

		case PASSWD_ExitSecureMode:   /* exit secure mode */
			/* Secure Mode can only be de-activated at factory level */
			if (CFG_Security_GetLevel() == SECURITY_LEVEL_FACTORY)
			{
				DRV_Flash_ExitSecureMode();
				/* never reach here */
			}
			break;

		case PASSWD_EnterDownloadMode:	/* enter download mode */
			/* download mode can only be entered at factory level,
			 *	and not Secure Mode.
			 */
			if (CFG_Security_GetLevel() == SECURITY_LEVEL_FACTORY)
			{
				if (!DRV_Flash_IsSecureMode())
				{
					DRV_Flash_EnterDownloadMode();
					/* never reach here */
				}
			}
			break;
			
		default:
			break;
	}
#endif
	
	/* update security level */
	CFG_Security_UpdateLevel(); 		
}


void APT_MSA_I2C_GetDrvStatus(OUT UINT16* pI2CStatus)
{
	UINT16 vState;

	if(NULL == pI2CStatus)
	{
		return;
	}

	*pI2CStatus = 0;
	vState = DRV_I2CS_ReadStatus();

	if(DRV_I2CS_IsReStart(vState))
	{
		*pI2CStatus |= APT_I2C_STATE_RESTART;
	}
		
	if(DRV_I2CS_IsMasterRead(vState))
	{
		*pI2CStatus |= APT_I2C_STATE_MREAD;
	}
	
	if(DRV_I2CS_IsMasterWrite(vState))
	{
		*pI2CStatus |= APT_I2C_STATE_MWRITE;
	}

	if(DRV_I2CS_IsI2cStop(vState))
	{
		*pI2CStatus |= APT_I2C_STATE_STOP;
	}
}

void APT_MSA_I2C_GetDrvAddr(OUT UINT8* pI2CAddr)
{
	UINT16 vState;

	if(NULL == pI2CAddr)
	{
		return;
	}

	*pI2CAddr = 0;
	vState = DRV_I2CS_ReadStatus();
	
	*pI2CAddr = DRV_I2CS_GetMatchAddrID(vState);
}

void APT_MSA_I2C_SetAck(IN BOOL vEnable)
{
	if(TRUE == vEnable)
	{
		DRV_I2CS_EnableACK();
	}
	else
	{
		DRV_I2CS_DisableACK();
	}
}

void APT_MSA_I2C_SetEn(IN BOOL vEnable)
{
	if(TRUE == vEnable)
	{
		DRV_I2CS_Enable();
	}
	else
	{
		DRV_I2CS_Disable();
	}
}

UINT8 APT_MSA_I2C_RxByte(void)
{
	return DRV_I2CS_ReceiveByte();
}


#endif

