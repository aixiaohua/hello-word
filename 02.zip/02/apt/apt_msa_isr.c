/******************************************************************************
 *
 * COPYRIGHT:
 *	 Copyright (c)	2005-2050	Source Photonics Inc.	 All rights reserved.
 *
 *	 This is unpublished proprietary source code of Source Photonics Inc.
 *	 The copyright notice above does not evidence any actual or intended
 *	 publication of such source code.
 *
 * FILE NAME:
 *	 apt_isr_ctrl.c
 *
 * DESCRIPTION:
 *	 MSA ISR adaption layer
 *
 * HISTORY:
 *	 2018.7.26		 Harry.Huang		 Create/Update
*****************************************************************************/

#include "cfg.h"
#include "drv.h"
#include "apt_msa_isr.h"

/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_ISR_SetLPMode
 *
 * DESCRIPTION:
 *		Enter LPMode
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *		N/A
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.8.7		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_ISR_SetLPMode(void)
{
	/* power-off on-board chips, to enter power level 1,
	 * the remaining handling for LPMode will be done
	 * within system state machine.
	 */
	DRV_IO_Write(IO(IO_TXPWREN_OUT), LOW);
	DRV_IO_Write(IO(IO_RXPWREN_OUT), LOW);

	/* power-down TEC circuit */
	DRV_IO_Write(IO(IO_TECEN_OUT), LOW);
	DRV_IO_Write(IO(IO_TECSW1_OUT), HIGH);
	DRV_IO_Write(IO(IO_TECSW2_OUT), HIGH);

#if APP_TEC_SUPPORT && DRV_TIMER_SUPPORT
	/* disable TEC Control Timer */
	DRV_Timer_SetState(TIMER(Timer_TEC), DISABLE);
#endif

	/* disable APD */
	DRV_IO_Write(IO(IO_APDEN_OUT), LOW);

	/* disable LPower_EN */
	DRV_IO_Write(IO(IO_LPowerEN_OUT), LOW);
}


/******************************************************************************
 * FUNCTION NAME:
 *		APT_MSA_ISR_MgmtInit
 *
 * DESCRIPTION:
 *		Management init state for MSA ISR adaption layer
 *
 * PARAMETERS:
 *		N/A
 *
 * RETURN:
 *
 *
 * NOTES:
 *		N/A
 *
 * HISTORY:
 *		2018.7.30		Harry.Huang 		Create/Update
 *****************************************************************************/
void APT_MSA_ISR_MgmtInit(void)
{
	/* Update real-time status of IntL */
	CFG_SET_BIT(RT_IntL_State, DRV_IO_Read(IO(IO_IntL_OUT)));
}

void APT_MSA_ISR_SetDrvIntL(IN BOOL bHasInterrupt)
{
	DRV_IO_Write(IO(IO_IntL_OUT), !bHasInterrupt);
}

void APT_MSA_ISR_SetSWIInterrupt(void)
{
	DRV_SWI_SetInterrupt(SWI(SWI_IntL));
}


BOOL APT_MSA_ISR_GetIOData(ISR_DRV_TYPE_T vDrvType)
{
	BOOL bRet;

	switch (vDrvType)
	{
		case APT_DRV_LPMODE:
			bRet = DRV_IO_Read(IO(IO_LPMode_IN));
			break;
			
		case APT_DRV_RESETL:
			bRet = DRV_IO_Read(IO(IO_ResetL_IN));
			break;
			
		case APT_DRV_MODSEL:
			bRet = DRV_IO_Read(IO(IO_ModSelL_IN));
			break;	

		default:
			return FALSE;
	}

	return bRet;
}

void APT_MSA_ISR_SetState(BOOL vEn, ISR_DRV_TYPE_T vDrvType)
{
	switch (vDrvType)
	{
		case APT_DRV_SWI:
			DRV_SWI_SetState(SWI(SWI_IntL), vEn);
			break;

		default:
			break;
	}
}

void APT_MSA_ISR_SetTimer(BOOL vEn, ISR_DRV_TYPE_T vDrvType)
{
	switch (vDrvType)
	{
		case APT_DRV_MODSEL:
			DRV_Timer_SetState(TIMER(Timer_ModSelL), vEn);
			break;

		default:
			break;
	}
}

BOOL APT_MSA_ISR_SetInterrupt(ISR_INT_OPER_T vOper, ISR_DRV_TYPE_T vDrvType)
{
	SINT16 vIntId;

	switch (vDrvType)
	{
		case APT_DRV_LPMODE:
			vIntId = VECTOR(Vector_LPMode);
			break;
			
		case APT_DRV_RESETL:
			vIntId = VECTOR(Vector_ResetL);
			break;	

		default:
			return FALSE;
	}

	switch (vOper)
	{
		case APT_INT_EN:
			DRV_VECTOR_EnableInterrupt(vIntId);
			break;

		case APT_INT_DIS:
			DRV_VECTOR_DisableInterrupt(vIntId);
			break;		

		case APT_INT_CLR:
			DRV_VECTOR_ClearInterrupt(vIntId);
			break;	

		default:
			return FALSE;
	}

	return TRUE;
}
